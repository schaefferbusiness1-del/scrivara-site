# MLS Assist (Chrome extension) — Stage 1

A consented, transparent AI-scribe assistant that works inside *any* web EMR.
You record/select the visit, MLS drafts the note, you review it, and one click
drops it into the chart field. Nothing is written automatically.

## Load it (developer mode)
1. Open `chrome://extensions`
2. Turn on **Developer mode** (top-right)
3. Click **Load unpacked** and pick this `mls-assist-extension` folder
4. Click the MLS Assist toolbar icon → paste your **MLS API key** → Save
   (get a key from MLS → Settings → API)

## Use it
- A small **🩺 MLS Assist** badge sits at the bottom-right of every page.
- Click it to open the panel (this is the consent gate — it does nothing until opened).
- **Dictate** the visit (or **Use page selection** to grab chart text), then **Generate note**.
- Review the drafted note, click into your EMR's note field, then **Insert into chart**.

## Privacy / safety
- The API key lives only in this browser and is sent **only** to your MLS backend
  (by the background worker) — never to the EMR page.
- Human-in-the-loop: you review every note and click to insert. No auto-writes.
- Transparent: the badge turns green while dictating; the panel logs every action.

## Roadmap (next stages)
- Vision layer for EMRs with messy DOM; auto-detect the note field.
- Hybrid: use the FHIR/SMART API where the EMR supports it.
- Packaged install + per-site enable + richer audit log.
