const $ = id => document.getElementById(id);
chrome.storage.local.get(['mlsKey', 'mlsBackend'], c => {
  if (c.mlsKey) $('key').value = c.mlsKey;
  if (c.mlsBackend) $('backend').value = c.mlsBackend;
});
$('save').addEventListener('click', () => {
  chrome.storage.local.set({
    mlsKey: $('key').value.trim(),
    mlsBackend: ($('backend').value.trim() || 'https://scrivara-backend.onrender.com')
  }, () => { $('ok').textContent = '✓ Saved'; setTimeout(() => $('ok').textContent = '', 1800); });
});
