const $ = id => document.getElementById(id);
chrome.storage.local.get(['mlsKey', 'mlsBackend'], c => {
  if (c.mlsKey) $('key').value = c.mlsKey;
  if (c.mlsBackend) $('backend').value = c.mlsBackend;
});
$('save').addEventListener('click', () => {
  chrome.storage.local.set({
    mlsKey: $('key').value.trim(),
    mlsBackend: ($('backend').value.trim() || 'https://scrivara-backend.onrender.com')
  }, () => { $('ok').textContent = '✓ Saved'; setTimeout(() => $('ok').textContent = '', 1800); });
});

const _ot = document.getElementById('openTab');
if (_ot) _ot.addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const t = tabs[0]; if (!t) return;
    chrome.tabs.sendMessage(t.id, { type: 'mlsOpenPanel' }, () => {
      if (chrome.runtime.lastError) { $('ok').textContent = 'Can\u2019t open here - try a normal web page or your EMR.'; }
      else { $('ok').textContent = '\u2713 Opened on this tab'; setTimeout(() => window.close(), 600); }
    });
  });
});
