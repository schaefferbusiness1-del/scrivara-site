/* MLS Assist — content script.
   Sits dormant as a small badge on every page. Does NOTHING until the doctor
   opens the panel (consent). Then: capture the visit (live dictation or page
   selection) -> MLS generates a note -> the doctor reviews -> one click inserts
   it into the focused EMR field. Nothing is ever written automatically. */
(function () {
  if (window.__mlsAssistLoaded) return; window.__mlsAssistLoaded = true;
  // Bridge: the MLS web app can ping us (to show "Assist installed") and ask us
  // to capture the patient currently open in the doctor's EMR tab.
  window.addEventListener('message', function (e) {
    var d = e.data; if (!d || d.source !== 'mls-app') return;
    if (d.type === 'mlsPing') { window.postMessage({ source: 'mls-ext', type: 'mlsPong' }, '*'); return; }
    if (d.type === 'mlsAppCapture') {
      try {
        chrome.runtime.sendMessage({ type: 'mlsAppCaptureRequest' }, function (resp) {
          window.postMessage({ source: 'mls-ext', type: 'mlsAppCaptureResult', resp: resp || { error: 'no response' } }, '*');
        });
      } catch (err) { window.postMessage({ source: 'mls-ext', type: 'mlsAppCaptureResult', resp: { error: 'extension error' } }, '*'); }
    }
  });

  // --- custom hover tooltips: appear only after the cursor rests ~2s on a button ---
  (function () {
    var DELAY = 2000, tipEl = null, timer = null, currentEl = null;
    function ensure() { if (tipEl) return tipEl; tipEl = document.createElement('div'); tipEl.id = 'mls-tip'; (document.body || document.documentElement).appendChild(tipEl); return tipEl; }
    function show(el) {
      if (!el || !el.getAttribute) return;
      var txt = el.getAttribute('data-tip'); if (!txt) return;
      var t = ensure(); t.textContent = txt; t.style.display = 'block'; t.style.opacity = '0';
      var r = el.getBoundingClientRect(), tw = t.offsetWidth, th = t.offsetHeight;
      var left = Math.min(Math.max(8, r.left + r.width / 2 - tw / 2), window.innerWidth - tw - 8);
      var top = r.top - th - 8; if (top < 8) top = r.bottom + 8;
      t.style.left = left + 'px'; t.style.top = top + 'px'; t.style.opacity = '1';
    }
    function hide() { if (timer) { clearTimeout(timer); timer = null; } if (tipEl) tipEl.style.display = 'none'; }
    document.addEventListener('mouseover', function (e) {
      var el = (e.target && e.target.closest) ? e.target.closest('[data-tip]') : null;
      if (el === currentEl) return;
      currentEl = el; hide();
      if (el) timer = setTimeout(function () { show(el); }, DELAY);
    }, true);
    document.addEventListener('mousedown', hide, true);
    window.addEventListener('scroll', hide, true);
  })();

  // --- remember the last editable field the user focused (the note field) ---
  let lastEditable = null;
  function isEditable(el) {
    if (!el) return false;
    const t = (el.tagName || '').toUpperCase();
    if (t === 'TEXTAREA') return true;
    if (t === 'INPUT') return /^(text|search|email|url|tel|)$/i.test(el.type || '');
    return !!el.isContentEditable;
  }
  document.addEventListener('focusin', e => { if (isEditable(e.target)) lastEditable = e.target; }, true);
  // Smart note-field detection so the doctor doesn't have to click the field first.
  function bestNoteField() {
    if (isEditable(lastEditable)) return lastEditable;
    if (isEditable(document.activeElement)) return document.activeElement;
    const cands = [...document.querySelectorAll('textarea,[contenteditable=""],[contenteditable="true"]')].filter(el => { const r = el.getBoundingClientRect(); return r.width > 120 && r.height > 36 && r.bottom > 0 && r.top < innerHeight; });
    cands.sort((a, b) => { const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect(); return (rb.width * rb.height) - (ra.width * ra.height); });
    return cands[0] || null;
  }

  // --- build UI ---
  const badge = document.createElement('div');
  badge.id = 'mls-assist-badge';
  badge.innerHTML = '<span class="dot"></span>🩺 MLS Assist';
  badge.setAttribute('data-tip', 'Open MLS Assist — dictate, draft, and insert your note');

  const panel = document.createElement('div');
  panel.id = 'mls-assist-panel';
  panel.innerHTML = [
    '<header><b>🩺 MLS Assist</b><span class="x" data-tip="Close MLS Assist">×</span></header>',
    '<div class="body">',
    '  <div class="consent">Runs only when you open this panel. It captures what you dictate or select, drafts a note, and inserts it <b>only when you click</b>. You review everything first.</div>',
    '  <label>Visit transcript / context</label>',
    '  <textarea id="mls-tx" rows="5" placeholder="Press Dictate and talk through the visit, or paste/select text from the chart…"></textarea>',
    '  <div class="row">',
    '    <button class="b b-rec" id="mls-rec" data-tip="Dictate the visit out loud — MLS transcribes as you talk">🎙 Dictate</button>',
    '    <button class="b b-ghost" id="mls-sel" data-tip="Use the text you have highlighted on the chart as the visit context">Use page selection</button>',
    '    <button class="b b-ghost" id="mls-clr" data-tip="Clear the transcript and the drafted note">Clear</button>',
    '  </div>',
    '  <div class="row"><button class="b b-go" id="mls-gen" data-tip="Turn the transcript into a structured clinical note" style="flex:1">✨ Generate note</button></div>',
    '  <label>Drafted note (review before inserting)</label>',
    '  <textarea id="mls-note" rows="7" placeholder="Your generated note appears here for review."></textarea>',
    '  <div class="row">',
    '    <button class="b b-primary" id="mls-ins" data-tip="Copy the drafted note so you can paste it into your EMR - MLS Assist never types into your chart" style="flex:1">📋 Copy note for chart</button>',
    '    <button class="b b-ghost" id="mls-cpy" data-tip="Copy the drafted note to your clipboard">Copy</button>',
    '  </div>',
    '  <div style="border-top:1px dashed #e0e8f2;margin-top:12px;padding-top:10px">',
    '    <label>Pull the whole chart into MLS</label>',
    '    <div class="row"><button class="b b-ghost" id="mls-cap" data-tip="Read this patient and their prior visits into MLS — nothing is written back to the EMR" style="flex:1">📋 Capture whole chart → MLS</button></div>',
    '    <div class="consent" style="margin-top:6px">Reads the patient + their prior visits off this page and saves them into MLS (encrypted). Nothing is written back to the EMR.</div>',
    '  </div>',
    '  <div class="log" id="mls-log"></div>',
    '</div>'
  ].join('');

  document.documentElement.appendChild(badge);
  document.documentElement.appendChild(panel);

  const $ = s => panel.querySelector(s);
  const tx = $('#mls-tx'), noteBox = $('#mls-note'), logBox = $('#mls-log');
  function log(m) { const d = document.createElement('div'); d.textContent = '• ' + m; logBox.prepend(d); }

  badge.addEventListener('click', () => {
    const open = panel.classList.toggle('open');
    if (open) log('Panel opened — capture is active.');
  });
  $('.x').addEventListener('click', () => { panel.classList.remove('open'); stopRec(); });
  chrome.runtime.onMessage.addListener((m, s, send) => { if (m && m.type === 'mlsOpenPanel') { panel.classList.add('open'); log('Opened MLS Assist from the toolbar.'); try { send && send({ ok: true }); } catch (e) {} } return true; });

  // --- live dictation (Web Speech API) ---
  let rec = null, recing = false;
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recBtn = $('#mls-rec');
  if (!SR) { recBtn.disabled = true; recBtn.textContent = '🎙 (no speech support)'; }
  function startRec() {
    if (!SR) return;
    rec = new SR(); rec.lang = 'en-US'; rec.continuous = true; rec.interimResults = true;
    let base = tx.value;
    rec.onresult = (e) => {
      let finalTxt = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) finalTxt += e.results[i][0].transcript + ' ';
      }
      if (finalTxt) { base += (base && !/\s$/.test(base) ? ' ' : '') + finalTxt.trim() + ' '; tx.value = base; }
    };
    rec.onerror = (e) => log('Dictation: ' + (e.error || 'error'));
    rec.onend = () => { if (recing) { try { rec.start(); } catch (e) {} } };
    try { rec.start(); recing = true; recBtn.textContent = '⏹ Stop'; badge.classList.add('active'); log('Dictation started.'); } catch (e) { log('Could not start mic.'); }
  }
  function stopRec() {
    recing = false; if (rec) { try { rec.stop(); } catch (e) {} } recBtn.textContent = '🎙 Dictate'; badge.classList.remove('active');
  }
  recBtn.addEventListener('click', () => { recing ? (stopRec(), log('Dictation stopped.')) : startRec(); });

  // --- use page selection ---
  $('#mls-sel').addEventListener('click', () => {
    const sel = (window.getSelection ? window.getSelection().toString() : '').trim();
    if (!sel) { log('No text selected on the page.'); return; }
    tx.value = (tx.value ? tx.value + '\n\n' : '') + sel; log('Added ' + sel.length + ' chars from selection.');
  });
  $('#mls-clr').addEventListener('click', () => { tx.value = ''; noteBox.value = ''; });

  // --- generate (key + network handled by the background worker) ---
  $('#mls-gen').addEventListener('click', () => {
    const transcript = tx.value.trim();
    if (!transcript) { log('Add a transcript or selection first.'); return; }
    const btn = $('#mls-gen'); btn.disabled = true; btn.textContent = '… generating';
    chrome.runtime.sendMessage({ type: 'mlsAssistGenerate', transcript }, (resp) => {
      btn.disabled = false; btn.textContent = '✨ Generate note';
      if (!resp) { log('No response (extension reloaded?).'); return; }
      if (resp.error) { log('Error: ' + resp.error); return; }
      noteBox.value = resp.note || '';
      log('Note drafted' + (resp.model ? ' (' + resp.model + ')' : '') + ' — review, then Insert.');
    });
  });

  // --- capture the whole chart (read all data) into MLS ---
  $('#mls-cap').addEventListener('click', () => {
    const pageText = ((document.body && document.body.innerText) || '').trim().slice(0, 20000);
    if (!pageText) { log('Nothing readable on this page to capture.'); return; }
    const btn = $('#mls-cap'); btn.disabled = true; btn.textContent = '… capturing chart';
    chrome.runtime.sendMessage({ type: 'mlsAssistExtract', pageText, url: location.href }, (resp) => {
      btn.disabled = false; btn.textContent = '📋 Capture whole chart → MLS';
      if (!resp) { log('No response (extension reloaded?).'); return; }
      if (resp.ok) { log('✓ Captured ' + (resp.patient || 'patient') + ' + ' + (resp.visits || 0) + ' prior visit(s) into MLS.'); return; }
      log('Capture: ' + (resp.error || 'no patient identity found on this page.'));
    });
  });

  // --- insert into the focused EMR field (React/Angular-safe) ---
  function setNativeValue(el, value) {
    const proto = (el.tagName === 'TEXTAREA') ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value');
    if (setter && setter.set) setter.set.call(el, value); else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  $('#mls-ins').addEventListener('click', () => {
    const note = noteBox.value.trim();
    if (!note) { log('Nothing to copy yet.'); return; }
    navigator.clipboard.writeText(note).then(
      function () { log('Note copied. Click into your EMR note field and paste it (Ctrl/Cmd + V).'); },
      function () { log('Copy was blocked by the page.'); });
  });
  $('#mls-cpy').addEventListener('click', () => {
    navigator.clipboard.writeText(noteBox.value || '').then(() => log('Copied to clipboard.'), () => log('Copy blocked by page.'));
  });
})();

/* MLS Assist — Stage 2 Autopilot (beta).
   A supervised agent loop: screenshot + page text -> MLS agent brain decides the
   next action -> we execute it on the page -> repeat. Hard safety rail: it never
   commits to the chart; on a Save/Sign it PAUSES and asks the doctor to do it. */
(function () {
  function ready() { const p = document.getElementById('mls-assist-panel'); if (!p) return setTimeout(ready, 600); init(p); }
  ready();
  function init(panel) {
    const body = panel.querySelector('.body'); if (!body || panel.__apInit) return; panel.__apInit = true;
    const log = panel.querySelector('#mls-log'); const L = m => { const d = document.createElement('div'); d.textContent = '⤷ ' + m; log.prepend(d); };
    const wrap = document.createElement('div');
    wrap.style.cssText = 'border-top:1px dashed #e0e8f2;margin-top:12px;padding-top:10px';
    wrap.innerHTML =
      '<label>Autopilot (beta) — the agent does the steps</label>' +
      '<input id="mls-ap-goal" placeholder="e.g. find the note field and insert the visit note" style="width:100%;box-sizing:border-box;border:1px solid #cfe0f3;border-radius:8px;padding:7px;font:13px inherit">' +
      '<div class="row"><button class="b b-go" id="mls-ap-run" data-tip="Let the agent take the steps toward your goal — it pauses before any Save or Sign" style="flex:1">▶ Run autopilot</button><button class="b b-rec" id="mls-ap-stop" data-tip="Stop the autopilot right now" style="display:none">⏹ Stop</button></div>' +
      '<div class="consent" style="margin-top:8px">Autopilot reads the screen and acts step-by-step while you watch. It will <b>never</b> click Save/Sign on its own — it pauses and asks you to approve any chart commit. Hit Stop anytime.</div>';
    body.appendChild(wrap);
    const goalI = wrap.querySelector('#mls-ap-goal'), runB = wrap.querySelector('#mls-ap-run'), stopB = wrap.querySelector('#mls-ap-stop');
    const send = (type, extra) => new Promise(res => chrome.runtime.sendMessage(Object.assign({ type }, extra || {}), res));
    let running = false;
    function findEl(target) {
      if (!target) return null;
      try { const el = document.querySelector(target); if (el) return el; } catch (e) {}
      const t = String(target).toLowerCase().trim();
      const cand = [...document.querySelectorAll('button,a,[role=button],input[type=submit],input[type=button],label,[onclick]')];
      return cand.find(e => ((e.innerText || e.value || e.getAttribute('aria-label') || '')).toLowerCase().trim().includes(t)) || null;
    }
    function typeInto(el, text) {
      el.focus();
      if (el.isContentEditable) { if (!document.execCommand('insertText', false, text)) { el.textContent = text; el.dispatchEvent(new Event('input', { bubbles: true })); } }
      else { const p = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; const s = Object.getOwnPropertyDescriptor(p, 'value'); if (s && s.set) s.set.call(el, text); else el.value = text; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); }
    }
    async function loop() {
      const goal = goalI.value.trim(); if (!goal) { L('Enter a goal for autopilot.'); return; }
      running = true; runB.style.display = 'none'; stopB.style.display = ''; const history = [];
      for (let step = 0; step < 12 && running; step++) {
        const cap = await send('mlsAssistCapture');
        const pageText = (document.body.innerText || '').slice(0, 9000);
        const resp = await send('mlsAssistAgentStep', { goal, pageText, screenshot: (cap && cap.dataUrl) || '', history });
        if (!resp || resp.error) { L('Agent: ' + ((resp && resp.error) || 'no response')); break; }
        const a = resp.action || {}; if (resp.reasoning) L(String(resp.reasoning).slice(0, 100));
        history.push({ type: a.type, target: a.target });
        if (a.type === 'done') { L('✓ Autopilot finished.'); break; }
        if (a.type === 'confirm') { L('⚠ Agent wants to commit ("' + (a.target || '') + '"). You do that one — paused for safety.'); break; }
        if (a.type === 'ask') { L('Agent needs you: ' + (a.target || a.reasoning || '')); break; }
        if (a.type === 'click') { const el = findEl(a.target); if (el) { el.scrollIntoView({ block: 'center' }); el.click(); L('Clicked: ' + (a.target || '')); } else { L('Could not find: ' + (a.target || '')); } }
        else if (a.type === 'type') { L('Agent wants to enter text into ' + (a.target || 'a field') + ' - paused. MLS Assist does not type; you type or paste it.'); break; }
        else if (a.type === 'scroll') { window.scrollBy(0, 600); L('Scrolled.'); }
        else if (a.type === 'read') { L('Read the screen.'); }
        await new Promise(r => setTimeout(r, 1300));
      }
      running = false; runB.style.display = ''; stopB.style.display = 'none';
    }
    runB.addEventListener('click', loop);
    stopB.addEventListener('click', () => { running = false; L('Stopped by you.'); });
  }
})();
