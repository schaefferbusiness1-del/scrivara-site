/* MLS Assist — content script.
   Sits dormant as a small badge on every page. Does NOTHING until the doctor
   opens the panel (consent). Then: capture the visit (live dictation or page
   selection) -> MLS generates a note -> the doctor reviews -> one click inserts
   it into the focused EMR field. Nothing is ever written automatically. */
(function () {
  if (window.__mlsAssistLoaded) return; window.__mlsAssistLoaded = true;
  // Bridge: the MLS web app can ping us (to show "Assist installed") and ask us
  // to capture the patient currently open in the doctor's EMR tab.
  window.addEventListener('message', function (e) {
    var d = e.data; if (!d || d.source !== 'mls-app') return;
    if (d.type === 'mlsPing') { window.postMessage({ source: 'mls-ext', type: 'mlsPong' }, '*'); return; }
    if (d.type === 'mlsAppCapture') {
      try {
        chrome.runtime.sendMessage({ type: 'mlsAppCaptureRequest' }, function (resp) {
          window.postMessage({ source: 'mls-ext', type: 'mlsAppCaptureResult', resp: resp || { error: 'no response' } }, '*');
        });
      } catch (err) { window.postMessage({ source: 'mls-ext', type: 'mlsAppCaptureResult', resp: { error: 'extension error' } }, '*'); }
    }
  });

  // --- custom hover tooltips: appear only after the cursor rests ~2s on a button ---
  (function () {
    var DELAY = 2000, tipEl = null, timer = null, currentEl = null;
    function ensure() { if (tipEl) return tipEl; tipEl = document.createElement('div'); tipEl.id = 'mls-tip'; (document.body || document.documentElement).appendChild(tipEl); return tipEl; }
    function show(el) {
      if (!el || !el.getAttribute) return;
      var txt = el.getAttribute('data-tip'); if (!txt) return;
      var t = ensure(); t.textContent = txt; t.style.display = 'block'; t.style.opacity = '0';
      var r = el.getBoundingClientRect(), tw = t.offsetWidth, th = t.offsetHeight;
      var left = Math.min(Math.max(8, r.left + r.width / 2 - tw / 2), window.innerWidth - tw - 8);
      var top = r.top - th - 8; if (top < 8) top = r.bottom + 8;
      t.style.left = left + 'px'; t.style.top = top + 'px'; t.style.opacity = '1';
    }
    function hide() { if (timer) { clearTimeout(timer); timer = null; } if (tipEl) tipEl.style.display = 'none'; }
    document.addEventListener('mouseover', function (e) {
      var el = (e.target && e.target.closest) ? e.target.closest('[data-tip]') : null;
      if (el === currentEl) return;
      currentEl = el; hide();
      if (el) timer = setTimeout(function () { show(el); }, DELAY);
    }, true);
    document.addEventListener('mousedown', hide, true);
    window.addEventListener('scroll', hide, true);
  })();

  // --- remember the last editable field the user focused (the note field) ---
  let lastEditable = null;
  function isEditable(el) {
    if (!el) return false;
    const t = (el.tagName || '').toUpperCase();
    if (t === 'TEXTAREA') return true;
    if (t === 'INPUT') return /^(text|search|email|url|tel|)$/i.test(el.type || '');
    return !!el.isContentEditable;
  }
  document.addEventListener('focusin', e => { if (isEditable(e.target)) lastEditable = e.target; }, true);
  // Smart note-field detection so the doctor doesn't have to click the field first.
  function bestNoteField() {
    if (isEditable(lastEditable)) return lastEditable;
    if (isEditable(document.activeElement)) return document.activeElement;
    const cands = [...document.querySelectorAll('textarea,[contenteditable=""],[contenteditable="true"]')].filter(el => { const r = el.getBoundingClientRect(); return r.width > 120 && r.height > 36 && r.bottom > 0 && r.top < innerHeight; });
    cands.sort((a, b) => { const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect(); return (rb.width * rb.height) - (ra.width * ra.height); });
    return cands[0] || null;
  }

  // --- build UI ---
  const badge = document.createElement('div');
  badge.id = 'mls-assist-badge';
  badge.innerHTML = '<span class="dot"></span>🩺 MLS Assist';
  badge.setAttribute('data-tip', 'Open MLS Assist — dictate, draft, and insert your note');

  const panel = document.createElement('div');
  panel.id = 'mls-assist-panel';
  panel.innerHTML = [
    '<header><b>🩺 MLS Assist</b><span class="x" data-tip="Close MLS Assist">×</span></header>',
    '<div class="body">',
    '  <div class="consent">Runs only when you open this panel. It captures what you dictate or select, drafts a note, and inserts it <b>only when you click</b>. You review everything first.</div>',
    '  <label>Visit transcript / context</label>',
    '  <textarea id="mls-tx" rows="5" placeholder="Press Dictate and talk through the visit, or paste/select text from the chart…"></textarea>',
    '  <div class="row">',
    '    <button class="b b-rec" id="mls-rec" data-tip="Dictate the visit out loud — MLS transcribes as you talk">🎙 Dictate</button>',
    '    <button class="b b-ghost" id="mls-sel" data-tip="Use the text you have highlighted on the chart as the visit context">Use page selection</button>',
    '    <button class="b b-ghost" id="mls-clr" data-tip="Clear the transcript and the drafted note">Clear</button>',
    '  </div>',
    '  <div class="row"><button class="b b-go" id="mls-gen" data-tip="Turn the transcript into a structured clinical note" style="flex:1">✨ Generate note</button></div>',
    '  <label>Drafted note (review before inserting)</label>',
    '  <textarea id="mls-note" rows="7" placeholder="Your generated note appears here for review."></textarea>',
    '  <div class="row">',
    '    <button class="b b-primary" id="mls-ins" data-tip="Paste the drafted note straight into your EMR note field - it finds the field for you (a one-shot paste, not keystroke typing)" style="flex:1">⤵ Paste note into chart</button>',
    '    <button class="b b-ghost" id="mls-cpy" data-tip="Copy the drafted note to your clipboard">Copy</button>',
    '  </div>',
    '  <div style="border-top:1px dashed #e0e8f2;margin-top:12px;padding-top:10px">',
    '    <label>Pull the whole chart into MLS</label>',
    '    <div class="row"><button class="b b-ghost" id="mls-cap" data-tip="Read this patient and their prior visits into MLS — nothing is written back to the EMR" style="flex:1">📋 Capture whole chart → MLS</button></div>',
    '    <div class="consent" style="margin-top:6px">Reads the patient + their prior visits off this page and saves them into MLS (encrypted). Nothing is written back to the EMR.</div>',
    '  </div>',
    '  <div class="log" id="mls-log"></div>',
    '</div>'
  ].join('');

  document.documentElement.appendChild(badge);
  document.documentElement.appendChild(panel);

  const $ = s => panel.querySelector(s);
  const tx = $('#mls-tx'), noteBox = $('#mls-note'), logBox = $('#mls-log');
  function log(m) { const d = document.createElement('div'); d.textContent = '• ' + m; logBox.prepend(d); }

  function mlsVerCmp(a, b) { a = String(a).split('.').map(Number); b = String(b).split('.').map(Number); for (let i = 0; i < Math.max(a.length, b.length); i++) { const x = a[i] || 0, y = b[i] || 0; if (x > y) return 1; if (x < y) return -1; } return 0; }
  let _updChecked = false;
  async function checkForUpdate() {
    if (_updChecked) return; _updChecked = true;
    try {
      const cur = chrome.runtime.getManifest().version;
      const r = await fetch('https://mlsscribe.com/extension-version.json?t=' + Date.now());
      const d = await r.json();
      if (d && d.version && mlsVerCmp(d.version, cur) > 0) {
        const url = d.url || 'https://mlsscribe.com/assist.html';
        const bn = document.createElement('div');
        bn.style.cssText = 'background:#fff7e6;border:1px solid #f0d9a0;border-radius:8px;padding:8px 10px;margin:0 0 8px;font-size:12.5px;color:#8a5a00';
        bn.innerHTML = '\u{1F504} <b>Update available</b> (v' + String(d.version).replace(/[<>&"]/g, '') + '). <a href="' + url + '" target="_blank" style="color:#1f7ae0;font-weight:700">Download</a>, then reload it at chrome://extensions.';
        const body = panel.querySelector('.body'); if (body) body.insertBefore(bn, body.firstChild);
        log('A newer version of MLS Assist is available.');
      }
    } catch (e) {}
  }
  badge.addEventListener('click', () => {
    const open = panel.classList.toggle('open');
    if (open) { log('Panel opened — capture is active.'); checkForUpdate(); }
  });
  $('.x').addEventListener('click', () => { panel.classList.remove('open'); stopRec(); });
  chrome.runtime.onMessage.addListener((m, s, send) => { if (m && m.type === 'mlsOpenPanel') { panel.classList.add('open'); log('Opened MLS Assist from the toolbar.'); try { send && send({ ok: true }); } catch (e) {} } return true; });

  // --- live dictation (Web Speech API) ---
  let rec = null, recing = false;
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recBtn = $('#mls-rec');
  if (!SR) { recBtn.disabled = true; recBtn.textContent = '🎙 (no speech support)'; }
  function startRec() {
    if (!SR) return;
    rec = new SR(); rec.lang = 'en-US'; rec.continuous = true; rec.interimResults = true;
    let base = tx.value;
    rec.onresult = (e) => {
      let finalTxt = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) finalTxt += e.results[i][0].transcript + ' ';
      }
      if (finalTxt) { base += (base && !/\s$/.test(base) ? ' ' : '') + finalTxt.trim() + ' '; tx.value = base; }
    };
    rec.onerror = (e) => log('Dictation: ' + (e.error || 'error'));
    rec.onend = () => { if (recing) { try { rec.start(); } catch (e) {} } };
    try { rec.start(); recing = true; recBtn.textContent = '⏹ Stop'; badge.classList.add('active'); log('Dictation started.'); } catch (e) { log('Could not start mic.'); }
  }
  function stopRec() {
    recing = false; if (rec) { try { rec.stop(); } catch (e) {} } recBtn.textContent = '🎙 Dictate'; badge.classList.remove('active');
  }
  recBtn.addEventListener('click', () => { recing ? (stopRec(), log('Dictation stopped.')) : startRec(); });

  // --- use page selection ---
  $('#mls-sel').addEventListener('click', () => {
    const sel = (window.getSelection ? window.getSelection().toString() : '').trim();
    if (!sel) { log('No text selected on the page.'); return; }
    tx.value = (tx.value ? tx.value + '\n\n' : '') + sel; log('Added ' + sel.length + ' chars from selection.');
  });
  $('#mls-clr').addEventListener('click', () => { tx.value = ''; noteBox.value = ''; });

  // --- generate (key + network handled by the background worker) ---
  $('#mls-gen').addEventListener('click', () => {
    const transcript = tx.value.trim();
    if (!transcript) { log('Add a transcript or selection first.'); return; }
    const btn = $('#mls-gen'); btn.disabled = true; btn.textContent = '… generating';
    chrome.runtime.sendMessage({ type: 'mlsAssistGenerate', transcript }, (resp) => {
      btn.disabled = false; btn.textContent = '✨ Generate note';
      if (!resp) { log('No response (extension reloaded?).'); return; }
      if (resp.error) { log('Error: ' + resp.error); return; }
      noteBox.value = resp.note || '';
      log('Note drafted' + (resp.model ? ' (' + resp.model + ')' : '') + ' — review, then Insert.');
    });
  });

  // --- capture the whole chart (read all data) into MLS ---
  $('#mls-cap').addEventListener('click', () => {
    const pageText = ((document.body && document.body.innerText) || '').trim().slice(0, 20000);
    if (!pageText) { log('Nothing readable on this page to capture.'); return; }
    const btn = $('#mls-cap'); btn.disabled = true; btn.textContent = '… capturing chart';
    chrome.runtime.sendMessage({ type: 'mlsAssistExtract', pageText, url: location.href }, (resp) => {
      btn.disabled = false; btn.textContent = '📋 Capture whole chart → MLS';
      if (!resp) { log('No response (extension reloaded?).'); return; }
      if (resp.ok) { log('✓ Captured ' + (resp.patient || 'patient') + ' + ' + (resp.visits || 0) + ' prior visit(s) into MLS.'); return; }
      log('Capture: ' + (resp.error || 'no patient identity found on this page.'));
    });
  });

  // --- insert into the focused EMR field (React/Angular-safe) ---
  function setNativeValue(el, value) {
    const proto = (el.tagName === 'TEXTAREA') ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value');
    if (setter && setter.set) setter.set.call(el, value); else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  $('#mls-ins').addEventListener('click', () => {
    const note = noteBox.value.trim();
    if (!note) { log('Nothing to paste yet.'); return; }
    const target = bestNoteField();
    if (!target || !isEditable(target)) {
      navigator.clipboard.writeText(note).then(function () { log('No note field found here - copied instead; click into the field and paste (Ctrl/Cmd + V).'); }, function () { log('No note field found on this page.'); });
      return;
    }
    try {
      target.focus();
      if (target.isContentEditable) {
        if (!document.execCommand('insertText', false, note)) { target.textContent = note; target.dispatchEvent(new Event('input', { bubbles: true })); }
      } else { setNativeValue(target, note); }
      log('Pasted the note into the chart field. Review and save in your EMR.');
    } catch (e) { navigator.clipboard.writeText(note).catch(function(){}); log('Could not paste - copied to clipboard instead.'); }
  });
  $('#mls-cpy').addEventListener('click', () => {
    navigator.clipboard.writeText(noteBox.value || '').then(() => log('Copied to clipboard.'), () => log('Copy blocked by page.'));
  });
})();

/* MLS Assist — Stage 2 Autopilot (beta).
   A supervised agent loop: screenshot + page text -> MLS agent brain decides the
   next action -> we execute it on the page -> repeat. Hard safety rail: it never
   commits to the chart; on a Save/Sign it PAUSES and asks the doctor to do it. */
(function () {
  function ready() { const p = document.getElementById('mls-assist-panel'); if (!p) return setTimeout(ready, 600); init(p); }
  ready();
  function init(panel) {
    const body = panel.querySelector('.body'); if (!body || panel.__apInit) return; panel.__apInit = true;
    const log = panel.querySelector('#mls-log'); const L = m => { const d = document.createElement('div'); d.textContent = '⤷ ' + m; log.prepend(d); };
    const wrap = document.createElement('div');
    wrap.style.cssText = 'border-top:1px dashed #e0e8f2;margin-top:12px;padding-top:10px';
    wrap.innerHTML =
      '<label>Autopilot (beta) — the agent does the steps</label>' +
      '<input id="mls-ap-goal" placeholder="e.g. find the note field and insert the visit note" style="width:100%;box-sizing:border-box;border:1px solid #cfe0f3;border-radius:8px;padding:7px;font:13px inherit">' +
      '<div class="row"><button class="b b-go" id="mls-ap-run" data-tip="Let the agent take the steps toward your goal — it pauses before any Save or Sign" style="flex:1">▶ Run autopilot</button><button class="b b-rec" id="mls-ap-stop" data-tip="Stop the autopilot right now" style="display:none">⏹ Stop</button></div>' +
      '<div class="row" style="gap:6px;margin-top:6px"><button class="b b-ghost" id="mls-ap-mic" data-tip="Speak your goal instead of typing it">🎤 Speak</button><button class="b b-ghost" id="mls-ap-savepb" data-tip="Save this goal as a one-tap playbook">💾 Save as playbook</button></div>' +
      '<div id="mls-ap-pbs" style="display:flex;gap:5px;flex-wrap:wrap;margin:6px 0 0"></div>' +
      '<div class="row" style="gap:6px;margin-top:8px"><button class="b b-ghost" id="mls-ap-rec" data-tip="Record the clicks and typing you do, then replay it anytime">⏺ Record a task</button><button class="b b-ghost" id="mls-ap-undo" data-tip="Undo the last text the agent typed into a field">↩ Undo last</button></div>' +
      '<div id="mls-ap-recs" style="display:flex;gap:5px;flex-wrap:wrap;margin:6px 0 0"></div>' +
      '<label class="row" style="display:flex;align-items:center;gap:6px;margin-top:8px;font-size:12.5px;color:#8a5a00"><input type="checkbox" id="mls-ap-save" style="width:auto;flex:none"> Let it click Save / Sign on its own (use with care)</label>' +
      '<div class="consent" style="margin-top:8px">Autopilot reads the screen and acts step-by-step while you watch. By default it <b>pauses</b> before any Save/Sign and asks you. Tick the box above to let it commit on its own — only do that while watching. Hit Stop anytime.</div>';
    body.appendChild(wrap);
    const goalI = wrap.querySelector('#mls-ap-goal'), runB = wrap.querySelector('#mls-ap-run'), stopB = wrap.querySelector('#mls-ap-stop');
    const send = (type, extra) => new Promise(res => chrome.runtime.sendMessage(Object.assign({ type }, extra || {}), res));
    let running = false;
    let lastTypeTarget = null;
    function findEl(target) {
      if (!target) return null;
      try { const el = document.querySelector(target); if (el) return el; } catch (e) {}
      const t = String(target).toLowerCase().trim();
      const cand = [...document.querySelectorAll('button,a,[role=button],input[type=submit],input[type=button],label,[onclick]')];
      return cand.find(e => ((e.innerText || e.value || e.getAttribute('aria-label') || '')).toLowerCase().trim().includes(t)) || null;
    }
    function typeInto(el, text) {
      el.focus();
      if (el.isContentEditable) { if (!document.execCommand('insertText', false, text)) { el.textContent = text; el.dispatchEvent(new Event('input', { bubbles: true })); } }
      else { const p = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; const s = Object.getOwnPropertyDescriptor(p, 'value'); if (s && s.set) s.set.call(el, text); else el.value = text; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); }
    }
    async function loop() {
      const goal = goalI.value.trim(); if (!goal) { L('Enter a goal for autopilot.'); return; }
      running = true; runB.style.display = 'none'; stopB.style.display = ''; const history = [];
      for (let step = 0; step < 40 && running; step++) {
        const cap = await send('mlsAssistCapture');
        const pt = await send('mlsAssistPageText');
        const pageText = (pt && pt.text) || '';
        const resp = await send('mlsAssistAgentStep', { goal, pageText, screenshot: (cap && cap.dataUrl) || '', history });
        if (!resp || resp.error) { L('Agent: ' + ((resp && resp.error) || 'no response')); break; }
        const a = resp.action || {}; if (resp.reasoning) L(String(resp.reasoning).slice(0, 100));
        history.push({ type: a.type, target: a.target });
        if (a.type === 'done') { L('✓ Autopilot finished.'); break; }
        if (a.type === 'confirm') {
          var _allow = !!((document.getElementById('mls-ap-save') || {}).checked);
          if (_allow) { const cr = await send('mlsAssistExec', { action: { type: 'click', target: a.target } }); if (cr && cr.ok) { L('✅ ' + cr.msg + ' (Save/Sign allowed)'); await new Promise(function (r) { setTimeout(r, 1000); }); continue; } L('Wanted to commit but ' + ((cr && cr.msg) || 'failed') + ' — paused.'); break; }
          L('⚠ Agent wants to commit ("' + (a.target || '') + '"). Tick "Let it click Save/Sign" to allow, or do it yourself — paused.'); break;
        }
        if (a.type === 'ask') { L('Agent needs you: ' + (a.target || a.reasoning || '')); break; }
        if (a.type === 'switchtab') { const sr = await send('mlsAssistExec', { action: a }); L((sr && sr.ok) ? ('\u21B9 ' + sr.msg) : ('Could not switch tab: ' + ((sr && sr.msg) || ''))); await new Promise(function (r) { setTimeout(r, 1200); }); continue; }
        let er = await send('mlsAssistExec', { action: a });
        if (er && er.ok === false && (a.type === 'click' || a.type === 'select')) { await send('mlsAssistExec', { action: { type: 'scroll' } }); await new Promise(r => setTimeout(r, 500)); er = await send('mlsAssistExec', { action: a }); }
        if (a.type === 'type' && er && er.ok) lastTypeTarget = a.target;
        L((er && er.msg) ? er.msg : ('Did: ' + (a.type || '')));
        await new Promise(r => setTimeout(r, 1000));
      }
      running = false; runB.style.display = ''; stopB.style.display = 'none';
    }
    runB.addEventListener('click', loop);
    stopB.addEventListener('click', () => { running = false; L('Stopped by you.'); });
    (function () {
      var micB = wrap.querySelector('#mls-ap-mic'); if (!micB) return;
      var SRx = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SRx) { micB.disabled = true; micB.textContent = '🎤 (no voice)'; return; }
      var arec = null, aon = false;
      micB.addEventListener('click', function () {
        if (aon) { try { arec.stop(); } catch (e) {} return; }
        arec = new SRx(); arec.lang = 'en-US'; arec.interimResults = true; arec.continuous = false;
        var base = goalI.value;
        arec.onresult = function (e) { var t = ''; for (var i = e.resultIndex; i < e.results.length; i++) t += e.results[i][0].transcript; goalI.value = (base ? base + ' ' : '') + t; };
        arec.onerror = function () { aon = false; micB.textContent = '🎤 Speak'; };
        arec.onend = function () { aon = false; micB.textContent = '🎤 Speak'; };
        try { arec.start(); aon = true; micB.textContent = '⏹ Listening…'; } catch (e) {}
      });
    })();
    function pbGet() { try { return JSON.parse(localStorage.getItem('mls_playbooks') || '[]') || []; } catch (e) { return []; } }
    function pbSet(a) { try { localStorage.setItem('mls_playbooks', JSON.stringify(a.slice(0, 12))); } catch (e) {} }
    function pbRender() {
      var box = wrap.querySelector('#mls-ap-pbs'); if (!box) return;
      var a = pbGet(); box.innerHTML = '';
      a.forEach(function (g, i) {
        var chip = document.createElement('span'); chip.style.cssText = 'display:inline-flex;align-items:center;gap:4px;background:#eef4fc;border:1px solid #cfe0f3;border-radius:999px;padding:3px 4px 3px 9px;font-size:12px;max-width:100%';
        var run = document.createElement('button'); run.textContent = '▶ ' + (g.length > 26 ? g.slice(0, 26) + '…' : g); run.title = g; run.style.cssText = 'background:none;border:none;color:#1f7ae0;font:inherit;cursor:pointer;padding:0;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
        run.addEventListener('click', function () { goalI.value = g; loop(); });
        var del = document.createElement('button'); del.textContent = '✕'; del.title = 'Remove'; del.style.cssText = 'background:none;border:none;color:#9aa7b4;font:inherit;cursor:pointer;padding:0 2px';
        del.addEventListener('click', function (ev) { ev.stopPropagation(); var arr = pbGet(); arr.splice(i, 1); pbSet(arr); pbRender(); });
        chip.appendChild(run); chip.appendChild(del); box.appendChild(chip);
      });
    }
    var savepb = wrap.querySelector('#mls-ap-savepb');
    if (savepb) savepb.addEventListener('click', function () { var g = goalI.value.trim(); if (!g) { L('Type or speak a goal first, then save it.'); return; } var a = pbGet(); if (a.indexOf(g) === -1) { a.unshift(g); pbSet(a); pbRender(); L('Saved playbook.'); } });
    pbRender();
    var undoB = wrap.querySelector('#mls-ap-undo');
    if (undoB) undoB.addEventListener('click', async function () {
      if (!lastTypeTarget) { L('Nothing to undo yet.'); return; }
      var er = await send('mlsAssistExec', { action: { type: 'type', target: lastTypeTarget, text: '' } });
      L((er && er.ok) ? ('Cleared: ' + lastTypeTarget) : ('Could not undo: ' + ((er && er.msg) || '')));
      lastTypeTarget = null;
    });
    var recOn = false, recSteps = [];
    var recB = wrap.querySelector('#mls-ap-rec');
    function elSelector(el) {
      if (!el || el === document.body || el === document.documentElement) return '';
      if (el.id && /^[A-Za-z][\w-]*$/.test(el.id)) return '#' + el.id;
      if (el.getAttribute && el.getAttribute('name')) return el.tagName.toLowerCase() + '[name="' + el.getAttribute('name') + '"]';
      var txt = (el.innerText || el.value || '').trim();
      if (txt && txt.length < 40 && /^(BUTTON|A|LABEL)$/.test(el.tagName)) return txt;
      var s = el.tagName.toLowerCase();
      if (typeof el.className === 'string' && el.className.trim()) { var cl = el.className.trim().split(/\s+/)[0].replace(/[^\w-]/g, ''); if (cl) s += '.' + cl; }
      return s;
    }
    function fieldLabel(el) {
      try {
        if (el.getAttribute) {
          var al = el.getAttribute('aria-label'); if (al) return al.trim();
          var ph = el.getAttribute('placeholder'); if (ph) return ph.trim();
          if (el.id) { var lab = document.querySelector('label[for="' + el.id + '"]'); if (lab && lab.textContent) return lab.textContent.trim().slice(0, 50); }
        }
        var p = el.closest && el.closest('label'); if (p) { var t = p.textContent.replace(el.value || '', '').trim(); if (t) return t.slice(0, 50); }
        var nm = el.getAttribute && el.getAttribute('name'); if (nm) return nm;
      } catch (e) {}
      return (el.tagName || 'field').toLowerCase();
    }
    function stepDesc(type, el, text) {
      if (type === 'click') return 'Click "' + ((el.innerText || el.value || fieldLabel(el)) || '').trim().replace(/\s+/g, ' ').slice(0, 50) + '"';
      if (type === 'type') return 'Type "' + String(text || '').slice(0, 40) + '" into the "' + fieldLabel(el) + '" field';
      if (type === 'select') return 'Choose "' + String(text || '').slice(0, 40) + '" in the "' + fieldLabel(el) + '" dropdown';
      return type;
    }
    function recPush(type, el, text) {
      if (!recOn || !el || panel.contains(el)) return;
      var target = elSelector(el); if (!target) return;
      recSteps.push({ type: type, target: target, text: text || '', desc: stepDesc(type, el, text) });
      if (recB) recB.textContent = '⏹ Stop (' + recSteps.length + ')';
    }
    function recClick(e) { var el = (e.target && e.target.closest) ? (e.target.closest('button,a,[role=button],input[type=submit],input[type=button],[onclick],label') || e.target) : e.target; if (el && el.tagName === 'SELECT') return; recPush('click', el); }
    function recChange(e) { var el = e.target; if (!el) return; if (el.tagName === 'SELECT') recPush('select', el, (el.options[el.selectedIndex] || {}).text || ''); else if (/^(INPUT|TEXTAREA)$/.test(el.tagName)) recPush('type', el, el.value); }
    function recStart() { recOn = true; recSteps = []; document.addEventListener('click', recClick, true); document.addEventListener('change', recChange, true); if (recB) recB.textContent = '⏹ Stop (0)'; L('Recording — do your task, then press Stop.'); }
    function recStop() {
      recOn = false; document.removeEventListener('click', recClick, true); document.removeEventListener('change', recChange, true);
      if (recB) recB.textContent = '⏺ Record a task';
      if (!recSteps.length) { L('Nothing was recorded.'); return; }
      var name = prompt('Name this recorded task:', 'Task ' + (mrGet().length + 1));
      if (name === null) { L('Recording discarded.'); return; }
      var a = mrGet(); a.unshift({ name: String(name).slice(0, 40) || 'Task', steps: recSteps.slice() }); mrSet(a); mrRender();
      L('Saved recording (' + recSteps.length + ' steps).');
    }
    if (recB) recB.addEventListener('click', function () { recOn ? recStop() : recStart(); });
    function mrGet() { try { return JSON.parse(localStorage.getItem('mls_recordings') || '[]') || []; } catch (e) { return []; } }
    function mrSet(a) { try { localStorage.setItem('mls_recordings', JSON.stringify(a.slice(0, 12))); } catch (e) {} }
    async function mrReplay(steps) {
      L('▶ Replaying ' + steps.length + ' steps (smart/adaptive)…'); running = true; runB.style.display = 'none'; stopB.style.display = '';
      for (var i = 0; i < steps.length && running; i++) {
        var s = steps[i];
        var er = await send('mlsAssistExec', { action: s });
        if (!er || er.ok === false) {
          L('  ' + (i + 1) + '. page changed — adapting: ' + (s.desc || s.type));
          var cap = await send('mlsAssistCapture');
          var pt = await send('mlsAssistPageText');
          var resp = await send('mlsAssistAgentStep', { goal: 'Do exactly this ONE UI step on the current screen and nothing else: ' + (s.desc || (s.type + ' ' + s.target)), pageText: (pt && pt.text) || '', screenshot: (cap && cap.dataUrl) || '', history: [] });
          if (resp && resp.action && resp.action.type && resp.action.type !== 'ask' && resp.action.type !== 'done') {
            er = await send('mlsAssistExec', { action: resp.action });
            L('     \u21B3 ' + ((er && er.msg) || 'adapted') + (resp.reasoning ? (' — ' + String(resp.reasoning).slice(0, 60)) : ''));
          } else {
            L('     \u21B3 could not adapt this step.');
          }
        } else {
          L('  ' + (i + 1) + '. ' + ((er && er.msg) || s.type));
        }
        await new Promise(function (r) { setTimeout(r, 900); });
      }
      running = false; runB.style.display = ''; stopB.style.display = 'none'; L('\u2713 Replay finished.');
    }
    function mrRender() {
      var box = wrap.querySelector('#mls-ap-recs'); if (!box) return; var a = mrGet(); box.innerHTML = '';
      a.forEach(function (rec, i) {
        var chip = document.createElement('span'); chip.style.cssText = 'display:inline-flex;align-items:center;gap:4px;background:#eef9f1;border:1px solid #bfe6cf;border-radius:999px;padding:3px 4px 3px 9px;font-size:12px';
        var run = document.createElement('button'); run.textContent = '🎬 ' + rec.name; run.title = 'Replay (' + rec.steps.length + ' steps)'; run.style.cssText = 'background:none;border:none;color:#1c7a43;font:inherit;cursor:pointer;padding:0;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
        run.addEventListener('click', function () { mrReplay(rec.steps); });
        var del = document.createElement('button'); del.textContent = '✕'; del.title = 'Remove'; del.style.cssText = 'background:none;border:none;color:#9aa7b4;font:inherit;cursor:pointer;padding:0 2px';
        del.addEventListener('click', function (ev) { ev.stopPropagation(); var arr = mrGet(); arr.splice(i, 1); mrSet(arr); mrRender(); });
        chip.appendChild(run); chip.appendChild(del); box.appendChild(chip);
      });
    }
    mrRender();
  }
})();
