/* MLS Assist — content script.
   Sits dormant as a small badge on every page. Does NOTHING until the doctor
   opens the panel (consent). Then: capture the visit (live dictation or page
   selection) -> MLS generates a note -> the doctor reviews -> one click inserts
   it into the focused EMR field. Nothing is ever written automatically. */
(function () {
  if (window.__mlsAssistLoaded) return; window.__mlsAssistLoaded = true;

  // --- remember the last editable field the user focused (the note field) ---
  let lastEditable = null;
  function isEditable(el) {
    if (!el) return false;
    const t = (el.tagName || '').toUpperCase();
    if (t === 'TEXTAREA') return true;
    if (t === 'INPUT') return /^(text|search|email|url|tel|)$/i.test(el.type || '');
    return !!el.isContentEditable;
  }
  document.addEventListener('focusin', e => { if (isEditable(e.target)) lastEditable = e.target; }, true);
  // Smart note-field detection so the doctor doesn't have to click the field first.
  function bestNoteField() {
    if (isEditable(lastEditable)) return lastEditable;
    if (isEditable(document.activeElement)) return document.activeElement;
    const cands = [...document.querySelectorAll('textarea,[contenteditable=""],[contenteditable="true"]')].filter(el => { const r = el.getBoundingClientRect(); return r.width > 120 && r.height > 36 && r.bottom > 0 && r.top < innerHeight; });
    cands.sort((a, b) => { const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect(); return (rb.width * rb.height) - (ra.width * ra.height); });
    return cands[0] || null;
  }

  // --- build UI ---
  const badge = document.createElement('div');
  badge.id = 'mls-assist-badge';
  badge.innerHTML = '<span class="dot"></span>🩺 MLS Assist';

  const panel = document.createElement('div');
  panel.id = 'mls-assist-panel';
  panel.innerHTML = [
    '<header><b>🩺 MLS Assist</b><span class="x" title="Close">×</span></header>',
    '<div class="body">',
    '  <div class="consent">Runs only when you open this panel. It captures what you dictate or select, drafts a note, and inserts it <b>only when you click</b>. You review everything first.</div>',
    '  <label>Visit transcript / context</label>',
    '  <textarea id="mls-tx" rows="5" placeholder="Press Dictate and talk through the visit, or paste/select text from the chart…"></textarea>',
    '  <div class="row">',
    '    <button class="b b-rec" id="mls-rec">🎙 Dictate</button>',
    '    <button class="b b-ghost" id="mls-sel">Use page selection</button>',
    '    <button class="b b-ghost" id="mls-clr">Clear</button>',
    '  </div>',
    '  <div class="row"><button class="b b-go" id="mls-gen" style="flex:1">✨ Generate note</button></div>',
    '  <label>Drafted note (review before inserting)</label>',
    '  <textarea id="mls-note" rows="7" placeholder="Your generated note appears here for review."></textarea>',
    '  <div class="row">',
    '    <button class="b b-primary" id="mls-ins" style="flex:1">⤵ Insert into chart</button>',
    '    <button class="b b-ghost" id="mls-cpy">Copy</button>',
    '  </div>',
    '  <div class="log" id="mls-log"></div>',
    '</div>'
  ].join('');

  document.documentElement.appendChild(badge);
  document.documentElement.appendChild(panel);

  const $ = s => panel.querySelector(s);
  const tx = $('#mls-tx'), noteBox = $('#mls-note'), logBox = $('#mls-log');
  function log(m) { const d = document.createElement('div'); d.textContent = '• ' + m; logBox.prepend(d); }

  badge.addEventListener('click', () => {
    const open = panel.classList.toggle('open');
    if (open) log('Panel opened — capture is active.');
  });
  $('.x').addEventListener('click', () => { panel.classList.remove('open'); stopRec(); });

  // --- live dictation (Web Speech API) ---
  let rec = null, recing = false;
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recBtn = $('#mls-rec');
  if (!SR) { recBtn.disabled = true; recBtn.textContent = '🎙 (no speech support)'; }
  function startRec() {
    if (!SR) return;
    rec = new SR(); rec.lang = 'en-US'; rec.continuous = true; rec.interimResults = true;
    let base = tx.value;
    rec.onresult = (e) => {
      let finalTxt = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) finalTxt += e.results[i][0].transcript + ' ';
      }
      if (finalTxt) { base += (base && !/\s$/.test(base) ? ' ' : '') + finalTxt.trim() + ' '; tx.value = base; }
    };
    rec.onerror = (e) => log('Dictation: ' + (e.error || 'error'));
    rec.onend = () => { if (recing) { try { rec.start(); } catch (e) {} } };
    try { rec.start(); recing = true; recBtn.textContent = '⏹ Stop'; badge.classList.add('active'); log('Dictation started.'); } catch (e) { log('Could not start mic.'); }
  }
  function stopRec() {
    recing = false; if (rec) { try { rec.stop(); } catch (e) {} } recBtn.textContent = '🎙 Dictate'; badge.classList.remove('active');
  }
  recBtn.addEventListener('click', () => { recing ? (stopRec(), log('Dictation stopped.')) : startRec(); });

  // --- use page selection ---
  $('#mls-sel').addEventListener('click', () => {
    const sel = (window.getSelection ? window.getSelection().toString() : '').trim();
    if (!sel) { log('No text selected on the page.'); return; }
    tx.value = (tx.value ? tx.value + '\n\n' : '') + sel; log('Added ' + sel.length + ' chars from selection.');
  });
  $('#mls-clr').addEventListener('click', () => { tx.value = ''; noteBox.value = ''; });

  // --- generate (key + network handled by the background worker) ---
  $('#mls-gen').addEventListener('click', () => {
    const transcript = tx.value.trim();
    if (!transcript) { log('Add a transcript or selection first.'); return; }
    const btn = $('#mls-gen'); btn.disabled = true; btn.textContent = '… generating';
    chrome.runtime.sendMessage({ type: 'mlsAssistGenerate', transcript }, (resp) => {
      btn.disabled = false; btn.textContent = '✨ Generate note';
      if (!resp) { log('No response (extension reloaded?).'); return; }
      if (resp.error) { log('Error: ' + resp.error); return; }
      noteBox.value = resp.note || '';
      log('Note drafted' + (resp.model ? ' (' + resp.model + ')' : '') + ' — review, then Insert.');
    });
  });

  // --- insert into the focused EMR field (React/Angular-safe) ---
  function setNativeValue(el, value) {
    const proto = (el.tagName === 'TEXTAREA') ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value');
    if (setter && setter.set) setter.set.call(el, value); else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  $('#mls-ins').addEventListener('click', () => {
    const note = noteBox.value.trim();
    if (!note) { log('Nothing to insert.'); return; }
    const target = bestNoteField();
    if (!target || !isEditable(target)) { log('No note field found on this page — click into one, then Insert.'); return; }
    try {
      target.focus();
      if (target.isContentEditable) {
        if (!document.execCommand('insertText', false, note)) { target.textContent = note; target.dispatchEvent(new Event('input', { bubbles: true })); }
      } else {
        setNativeValue(target, note);
      }
      log('Inserted into the chart field. Review & save in your EMR.');
    } catch (e) { log('Insert failed: ' + e.message); }
  });
  $('#mls-cpy').addEventListener('click', () => {
    navigator.clipboard.writeText(noteBox.value || '').then(() => log('Copied to clipboard.'), () => log('Copy blocked by page.'));
  });
})();

/* MLS Assist — Stage 2 Autopilot (beta).
   A supervised agent loop: screenshot + page text -> MLS agent brain decides the
   next action -> we execute it on the page -> repeat. Hard safety rail: it never
   commits to the chart; on a Save/Sign it PAUSES and asks the doctor to do it. */
(function () {
  function ready() { const p = document.getElementById('mls-assist-panel'); if (!p) return setTimeout(ready, 600); init(p); }
  ready();
  function init(panel) {
    const body = panel.querySelector('.body'); if (!body || panel.__apInit) return; panel.__apInit = true;
    const log = panel.querySelector('#mls-log'); const L = m => { const d = document.createElement('div'); d.textContent = '⤷ ' + m; log.prepend(d); };
    const wrap = document.createElement('div');
    wrap.style.cssText = 'border-top:1px dashed #e0e8f2;margin-top:12px;padding-top:10px';
    wrap.innerHTML =
      '<label>Autopilot (beta) — the agent does the steps</label>' +
      '<input id="mls-ap-goal" placeholder="e.g. find the note field and insert the visit note" style="width:100%;box-sizing:border-box;border:1px solid #cfe0f3;border-radius:8px;padding:7px;font:13px inherit">' +
      '<div class="row"><button class="b b-go" id="mls-ap-run" style="flex:1">▶ Run autopilot</button><button class="b b-rec" id="mls-ap-stop" style="display:none">⏹ Stop</button></div>' +
      '<div class="consent" style="margin-top:8px">Autopilot reads the screen and acts step-by-step while you watch. It will <b>never</b> click Save/Sign on its own — it pauses and asks you to approve any chart commit. Hit Stop anytime.</div>';
    body.appendChild(wrap);
    const goalI = wrap.querySelector('#mls-ap-goal'), runB = wrap.querySelector('#mls-ap-run'), stopB = wrap.querySelector('#mls-ap-stop');
    const send = (type, extra) => new Promise(res => chrome.runtime.sendMessage(Object.assign({ type }, extra || {}), res));
    let running = false;
    function findEl(target) {
      if (!target) return null;
      try { const el = document.querySelector(target); if (el) return el; } catch (e) {}
      const t = String(target).toLowerCase().trim();
      const cand = [...document.querySelectorAll('button,a,[role=button],input[type=submit],input[type=button],label,[onclick]')];
      return cand.find(e => ((e.innerText || e.value || e.getAttribute('aria-label') || '')).toLowerCase().trim().includes(t)) || null;
    }
    function typeInto(el, text) {
      el.focus();
      if (el.isContentEditable) { if (!document.execCommand('insertText', false, text)) { el.textContent = text; el.dispatchEvent(new Event('input', { bubbles: true })); } }
      else { const p = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; const s = Object.getOwnPropertyDescriptor(p, 'value'); if (s && s.set) s.set.call(el, text); else el.value = text; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); }
    }
    async function loop() {
      const goal = goalI.value.trim(); if (!goal) { L('Enter a goal for autopilot.'); return; }
      running = true; runB.style.display = 'none'; stopB.style.display = ''; const history = [];
      for (let step = 0; step < 12 && running; step++) {
        const cap = await send('mlsAssistCapture');
        const pageText = (document.body.innerText || '').slice(0, 9000);
        const resp = await send('mlsAssistAgentStep', { goal, pageText, screenshot: (cap && cap.dataUrl) || '', history });
        if (!resp || resp.error) { L('Agent: ' + ((resp && resp.error) || 'no response')); break; }
        const a = resp.action || {}; if (resp.reasoning) L(String(resp.reasoning).slice(0, 100));
        history.push({ type: a.type, target: a.target });
        if (a.type === 'done') { L('✓ Autopilot finished.'); break; }
        if (a.type === 'confirm') { L('⚠ Agent wants to commit ("' + (a.target || '') + '"). You do that one — paused for safety.'); break; }
        if (a.type === 'ask') { L('Agent needs you: ' + (a.target || a.reasoning || '')); break; }
        if (a.type === 'click') { const el = findEl(a.target); if (el) { el.scrollIntoView({ block: 'center' }); el.click(); L('Clicked: ' + (a.target || '')); } else { L('Could not find: ' + (a.target || '')); } }
        else if (a.type === 'type') { const el = findEl(a.target) || document.activeElement; if (el) { typeInto(el, a.text || ''); L('Typed into: ' + (a.target || 'field')); } }
        else if (a.type === 'scroll') { window.scrollBy(0, 600); L('Scrolled.'); }
        else if (a.type === 'read') { L('Read the screen.'); }
        await new Promise(r => setTimeout(r, 1300));
      }
      running = false; runB.style.display = ''; stopB.style.display = 'none';
    }
    runB.addEventListener('click', loop);
    stopB.addEventListener('click', () => { running = false; L('Stopped by you.'); });
  }
})();
