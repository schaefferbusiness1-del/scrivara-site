// MLS Assist — background worker. Only place that holds the API key + talks to MLS.
const DEFAULT_BACKEND = 'https://scrivara-backend.onrender.com';
function getCfg() { return new Promise(r => chrome.storage.local.get(['mlsBackend', 'mlsKey'], r)); }
async function callBackend(path, body) {
  const c = await getCfg();
  const base = (c.mlsBackend || DEFAULT_BACKEND).replace(/\/+$/, '');
  const key = (c.mlsKey || '').trim();
  if (!key) return { error: 'No API key set. Click the MLS Assist toolbar icon to add your key.' };
  try {
    const r = await fetch(base + path, {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    let d = {}; try { d = await r.json(); } catch (e) {}
    if (!r.ok) return { error: d.error || ('Request failed (HTTP ' + r.status + ')') };
    return d;
  } catch (e) { return { error: 'Network error: ' + e.message }; }
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  if (msg.type === 'mlsAssistGenerate') { callBackend('/api/assist/note', { transcript: msg.transcript }).then(sendResponse); return true; }
  if (msg.type === 'mlsAssistAgentStep') { callBackend('/api/assist/agent-step', { goal: msg.goal, pageText: msg.pageText, screenshot: msg.screenshot, history: msg.history }).then(sendResponse); return true; }
  if (msg.type === 'mlsAssistExtract') { callBackend('/api/assist/extract', { pageText: msg.pageText, url: msg.url }).then(sendResponse); return true; }
  // Read the innerText of whatever tab is ACTIVE right now (so the agent sees the
  // tab it is currently on, even after a tab switch).
  if (msg.type === 'mlsAssistPageText') {
    (async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) return sendResponse({ text: '' });
        const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => (document.body && document.body.innerText || '').slice(0, 9000) });
        sendResponse({ text: (r && r.result) || '', url: tab.url, title: tab.title });
      } catch (e) { sendResponse({ text: '' }); }
    })();
    return true;
  }
  // Execute a single agent action on the ACTIVE tab (or switch tabs). This lets the
  // autopilot act on whatever tab it is on, including after switching.
  if (msg.type === 'mlsAssistExec') {
    (async () => {
      try {
        const action = msg.action || {};
        if (action.type === 'switchtab') {
          const tabs = await chrome.tabs.query({});
          const t = String(action.target || '').toLowerCase().trim();
          const http = tabs.filter(x => /^https?:/.test(x.url || ''));
          let tab = t ? http.find(x => ((x.title || '').toLowerCase().includes(t) || (x.url || '').toLowerCase().includes(t))) : null;
          if (!tab) { const others = http.filter(x => !x.active).sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0)); tab = others[0]; }
          if (!tab) return sendResponse({ ok: false, msg: 'No other tab to switch to.' });
          await chrome.tabs.update(tab.id, { active: true });
          try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (e) {}
          return sendResponse({ ok: true, msg: 'Switched to: ' + (tab.title || tab.url || 'tab') });
        }
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) return sendResponse({ ok: false, msg: 'No active tab.' });
        const [r] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          args: [action],
          func: (act) => {
            function findEl(target) {
              if (!target) return null;
              try { const el = document.querySelector(target); if (el) return el; } catch (e) {}
              const t = String(target).toLowerCase().trim();
              const cand = [...document.querySelectorAll('button,a,[role=button],input,textarea,select,label,[onclick],[contenteditable=""],[contenteditable="true"]')];
              return cand.find(e => ((e.innerText || e.value || (e.getAttribute && (e.getAttribute('aria-label') || e.getAttribute('title') || e.getAttribute('placeholder'))) || '') + '').toLowerCase().includes(t)) || null;
            }
            function typeInto(el, text) {
              try { el.focus(); } catch (e) {}
              if (el.isContentEditable) { if (!document.execCommand('insertText', false, text)) { el.textContent = text; el.dispatchEvent(new Event('input', { bubbles: true })); } }
              else { const p = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; const s = Object.getOwnPropertyDescriptor(p, 'value'); if (s && s.set) s.set.call(el, text); else el.value = text; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); }
            }
            function setSelectByText(sel, text) {
              const t = String(text || '').toLowerCase().trim();
              const opt = [...sel.options].find(o => ((o.textContent || '').toLowerCase().trim().includes(t)) || ((o.value || '').toLowerCase().trim() === t));
              if (!opt) return false;
              sel.value = opt.value; sel.dispatchEvent(new Event('input', { bubbles: true })); sel.dispatchEvent(new Event('change', { bubbles: true })); return true;
            }
            const a = act || {};
            if (a.type === 'select') {
              const t = String(a.target || '').toLowerCase().trim();
              let sel = null;
              try { const q = document.querySelector(a.target); if (q && q.tagName === 'SELECT') sel = q; } catch (e) {}
              if (!sel) sel = [...document.querySelectorAll('select')].find(s => (((s.id || '') + ' ' + (s.name || '') + ' ' + (s.getAttribute('aria-label') || '') + ' ' + (s.getAttribute('title') || '')).toLowerCase().includes(t)));
              if (!sel) sel = [...document.querySelectorAll('select')].find(s => [...s.options].some(o => (o.textContent || '').toLowerCase().includes(String(a.text || '').toLowerCase().trim())));
              if (!sel) return { ok: false, msg: 'No dropdown found for: ' + (a.target || '') };
              return setSelectByText(sel, a.text) ? { ok: true, msg: 'Set ' + (a.target || 'dropdown') + ' to ' + (a.text || '') } : { ok: false, msg: 'Option not found: ' + (a.text || '') };
            }
            if (a.type === 'click' || a.type === 'confirm') {
              const el = findEl(a.target);
              if (!el) {
                const t = String(a.target || '').toLowerCase().trim();
                for (const s of document.querySelectorAll('select')) { const o = [...s.options].find(o => (o.textContent || '').toLowerCase().trim().includes(t)); if (o) { s.value = o.value; s.dispatchEvent(new Event('input', { bubbles: true })); s.dispatchEvent(new Event('change', { bubbles: true })); return { ok: true, msg: 'Selected option: ' + (a.target || '') }; } }
                return { ok: false, msg: 'Could not find: ' + (a.target || '') };
              }
              el.scrollIntoView({ block: 'center' }); el.click(); return { ok: true, msg: 'Clicked: ' + (a.target || '') };
            }
            if (a.type === 'type') {
              const el = findEl(a.target) || document.activeElement;
              if (!el) return { ok: false, msg: 'No field to type into.' };
              if (el.tagName === 'SELECT') return setSelectByText(el, a.text) ? { ok: true, msg: 'Selected ' + (a.text || '') + ' in ' + (a.target || 'dropdown') } : { ok: false, msg: 'Option not found in dropdown.' };
              typeInto(el, a.text || ''); return { ok: true, msg: 'Typed into: ' + (a.target || 'field') };
            }
            if (a.type === 'scroll') { window.scrollBy(0, 600); return { ok: true, msg: 'Scrolled.' }; }
            if (a.type === 'read') { return { ok: true, msg: 'Read the screen.' }; }
            return { ok: false, msg: 'Unknown action.' };
          }
        });
        sendResponse((r && r.result) || { ok: false, msg: 'No result.' });
      } catch (e) { sendResponse({ ok: false, msg: 'Action failed: ' + e.message }); }
    })();
    return true;
  }
  if (msg.type === 'mlsAppCaptureRequest') {
    (async () => {
      try {
        const tabs = await chrome.tabs.query({});
        const cands = tabs.filter(t => /^https?:/.test(t.url || '') && !/mlsscribe\.com/.test(t.url || ''));
        cands.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
        const tab = cands[0];
        if (!tab) return sendResponse({ error: 'No EMR tab is open. Open the patient in your EMR in another tab, then try again.' });
        let pageText = '';
        try {
          const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => (document.body && document.body.innerText || '').slice(0, 20000) });
          pageText = (r && r.result) || '';
        } catch (e) { return sendResponse({ error: 'Could not read the EMR tab (' + e.message + ').' }); }
        if (!pageText.trim()) return sendResponse({ error: 'The EMR tab had no readable text.' });
        const res = await callBackend('/api/assist/extract', { pageText, url: tab.url });
        sendResponse(Object.assign({ fromTab: tab.url }, res));
      } catch (e) { sendResponse({ error: 'Capture failed: ' + e.message }); }
    })();
    return true;
  }
  if (msg.type === 'mlsAssistCapture') {
    try { chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: 'png' }, (dataUrl) => sendResponse({ dataUrl: dataUrl || '' })); }
    catch (e) { sendResponse({ dataUrl: '' }); }
    return true;
  }
});
