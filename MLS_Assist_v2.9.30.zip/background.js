/* MLS_TOP_ERROR_TRAP (wet-1.1.0, 2026-07-17 schedule lane)  FIRST statement of the worker.
 * The v2.9.26 AllVisits run and the v2.9.27 write probe both killed the service worker and
 * left it BOOT-LOOPING with no log (only a chrome://extensions Reload  which clears session
 * storage  revived it). Registering the error listeners before ANY other code means even a
 * top-level evaluation crash is persisted to chrome.storage.local (mlsWorkerErrorLogV1) and
 * surfaced through the mlsExtHealth verb. PHI-free; never throws; never blocks. */
try {
  var __mlsTrapWrite = function (kind, message, stackHead) {
    try {
      chrome.storage.local.get('mlsWorkerErrorLogV1', function (bag) {
        try {
          var log = (bag && Array.isArray(bag.mlsWorkerErrorLogV1)) ? bag.mlsWorkerErrorLogV1 : [];
          log.push({ at: Date.now(), kind: String(kind).slice(0, 30), message: String(message == null ? '' : message).slice(0, 300), stack: String(stackHead == null ? '' : stackHead).slice(0, 400) });
          while (log.length > 16) log.shift();
          chrome.storage.local.set({ mlsWorkerErrorLogV1: log });
        } catch (eTrapInner) {}
      });
    } catch (eTrapOuter) {}
  };
  var __mlsTrapHead = function (stack) {
    try { return String(stack || '').split(String.fromCharCode(10)).slice(0, 5).join(' | '); } catch (e) { return ''; }
  };
  self.addEventListener('error', function (ev) {
    try { __mlsTrapWrite('error', (ev && ev.message) + ' @' + (ev && ev.filename ? String(ev.filename).split('/').pop() : '?') + ':' + (ev && ev.lineno), __mlsTrapHead(ev && ev.error && ev.error.stack)); } catch (e) {}
  });
  self.addEventListener('unhandledrejection', function (ev) {
    try { var r = ev && ev.reason; __mlsTrapWrite('unhandledrejection', r && (r.message || r), __mlsTrapHead(r && r.stack)); } catch (e) {}
  });
  __mlsTrapWrite('boot', 'worker evaluation started v' + ((chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '?'), '');
} catch (eTrapSetup) {}
try { importScripts('feat_codes_driver.js'); } catch (e) {}
try { importScripts('write_safety_guard.js', 'teach_destination_memory.js'); } catch (e) {} /* wsg-1.0.0 + tdm-1.0.0; a load failure fail-closes final actions at the gate below */
function mlsHostOnly(u){ try { return new URL(u).hostname; } catch (e) { return ''; } }
function mlsIsAthenaTab(t) {
  try { return !!(t && /(^|\.)athenanet\.athenahealth\.com$/i.test(new URL(t.url || '').hostname)); } catch (e) { return false; }
}
/* Read-side focus rail: a read may activate a tab only when that exact tab is
 * already the active tab in the focused Chrome window. A doctor deliberately
 * browsing another Athena tab owns that choice just as much as any other tab.
 * Reads may make Athena visible in the unfocused work strip, but they never
 * change the user's selection. Write paths intentionally do not call this. */
async function mlsReadFocusWouldYank(targetTabId) {
  try {
    var w = await chrome.windows.getLastFocused({ populate: true, windowTypes: ['normal'] });
    var tabs = (w && w.tabs) || [], cur = null;
    for (var i = 0; i < tabs.length; i++) { if (tabs[i] && tabs[i].active) { cur = tabs[i]; break; } }
    if (!w || w.focused !== true || !cur) return true;
    return !(targetTabId != null && cur.id === targetTabId);
  } catch (e) { return true; } /* fail closed: a read never guesses it may focus */
}
// MLS Assist — background worker. Only place that holds the API key + talks to MLS. (v1.7 robust executor)
const DEFAULT_BACKEND = 'https://scrivara-backend.onrender.com';
// Maps each global element #index → { frameId, localIndex } so the autopilot can
// read AND act inside iframes (e.g. athenaNet, which is heavily iframed). Rebuilt
// on every mlsAssistElements call, consumed by mlsAssistExec for #index targets.
const _mlsFrameMap = {};

/* ===========================================================================
 * v1.74 FOCUS GUARDIAN — never strand the doctor on athenaOne.
 * Every app-initiated operation that foregrounds a non-MLS tab records "focus
 * debt" (self.__mlsFgNote). The debt is repaid — focus returned to the MLS app
 * tab — by the FIRST of:
 *   1) the app's explicit end-of-op mlsAppFocusMlsTab, but only while the exact
 *      tab/window focus taken by the extension is still unchanged;
 *   2) the watchdog: debt present and the operation has gone quiet — 90s with
 *      no bridge traffic (a slow chart read can legitimately be silent ~70s,
 *      so never sooner; this is the every-path backstop for error/abort);
 *   3) a chrome.alarms backstop, so a sleeping service worker still repays.
 * Any user tab/window/app change cancels the return; the guardian never fights
 * a human. Read-only: activates tabs, clicks nothing.
 * =========================================================================== */
(function () {
  const FG = { debt: false, at: 0, appTabId: null, focusedTabId: null, focusedWindowId: null };
  self.__mlsFg = FG;
  /* Which mlsscribe tab is "the app"? v1.75: the review-finder page is ALSO on
     mlsscribe.com, so a bare host match could return the doctor to the WRONG
     page. Prefer, in order: the tab that asked (remembered as appTabId), the
     ScribeFlow app page, then any mlsscribe tab. */
  function pickAppTab(all) {
    const mine = all.filter((t) => { try { return /(^|\.)mlsscribe\.com$/i.test(new URL(t.url || '').host); } catch (e) { return false; } });
    if (!mine.length) return null;
    if (FG.appTabId != null) { const remembered = mine.find((t) => t.id === FG.appTabId); if (remembered) return remembered; }
    return mine.find((t) => /ScribeFlow/i.test(t.url || '')) || mine[0];
  }
  self.__mlsFgPickAppTab = pickAppTab;
  function clearDebt() {
    FG.debt = false; FG.focusedTabId = null; FG.focusedWindowId = null;
    try { chrome.storage.session.set({ mlsFgDebt: null }); } catch (e) {}
  }
  async function focusStillOwned() {
    if (!FG.debt || FG.focusedTabId == null) return false;
    try {
      const w = await chrome.windows.getLastFocused({ populate: true, windowTypes: ['normal'] });
      const tabs = (w && w.tabs) || [];
      const active = tabs.find((t) => t && t.active) || null;
      return !!(w && w.focused === true && active && active.id === FG.focusedTabId && (FG.focusedWindowId == null || w.id === FG.focusedWindowId));
    } catch (e) { return false; }
  }
  self.__mlsFgFocusStillOwned = focusStillOwned;
  async function fgFocusApp() {
    /* Repay only focus this extension demonstrably took and still owns. If the
       doctor changed tabs/windows meanwhile, that newer choice always wins. */
    if (!(await focusStillOwned())) { clearDebt(); return { ok: true, activated: false, skipped: 'user-moved' }; }
    try {
      const all = await chrome.tabs.query({});
      const app = pickAppTab(all);
      if (!app) { clearDebt(); return { ok: false, activated: false, skipped: 'no-app-tab' }; }
      if (!(await focusStillOwned())) { clearDebt(); return { ok: true, activated: false, skipped: 'user-moved' }; }
      await chrome.tabs.update(app.id, { active: true });
      if (app.windowId != null) await chrome.windows.update(app.windowId, { focused: true });
      clearDebt();
      return { ok: true, activated: true, tabId: app.id };
    } catch (e) { clearDebt(); return { ok: false, activated: false, error: String((e && e.message) || e) }; }
  }
  self.__mlsFgFocusApp = fgFocusApp;
  self.__mlsFgNote = function (senderTabId, focusedTabId, focusedWindowId) {
    FG.debt = true; FG.at = Date.now();
    if (senderTabId != null) FG.appTabId = senderTabId;
    FG.focusedTabId = focusedTabId == null ? null : focusedTabId;
    FG.focusedWindowId = focusedWindowId == null ? null : focusedWindowId;
    try { chrome.storage.session.set({ mlsFgDebt: { at: FG.at, appTabId: FG.appTabId, focusedTabId: FG.focusedTabId, focusedWindowId: FG.focusedWindowId } }); } catch (e) {}
    try { chrome.alarms.create('mlsFgWatch', { delayInMinutes: 1 }); } catch (e) {}
  };
  self.__mlsFgBump = function () { if (FG.debt) { FG.at = Date.now(); try { chrome.storage.session.set({ mlsFgDebt: { at: FG.at, appTabId: FG.appTabId, focusedTabId: FG.focusedTabId, focusedWindowId: FG.focusedWindowId } }); } catch (e) {} } };
  self.__mlsFgEnd = function () {
    clearDebt();
    FG.endAt = Date.now(); /* v1.89: lets the FocusMlsTab handler tell a straggler re-tap from a stale one */
  };
  setInterval(function () {
    if (!FG.debt) return;
    if (Date.now() - FG.at > 90000) fgFocusApp();
  }, 3000);
  try {
    chrome.alarms.onAlarm.addListener(function (a) {
      if (!a || a.name !== 'mlsFgWatch') return;
      try {
        chrome.storage.session.get(['mlsFgDebt'], function (st) {
          const d = st && st.mlsFgDebt;
          if (d && d.at) {
            FG.debt = true; FG.at = d.at; FG.appTabId = d.appTabId == null ? FG.appTabId : d.appTabId;
            FG.focusedTabId = d.focusedTabId == null ? null : d.focusedTabId;
            FG.focusedWindowId = d.focusedWindowId == null ? null : d.focusedWindowId;
          }
          if (d && d.at && (Date.now() - d.at) > 90000) fgFocusApp();
          else if (d && d.at) { try { chrome.alarms.create('mlsFgWatch', { delayInMinutes: 1 }); } catch (e) {} }
        });
      } catch (e) {}
    });
  } catch (e) {}
  try {
    chrome.tabs.onActivated.addListener(function (info) {
      try {
        chrome.tabs.get(info.tabId, function (t) {
          try { if (t && /(^|\.)mlsscribe\.com$/i.test(new URL(t.url || '').host)) clearDebt(); } catch (e) {}
        });
      } catch (e) {}
    });
  } catch (e) {}
  /* every OP-FAMILY bridge message = the op is still alive; refresh the quiet
     clock. v1.76: only 'mlsApp*' messages count (and never the FocusMlsTab
     return itself) — background chatter like the Settings module's 4-second
     mlsPing or the read-only mlsFgState probe must NOT hold the debt open,
     or the watchdog can never fire. Passive listener: returns undefined so it
     never interferes with the real handlers' sendResponse channels. */
  try {
    chrome.runtime.onMessage.addListener(function (m) {
      try {
        const ty = (m && m.type) || '';
        if (ty.indexOf('mlsApp') === 0 && ty !== 'mlsAppFocusMlsTab') { self.__mlsFgBump && self.__mlsFgBump(); self.__mlsQpTouch && self.__mlsQpTouch(); }
      } catch (e) {}
    });
  } catch (e) {}
})();

/* ATHENA_ACTION_V2_DRIVER_START */
/* A self-contained page driver for the supervised v2 Athena action contract.
 * It is injected once into the TOP frame and walks only same-origin descendants.
 * It never navigates, reloads, retries, submits charges, or chains actions. */
async function mlsAthenaActionV2DriverFn(req) {
  try {
    req = req || {};
    var mode = String(req.mode || 'probe');
    var action = String(req.action || '');
    var expectedPatient = req.expectedPatient || {};
    var expectedContext = req.expectedContext || {};
    var locked = req.locked || null;
    var taughtDestination = req.taughtDestination && typeof req.taughtDestination === 'object' ? req.taughtDestination : null;
    var billing = req.billing || {};
    var order = req.order || {};
    var mutationAttempted = false;
    var orderFinalActionAttempted = false;
    var sleep = function (ms) { return new Promise(function (resolve) { setTimeout(resolve, ms); }); };
    var ACTIONS = { write_note: 1, stage_billing: 1, save_draft: 1, sign_encounter: 1, place_order: 1 };
    if (!ACTIONS[action]) return { ok: false, blocked: true, reason: 'unknown-action' };
    /* MLS_WRITE_SAFETY_DRIVER_GUARD_START (wsg-1.0.0)  self-contained in-page
       defense in depth. The driver refuses to EXECUTE final/financial actions
       and clickOnce refuses ANY control whose own label or machine name marks a
       final/irrevocable action (sign, sign off, submit, send, approve, finalize,
       place order, prescribe, transmit, post charges, file claim...). This list
       mirrors write_safety_guard.js FORBIDDEN_LABEL_SOURCES / _ATTR_FRAGMENTS. */
    var WS_FORBIDDEN_LABELS = [/\bsign\b/, /\bsigns?\s+and\s+saves?\b/, /\bco\s?sign\b/, /\battest\b/, /\bsubmit\b/, /\bsend\b/, /\bapprove\b/, /\bfinali[sz]e\b/, /\bplace\s+orders?\b/, /\badd\s+orders?\b/, /\bprescribe\b/, /\be\s?(?:rx|prescribe|prescription)\b/, /\btransmit\b/, /\bpost\s+charges?\b/, /\bfile\s+claims?\b/, /\bsubmit\s+claims?\b/, /\bbill\s+(?:now|patient|insurance)\b/, /\bclose\s+encounter\b/, /\bdelete\s+(?:chart|patient|encounter)\b/];
    var WS_FORBIDDEN_ATTRS = ['signoff','sign-off','sign_off','signandsave','sign-and-save','sign_and_save','signsave','signencounter','sign-encounter','sign_encounter','placeorder','place-order','place_order','submitorder','submit-order','submit_order','sendorder','send-order','send_order','approveorder','approve-order','prescribe','e-rx','erx-send','sendrx','send-rx','transmitrx','transmit-rx','sendtopharmacy','send-to-pharmacy','finalizenote','finalize-note','finalize_note','postcharge','post-charge','post_charge','submitclaim','submit-claim','fileclaim','file-claim','closeencounter','close-encounter','mls-forbidden'];
    function wsForbiddenControl(el) {
      if (!el || el.nodeType !== 1) return false;
      var wsLabels = [];
      try { wsLabels = [el.textContent, el.value, el.getAttribute && el.getAttribute('aria-label'), el.getAttribute && el.getAttribute('title')].map(function (v) { return norm(v); }).filter(function (v) { return v && v.length <= 120; }); } catch (eWsL) {}
      for (var wsI = 0; wsI < wsLabels.length; wsI++) for (var wsJ = 0; wsJ < WS_FORBIDDEN_LABELS.length; wsJ++) if (WS_FORBIDDEN_LABELS[wsJ].test(wsLabels[wsI])) return true;
      var wsHay = '';
      try { wsHay = [el.id, el.getAttribute && el.getAttribute('name'), el.getAttribute && el.getAttribute('data-action'), el.getAttribute && el.getAttribute('data-testid'), String(el.className || '')].join(' ').toLowerCase(); } catch (eWsH) {}
      for (var wsK = 0; wsK < WS_FORBIDDEN_ATTRS.length; wsK++) if (wsHay.indexOf(WS_FORBIDDEN_ATTRS[wsK]) >= 0) return true;
      return false;
    }
    if (mode === 'execute' && (action === 'sign_encounter' || action === 'place_order' || action === 'stage_billing')) {
      return { ok: false, blocked: true, reason: 'write-safety-final-action-blocked', error: 'This action is preview-only by write-safety policy. Perform the final step yourself in athenaOne. Nothing was changed.' };
    }
    /* MLS_WRITE_SAFETY_DRIVER_GUARD_END */

    function text(v) { return String(v == null ? '' : v).replace(/\s+/g, ' ').trim(); }
    function norm(v) { return text(v).toLowerCase().replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, ' ').replace(/\s+/g, ' ').trim(); }
    function digits(v) { return String(v || '').replace(/\D/g, ''); }
    function dateKey(v) {
      var m = /([01]?\d)[\/\-.]([0-3]?\d)[\/\-.](\d{2,4})/.exec(String(v || ''));
      if (!m) return '';
      var y = m[3]; if (y.length === 2) y = (Number(y) > ((new Date().getFullYear() % 100) + 1) ? '19' : '20') + y;
      return Number(m[1]) + '/' + Number(m[2]) + '/' + y;
    }
    function dateSeen(body, want) {
      var k = dateKey(want); if (!k) return false;
      var p = k.split('/');
      var variants = [p[0] + '/' + p[1] + '/' + p[2], ('0' + p[0]).slice(-2) + '/' + ('0' + p[1]).slice(-2) + '/' + p[2], p[0] + '-' + p[1] + '-' + p[2], ('0' + p[0]).slice(-2) + '-' + ('0' + p[1]).slice(-2) + '-' + p[2]];
      var low = String(body || '').toLowerCase();
      for (var i = 0; i < variants.length; i++) if (low.indexOf(variants[i].toLowerCase()) >= 0) return true;
      return false;
    }
    function nameKey(v) {
      var raw = text(v), comma = /^\s*([^,]+),\s*(.+)$/.exec(raw);
      if (comma) raw = comma[2] + ' ' + comma[1];
      return norm(raw);
    }
    function noteNorm(v) {
      return String(v == null ? '' : v).replace(/\r\n?/g, '\n').replace(/\u00a0/g, ' ').split('\n').map(function (line) { return line.replace(/[ \t]+$/g, ''); }).join('\n').replace(/\n{3,}/g, '\n\n').trim();
    }
    function providerSeen(body, want) {
      var w = norm(want), b = norm(body);
      return w.length >= 3 && (' ' + b + ' ').indexOf(' ' + w + ' ') >= 0;
    }
    function stableHash(v) {
      var s = String(v || ''), h = 2166136261;
      for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
      return ('00000000' + (h >>> 0).toString(16)).slice(-8);
    }
    function visible(el, win) {
      try {
        if (!el || el.disabled || el.getAttribute('aria-hidden') === 'true') return false;
        var s = (win || window).getComputedStyle(el), r = el.getBoundingClientRect();
        return s.display !== 'none' && s.visibility !== 'hidden' && parseFloat(s.opacity || '1') > 0.05 && r.width > 2 && r.height > 2;
      } catch (e) { return false; }
    }
    function label(el) {
      try { return text((el.textContent || el.value || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '')); }
      catch (e) { return ''; }
    }
    function labelSources(el) {
      try { return [el.textContent, el.value, el.getAttribute('aria-label'), el.getAttribute('title')].map(text).filter(Boolean); }
      catch (e) { return []; }
    }
    function domPath(el) {
      var out = [], n = el, guard = 0;
      while (n && n.nodeType === 1 && guard++ < 8) {
        var part = String(n.tagName || '').toLowerCase();
        if (n.id) part += '#' + n.id;
        else if (n.getAttribute && n.getAttribute('data-testid')) part += '[data-testid=' + n.getAttribute('data-testid') + ']';
        else if (n.getAttribute && n.getAttribute('name')) part += '[name=' + n.getAttribute('name') + ']';
        out.unshift(part);
        if (n.parentElement) n = n.parentElement;
        else {
          try { var root = n.getRootNode && n.getRootNode(); n = root && root.host ? root.host : null; } catch (e) { n = null; }
        }
      }
      return out.join('>');
    }
    function controlFingerprint(el, frameUrl, kind) {
      /* Fingerprints authorize a DOM owner, never its mutable text/value. The
         note editor changes from empty to populated between Write and Sign. */
      var stableLabels = '';
      try { stableLabels = [el.getAttribute('aria-label') || '', el.getAttribute('title') || '', el.getAttribute('placeholder') || ''].map(norm).join('|'); } catch (e) {}
      return stableHash([kind, frameUrl, el.tagName, el.id || '', el.getAttribute('name') || '', el.getAttribute('data-testid') || '', stableLabels, domPath(el)].join('|'));
    }
    function encounterId(url) {
      var s = String(url || '');
      var m = /\/(?:encounter|visit|appointment)\/(\d{3,})/i.exec(s) || /(?:encounter|appointment|visit)(?:id)?[=\/](\d{3,})/i.exec(s);
      return m ? m[1] : '';
    }
    function appointmentIdFor(frame, actionRoot, identityRoot) {
      var values = {}, url = String(frame && frame.url || '');
      var fromUrl = /\/appointment\/(\d{3,})/i.exec(url) || /(?:appointment|appointmentid|appointment_id|apptid)[=\/:](\d{3,})/i.exec(url);
      if (fromUrl) values[fromUrl[1]] = 1;
      var roots = [actionRoot, identityRoot].filter(Boolean);
      for (var ri = 0; ri < roots.length; ri++) {
        var nodes = [roots[ri]];
        try { nodes = nodes.concat(deepQueryAll(roots[ri], '[data-appointment-id],[data-appointmentid],[data-appt-id],[appointmentid],a[href*="appointment"]')).slice(0, 500); } catch (eNodes) {}
        for (var ni = 0; ni < nodes.length; ni++) {
          var raw = '';
          try {
            raw = nodes[ni].getAttribute('data-appointment-id') || nodes[ni].getAttribute('data-appointmentid') ||
              nodes[ni].getAttribute('data-appt-id') || nodes[ni].getAttribute('appointmentid') || '';
            if (!raw) {
              var href = nodes[ni].getAttribute('href') || '';
              var hm = /\/appointment\/(\d{3,})/i.exec(href) || /(?:appointment|appointmentid|appointment_id|apptid)[=\/:](\d{3,})/i.exec(href);
              raw = hm ? hm[1] : '';
            }
          } catch (eAttr) {}
          raw = digits(raw); if (raw) values[raw] = 1;
        }
      }
      var ids = Object.keys(values);
      return ids.length === 1 ? ids[0] : '';
    }
    function sameOriginFrames() {
      var out = [];
      function walk(w, depth, path) {
        if (depth > 6) return;
        try { void w.document; out.push({ w: w, doc: w.document, url: String(w.location.href || ''), path: path }); } catch (e) { return; }
        for (var i = 0; i < w.frames.length; i++) {
          try { void w.frames[i].document; walk(w.frames[i], depth + 1, path + '.' + i); } catch (e2) {}
        }
      }
      walk(window, 0, 'top');
      return out;
    }
    function parentAcrossRoots(node) {
      if (!node) return null;
      if (node.parentElement) return node.parentElement;
      try { var root = node.getRootNode && node.getRootNode(); return root && root.host ? root.host : null; } catch (e) { return null; }
    }
    function deepContains(root, node) {
      var cur = node, guard = 0;
      while (cur && guard++ < 40) { if (cur === root) return true; cur = parentAcrossRoots(cur); }
      return false;
    }
    function closestAcrossRoots(node, selector, stopAt) {
      var cur = node, seen = new Set();
      while (cur && !seen.has(cur)) {
        seen.add(cur);
        try { if (cur.matches && cur.matches(selector)) return cur; } catch (e) {}
        if (cur === stopAt) break;
        cur = parentAcrossRoots(cur);
      }
      return null;
    }
    function deepQueryAll(root, selector) {
      var out = [], seen = new Set(), queued = new Set(), queue = [root];
      queued.add(root);
      while (queue.length) {
        var scope = queue.shift(), matches = [], all = [];
        /* A caller may hand us the custom-element host itself. Queue its open
           shadow root before looking at descendants, then drain every unique
           open root so nested web components cannot hide an action target. */
        var ownShadow = null; try { ownShadow = scope && scope.shadowRoot; } catch (eShadow) {}
        if (ownShadow && !queued.has(ownShadow)) { queued.add(ownShadow); queue.push(ownShadow); }
        try { if (scope.matches && scope.matches(selector)) matches.push(scope); } catch (e0) {}
        try { matches = matches.concat(Array.prototype.slice.call(scope.querySelectorAll(selector))); } catch (e1) {}
        for (var mi = 0; mi < matches.length; mi++) if (!seen.has(matches[mi])) { seen.add(matches[mi]); out.push(matches[mi]); }
        try { all = Array.prototype.slice.call(scope.querySelectorAll('*')); } catch (e2) {}
        for (var ai = 0; ai < all.length; ai++) {
          var shadow = null; try { shadow = all[ai].shadowRoot; } catch (e3) {}
          if (shadow && !queued.has(shadow)) { queued.add(shadow); queue.push(shadow); }
        }
      }
      return out;
    }
    function collapseContainedMatches(nodes) {
      return (nodes || []).filter(function (node, index, all) {
        for (var i = 0; i < all.length; i++) {
          if (i !== index && deepContains(node, all[i])) return false;
        }
        return true;
      });
    }
    function collapseToOutermostMatches(nodes) {
      return (nodes || []).filter(function (node, index, all) {
        for (var i = 0; i < all.length; i++) {
          if (i !== index && deepContains(all[i], node)) return false;
        }
        return true;
      });
    }
    function uniqueBy(values, keyFn) {
      var out = [], seen = {};
      for (var i = 0; i < values.length; i++) {
        var v = text(values[i]), k = keyFn(v); if (!k || seen[k]) continue;
        seen[k] = 1; out.push(v);
      }
      return out;
    }
    function valueOf(el, attrs) {
      if (!el) return '';
      for (var i = 0; i < attrs.length; i++) { try { var a = el.getAttribute(attrs[i]); if (text(a)) return text(a); } catch (e) {} }
      try { if (text(el.value)) return text(el.value); } catch (e2) {}
      return text(el.textContent);
    }
    /* ATHENA_ACTION_V2_PATIENT_HEADER_START */
    function identityRoots(frame) {
      var selector = [
        '[data-testid*="patient-header" i]','[data-testid*="patient-banner" i]','[data-testid*="patient-identity" i]','[data-testid*="patient-demographic" i]','[data-testid*="chart-header" i]',
        '[data-component*="patient-header" i]','[data-component*="patient-banner" i]','[data-component*="patient-identity" i]','[data-component*="chart-header" i]',
        '[aria-label*="patient header" i]','[aria-label*="patient banner" i]','[aria-label*="patient identity" i]','[aria-label*="patient demographic" i]','[aria-label*="chart header" i]',
        '#patient-header','#patientHeader','#patient-banner','#patientBanner','#chart-header','#chartHeader','.patient-header','.patientHeader','.patient-banner','.patientBanner','.patient-identity','.patient-demographics','.chart-header','.chartHeader'
      ].join(',');
      var raw = []; try { raw = deepQueryAll(frame.doc, selector); } catch (e) {}
      return raw.filter(function (el, idx) { return visible(el, frame.w) && raw.indexOf(el) === idx; });
    }
    function parseIdentity(root) {
      var names = [], dobs = [], ids = [], raw = '';
      try { raw = String(root.innerText || root.textContent || ''); } catch (e) {}
      function collect(selector, bucket, attrs) {
        var els = []; try { els = deepQueryAll(root, selector); } catch (e2) {}
        if (root.matches) try { if (root.matches(selector)) els.unshift(root); } catch (e3) {}
        for (var i = 0; i < els.length; i++) { var v = valueOf(els[i], attrs || []); if (v) bucket.push(v); }
      }
      collect('[data-patient-name],[data-testid*="patient-name" i],[aria-label^="patient name" i],[name="patientName" i]', names, ['data-patient-name','aria-label']);
      collect('[data-patient-dob],[data-testid*="patient-dob" i],[data-testid="dob" i],[aria-label*="date of birth" i],[aria-label^="dob" i]', dobs, ['data-patient-dob','aria-label']);
      collect('[data-patient-mrn],[data-patient-id],[data-testid*="patient-mrn" i],[data-testid*="patient-id" i],[data-testid*="medical-record" i],[aria-label*="medical record" i],[aria-label^="mrn" i],[aria-label^="patient id" i]', ids, ['data-patient-mrn','data-patient-id','aria-label']);
      try { if (text(root.getAttribute('data-patient-name'))) names.push(root.getAttribute('data-patient-name')); } catch (e4) {}
      try { if (text(root.getAttribute('data-patient-dob'))) dobs.push(root.getAttribute('data-patient-dob')); } catch (e5) {}
      try { if (text(root.getAttribute('data-patient-mrn'))) ids.push(root.getAttribute('data-patient-mrn')); } catch (e6) {}
      var m;
      var dobRe = /(?:^|\n|\|)\s*(?:dob|date\s+of\s+birth)\s*[:#\-]?\s*([01]?\d[\/\-.][0-3]?\d[\/\-.]\d{2,4})/ig;
      while ((m = dobRe.exec(raw)) && dobs.length < 12) dobs.push(m[1]);
      var idRe = /(?:^|\n|\|)\s*(?:mrn|medical\s+record\s+(?:number|no\.?|id)|patient\s*(?:id|number))\s*[:#\-]?\s*([A-Z0-9\-]{4,})/ig;
      while ((m = idRe.exec(raw)) && ids.length < 12) ids.push(m[1]);
      if (!names.length) {
        var nameRe = /(?:^|\n|\|)\s*patient\s+name\s*[:#\-]\s*([^\n|]{3,100})/ig;
        while ((m = nameRe.exec(raw)) && names.length < 6) names.push(m[1]);
      }
      if (!names.length) {
        var heads = []; try { heads = deepQueryAll(root, 'h1,h2,[role="heading"]'); } catch (e7) {}
        for (var hi = 0; hi < heads.length; hi++) { var hv = text(heads[hi].textContent); if (hv && hv.length <= 100 && !/\d/.test(hv)) names.push(hv); }
      }
      names = uniqueBy(names.map(function (v) { return text(v).replace(/^patient\s+name\s*[:#\-]?\s*/i, ''); }).filter(function (v) { return v.length >= 3 && !/\b(?:dob|date of birth|mrn|medical record)\b/i.test(v) && !/\d/.test(v); }), nameKey);
      dobs = uniqueBy(dobs.map(dateKey).filter(Boolean), dateKey);
      ids = uniqueBy(ids.map(digits).filter(function (v) { return v.length >= 4; }), digits);
      if (names.length !== 1 || dobs.length !== 1 || ids.length !== 1) return null;
      return { name: names[0], dob: dobs[0], mrn: ids[0], root: root };
    }
    function anchoredIdentity(frame) {
      var roots = identityRoots(frame);
      /* A repeated copy of the same demographics is still more than one
         possible chart-header owner. Do not collapse duplicate text across
         containers: one visible explicit header must own the identity. */
      if (roots.length !== 1) return { identity: null, ambiguous: roots.length > 1 };
      var parsed = parseIdentity(roots[0]);
      return parsed ? { identity: parsed, ambiguous: false } : { identity: null, ambiguous: false };
    }
    /* ATHENA_ACTION_V2_PATIENT_HEADER_END */
    function exactSave(el) {
      var raw = [];
      try { raw = [el.textContent, el.value, el.getAttribute && el.getAttribute('aria-label'), el.getAttribute && el.getAttribute('title')].filter(function (v) { return String(v || '').trim(); }); } catch (e) {}
      if (!raw.length) raw = [label(el)];
      var src = raw.map(norm);
      if (src.some(function (n) { return /\b(sign|submit|post|bill|charge|claim|delete|discard|void)\b/.test(n); })) return false;
      return src.some(function (n) { return n === 'save' || n === 'save draft' || n === 'save note'; });
    }
    function exactSign(el) {
      var raw = [];
      try { raw = [el.textContent, el.value, el.getAttribute && el.getAttribute('aria-label'), el.getAttribute && el.getAttribute('title')].filter(function (v) { return String(v || '').trim(); }); } catch (e) {}
      if (!raw.length) raw = [label(el)];
      var src = raw.map(norm);
      if (src.some(function (n) { return /\b(unsign|sign out|submit|post|bill|charge|claim|delete|discard|void)\b/.test(n); })) return false;
      return src.some(function (n) { return n === 'sign and save'; });
    }
    function exactPlaceOrder(el) {
      var raw = [];
      try { raw = [el.textContent, el.value, el.getAttribute && el.getAttribute('aria-label'), el.getAttribute && el.getAttribute('title')].filter(function (v) { return String(v || '').trim(); }); } catch (e) {}
      if (!raw.length) raw = [label(el)];
      var src = raw.map(norm);
      if (src.some(function (n) { return /\b(save|sign|submit|prescribe|e\s*rx|billing|bill|charge|claim|delete|remove|cancel|continue|next|finish|done|confirm)\b/.test(n); })) return false;
      return src.some(function (n) { return n === 'place order' || n === 'add order'; });
    }
    function interactive(doc, win) {
      return deepQueryAll(doc, 'button,[role="button"],input[type="button"],input[type="submit"]').filter(function (el) { return visible(el, win); });
    }
    function fieldHay(el) {
      var s = '';
      try {
        s = [el.id, el.name, el.placeholder, el.getAttribute('aria-label'), el.getAttribute('title'), el.getAttribute('data-testid')].join(' ');
        var p = el.parentElement, n = 0;
        while (p && n++ < 4) { s += ' ' + (p.getAttribute('aria-label') || '') + ' ' + (p.getAttribute('data-testid') || '') + ' ' + (p.id || '') + ' ' + String(p.className || ''); p = p.parentElement; }
      } catch (e) {}
      return norm(s);
    }
    function billingField(frame) {
      var els = deepQueryAll(frame.doc, 'input:not([type="hidden"]),textarea,[contenteditable="true"],[contenteditable="plaintext-only"]').filter(function (el) { return visible(el, frame.w); });
      var hits = els.filter(function (el) { return /\b(add charge|charge search|cpt|procedure code|billing code|superbill|e m level|level of service)\b/.test(fieldHay(el)); });
      if (hits.length !== 1) return { error: hits.length ? 'billing-duplicate-rejected' : 'billing-context-unverified' };
      var root = hits[0], p = hits[0], guard = 0;
      while (p && guard++ < 7) {
        var ph = norm((p.getAttribute && ((p.getAttribute('aria-label') || '') + ' ' + (p.getAttribute('data-testid') || '') + ' ' + (p.id || '') + ' ' + String(p.className || ''))) || '');
        if (/\b(billing|charges|superbill|claim charges)\b/.test(ph)) { root = p; break; }
        p = parentAcrossRoots(p);
      }
      if (root === hits[0]) return { error: 'billing-context-unverified' };
      return { el: hits[0], root: root };
    }
    function orderWorkspace(frame) {
      var selector = [
        '[data-testid="orders"]','[data-testid="order-entry"]','[data-testid="orders-workspace"]','[data-testid="order-workspace"]',
        '[data-component="orders"]','[data-component="order-entry"]','[data-component="orders-workspace"]',
        '[aria-label="Orders"]','[aria-label="Order entry"]','[aria-label="Orders workspace"]',
        '#orders','#order-entry','#orderEntry','.orders-workspace','.order-workspace','.order-entry'
      ].join(',');
      var roots = deepQueryAll(frame.doc, selector).filter(function (el) {
        if (!visible(el, frame.w)) return false;
        var d = scopeDescriptor(el);
        return /\border(?:s| entry| workspace)\b/.test(d) && !/\b(prescription|medication|e\s*rx|billing|charge|claim)\b/.test(d);
      });
      roots = collapseContainedMatches(roots);
      if (roots.length !== 1) return { error: roots.length ? 'order-workspace-duplicate-rejected' : 'order-workspace-unverified' };
      var root = roots[0];
      var controls = deepQueryAll(root, 'input:not([type="hidden"]),textarea,[contenteditable="true"],[contenteditable="plaintext-only"]').filter(function (el) {
        if (!visible(el, frame.w)) return false;
        var h = fieldHay(el);
        return /\border\b/.test(h) && /\b(search|catalog|find|add)\b/.test(h) && !/\b(prescription|medication|drug|billing|charge|claim|diagnosis)\b/.test(h);
      });
      if (controls.length !== 1) return { error: controls.length ? 'order-search-duplicate-rejected' : 'order-search-unverified' };
      return { root: root, search: controls[0] };
    }
    /* ATHENA_ACTION_V2_NOTE_SCOPE_START */
    function scopeDescriptor(el) {
      var out = '';
      try {
        out = [el.id, el.getAttribute('name'), el.getAttribute('aria-label'), el.getAttribute('data-testid'), el.getAttribute('data-component'), String(el.className || '')].join(' ');
        var heads = deepQueryAll(el, 'legend,h1,h2,h3,header,[role="heading"]').slice(0, 4);
        for (var i = 0; i < heads.length; i++) out += ' ' + text(heads[i].textContent);
      } catch (e) {}
      return norm(out);
    }
    function noteScopeStrength(el) {
      var h = scopeDescriptor(el);
      if (/\b(clinical|encounter|visit|progress|soap|chart)\s+(note|documentation)\b|\b(note|documentation)\s+(editor|form|workspace|panel)\b|\bdraft\s+note\b/.test(h)) return 3;
      if (/\bencounter\b/.test(h) && /\b(note|documentation|clinical)\b/.test(h)) return 3;
      if (/\b(note|documentation)\b/.test(h)) return 1;
      return 0;
    }
    function explicitNoteScopes(frame) {
      var selector = [
        '[data-testid*="encounter-note" i]','[data-testid*="encounter-documentation" i]','[data-testid*="note-container" i]','[data-testid*="note-editor" i]','[data-testid*="note-workspace" i]','[data-testid*="documentation-container" i]','[data-testid*="documentation-workspace" i]',
        '[data-component*="encounter-note" i]','[data-component*="encounter-documentation" i]','[data-component*="note-editor" i]','[data-component*="note-workspace" i]',
        '[aria-label*="encounter note" i]','[aria-label*="encounter documentation" i]','[aria-label*="clinical note" i]','[aria-label*="note editor" i]','[aria-label*="note workspace" i]',
        '#encounter-note','#encounterNote','#clinical-note','#clinicalNote','.encounter-note','.encounterNote','.clinical-note','.clinicalNote','.note-editor','.note-workspace','.documentation-container','.documentation-workspace'
      ].join(',');
      var scopes = []; try { scopes = deepQueryAll(frame.doc, selector); } catch (e) {}
      scopes = scopes.filter(function (el, idx) { return visible(el, frame.w) && noteScopeStrength(el) >= 3 && scopes.indexOf(el) === idx; });
      return scopes.length === 1 ? scopes : [];
    }
    function noteScopeAncestors(el) {
      var out = [], p = el && el.parentElement, guard = 0;
      while (p && guard++ < 12) {
        if (/^(FORM|SECTION|ARTICLE|FIELDSET|DIV|MAIN)$/.test(String(p.tagName || '')) || p.getAttribute('role') === 'form') {
          var strength = noteScopeStrength(p); if (strength >= 3) out.push({ root: p, strength: strength });
        }
        p = parentAcrossRoots(p);
      }
      return out;
    }
    function editorHay(el) {
      var h = fieldHay(el), p = el.parentElement, guard = 0;
      while (p && guard++ < 3) { h += ' ' + scopeDescriptor(p); p = p.parentElement; }
      return norm(h);
    }
    function editorsIn(root, frame) {
      var els = deepQueryAll(root, 'textarea,[contenteditable="true"],[contenteditable="plaintext-only"]').filter(function (el) { return visible(el, frame.w); });
      return els.filter(function (el) { return !/\b(search|find|lookup|filter|message|comment|chat|patient id|mrn|billing|charge|claim|order)\b/.test(editorHay(el)); });
    }
    function editorValue(el) {
      try { return noteNorm(el.isContentEditable ? el.innerText : el.value); } catch (e) { return ''; }
    }
    function editorFingerprint(el, frameUrl) { return controlFingerprint(el, frameUrl, 'note_editor'); }
    function noteTargetForControl(frame, control, allowGenericSave) {
      var scopes = noteScopeAncestors(control);
      for (var i = 0; i < scopes.length; i++) {
        var editors = editorsIn(scopes[i].root, frame);
        if (editors.length === 1 && (!allowGenericSave || scopes[i].strength >= 3)) return { control: control, editor: editors[0], root: scopes[i].root, strength: scopes[i].strength };
      }
      return null;
    }
    function findNoteAction(frame, action) {
      var noteContainers = explicitNoteScopes(frame);
      if (noteContainers.length !== 1) return null;
      var noteScope = noteContainers[0], noteEditors = editorsIn(noteScope, frame);
      if (noteEditors.length !== 1) return null;
      if (action === 'write_note') return { control: noteEditors[0], editor: noteEditors[0], root: noteScope, strength: noteScopeStrength(noteScope) };
      var all = interactive(noteScope, frame.w), preferred = [], generic = [], sign = [];
      for (var i = 0; i < all.length; i++) {
        if (action === 'sign_encounter' && exactSign(all[i])) { sign.push({ control: all[i], editor: noteEditors[0], root: noteScope, strength: noteScopeStrength(noteScope) }); continue; }
        if (action !== 'save_draft' || !exactSave(all[i])) continue;
        var sources = labelSources(all[i]).map(norm), isPreferred = sources.some(function (s) { return s === 'save draft' || s === 'save note'; });
        var target = { control: all[i], editor: noteEditors[0], root: noteScope, strength: noteScopeStrength(noteScope) };
        if (!isPreferred && target.strength < 3) continue;
        (isPreferred ? preferred : generic).push(target);
      }
      var pool = action === 'sign_encounter' ? sign : (preferred.length ? preferred : generic);
      return pool.length === 1 ? pool[0] : null;
    }
    /* A taught selector is only an additional exact anchor inside the typed
       action scope discovered above. It can never create a new generic write
       lane or bypass the patient/encounter/action checks. */
    function taughtSectionLabel(el, stopAt) {
      var own = '';
      try {
        own = text((el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '') + ' ' + (el.getAttribute('placeholder') || ''));
        if (!own && el.labels && el.labels.length === 1) own = text(el.labels[0].textContent);
      } catch (e) {}
      if (own && own.length <= 240) return own;
      var cur = el, guard = 0;
      while (cur && guard++ < 8) {
        var heads = []; try { heads = deepQueryAll(cur, ':scope > legend,:scope > h1,:scope > h2,:scope > h3,:scope > header,:scope > [role="heading"]'); } catch (e2) {}
        if (heads.length === 1) { var h = text(heads[0].textContent); if (h && h.length <= 240) return h; }
        if (cur === stopAt) break;
        cur = parentAcrossRoots(cur);
      }
      var fallback = label(el); return fallback.length <= 240 ? fallback : fallback.slice(0, 240);
    }
    function taughtQuery(frame, selector) {
      var parts = String(selector || '').split(/\s*>>>\s*/).filter(Boolean), scope = frame.doc, el = null;
      if (!parts.length || parts.length > 10) return null;
      for (var i = 0; i < parts.length; i++) {
        var hits = []; try { hits = Array.prototype.slice.call(scope.querySelectorAll(parts[i])); } catch (e) { return null; }
        if (hits.length !== 1) return null;
        el = hits[0];
        if (i < parts.length - 1) { try { scope = el.shadowRoot; } catch (e2) { scope = null; } if (!scope) return null; }
      }
      return el;
    }
    function validateTaughtDestination(frame, actionScope, actionControl, td) {
      if (!td || !text(td.selector)) return { ok: false, reason: 'taught-destination-required' };
      var selector = String(td.selector || ''), sectionLabel = text(td.sectionLabel), framePath = text(td.framePath), frameUrl = String(td.frameUrl || '').split('#')[0];
      var tag = text(td.tag).toLowerCase(), suppliedFingerprint = text(td.targetFingerprint);
      if (!selector || selector.length > 2000 || !sectionLabel || sectionLabel.length > 240 || !framePath || framePath.length > 100 || !suppliedFingerprint) return { ok: false, reason: 'taught-destination-invalid' };
      if (framePath !== frame.path || (frameUrl && frameUrl !== String(frame.url || '').split('#')[0])) return { ok: false, reason: 'taught-destination-frame-mismatch' };
      var target = taughtQuery(frame, selector);
      if (!target || !visible(target, frame.w) || !deepContains(actionScope, target)) return { ok: false, reason: 'taught-destination-selector-mismatch' };
      /* Teaching identifies the exact typed mutation control, not merely a
         heading, editor, Save button, or sibling somewhere in the same broad
         encounter section. SVG/icon clicks are canonicalized to their owning
         control by the watcher before the selector is created. */
      if (!actionControl || target !== actionControl) return { ok: false, reason: 'taught-destination-control-mismatch' };
      var observedTag = String(target.tagName || '').toLowerCase(), observedLabel = taughtSectionLabel(target, actionScope);
      if ((tag && tag !== observedTag) || norm(observedLabel) !== norm(sectionLabel)) return { ok: false, reason: 'taught-destination-label-mismatch' };
      var fingerprint = stableHash([frame.path, selector, sectionLabel, observedTag].join('|'));
      if (fingerprint !== suppliedFingerprint) return { ok: false, reason: 'taught-destination-fingerprint-mismatch' };
      return { ok: true, target: target, binding: { selector: selector, sectionLabel: sectionLabel, label: text(td.label || sectionLabel), framePath: frame.path, frameUrl: String(frame.url || '').split('#')[0], tag: observedTag, targetFingerprint: fingerprint } };
    }
    /* ATHENA_ACTION_V2_NOTE_SCOPE_END */
    /* ATHENA_ACTION_V2_SCOPED_STATUS_START */
    function statusElements(root) {
      if (!root || !root.querySelectorAll) return [];
      var selector = '[role="status"],[role="alert"],.toast,.notification,[data-testid*="status"],[data-testid*="success"]';
      var els = typeof deepQueryAll === 'function' ? deepQueryAll(root, selector) : Array.prototype.slice.call(root.querySelectorAll(selector));
      return els.filter(function (el) { return visible(el, el.ownerDocument && el.ownerDocument.defaultView); });
    }
    function statusEvidenceSnapshot(roots) {
      var baseline = new Map();
      for (var i = 0; i < roots.length; i++) {
        var els = statusElements(roots[i]);
        for (var j = 0; j < els.length; j++) baseline.set(els[j], norm(label(els[j])));
      }
      return baseline;
    }
    function newScopedStatus(before, roots, re) {
      for (var i = 0; i < roots.length; i++) {
        var els = statusElements(roots[i]);
        for (var j = 0; j < els.length; j++) {
          var now = norm(label(els[j]));
          /* A pre-existing status node changing text is not durable evidence:
             Athena reuses global/toast nodes. Require a newly created scoped
             node inside this exact note container or its action dialog. */
          if (re.test(now) && !before.has(els[j])) return true;
        }
      }
      return false;
    }
    /* ATHENA_ACTION_V2_SCOPED_STATUS_END */
    function canonicalContext(c) {
      return [nameKey(c.patientName), dateKey(c.dob), digits(c.mrn), digits(c.appointmentId), String(c.encounterId || ''), String(c.encounterUrl || ''), dateKey(c.visitDate), norm(c.provider), String(c.framePath || ''), String(c.encounterRootFingerprint || ''), String(c.controlFingerprint || ''), String(c.actionContainerFingerprint || ''), String(c.editorFingerprint || ''), String(c.taughtDestinationFingerprint || '')].join('|');
    }
    function discoverLabeled(doc, kind) {
      var found = {}, els = [];
      try { els = deepQueryAll(doc, 'label,dt,dd,th,td,[aria-label],[data-testid],section,fieldset,div,span'); } catch (e) {}
      for (var i = 0; i < els.length && i < 12000; i++) {
        var docView = doc.defaultView || (doc.ownerDocument && doc.ownerDocument.defaultView) || window;
        if (!visible(els[i], docView)) continue;
        var t = text((els[i].getAttribute && ((els[i].getAttribute('aria-label') || '') + ' ' + (els[i].getAttribute('data-testid') || ''))) + ' ' + (els[i].textContent || ''));
        if (!t || t.length > 260) continue;
        if (kind === 'date' && /\b(date of service|visit date|appointment date|encounter date|dos)\b/i.test(t)) {
          var d = dateKey(t); if (d) found[d] = d;
        }
        if (kind === 'provider' && /\b(rendering provider|visit provider|seen by|clinician|physician|provider)\b/i.test(t)) {
          var m = /\b(?:rendering provider|visit provider|seen by|clinician|physician|provider)\b\s*[:\-]?\s*([A-Za-z][A-Za-z'\.\-]+(?:\s+[A-Za-z][A-Za-z'\.\-,]+){1,5})/i.exec(t);
          if (m) {
            var v = text(m[1]).replace(/\s+(?:date of service|visit date|appointment date|encounter date|dos)\b.*$/i, '');
            if (norm(v).split(' ').length >= 2) found[norm(v)] = v;
          }
        }
      }
      return Object.keys(found).map(function (k) { return found[k]; });
    }
    function encounterMetadataFor(frame, actionRoot, identityRoot) {
      var root = actionRoot, guard = 0;
      while (root && guard++ < 18) {
        var tag = String(root.tagName || '').toUpperCase();
        if ((tag === 'BODY' || tag === 'HTML') || root === frame.doc.body || root === frame.doc.documentElement) break;
        if (deepContains(root, identityRoot)) {
          var descriptor = scopeDescriptor(root);
          if (/\b(encounter|visit|clinical|chart|documentation)\b/.test(descriptor)) {
            var dates = discoverLabeled(root, 'date'), providers = discoverLabeled(root, 'provider');
            if (dates.length === 1 && providers.length === 1) return { root: root, visitDate: dateKey(dates[0]), provider: text(providers[0]) };
          }
        }
        root = parentAcrossRoots(root);
      }
      return null;
    }

    function driverOrderContract(value) {
      value = value && typeof value === 'object' ? value : {};
      var type = norm(value.type).replace(/ /g, '_');
      var schemas = {
        imaging: { allowed: ['study','region','indication','laterality','contrast','notes'], required: ['study','region','indication'] },
        pt: { allowed: ['dx','freq','duration','modalities','notes'], required: ['dx','freq','duration','modalities'] },
        referral: { allowed: ['specialty','reason','notes'], required: ['specialty','reason'] },
        dme: { allowed: ['item','dx','icd','notes'], required: ['item','dx','icd'] }
      };
      var schema = schemas[type], fields = value.fields && typeof value.fields === 'object' ? value.fields : {};
      if (!schema) return { ok: false, reason: /^(medication|rx|injection|procedure)$/.test(type) ? 'high-risk-order-blocked' : 'unsupported-order-type' };
      var keys = Object.keys(fields), unknown = keys.filter(function (key) { return schema.allowed.indexOf(key) < 0 || !text(fields[key]); });
      if (unknown.length) return { ok: false, reason: 'unsupported-order-fields' };
      if (keys.some(function (key) { return String(fields[key] == null ? '' : fields[key]).length > 2000; })) return { ok: false, reason: 'order-field-too-long' };
      if (schema.required.some(function (key) { return !text(fields[key]); })) return { ok: false, reason: 'missing-order-fields' };
      if (!text(value.clientOrderId) || !text(value.displayLabel) || !text(value.query) || norm(value.reviewStatus) !== 'accepted') return { ok: false, reason: 'order-payload-incomplete' };
      if (!text(value.catalogCode) && !text(value.catalogId)) return { ok: false, reason: 'catalog-identity-required' };
      if (String(value.clientOrderId || '').length > 160 || String(value.displayLabel || '').length > 300 || String(value.query || '').length > 300 || String(value.catalogCode || '').length > 100 || String(value.catalogId || '').length > 160) return { ok: false, reason: 'order-field-too-long' };
      if (!/^(provider entered|ai suggestion accepted|rule suggestion accepted)$/.test(norm(value.source))) return { ok: false, reason: 'unsupported-order-source' };
      return { ok: true, order: value, schema: schema };
    }

    if (!text(expectedPatient.name) || !dateKey(expectedPatient.dob) || !digits(expectedPatient.mrn)) return { ok: false, blocked: true, reason: 'patient-mismatch', error: 'Expected patient name, DOB, and MRN are required.' };
    var reviewedNote = noteNorm(req.noteText), notePolicy = String(req.notePolicy || 'empty_only');
    var checkedOrder = action === 'place_order' ? driverOrderContract(order) : null;
    if (action === 'place_order' && !checkedOrder.ok) return { ok: false, blocked: true, reason: checkedOrder.reason, error: 'The reviewed order payload is incomplete or unsupported.' };
    if (mode !== 'teach' && action !== 'stage_billing' && action !== 'place_order' && !reviewedNote) return { ok: false, blocked: true, reason: 'note-content-required', error: 'The exact reviewed note text is required.' };
    if (mode !== 'teach' && action === 'write_note' && notePolicy !== 'empty_only') return { ok: false, blocked: true, reason: 'unsafe-note-policy', error: 'Only empty_only note placement is allowed.' };

    var frames = sameOriginFrames(), candidates = [], sawOtherPatient = false;
    for (var fi = 0; fi < frames.length; fi++) {
      var fr = frames[fi], eid = encounterId(fr.url);
      if (!eid) continue;
      var chartHeader = anchoredIdentity(fr), observedIdentity = chartHeader.identity;
      if (!observedIdentity || chartHeader.ambiguous) continue;
      if (nameKey(observedIdentity.name) !== nameKey(expectedPatient.name) || dateKey(observedIdentity.dob) !== dateKey(expectedPatient.dob)) { sawOtherPatient = true; continue; }
      var wantMrn = digits(expectedPatient.mrn);
      if (wantMrn && digits(observedIdentity.mrn) !== wantMrn) { sawOtherPatient = true; continue; }
      if (expectedContext.encounterUrl && String(expectedContext.encounterUrl).split('#')[0] !== String(fr.url).split('#')[0]) continue;
      if (expectedContext.encounterId && digits(expectedContext.encounterId) !== digits(eid)) continue;
      var noteTarget = null, billTarget = null, orderTarget = null;
      if (action === 'stage_billing') { billTarget = billingField(fr); if (!billTarget.el) continue; }
      else if (action === 'place_order') { orderTarget = orderWorkspace(fr); if (!orderTarget.search) continue; }
      else {
        noteTarget = findNoteAction(fr, action); if (!noteTarget) continue;
        var currentNote = editorValue(noteTarget.editor);
        if (mode !== 'teach') {
          if (action === 'write_note') { if (currentNote && currentNote !== reviewedNote) continue; }
          else if (currentNote !== reviewedNote) continue;
        }
      }
      var targetRoot = billTarget ? billTarget.root : (orderTarget ? orderTarget.root : noteTarget.root);
      var observedAppointmentId = appointmentIdFor(fr, targetRoot, observedIdentity.root);
      if (digits(expectedContext.appointmentId) && observedAppointmentId !== digits(expectedContext.appointmentId)) continue;
      var encounterMeta = encounterMetadataFor(fr, targetRoot, observedIdentity.root);
      if (!encounterMeta || !encounterMeta.visitDate || !encounterMeta.provider) continue;
      if (dateKey(expectedContext.visitDate) && encounterMeta.visitDate !== dateKey(expectedContext.visitDate)) continue;
      if (norm(expectedContext.provider) && norm(encounterMeta.provider) !== norm(expectedContext.provider)) continue;
      candidates.push({ frame: fr, observedIdentity: observedIdentity, appointmentId: observedAppointmentId, encounterId: eid, visitDate: encounterMeta.visitDate, provider: encounterMeta.provider, encounterRoot: encounterMeta.root, noteTarget: noteTarget, bill: billTarget, orderTarget: orderTarget });
    }
    if (candidates.length !== 1) return { ok: false, blocked: true, reason: candidates.length ? 'context-mismatch' : (mode === 'teach' && sawOtherPatient ? 'patient-mismatch' : 'context-unverified'), error: mode === 'teach' && sawOtherPatient ? 'The open Athena chart is not the patient in this review.' : 'Could not identify one exact patient encounter frame.' };
    var hit = candidates[0], observedPatient = hit.observedIdentity, noteScope = hit.noteTarget && hit.noteTarget.root, noteEditor = hit.noteTarget && hit.noteTarget.editor;
    var bill = hit.bill, orderTarget = hit.orderTarget, actionControl = bill ? bill.el : (orderTarget ? orderTarget.search : hit.noteTarget.control);
    var actionScope = bill ? bill.root : (orderTarget ? orderTarget.root : noteScope);
    var taughtValidation = null;
    if (taughtDestination && text(taughtDestination.selector)) {
      taughtValidation = validateTaughtDestination(hit.frame, actionScope, actionControl, taughtDestination);
      if (!taughtValidation.ok) return { ok: false, blocked: true, reason: taughtValidation.reason, error: 'The taught destination no longer resolves to this exact typed Athena action scope.' };
    } else if (mode === 'teach') {
      return { ok: false, blocked: true, reason: 'taught-destination-required', error: 'No exact Athena destination was captured.' };
    }
    var controlLabels = labelSources(actionControl).map(text).filter(Boolean);
    var controlFallback = '';
    try { controlFallback = text(actionControl.getAttribute('placeholder') || actionControl.getAttribute('name') || actionControl.getAttribute('data-testid') || ''); } catch (eLabel) {}
    if (!controlFallback) controlFallback = action === 'write_note' ? 'Encounter note editor' : (action === 'stage_billing' ? 'Athena Billing / Charges field' : (action === 'place_order' ? 'Athena Orders catalog search' : ''));
    var context = {
      mrn: digits(observedPatient.mrn),
      patientName: text(observedPatient.name),
      dob: dateKey(observedPatient.dob),
      appointmentId: hit.appointmentId,
      encounterId: hit.encounterId,
      encounterUrl: hit.frame.url,
      visitDate: hit.visitDate,
      provider: hit.provider,
      framePath: hit.frame.path,
      encounterRootFingerprint: controlFingerprint(hit.encounterRoot, hit.frame.url, 'encounter_root'),
      controlFingerprint: controlFingerprint(actionControl, hit.frame.url, action),
      noteScopeFingerprint: controlFingerprint(actionScope, hit.frame.url, 'action_scope'),
      actionContainerFingerprint: controlFingerprint(actionScope, hit.frame.url, 'action_scope'),
      editorFingerprint: noteEditor ? editorFingerprint(noteEditor, hit.frame.url) : controlFingerprint(actionControl, hit.frame.url, action === 'place_order' ? 'order_search' : 'billing_field'),
      controlLabel: controlLabels[0] || controlFallback,
      taughtDestinationFingerprint: taughtValidation ? taughtValidation.binding.targetFingerprint : '',
      taughtDestinationLabel: taughtValidation ? taughtValidation.binding.sectionLabel : ''
    };
    context.contextHash = stableHash(canonicalContext(context));
    if (locked && (String(locked.contextHash || '') !== context.contextHash || String(locked.encounterRootFingerprint || '') !== context.encounterRootFingerprint || String(locked.controlFingerprint || '') !== context.controlFingerprint || String(locked.noteScopeFingerprint || '') !== context.noteScopeFingerprint || String(locked.editorFingerprint || '') !== context.editorFingerprint || nameKey(locked.patientName) !== nameKey(context.patientName) || dateKey(locked.dob) !== dateKey(context.dob) || digits(locked.mrn) !== digits(context.mrn) || digits(locked.appointmentId) !== digits(context.appointmentId) || String(locked.encounterId || '') !== String(context.encounterId || ''))) {
      return { ok: false, blocked: true, reason: 'context-mismatch', context: context };
    }
    if (mode === 'teach') return { ok: true, mode: 'teach', action: action, readOnly: true, reason: 'taught-destination-validated', contextVerified: true, context: context, targetValidated: true, target: taughtValidation.binding, noAutomaticChaining: 'no-automatic-chaining' };
    /* ATHENA_ACTION_V2_PROBE_READ_ONLY_RETURN */
    if (mode === 'probe') return { ok: true, mode: 'probe', action: action, readOnly: true, reason: action === 'stage_billing' ? 'billing-context-verified' : (action === 'place_order' ? 'order-workspace-context-verified' : 'context-verified'), contextVerified: true, context: context, noAutomaticChaining: 'no-automatic-chaining' };
    if (mode !== 'execute') return { ok: false, blocked: true, reason: 'unknown-action' };
    /* ATHENA_ACTION_V2_MUTATION_BOUNDARY */

    function setNoteEditorExact(el, value) {
      try { el.focus(); } catch (e) {}
      try {
        if (el.isContentEditable) {
          el.textContent = value;
          try { el.dispatchEvent(new hit.frame.w.InputEvent('input', { bubbles: true, inputType: 'insertText', data: value })); } catch (e1) { el.dispatchEvent(new hit.frame.w.Event('input', { bubbles: true })); }
        } else {
          var proto = el.tagName === 'TEXTAREA' ? hit.frame.w.HTMLTextAreaElement.prototype : hit.frame.w.HTMLInputElement.prototype;
          var desc = Object.getOwnPropertyDescriptor(proto, 'value'); if (desc && desc.set) desc.set.call(el, value); else el.value = value;
          try { el.dispatchEvent(new hit.frame.w.InputEvent('input', { bubbles: true, inputType: 'insertText', data: value })); } catch (e2) { el.dispatchEvent(new hit.frame.w.Event('input', { bubbles: true })); }
        }
        el.dispatchEvent(new hit.frame.w.Event('change', { bubbles: true }));
      } catch (e3) { return false; }
      return true;
    }

    /* ATHENA_ACTION_V2_WRITE_NOTE_START */
    if (action === 'write_note') {
      var beforeNote = editorValue(noteEditor), alreadyExact = beforeNote === reviewedNote;
      if (beforeNote && !alreadyExact) return { ok: false, blocked: true, action: action, attempted: false, written: false, verified: false, draftEntered: false, draftVerified: false, reason: 'note-editor-not-empty', context: context, results: [{ key: 'note', attempted: false, written: false, verified: false, reason: 'note-editor-not-empty' }], noAutomaticChaining: 'no-automatic-chaining' };
      var noteAttempted = false;
      if (!alreadyExact) { noteAttempted = true; mutationAttempted = true; if (!setNoteEditorExact(noteEditor, req.noteText)) return { ok: false, action: action, attempted: true, written: false, verified: false, draftEntered: false, draftVerified: false, reason: 'outcome-uncertain', context: context, results: [{ key: 'note', attempted: true, written: false, verified: false, reason: 'note-write-unverified' }], noAutomaticChaining: 'no-automatic-chaining' }; await sleep(250); }
      var noteVerified = editorValue(noteEditor) === reviewedNote;
      if (!noteVerified) return { ok: false, action: action, attempted: noteAttempted, written: false, verified: false, draftEntered: noteAttempted, draftVerified: false, reason: 'outcome-uncertain', detail: 'note-write-unverified', context: context, results: [{ key: 'note', attempted: noteAttempted, written: false, verified: false, reason: 'note-write-unverified' }], noAutomaticChaining: 'no-automatic-chaining' };
      return { ok: true, action: action, attempted: noteAttempted, written: true, verified: true, draftEntered: true, draftVerified: true, reason: 'exact-note-editor-verified', context: context, results: [{ key: 'note', attempted: noteAttempted, written: true, verified: true, alreadyPresent: alreadyExact }], noAutomaticChaining: 'no-automatic-chaining' };
    }
    /* ATHENA_ACTION_V2_WRITE_NOTE_END */

    function exactCode(code) { return /^(?=[A-Z0-9]*\d)[A-Z0-9]{5}$/.test(String(code || '').trim().toUpperCase()); }
    function tokenRe(code) { return new RegExp('(^|[^A-Z0-9])' + String(code).toUpperCase().replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '([^A-Z0-9]|$)', 'i'); }
    function codeTokens(value) {
      var raw = String(value || '').toUpperCase().match(/\b(?=[A-Z0-9]*\d)[A-Z0-9]{5}\b/g) || [], out = [], seen = {};
      for (var i = 0; i < raw.length; i++) if (!seen[raw[i]]) { seen[raw[i]] = 1; out.push(raw[i]); }
      return out;
    }
    function codeOccurrenceCount(value, code) {
      var exact = String(code || '').trim().toUpperCase();
      if (!/^[A-Z0-9]{5}$/.test(exact)) return 0;
      var re = new RegExp('(^|[^A-Z0-9])' + exact + '(?=$|[^A-Z0-9])', 'gi'), count = 0;
      while (re.exec(String(value || ''))) count++;
      return count;
    }
    function metadataFieldSemantics(raw) {
      var s = String(raw || '').replace(/([a-z])([A-Z])/g, '$1 $2').replace(/[-_:.\[\]]+/g, ' ').toLowerCase();
      return /(?:^|[^a-z0-9])(?:modifier|mod|units?|qty|quantity|diagnosis|diagnoses|diag|dx|icd(?:9|10)?|pointer)(?:[^a-z]|[0-9]|$)/.test(s);
    }
    function activeMetadataDescriptor(raw) {
      var s = String(raw || '').replace(/([a-z])([A-Z])/g, '$1 $2').toLowerCase();
      if (/(?:modifier|mod)[^a-z0-9]*(?:[0-9]+|[a-z]{2}|[a-z][0-9]|[0-9][a-z]|active|applied|selected|true)\b/i.test(s)) return true;
      if (/(?:units?|qty|quantity)[^a-z0-9]*(?:[0-9]+|active|applied|selected|true)\b/i.test(s)) return true;
      if (/(?:diagnosis|diag|dx|icd(?:9|10)?|pointer)[^a-z0-9]*(?:[a-z][0-9][0-9a-z](?:\.[0-9a-z]{1,4}|[0-9a-z]{1,4})?|[a-z]|[0-9]+|active|applied|selected|true)\b/i.test(s)) return true;
      return /(?:active|applied|selected|true)[^a-z0-9]+(?:modifier|mod|units?|qty|quantity|diagnosis|diag|dx|icd(?:9|10)?|pointer)\b/i.test(s);
    }
    function metadataSemantics(raw, code) {
      var s = String(raw || ''), escaped = String(code || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      if (metadataFieldSemantics(s)) return true;
      var withoutRequestedCode = escaped ? s.replace(new RegExp('(^|[^A-Z0-9])' + escaped + '(?=$|[^A-Z0-9])', 'gi'), '$1 ') : s;
      if (/(?:^|[^A-Z0-9])[A-Z][0-9][0-9A-Z](?:\.[0-9A-Z]{1,4}|[0-9A-Z]{1,4})?(?=$|[^A-Z0-9])/i.test(withoutRequestedCode)) return true;
      if (/\b\d+\b/.test(withoutRequestedCode) || /(?:^|[^A-Za-z0-9])(?:[A-Z]|[A-Z][0-9]|[0-9][A-Z]|[A-Z]{2})(?=$|[^A-Za-z0-9])/.test(withoutRequestedCode)) return true;
      if (escaped && new RegExp(escaped + '\\s*(?:[,|/:-]\\s*[A-Z0-9]{1,2}\\b|\\(\\s*[A-Z0-9]{1,2}\\s*\\)|(?:[x\\u00d7]\\s*\\d+|\\d+\\s*[x\\u00d7])\\b|\\s+(?:\\d+|[A-Z]{1,2})\\b)', 'i').test(s)) return true;
      if (escaped && new RegExp('(?:\\(\\s*[A-Z0-9]{1,2}\\s*\\)|(?:^|[^A-Z0-9])(?:\\d+|[A-Z]{1,2}))\\s*' + escaped + '(?=$|[^A-Z0-9])', 'i').test(s)) return true;
      if (/(?:^|[^A-Z0-9])(?:x|\u00d7)\s*\d+\b/i.test(s)) return true;
      if (/\b\d+\s*(?:units?|qty|x|\u00d7)\b/i.test(s)) return true;
      if (/\b(?:dx|diagnosis|pointer)\s*[:#-]?\s*[A-TV-Z][0-9][0-9A-Z](?:\.[0-9A-Z]{1,4})?\b/i.test(s)) return true;
      return false;
    }
    function elementAttributes(el) {
      var attrs = [];
      try {
        for (var i = 0; i < el.attributes.length; i++) attrs.push([String(el.attributes[i].name || '').toLowerCase(), String(el.attributes[i].value || '')]);
      } catch (eAttrs) { attrs.push(['<unreadable>', '']); }
      attrs.sort(function (a, b) { var ak = a[0] + '\u0000' + a[1], bk = b[0] + '\u0000' + b[1]; return ak < bk ? -1 : (ak > bk ? 1 : 0); });
      return attrs;
    }
    function chargeRowStateKey(el, ignoredControl) {
      var parts = [], controls = [el].concat(deepQueryAll(el, '*')).filter(function (node) { return node !== ignoredControl; });
      for (var i = 0; i < controls.length; i++) {
        var c = controls[i], value = '', nodeText = '';
        try { if ('value' in c) value = String(c.value == null ? '' : c.value); } catch (eValue) { value = '<unreadable>'; }
        try { nodeText = String(c.textContent || ''); } catch (eText) { nodeText = '<unreadable>'; }
        try { parts.push(JSON.stringify([i, String(c.tagName || ''), elementAttributes(c), value, c.checked === true, c.selected === true, Number.isFinite(Number(c.selectedIndex)) ? Number(c.selectedIndex) : -1, nodeText])); }
        catch (eState) { parts.push(String(i) + '|unreadable'); }
      }
      return JSON.stringify(parts);
    }
    function chargeRowHasMetadata(el, code) {
      var rowSignals = '';
      try { rowSignals = [el.textContent, el.getAttribute('aria-label'), el.getAttribute('title')].join(' '); } catch (eRow) {}
      var metaNodes = [el].concat(deepQueryAll(el, '*'));
      for (var mi = 0; mi < metaNodes.length; mi++) {
        var node = metaNodes[mi], attrs = elementAttributes(node), descriptor = '', nodeValue = '';
        try { if ('value' in node) nodeValue = norm(node.value); } catch (eNodeValue) {}
        try { if (!nodeValue && node.children && node.children.length === 0) nodeValue = norm(node.textContent); } catch (eNodeText) {}
        for (var ai = 0; ai < attrs.length; ai++) {
          var attrName = attrs[ai][0], attrValue = norm(attrs[ai][1]);
          descriptor += ' ' + attrName + ' ' + attrs[ai][1];
          if (metadataFieldSemantics(attrName) && attrValue && !/^(none|select|choose|n a|not set|false|0)$/.test(attrValue)) return true;
          if (attrName === 'data-value' && attrValue) nodeValue = attrValue;
          if (/^(aria-label|title|data-testid|data-action|data-value)$/.test(attrName)) rowSignals += ' ' + attrs[ai][1];
        }
        if (activeMetadataDescriptor(descriptor)) return true;
        if (metadataFieldSemantics(descriptor) && (node.checked === true || node.selected === true || (nodeValue && !/^(none|select|choose|n a|not set|false|0)$/.test(nodeValue)))) return true;
      }
      if (metadataSemantics(rowSignals, code)) return true;
      var controls = deepQueryAll(el, 'input,select,textarea,[contenteditable="true"],[contenteditable="plaintext-only"]');
      for (var i = 0; i < controls.length; i++) {
        var c = controls[i], hay = fieldHay(c) + ' ' + elementAttributes(c).map(function (pair) { return pair.join(' '); }).join(' '), value = '';
        if (!metadataFieldSemantics(hay)) continue;
        try { value = norm(c.isContentEditable ? c.textContent : c.value); } catch (eValue) {}
        if (c.checked === true || c.selected === true || (value && !/^(none|select|choose|n a|not set)$/.test(value))) return true;
      }
      return false;
    }
    function persistedChargeRows(root, exclude) {
      var rows = deepQueryAll(root, 'tr,[role="row"],li,.charge-row,[data-testid*="charge"],[data-testid*="billing"]').filter(function (el) {
        if (!visible(el, hit.frame.w) || (exclude && deepContains(exclude, el))) return false;
        if (closestAcrossRoots(el, '[role="listbox"],[role="menu"],.dropdown,.autocomplete,.typeahead', root)) return false;
        return codeTokens(el.textContent).length > 0;
      });
      return collapseToOutermostMatches(rows);
    }
    function rowsIn(root, code, exclude) {
      var re = tokenRe(code);
      return persistedChargeRows(root, exclude).filter(function (el) { return re.test(text(el.textContent)); });
    }
    function chargeRowsSnapshot(root, exclude, requestedCode, ignoredControl) {
      return persistedChargeRows(root, exclude).map(function (el) { return { text: text(el.textContent), state: chargeRowStateKey(el, ignoredControl), codes: codeTokens(el.textContent), requestedOccurrences: codeOccurrenceCount(el.textContent, requestedCode), hasMetadata: chargeRowHasMetadata(el, requestedCode) }; });
    }
    function sameChargeRowState(before, after) {
      if (!Array.isArray(before) || !Array.isArray(after) || before.length !== after.length) return false;
      var beforeState = before.map(function (row) { return row.state; }).sort();
      var afterState = after.map(function (row) { return row.state; }).sort();
      return JSON.stringify(beforeState) === JSON.stringify(afterState);
    }
    async function stableChargeRows(root, exclude, requestedCode, ignoredControl) {
      var started = Date.now(), quietSince = started, last = chargeRowsSnapshot(root, exclude, requestedCode, ignoredControl), lastKey = JSON.stringify(last);
      while (Date.now() - started < 6000) {
        await sleep(250);
        var current = chargeRowsSnapshot(root, exclude, requestedCode, ignoredControl), key = JSON.stringify(current);
        if (key !== lastKey) { last = current; lastKey = key; quietSince = Date.now(); }
        if (Date.now() - started >= 3000 && Date.now() - quietSince >= 1000) return last;
      }
      return null;
    }
    function verifiedIsolatedCodeAdd(before, after, code) {
      if (!Array.isArray(before) || !Array.isArray(after) || after.length !== before.length + 1) return false;
      var addedIndex = -1;
      for (var i = 0; i < after.length; i++) {
        if (after[i].codes.indexOf(code) < 0) continue;
        if (addedIndex >= 0 || after[i].codes.length !== 1 || after[i].requestedOccurrences !== 1 || after[i].hasMetadata === true) return false;
        addedIndex = i;
      }
      if (addedIndex < 0) return false;
      var beforeState = before.map(function (row) { return row.state; }).sort();
      var afterState = after.filter(function (_, index) { return index !== addedIndex; }).map(function (row) { return row.state; }).sort();
      return JSON.stringify(beforeState) === JSON.stringify(afterState);
    }
    function setField(el, value) {
      try { el.focus(); } catch (e) {}
      var editable = false;
      try { editable = !!el.isContentEditable || /^(true|plaintext-only)$/i.test(String(el.getAttribute('contenteditable') || '')); } catch (eEditable) {}
      try {
        if (editable) el.textContent = '';
        else {
          var proto = el.tagName === 'TEXTAREA' ? hit.frame.w.HTMLTextAreaElement.prototype : hit.frame.w.HTMLInputElement.prototype;
          var desc = Object.getOwnPropertyDescriptor(proto, 'value'); if (desc && desc.set) desc.set.call(el, ''); else el.value = '';
        }
      } catch (e2) { try { if (editable) el.textContent = ''; else el.value = ''; } catch (e3) {} }
      /* Never dispatch `change` while discovering options: reactive billing
         widgets may treat it as a commit. Input events populate the picker; the
         verified option click below is the only commit operation. */
      try { el.dispatchEvent(new hit.frame.w.InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward', data: null })); } catch (eClear) { try { el.dispatchEvent(new hit.frame.w.Event('input', { bubbles: true })); } catch (eClear2) {} }
      for (var i = 0; i < value.length; i++) {
        var next = String(editable ? (el.textContent || '') : (el.value || '')) + value.charAt(i);
        try {
          if (editable) el.textContent = next;
          else { var p = el.tagName === 'TEXTAREA' ? hit.frame.w.HTMLTextAreaElement.prototype : hit.frame.w.HTMLInputElement.prototype; var d = Object.getOwnPropertyDescriptor(p, 'value'); if (d && d.set) d.set.call(el, next); else el.value = next; }
        } catch (e4) { if (editable) el.textContent = next; else el.value = next; }
        try { el.dispatchEvent(new hit.frame.w.InputEvent('input', { bubbles: true, inputType: 'insertText', data: value.charAt(i) })); } catch (e5) { el.dispatchEvent(new hit.frame.w.Event('input', { bubbles: true })); }
      }
    }

    /* ATHENA_ACTION_V2_ORDER_HELPERS_START */
    function orderIdentitySignals(el, wanted) {
      var labelSignals = [], catalogIds = [], codes = [], attrs = [];
      try {
        attrs = elementAttributes(el);
        labelSignals = [el.textContent, el.getAttribute('aria-label'), el.getAttribute('title'), el.getAttribute('data-label'), el.getAttribute('data-display-label')].map(text).filter(Boolean);
        var named = deepQueryAll(el, '[data-label],[data-display-label],[data-catalog-id],[data-order-id],[data-item-id],[data-catalog-code],[data-order-code],[data-code],[aria-label],h1,h2,h3,[role="heading"]').slice(0, 32);
        for (var ni = 0; ni < named.length; ni++) {
          labelSignals.push(text((named[ni].getAttribute && (named[ni].getAttribute('data-display-label') || named[ni].getAttribute('data-label') || named[ni].getAttribute('aria-label'))) || named[ni].textContent));
          attrs = attrs.concat(elementAttributes(named[ni]));
        }
        for (var i = 0; i < attrs.length; i++) {
          var key = attrs[i][0], value = text(attrs[i][1]);
          if (!value) continue;
          /* `data-order-id`/generic `data-id` identify a placed row instance,
             not necessarily the catalog item. Never confuse them with the
             durable catalog binding authorized by the clinician. */
          if (/^(data-catalog-id|data-catalog-item-id|data-item-id)$/.test(key)) catalogIds.push(value);
          if (/^(data-catalog-code|data-order-code|data-code|data-cpt|data-hcpcs)$/.test(key)) codes.push(value);
        }
        if (el.value && /^(OPTION)$/.test(String(el.tagName || ''))) catalogIds.push(text(el.value));
      } catch (e) {}
      var wantedCode = text(wanted && wanted.catalogCode), wantedId = text(wanted && wanted.catalogId);
      function cleanLabel(raw) {
        var out = text(raw).replace(/^\s*(?:select|choose|use|add)\s*[:\-]?\s*/i, '');
        if (wantedCode) out = out.replace(new RegExp('(^|[^A-Za-z0-9])' + wantedCode.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?=$|[^A-Za-z0-9])', 'ig'), '$1 ');
        if (wantedId) out = out.replace(new RegExp('(^|[^A-Za-z0-9])' + wantedId.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?=$|[^A-Za-z0-9])', 'ig'), '$1 ');
        return norm(out.replace(/[()\[\]]/g, ' '));
      }
      return { labels: labelSignals.map(cleanLabel).filter(Boolean), catalogIds: uniqueBy(catalogIds, norm).map(norm), codes: uniqueBy(codes, norm).map(norm) };
    }
    function exactCatalogOrderElement(el, wanted) {
      var signals = orderIdentitySignals(el, wanted), labelKey = norm(wanted && wanted.displayLabel);
      if (!labelKey || signals.labels.indexOf(labelKey) < 0) return false;
      var wantId = norm(wanted && wanted.catalogId), wantCode = norm(wanted && wanted.catalogCode);
      if (!wantId && !wantCode) return false;
      if (wantId && (signals.catalogIds.indexOf(wantId) < 0 || signals.catalogIds.some(function (v) { return v !== wantId; }))) return false;
      if (wantCode) {
        var raw = text((el && el.textContent) || ''), escaped = String(wanted.catalogCode).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        var rawHas = new RegExp('(^|[^A-Za-z0-9])' + escaped + '(?=$|[^A-Za-z0-9])', 'i').test(raw);
        if (signals.codes.length ? (signals.codes.indexOf(wantCode) < 0 || signals.codes.some(function (v) { return v !== wantCode; })) : !rawHas) return false;
      }
      return true;
    }
    function orderFieldValueKey(value) { return text(value).toLowerCase(); }
    function placedOrderFieldValues(el, type, key) {
      var aliases = uniqueBy(orderFieldAliases(type, key).concat([key]).map(norm), function (v) { return v; }), values = [], seenOccurrences = Object.create(null);
      function descriptorMatch(raw) {
        var d = norm(raw).replace(/^order (?:field )?/, '').replace(/^field /, '').replace(new RegExp('^' + type.replace(/_/g, ' ') + ' '), '').replace(/ (?:field|input|select|control)$/, '');
        return aliases.indexOf(d) >= 0;
      }
      function add(value, source) {
        value = text(value); if (!value) return;
        var occurrence = String(source || 'unknown') + '|' + orderFieldValueKey(value);
        if (!seenOccurrences[occurrence]) { seenOccurrences[occurrence] = 1; values.push(value); }
      }
      var nodes = [el].concat(deepQueryAll(el, 'input:not([type="hidden"]),textarea,select,[contenteditable="true"],[contenteditable="plaintext-only"],[data-order-field],[data-field],[data-value],dt,dd,th,td'));
      for (var i = 0; i < nodes.length; i++) {
        var node = nodes[i], descriptor = '', direct = '';
        try {
          descriptor = [node.getAttribute('data-order-field'), node.getAttribute('data-field'), node.name, node.id, node.getAttribute('aria-label'), node.getAttribute('title'), node.getAttribute('placeholder'), node.getAttribute('data-testid')].join(' ');
          var directNames = ['data-' + key.replace(/_/g, '-'), 'data-order-' + key.replace(/_/g, '-')];
            for (var ai = 0; ai < directNames.length; ai++) if (text(node.getAttribute(directNames[ai]))) add(node.getAttribute(directNames[ai]), 'node:' + i);
          if (node.id) {
            var ownedLabels = deepQueryAll(el, 'label[for="' + String(node.id).replace(/"/g, '\\"') + '"]');
            for (var li = 0; li < ownedLabels.length; li++) descriptor += ' ' + text(ownedLabels[li].textContent);
          }
          if (descriptorMatch(descriptor)) {
            if (String(node.tagName || '').toUpperCase() === 'SELECT') {
              var selected = node.options && node.selectedIndex >= 0 ? node.options[node.selectedIndex] : null;
              direct = selected ? (selected.value || selected.textContent) : node.value;
            } else if (node.isContentEditable) direct = node.textContent;
            else direct = node.getAttribute('data-value') || node.value || node.textContent;
            add(direct, 'node:' + i);
          }
          var ownText = text(node.textContent);
          if (descriptorMatch(ownText) && node.nextElementSibling) add(node.nextElementSibling.textContent, 'sibling:' + i);
        } catch (e) {}
      }
      var raw = ''; try { raw = String(el.innerText || el.textContent || ''); } catch (eRaw) {}
      var lines = raw.split(/[\r\n]+/);
      for (var a = 0; a < aliases.length; a++) {
        var escaped = aliases[a].replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s+');
        var re = new RegExp('^\\s*' + escaped + '\\s*[:\\-]\\s*(.+?)\\s*$', 'i');
        for (var ln = 0; ln < lines.length; ln++) { var match = re.exec(lines[ln]); if (match) add(match[1], 'line:' + ln); }
      }
      return values;
    }
    function exactPlacedOrderElement(el, wanted) {
      if (!exactCatalogOrderElement(el, wanted)) return false;
      var fields = wanted && wanted.fields && typeof wanted.fields === 'object' ? wanted.fields : {}, keys = Object.keys(fields).filter(function (key) { return text(fields[key]); }).sort();
      if (!keys.length) return false;
      for (var i = 0; i < keys.length; i++) {
        var values = placedOrderFieldValues(el, wanted.type, keys[i]), expected = orderFieldValueKey(fields[keys[i]]);
        if (values.length !== 1 || orderFieldValueKey(values[0]) !== expected) return false;
      }
      return true;
    }
    function exactOrderElement(el, wanted) { return exactPlacedOrderElement(el, wanted); }
    function oneExactOrderChoice(items, missingReason, duplicateReason) {
      items = Array.isArray(items) ? items : [];
      if (!items.length) return { ok: false, reason: missingReason };
      if (items.length !== 1) return { ok: false, reason: duplicateReason };
      return { ok: true, item: items[0] };
    }
    function existingExactOrderDecision(rows) {
      var matches = (Array.isArray(rows) ? rows : []).filter(function (row) { return row && row.exact; });
      if (matches.length > 1) return { ok: false, reason: 'order-existing-duplicate-rejected' };
      if (matches.length === 1) return { ok: true, alreadyPresent: true };
      return { ok: true, alreadyPresent: false };
    }
    function orderPickerFor(target) {
      var scope = null, owns = '';
      try { owns = target.search.getAttribute('aria-controls') || target.search.getAttribute('aria-owns') || ''; } catch (e) {}
      if (owns) try { scope = hit.frame.doc.getElementById(owns); } catch (e2) {}
      if (!scope) {
        var boxes = deepQueryAll(target.root, '[role="listbox"],[data-testid*="order-result" i],[data-testid*="catalog-result" i],.order-results,.catalog-results,.autocomplete,.typeahead').filter(function (el) { return visible(el, hit.frame.w); });
        boxes = collapseContainedMatches(boxes);
        if (boxes.length === 1) scope = boxes[0];
      }
      if (!scope || !visible(scope, hit.frame.w)) return { error: 'order-catalog-missing' };
      var descriptor = norm([scope.getAttribute && scope.getAttribute('role'), scope.getAttribute && scope.getAttribute('aria-label'), scope.getAttribute && scope.getAttribute('data-testid'), String(scope.className || '')].join(' '));
      if (!/\b(listbox|order result|catalog result|autocomplete|typeahead)\b/.test(descriptor)) return { error: 'order-catalog-unverified' };
      return { scope: scope };
    }
    function exactCatalogCandidate(target, wanted) {
      var pick = orderPickerFor(target); if (!pick.scope) return pick;
      var rows = deepQueryAll(pick.scope, '[role="option"],option,[data-testid*="order-result" i],[data-testid*="catalog-result" i],li,tr,[role="row"]').filter(function (el) {
        if (!visible(el, hit.frame.w) || !deepContains(pick.scope, el)) return false;
        var role = norm(el.getAttribute && el.getAttribute('role'));
        var descriptor = norm([label(el), el.getAttribute && el.getAttribute('data-testid'), el.getAttribute && el.getAttribute('data-action'), String(el.className || '')].join(' '));
        if (/\b(remove|delete|discard|void|replace|substitute|bundle|save|sign|submit|prescribe|billing|claim|place order|add order)\b/.test(descriptor)) return false;
        if (el.disabled || norm(el.getAttribute && el.getAttribute('aria-disabled')) === 'true' || norm(el.getAttribute && el.getAttribute('aria-selected')) === 'true') return false;
        return String(el.tagName || '').toUpperCase() === 'OPTION' || role === 'option' || /\b(order result|catalog result|option)\b/.test(descriptor);
      });
      /* Catalog search results have not received the clinician-entered order
         details yet. Bind that click to the exact durable catalog identity;
         the placed-row readback below separately requires every structured
         field to match. */
      rows = collapseContainedMatches(rows).filter(function (el) { return exactCatalogOrderElement(el, wanted); });
      var decision = oneExactOrderChoice(rows, 'order-catalog-near-match-rejected', 'order-catalog-duplicate-rejected');
      if (!decision.ok) return { error: decision.reason, scope: pick.scope };
      return { option: decision.item, scope: pick.scope, fingerprint: controlFingerprint(decision.item, hit.frame.url, 'order_catalog_option') };
    }
    function orderFieldAliases(type, key) {
      var aliases = {
        imaging: { study: ['study','imaging study','modality'], region: ['region','body region'], indication: ['indication','reason for exam'], laterality: ['laterality'], contrast: ['contrast'], notes: ['notes','order notes'] },
        pt: { dx: ['dx','diagnosis','associated diagnosis'], freq: ['frequency','freq'], duration: ['duration'], modalities: ['modalities','modalities goals','goals'], notes: ['notes','order notes'] },
        referral: { specialty: ['specialty','specialty provider','provider specialty'], reason: ['reason','referral reason'], notes: ['notes','order notes'] },
        dme: { item: ['item','dme item','equipment'], dx: ['dx','diagnosis','indication diagnosis'], icd: ['icd','icd 10'], notes: ['notes','order notes'] }
      };
      return aliases[type] && aliases[type][key] || [];
    }
    function exactOrderField(target, type, key) {
      var aliases = orderFieldAliases(type, key), controls = deepQueryAll(target.root, 'input:not([type="hidden"]),textarea,select,[contenteditable="true"],[contenteditable="plaintext-only"]').filter(function (el) {
        if (!visible(el, hit.frame.w) || el === target.search) return false;
        var signals = [];
        try {
          signals = [el.name, el.id, el.getAttribute('data-field'), el.getAttribute('aria-label'), el.getAttribute('title'), el.getAttribute('placeholder'), el.getAttribute('data-testid')].map(norm).filter(Boolean);
          if (el.id) {
            var labels = deepQueryAll(target.root, 'label[for="' + String(el.id).replace(/"/g, '\\"') + '"]');
            for (var i = 0; i < labels.length; i++) signals.push(norm(labels[i].textContent));
          }
        } catch (e) { return false; }
        signals = signals.map(function (s) {
          return s.replace(/^order (?:field )?/, '').replace(/^field /, '').replace(new RegExp('^' + type.replace(/_/g, ' ') + ' '), '').replace(/ (?:field|input|select|control)$/, '');
        });
        return aliases.some(function (a) { return signals.indexOf(norm(a)) >= 0; });
      });
      controls = collapseContainedMatches(controls);
      if (controls.length !== 1) return { error: controls.length ? 'order-field-duplicate-rejected' : 'order-required-field-missing', field: key };
      return { el: controls[0] };
    }
    function setOrderFieldExact(el, value) {
      value = text(value);
      if (String(el.tagName || '').toUpperCase() === 'SELECT') {
        var options = Array.prototype.slice.call(el.options || []).filter(function (opt) { return norm(opt.value) === norm(value) || norm(opt.textContent) === norm(value); });
        if (options.length !== 1) return false;
        try { el.value = options[0].value; el.dispatchEvent(new hit.frame.w.Event('input', { bubbles: true })); el.dispatchEvent(new hit.frame.w.Event('change', { bubbles: true })); } catch (e) { return false; }
        return norm(el.value) === norm(options[0].value);
      }
      setField(el, value);
      var got = ''; try { got = el.isContentEditable ? el.textContent : el.value; } catch (e2) {}
      try { el.dispatchEvent(new hit.frame.w.Event('change', { bubbles: true })); } catch (e3) {}
      return text(got) === value;
    }
    function persistedOrderRows(target, exclude) {
      var rows = deepQueryAll(target.root, '[data-testid*="order-row" i],[data-component*="order-row" i],.order-row,tr,[role="row"],li').filter(function (el) {
        if (!visible(el, hit.frame.w) || (exclude && deepContains(exclude, el)) || deepContains(el, target.search)) return false;
        if (closestAcrossRoots(el, '[role="listbox"],.autocomplete,.typeahead,.order-results,.catalog-results', target.root)) return false;
        var d = norm([el.getAttribute && el.getAttribute('data-testid'), el.getAttribute && el.getAttribute('data-component'), String(el.className || '')].join(' '));
        return /\border row\b/.test(d) || /\border\b/.test(d) || exactOrderElement(el, order);
      });
      return collapseToOutermostMatches(rows);
    }
    function orderRowState(el) {
      var parts = [], nodes = [el].concat(deepQueryAll(el, '*'));
      for (var i = 0; i < nodes.length; i++) {
        var n = nodes[i], val = ''; try { if ('value' in n) val = String(n.value == null ? '' : n.value); } catch (e) {}
        parts.push(JSON.stringify([String(n.tagName || ''), elementAttributes(n), val, n.checked === true, n.selected === true, String(n.textContent || '')]));
      }
      return JSON.stringify(parts);
    }
    function orderRowsSnapshot(target, exclude, wanted) {
      return persistedOrderRows(target, exclude).map(function (el) { return { state: orderRowState(el), exact: exactOrderElement(el, wanted) }; });
    }
    function sameOrderRows(before, after) {
      if (!Array.isArray(before) || !Array.isArray(after) || before.length !== after.length) return false;
      return JSON.stringify(before.map(function (r) { return r.state; }).sort()) === JSON.stringify(after.map(function (r) { return r.state; }).sort());
    }
    function verifiedIsolatedOrderAdd(before, after) {
      if (!Array.isArray(before) || !Array.isArray(after) || after.length !== before.length + 1) return false;
      if (before.some(function (r) { return r.exact; }) || after.filter(function (r) { return r.exact; }).length !== 1) return false;
      var added = -1;
      for (var i = 0; i < after.length; i++) if (after[i].exact) { if (added >= 0) return false; added = i; }
      var remaining = after.filter(function (_, index) { return index !== added; }).map(function (r) { return r.state; }).sort();
      return JSON.stringify(before.map(function (r) { return r.state; }).sort()) === JSON.stringify(remaining);
    }
    async function stableOrderRows(target, exclude, wanted) {
      var prior = null;
      for (var i = 0; i < 5; i++) {
        await sleep(i ? 350 : 700);
        var next = orderRowsSnapshot(target, exclude, wanted);
        if (prior && JSON.stringify(prior) === JSON.stringify(next)) return next;
        prior = next;
      }
      return null;
    }
    /* ATHENA_ACTION_V2_ORDER_HELPERS_END */

    /* ATHENA_ACTION_V2_PLACE_ORDER_START */
    if (action === 'place_order') {
      var wantedOrder = checkedOrder.order, beforeOrderRows = orderRowsSnapshot(orderTarget, null, wantedOrder);
      function uncertainOrderMutation(detail, field) {
        var result = { ok: false, attempted: true, verified: false, orderPlaced: false, partialMutation: true, reason: 'outcome-uncertain', detail: detail, context: context, noAutomaticChaining: 'no-automatic-chaining' };
        if (field) result.field = field;
        return result;
      }
      var existingDecision = existingExactOrderDecision(beforeOrderRows);
      if (!existingDecision.ok) return { ok: false, blocked: true, attempted: false, verified: false, orderPlaced: false, reason: existingDecision.reason, context: context, noAutomaticChaining: 'no-automatic-chaining' };
      if (existingDecision.alreadyPresent) return { ok: true, action: action, attempted: false, verified: true, orderPlaced: false, alreadyPresent: true, reason: 'order-exact-already-present', context: context, noAutomaticChaining: 'no-automatic-chaining' };
      setField(orderTarget.search, wantedOrder.query); await sleep(650);
      var candidate = exactCatalogCandidate(orderTarget, wantedOrder);
      var afterSearchRows = orderRowsSnapshot(orderTarget, candidate.scope || null, wantedOrder);
      if (!sameOrderRows(beforeOrderRows, afterSearchRows)) return { ok: false, attempted: false, verified: false, orderPlaced: false, reason: 'outcome-uncertain', detail: 'order-search-side-effect', context: context, noAutomaticChaining: 'no-automatic-chaining' };
      if (!candidate.option) return { ok: false, blocked: true, attempted: false, verified: false, orderPlaced: false, reason: candidate.error || 'order-catalog-unverified', context: context, noAutomaticChaining: 'no-automatic-chaining' };
      /* Selecting a catalog item can immediately create or mutate a draft
         order in Athena. Treat this as the first mutation boundary; after
         this point MLS may never claim that nothing was attempted. */
      mutationAttempted = true;
      try { candidate.option.click(); } catch (eCandidate) { return uncertainOrderMutation('order-catalog-selection-click-outcome-uncertain'); }
      await sleep(450);
      var selectedRows = orderRowsSnapshot(orderTarget, candidate.scope, wantedOrder);
      if (!sameOrderRows(beforeOrderRows, selectedRows)) return uncertainOrderMutation('order-catalog-selection-side-effect');
      var fieldKeys = Object.keys(wantedOrder.fields).sort();
      for (var ofi = 0; ofi < fieldKeys.length; ofi++) {
        var fieldKey = fieldKeys[ofi], fieldHit = exactOrderField(orderTarget, wantedOrder.type, fieldKey);
        if (!fieldHit.el) return uncertainOrderMutation(fieldHit.error, fieldKey);
        if (!setOrderFieldExact(fieldHit.el, wantedOrder.fields[fieldKey])) return uncertainOrderMutation('order-field-value-rejected', fieldKey);
      }
      await sleep(250);
      var beforePlaceRows = orderRowsSnapshot(orderTarget, candidate.scope, wantedOrder);
      if (!sameOrderRows(beforeOrderRows, beforePlaceRows)) return uncertainOrderMutation('order-form-side-effect');
      var placeControls = interactive(orderTarget.root, hit.frame.w).filter(function (el) { return exactPlaceOrder(el) && !deepContains(candidate.scope, el); });
      placeControls = collapseContainedMatches(placeControls);
      var placeDecision = oneExactOrderChoice(placeControls, 'order-place-control-missing', 'order-place-control-duplicate-rejected');
      if (!placeDecision.ok) return uncertainOrderMutation(placeDecision.reason);
      orderFinalActionAttempted = true;
      try { placeDecision.item.click(); } catch (ePlace) { return uncertainOrderMutation('order-place-click-outcome-uncertain'); }
      var afterPlaceRows = await stableOrderRows(orderTarget, candidate.scope, wantedOrder);
      if (!afterPlaceRows || !verifiedIsolatedOrderAdd(beforeOrderRows, afterPlaceRows)) return { ok: false, attempted: true, verified: false, orderPlaced: false, partialMutation: true, reason: 'outcome-uncertain', detail: !afterPlaceRows ? 'order-readback-not-stable' : (afterPlaceRows.filter(function (r) { return r.exact; }).length !== 1 ? 'order-exact-readback-missing-or-duplicate' : 'order-unrelated-row-change'), context: context, noAutomaticChaining: 'no-automatic-chaining' };
      return { ok: true, action: action, attempted: true, verified: true, orderPlaced: true, alreadyPresent: false, reason: 'one-exact-order-isolated-readback-verified', context: context, noAutomaticChaining: 'no-automatic-chaining' };
    }
    /* ATHENA_ACTION_V2_PLACE_ORDER_END */

    /* ATHENA_ACTION_V2_STAGE_BILLING_START */
    /* STAGE_BILLING_START */
    if (action === 'stage_billing') {
      var codes = [], em = text(billing.emCode), cp = Array.isArray(billing.cptCodes) ? billing.cptCodes : [];
      if (em) codes.push(em.toUpperCase()); for (var ci = 0; ci < cp.length; ci++) codes.push(text(cp[ci]).toUpperCase());
      if (!codes.length) return { ok: false, blocked: true, attempted: false, verified: false, staged: false, partialMutation: false, results: [], stagedCodes: [], failedCodes: [], reason: 'billing-context-unverified', error: 'No E/M or CPT codes were supplied.' };
      var seen = {};
      for (var vc = 0; vc < codes.length; vc++) {
        if (!exactCode(codes[vc])) return { ok: false, blocked: true, attempted: false, verified: false, staged: false, partialMutation: false, results: [], stagedCodes: [], failedCodes: [codes[vc]], reason: 'billing-near-match-rejected', code: codes[vc] };
        if (seen[codes[vc]]) return { ok: false, blocked: true, attempted: false, verified: false, staged: false, partialMutation: false, results: [], stagedCodes: [], failedCodes: [codes[vc]], reason: 'billing-duplicate-rejected', code: codes[vc] };
        seen[codes[vc]] = 1;
      }
      function billingOption(code) {
        var scope = null, owns = bill.el.getAttribute('aria-controls') || bill.el.getAttribute('aria-owns');
        if (owns) scope = hit.frame.doc.getElementById(owns);
        if (!scope) {
          var boxes = deepQueryAll(bill.root, '[role="listbox"],.dropdown,.autocomplete,.typeahead').filter(function (el) { return visible(el, hit.frame.w); });
          if (boxes.length === 1) scope = boxes[0];
        }
        if (!scope) return { error: 'billing-context-unverified' };
        var scopeContract = '';
        try { scopeContract = norm([scope.getAttribute('role'), scope.getAttribute('aria-label'), scope.getAttribute('data-testid'), String(scope.className || '')].join(' ')); } catch (eScope) {}
        if (!/\b(listbox|option|result|suggestion|dropdown|autocomplete|typeahead|code search|charge search)\b/.test(scopeContract)) return { error: 'billing-context-unverified' };
        var optionRows = deepQueryAll(scope, '[role="option"],li,tr,[role="row"],button').filter(function (el) { return visible(el, hit.frame.w); });
        function optionStateUnsafe(node) {
          try {
            return !!node.disabled || node.checked === true || node.selected === true ||
              norm(node.getAttribute && node.getAttribute('aria-disabled')) === 'true' ||
              norm(node.getAttribute && node.getAttribute('aria-selected')) === 'true' ||
              norm(node.getAttribute && node.getAttribute('aria-checked')) === 'true' ||
              norm(node.getAttribute && node.getAttribute('aria-pressed')) === 'true' ||
              norm(node.getAttribute && node.getAttribute('data-selected')) === 'true' ||
              /\b(selected|checked)\b/.test(norm(String(node.className || '')));
          } catch (eState) { return true; }
        }
        function optionSafetySignal(node) {
          try { return norm([label(node), node.getAttribute && node.getAttribute('aria-label'), node.getAttribute && node.getAttribute('title'), node.getAttribute && node.getAttribute('data-testid'), node.getAttribute && node.getAttribute('data-action'), String(node.className || '')].join(' ')); }
          catch (eSignal) { return ''; }
        }
        var exact = optionRows.filter(function (el) {
          var optionLabel = norm(label(el)), safetySignals = optionLabel;
          try {
            var owner = el, ownerSeen = new Set(), reachedScope = false;
            while (owner && !ownerSeen.has(owner)) {
              ownerSeen.add(owner);
              safetySignals += ' ' + optionSafetySignal(owner);
              if (optionStateUnsafe(owner)) return false;
              if (owner === scope) { reachedScope = true; break; }
              owner = parentAcrossRoots(owner);
            }
            if (!reachedScope) return false;
            var signalNodes = deepQueryAll(el, '[aria-label],[title],[data-testid],[data-action],[aria-selected],[aria-checked],[aria-pressed],[data-selected],input,option,button,[role="button"]');
            for (var si = 0; si < signalNodes.length; si++) { safetySignals += ' ' + optionSafetySignal(signalNodes[si]); if (optionStateUnsafe(signalNodes[si])) return false; }
          } catch (eSafety) { return false; }
          if (/\b(remove|delete|discard|void|unselect|undo|clear|cancel|save|sign|submit|post|file|claim|place order|replace|swap|substitute|bundle|package|instead|exchange|overwrite|merge|convert)\b/.test(safetySignals)) return false;
          var role = ''; try { role = norm(el.getAttribute('role')); } catch (eRole) {}
          var ownActionSignal = ''; try { ownActionSignal = norm([label(el), el.getAttribute('aria-label'), el.getAttribute('title'), el.getAttribute('data-action')].join(' ')); } catch (eOwn) {}
          var explicitlyUnselectedOption = role === 'option' && norm(el.getAttribute && el.getAttribute('aria-selected')) === 'false';
          var positiveOwner = explicitlyUnselectedOption || /\b(add|select|choose|use)\b/.test(ownActionSignal);
          var rawOptionParts = []; try { rawOptionParts = [el.textContent, el.getAttribute('aria-label'), el.getAttribute('title'), el.value, el.getAttribute('data-value')].filter(function (part) { return String(part || '').trim(); }); } catch (eRaw) { rawOptionParts = [String(el.textContent || '')]; }
          var rawOption = rawOptionParts.join(' '), optionOccurrenceSafe = rawOptionParts.every(function (part) { return codeOccurrenceCount(part, code) <= 1; });
          var optionCodes = codeTokens(rawOption);
          return positiveOwner && optionOccurrenceSafe && !metadataSemantics(rawOption + ' ' + safetySignals, code) && optionCodes.length === 1 && optionCodes[0] === code;
        });
        exact = collapseContainedMatches(exact);
        if (!exact.length) return { error: 'billing-near-match-rejected' };
        if (exact.length !== 1) return { error: 'billing-duplicate-rejected' };
        return { option: exact[0], scope: scope, fingerprint: controlFingerprint(exact[0], hit.frame.url, 'billing_option') };
      }
      /* ATHENA_ACTION_V2_BILLING_PREFLIGHT_START */
      var preflight = [], results = [];
      for (var pf = 0; pf < codes.length; pf++) {
        var preCode = codes[pf], existing = rowsIn(bill.root, preCode, null);
        if (existing.length > 1) return { ok: false, blocked: true, attempted: false, verified: false, staged: false, partialMutation: false, results: results, stagedCodes: [], failedCodes: [preCode], reason: 'billing-duplicate-rejected', code: preCode };
        if (existing.length === 1) {
          var existingCodes = codeTokens(existing[0].textContent);
          if (existingCodes.length !== 1 || existingCodes[0] !== preCode || codeOccurrenceCount(existing[0].textContent, preCode) !== 1 || chargeRowHasMetadata(existing[0], preCode)) return { ok: false, blocked: true, attempted: false, verified: false, staged: false, partialMutation: false, results: results, stagedCodes: [], failedCodes: [preCode], reason: 'billing-existing-row-ambiguous', code: preCode };
          preflight.push({ code: preCode, alreadyPresent: true }); continue;
        }
        var preInputRows = chargeRowsSnapshot(bill.root, null, preCode, bill.el);
        mutationAttempted = true;
        setField(bill.el, preCode); await sleep(650);
        var preOption = billingOption(preCode);
        var prePickerRows = chargeRowsSnapshot(bill.root, preOption.scope || null, preCode, bill.el);
        if (!sameChargeRowState(preInputRows, prePickerRows)) {
          setField(bill.el, '');
          return { ok: false, attempted: true, verified: false, staged: false, partialMutation: true, results: results, stagedCodes: [], failedCodes: codes.slice(pf), reason: 'outcome-uncertain', detail: 'billing-input-side-effect', code: preCode, context: context, noAutomaticChaining: 'no-automatic-chaining' };
        }
        if (!preOption.option) {
          setField(bill.el, ''); await sleep(300);
          var missingOptionClearRows = chargeRowsSnapshot(bill.root, null, preCode, bill.el);
          if (!sameChargeRowState(preInputRows, missingOptionClearRows)) return { ok: false, attempted: true, verified: false, staged: false, partialMutation: true, results: results, stagedCodes: [], failedCodes: codes.slice(pf), reason: 'outcome-uncertain', detail: 'billing-input-side-effect', code: preCode, context: context, noAutomaticChaining: 'no-automatic-chaining' };
          return { ok: false, blocked: true, attempted: false, verified: false, staged: false, partialMutation: false, results: results, stagedCodes: [], failedCodes: [preCode], reason: preOption.error || 'billing-context-unverified', code: preCode };
        }
        setField(bill.el, ''); await sleep(300);
        var preClearRows = chargeRowsSnapshot(bill.root, null, preCode, bill.el);
        if (!sameChargeRowState(preInputRows, preClearRows)) return { ok: false, attempted: true, verified: false, staged: false, partialMutation: true, results: results, stagedCodes: [], failedCodes: codes.slice(pf), reason: 'outcome-uncertain', detail: 'billing-input-side-effect', code: preCode, context: context, noAutomaticChaining: 'no-automatic-chaining' };
        preflight.push({ code: preCode, alreadyPresent: false, optionFingerprint: preOption.fingerprint });
      }
      /* ATHENA_ACTION_V2_BILLING_PREFLIGHT_END */
      /* ATHENA_ACTION_V2_BILLING_COMMIT_START */
      var stagedCodes = [], failedCodes = [];
      for (var bc = 0; bc < preflight.length; bc++) {
        var code = preflight[bc].code;
        if (preflight[bc].alreadyPresent) { results.push({ code: code, attempted: false, verified: true, reason: 'billing-exact-match', alreadyPresent: true }); continue; }
        var beforeChargeRows = chargeRowsSnapshot(bill.root, null, code, bill.el);
        mutationAttempted = true;
        setField(bill.el, code);
        await sleep(650);
        var commitOption = billingOption(code);
        var afterCommitInputRows = chargeRowsSnapshot(bill.root, commitOption.scope || null, code, bill.el);
        if (!sameChargeRowState(beforeChargeRows, afterCommitInputRows)) {
          setField(bill.el, '');
          failedCodes = codes.slice(bc);
          results.push({ code: code, attempted: true, verified: false, reason: 'outcome-uncertain' });
          return { ok: false, attempted: true, verified: false, staged: false, partialMutation: true, reason: 'outcome-uncertain', detail: 'billing-input-side-effect', code: code, results: results, stagedCodes: stagedCodes, failedCodes: failedCodes, context: context, noAutomaticChaining: 'no-automatic-chaining' };
        }
        if (!commitOption.option || commitOption.fingerprint !== preflight[bc].optionFingerprint) {
          setField(bill.el, '');
          failedCodes = codes.slice(bc); return { ok: false, attempted: stagedCodes.length > 0, verified: false, staged: false, partialMutation: stagedCodes.length > 0, reason: commitOption.error || 'outcome-uncertain', code: code, results: results, stagedCodes: stagedCodes, failedCodes: failedCodes, context: context, noAutomaticChaining: 'no-automatic-chaining' };
        }
        try { commitOption.option.click(); }
        catch (clickError) {
          setField(bill.el, '');
          failedCodes = codes.slice(bc);
          results.push({ code: code, attempted: true, verified: false, reason: 'outcome-uncertain' });
          return { ok: false, attempted: true, verified: false, staged: false, partialMutation: true, reason: 'outcome-uncertain', detail: 'billing-click-outcome-uncertain', code: code, results: results, stagedCodes: stagedCodes, failedCodes: failedCodes, context: context, noAutomaticChaining: 'no-automatic-chaining' };
        }
        setField(bill.el, '');
        var afterChargeRows = await stableChargeRows(bill.root, commitOption.scope, code, bill.el);
        var after = rowsIn(bill.root, code, commitOption.scope);
        var isolatedCodeAdd = !!afterChargeRows && verifiedIsolatedCodeAdd(beforeChargeRows, afterChargeRows, code);
        if (after.length !== 1 || !isolatedCodeAdd) {
          failedCodes = codes.slice(bc);
          results.push({ code: code, attempted: true, verified: false, reason: 'outcome-uncertain' });
          /* The option was clicked, so the current code may have been staged
             even when DOM readback failed. Always surface a possible partial
             mutation, including when this was the first requested code. */
          return { ok: false, attempted: true, verified: false, staged: false, partialMutation: true, reason: 'outcome-uncertain', detail: !afterChargeRows ? 'billing-readback-not-stable' : (!isolatedCodeAdd ? 'billing-unrelated-charge-change' : (after.length ? 'billing-duplicate-rejected' : 'billing-context-unverified')), code: code, results: results, stagedCodes: stagedCodes, failedCodes: failedCodes, context: context, noAutomaticChaining: 'no-automatic-chaining' };
        }
        stagedCodes.push(code);
        results.push({ code: code, attempted: true, verified: true, reason: 'billing-exact-match' });
      }
      return { ok: true, action: action, attempted: stagedCodes.length > 0, verified: true, staged: true, partialMutation: false, reason: 'billing-context-verified', results: results, stagedCodes: stagedCodes, failedCodes: failedCodes, context: context, noAutomaticChaining: 'no-automatic-chaining' };
      /* ATHENA_ACTION_V2_BILLING_COMMIT_END */
    }
    /* STAGE_BILLING_END */
    /* ATHENA_ACTION_V2_STAGE_BILLING_END */

    function clickOnce(el) { if (wsForbiddenControl(el)) throw new Error('forbidden-control-blocked'); try { el.scrollIntoView({ block: 'center' }); } catch (e) {} el.click(); }

    /* ATHENA_ACTION_V2_SAVE_DRAFT_START */
    /* SAVE_DRAFT_START */
    if (action === 'save_draft') {
      var saveStatusEvidenceSnapshot = statusEvidenceSnapshot([noteScope]);
      mutationAttempted = true;
      clickOnce(actionControl);
      await sleep(1400);
      var saveVerified = newScopedStatus(saveStatusEvidenceSnapshot, [noteScope], /\b(draft saved|note saved|saved successfully|changes saved)\b/);
      return { ok: saveVerified, action: action, attempted: true, verified: saveVerified, saved: saveVerified, reason: saveVerified ? 'exact-save-control-context-verified' : 'outcome-uncertain', control: 'exact-save-control', context: context, noAutomaticChaining: 'no-automatic-chaining' };
    }
    /* SAVE_DRAFT_END */
    /* ATHENA_ACTION_V2_SAVE_DRAFT_END */

    /* ATHENA_ACTION_V2_SIGN_ENCOUNTER_START */
    /* SIGN_ENCOUNTER_START */
    if (action === 'sign_encounter') {
      var signStatusEvidenceSnapshot = statusEvidenceSnapshot([noteScope]);
      mutationAttempted = true;
      clickOnce(actionControl);
      await sleep(550);
      var dialogs = deepQueryAll(noteScope, '[role="dialog"],[role="alertdialog"],.modal,.dialog').filter(function (el) { return visible(el, hit.frame.w); });
      var actionDialog = null;
      if (dialogs.length) {
        var confirms = [];
        for (var di = 0; di < dialogs.length; di++) confirms = confirms.concat(interactive(dialogs[di], hit.frame.w).filter(exactSign));
        if (confirms.length !== 1) return { ok: false, attempted: true, verified: false, reason: 'outcome-uncertain', detail: 'exact-sign-confirmation-not-unique', context: context, noAutomaticChaining: 'no-automatic-chaining' };
        actionDialog = confirms[0].closest('[role="dialog"],[role="alertdialog"],.modal,.dialog');
        /* The dialog was created by the first click. Snapshot its existing
           status nodes before the final confirmation so static dialog copy
           cannot be mistaken for post-sign success evidence. */
        var dialogStatusSnapshot = statusEvidenceSnapshot([actionDialog]);
        dialogStatusSnapshot.forEach(function (value, node) { signStatusEvidenceSnapshot.set(node, value); });
        clickOnce(confirms[0]);
      }
      await sleep(1600);
      var signStatusRoots = actionDialog ? [noteScope, actionDialog] : [noteScope];
      var signVerified = newScopedStatus(signStatusEvidenceSnapshot, signStatusRoots, /\b(signed and saved|successfully signed|encounter signed|note signed|signed by)\b/);
      return { ok: signVerified, action: action, attempted: true, verified: signVerified, signed: signVerified, reason: signVerified ? 'exact-sign-control-context-verified' : 'outcome-uncertain', control: 'exact-sign-control', context: context, noAutomaticChaining: 'no-automatic-chaining' };
    }
    /* SIGN_ENCOUNTER_END */
    /* ATHENA_ACTION_V2_SIGN_ENCOUNTER_END */
    return { ok: false, blocked: true, reason: 'unknown-action' };
  } catch (e) {
    if (mutationAttempted) {
      return { ok: false, attempted: true, verified: false, partialMutation: action === 'stage_billing' || action === 'place_order' || orderFinalActionAttempted, reason: 'outcome-uncertain', detail: action === 'stage_billing' ? 'billing-action-threw-after-mutation-boundary' : (action === 'place_order' ? 'order-action-threw-after-mutation-boundary' : 'action-threw-after-mutation-boundary'), error: String((e && e.message) || e).slice(0, 220), noAutomaticChaining: 'no-automatic-chaining' };
    }
    return { ok: false, blocked: true, attempted: false, verified: false, reason: 'context-unverified', error: String((e && e.message) || e).slice(0, 220) };
  }
}
/* ATHENA_ACTION_V2_DRIVER_END */

/* DESTINATION_TEACH_WATCHER_START */
/* Injected into the isolated world of the one signed-in Athena tab. It observes
 * one trusted teaching click, suppresses that click before Athena can activate
 * the underlying control, and reports a robust selector. It never focuses a
 * tab, navigates, reloads, types, or otherwise mutates the DOM. */
function mlsAthenaTeachWatcherFn(config) {
  try {
    config = config || {};
    var KEY = '__mlsDestinationTeachWatcherV2';
    var prior = globalThis[KEY];
    var sessionId = String(config.sessionId || ''), timeoutMs = Math.max(5000, Math.min(300000, Number(config.timeoutMs || 180000)));
    if (!sessionId) return { ok: false, state: 'failed', reason: 'missing-session' };
    if (config.mode === 'cancel') {
      /* A late cancel may never tear down a newer watcher installed in the same
         frame. Cleanup is scoped to the immutable teaching session id. */
      if (!prior || prior.sessionId !== sessionId) return { ok: true, state: 'failed', reason: 'not-watching' };
      try { if (typeof prior.cancel === 'function') prior.cancel(); else if (typeof prior.cleanup === 'function') prior.cleanup(); } catch (eCancel) {}
      return { ok: true, state: 'failed', reason: 'cancelled' };
    }
    if (prior && typeof prior.cancel === 'function') try { prior.cancel(); } catch (ePrior) {}
    else if (prior && typeof prior.cleanup === 'function') try { prior.cleanup(); } catch (ePriorCleanup) {}
    var listeners = [], expiryTimer = null, cleanupTimer = null, finished = false, cancelRequested = false;
    var pointers = Object.create(null), mouseDown = false, touchCount = 0;
    function text(v) { return String(v == null ? '' : v).replace(/\s+/g, ' ').trim(); }
    function hash(v) { var s = String(v || ''), h = 2166136261; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return ('00000000' + (h >>> 0).toString(16)).slice(-8); }
    function ident(v) {
      try { if (globalThis.CSS && typeof globalThis.CSS.escape === 'function') return globalThis.CSS.escape(String(v)); } catch (e) {}
      return String(v).replace(/(^-?\d)|[^a-zA-Z0-9_-]/g, function (m, digit) { return digit ? '\\3' + digit + ' ' : '\\' + m; });
    }
    function attr(v) { return String(v).replace(/\\/g, '\\\\').replace(/"/g, '\\"'); }
    function unique(root, selector) { try { var all = root.querySelectorAll(selector); return all.length === 1; } catch (e) { return false; } }
    function selectorWithin(el, root) {
      var tag = String(el.tagName || '').toLowerCase(); if (!tag) return '';
      var id = ''; try { id = el.id || ''; } catch (e) {}
      if (id) { var byId = '#' + ident(id); if (unique(root, byId)) return byId; }
      var attrs = ['data-testid','data-component','name','aria-label','placeholder'];
      for (var ai = 0; ai < attrs.length; ai++) {
        var val = ''; try { val = el.getAttribute(attrs[ai]) || ''; } catch (e2) {}
        if (!val || val.length > 180) continue;
        var byAttr = tag + '[' + attrs[ai] + '="' + attr(val) + '"]'; if (unique(root, byAttr)) return byAttr;
      }
      var parts = [], cur = el, guard = 0;
      while (cur && cur.nodeType === 1 && guard++ < 9) {
        var part = String(cur.tagName || '').toLowerCase(), parent = cur.parentElement;
        if (!part) break;
        if (parent) {
          var peers = Array.prototype.filter.call(parent.children || [], function (n) { return n.tagName === cur.tagName; });
          if (peers.length > 1) part += ':nth-of-type(' + (peers.indexOf(cur) + 1) + ')';
        }
        parts.unshift(part);
        var candidate = parts.join(' > '); if (unique(root, candidate)) return candidate;
        if (!parent || parent === root || parent.nodeType !== 1) break;
        cur = parent;
      }
      return '';
    }
    function robustSelector(el) {
      var parts = [], cur = el, guard = 0;
      while (cur && guard++ < 8) {
        var root = null; try { root = cur.getRootNode(); } catch (e) { root = cur.ownerDocument; }
        if (!root || !root.querySelectorAll) return '';
        var part = selectorWithin(cur, root); if (!part) return '';
        parts.unshift(part);
        if (root.nodeType === 11 && root.host) cur = root.host; else break;
      }
      return parts.join(' >>> ');
    }
    function parentAcrossRoots(node) {
      if (!node) return null; if (node.parentElement) return node.parentElement;
      try { var root = node.getRootNode(); return root && root.host ? root.host : null; } catch (e) { return null; }
    }
    function canonicalControl(path, fallback) {
      var nodes = Array.isArray(path) ? path.slice(0, 16) : [];
      if (fallback && nodes.indexOf(fallback) < 0) nodes.push(fallback);
      for (var i = 0; i < nodes.length; i++) {
        var el = nodes[i]; if (!el || el.nodeType !== 1) continue;
        try {
          if (String(el.tagName || '').toLowerCase() === 'label' && el.control) return el.control;
          if (el.matches('button,input:not([type="hidden"]),textarea,select,[role="button"],[role="textbox"],[role="combobox"],[contenteditable="true"],[contenteditable="plaintext-only"]')) return el;
        } catch (eMatch) {}
      }
      var cur = fallback, guard = 0;
      while (cur && guard++ < 12) {
        try {
          if (String(cur.tagName || '').toLowerCase() === 'label' && cur.control) return cur.control;
          if (cur.matches && cur.matches('button,input:not([type="hidden"]),textarea,select,[role="button"],[role="textbox"],[role="combobox"],[contenteditable="true"],[contenteditable="plaintext-only"]')) return cur;
        } catch (eClosest) {}
        cur = parentAcrossRoots(cur);
      }
      return null;
    }
    function sectionLabel(el, stopAt) {
      var own = '';
      try { own = text((el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '') + ' ' + (el.getAttribute('placeholder') || '')); if (!own && el.labels && el.labels.length === 1) own = text(el.labels[0].textContent); } catch (e) {}
      if (own && own.length <= 240) return own;
      var cur = el, guard = 0;
      while (cur && guard++ < 8) {
        var heads = []; try { heads = Array.prototype.slice.call(cur.querySelectorAll(':scope > legend,:scope > h1,:scope > h2,:scope > h3,:scope > header,:scope > [role="heading"]')); } catch (e2) {}
        if (heads.length === 1) { var h = text(heads[0].textContent); if (h && h.length <= 240) return h; }
        if (cur === stopAt) break; cur = parentAcrossRoots(cur);
      }
      var fallback = ''; try { fallback = text((el.textContent || el.value || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '')); } catch (e3) {}
      return fallback.slice(0, 240);
    }
    function frames() {
      var out = [];
      function walk(w, depth, path) {
        if (depth > 6) return;
        try { void w.document; out.push({ w: w, doc: w.document, path: path, url: String(w.location.href || '').split('#')[0] }); } catch (e) { return; }
        for (var i = 0; i < w.frames.length; i++) try { void w.frames[i].document; walk(w.frames[i], depth + 1, path + '.' + i); } catch (e2) {}
      }
      walk(window, 0, 'top'); return out;
    }
    function cleanup() {
      if (expiryTimer) clearTimeout(expiryTimer); expiryTimer = null;
      if (cleanupTimer) clearTimeout(cleanupTimer); cleanupTimer = null;
      for (var i = 0; i < listeners.length; i++) try { listeners[i].target.removeEventListener(listeners[i].type, listeners[i].fn, true); } catch (e) {}
      listeners = [];
      try { if (globalThis[KEY] && globalThis[KEY].sessionId === sessionId) delete globalThis[KEY]; } catch (e2) { globalThis[KEY] = null; }
    }
    function gestureActive() { return Object.keys(pointers).length > 0 || mouseDown || touchCount > 0; }
    function scheduleShieldCleanup(trailing) {
      if (!finished && !cancelRequested) return;
      if (gestureActive()) return;
      if (cleanupTimer) clearTimeout(cleanupTimer);
      cleanupTimer = setTimeout(cleanup, trailing === false ? 0 : 1550);
    }
    function cancel() {
      cancelRequested = true; finished = true;
      /* Never drop the shield mid-gesture: a long press can release well after
         the old fixed 1.5s timer and activate pointerup/touchend handlers. */
      scheduleShieldCleanup(gestureActive());
    }
    function consume(ev) {
      try { ev.preventDefault(); } catch (ePrevent) {}
      try { ev.stopImmediatePropagation(); } catch (eImmediate) {}
      try { ev.stopPropagation(); } catch (eStop) {}
    }
    function capture(frame, ev) {
      if (!ev || ev.isTrusted !== true) return;
      /* Consume every phase before selector/label work. This protects icon/SVG,
         unlabeled, touch, and pointer targets even when they cannot be taught. */
      consume(ev);
      var type = String(ev.type || '').toLowerCase(), pointerId = String(ev.pointerId == null ? 'primary' : ev.pointerId);
      if (type === 'pointerdown') pointers[pointerId] = true;
      if (type === 'mousedown') mouseDown = true;
      if (type === 'touchstart') try { touchCount = Math.max(1, Number(ev.touches && ev.touches.length || 1)); } catch (eTouchStart) { touchCount = 1; }
      if (type === 'pointerup' || type === 'pointercancel') delete pointers[pointerId];
      if (type === 'mouseup') mouseDown = false;
      if (type === 'touchend' || type === 'touchcancel') try { touchCount = Number(ev.touches && ev.touches.length || 0); } catch (eTouchEnd) { touchCount = 0; }
      if (finished) {
        scheduleShieldCleanup(true); return;
      }
      var path = []; try { path = ev.composedPath ? ev.composedPath() : []; } catch (e) {}
      var el = canonicalControl(path, path[0] || ev.target); if (!el || el.nodeType !== 1) return;
      var selector = robustSelector(el), label = sectionLabel(el, frame.doc.body);
      if (!selector || !label) return;
      var tag = String(el.tagName || '').toLowerCase(), fingerprint = hash([frame.path, selector, label, tag].join('|'));
      /* Keep the shield through the matching release, however long the press,
         then through the trailing click/double-click window. */
      finished = true;
      try {
        chrome.runtime.sendMessage({ type: 'mlsAthenaTeachCaptured', sessionId: sessionId, target: { selector: selector, sectionLabel: label, label: label, framePath: frame.path, frameUrl: frame.url, tag: tag, targetFingerprint: fingerprint } }, function () { var ignored = chrome.runtime.lastError; });
      } catch (eSend) {}
      scheduleShieldCleanup(true);
    }
    /* Top injection recursively covers every same-origin frame with stable
       top.N paths. allFrames injection separately covers cross-origin frames;
       same-origin descendants skip their duplicate listener set. */
    if (window !== window.top) {
      try { void window.top.document; return { ok: true, state: 'covered-by-top', frameCount: 0 }; } catch (eCrossOrigin) {}
    }
    var found = frames();
    if (window !== window.top) {
      var isolatedPrefix = 'isolated-' + hash(String(window.location && window.location.href || 'frame'));
      for (var fp = 0; fp < found.length; fp++) found[fp].path = found[fp].path.replace(/^top/, isolatedPrefix);
    }
    /* Swallow the complete activation gesture. Some Athena controls attach to
       release/context events instead of click; leaving even one release phase
       live would let a teaching gesture mutate the chart. */
    var eventTypes = ['pointerdown','pointerup','pointercancel','mousedown','mouseup','touchstart','touchend','touchcancel','click','auxclick','dblclick','contextmenu'];
    for (var fi = 0; fi < found.length; fi++) {
      (function (frame) {
        var listenerTarget = frame.w && frame.w.addEventListener ? frame.w : frame.doc;
        for (var ei = 0; ei < eventTypes.length; ei++) {
          (function (type) {
            var fn = function (ev) { capture(frame, ev); };
            listenerTarget.addEventListener(type, fn, { capture: true, passive: false });
            listeners.push({ target: listenerTarget, type: type, fn: fn });
          })(eventTypes[ei]);
        }
      })(found[fi]);
    }
    if (!listeners.length) return { ok: false, state: 'failed', reason: 'watcher-unavailable' };
    expiryTimer = setTimeout(function () { finished = true; cancelRequested = true; scheduleShieldCleanup(gestureActive()); }, timeoutMs);
    globalThis[KEY] = { sessionId: sessionId, cleanup: cleanup, cancel: cancel };
    return { ok: true, state: 'waiting', frameCount: found.length, listenerCount: listeners.length };
  } catch (e) { return { ok: false, state: 'failed', reason: 'watcher-unavailable', error: String((e && e.message) || e).slice(0, 220) }; }
}
/* DESTINATION_TEACH_WATCHER_END */

/* ATHENA_ACTION_V2_HANDLER_START */
(function () {
  'use strict';
  if (self.__mlsAthenaActionV2Wired) return;
  self.__mlsAthenaActionV2Wired = true;
  var tokens = Object.create(null);
  var noteWriteProofs = Object.create(null);
  var TOKEN_TTL_MS = 90000;
  var NOTE_PROOF_TTL_MS = 180000;
  var executeBusy = false;
  function clean(v) { return String(v == null ? '' : v).trim(); }
  function norm(v) { return clean(v).toLowerCase().replace(/[^a-z0-9]+/g, ' ').replace(/\s+/g, ' ').trim(); }
  function digits(v) { return clean(v).replace(/\D/g, ''); }
  function dateKey(v) { var m = /([01]?\d)[\/\-.]([0-3]?\d)[\/\-.](\d{2,4})/.exec(clean(v)); if (!m) return ''; var y = m[3]; if (y.length === 2) y = (Number(y) > ((new Date().getFullYear() % 100) + 1) ? '19' : '20') + y; return Number(m[1]) + '/' + Number(m[2]) + '/' + y; }
  function simpleHash(v) { var s = String(v || ''), h = 2166136261; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return ('00000000' + (h >>> 0).toString(16)).slice(-8); }
  function patientKey(p) { p = p || {}; return [clean(p.patientId), norm(p.name), dateKey(p.dob)].join('|'); }
  function noteNorm(v) { return String(v == null ? '' : v).replace(/\r\n?/g, '\n').replace(/\u00a0/g, ' ').split('\n').map(function (line) { return line.replace(/[ \t]+$/g, ''); }).join('\n').replace(/\n{3,}/g, '\n\n').trim(); }
  function notePayloadKey(noteText, sections, policy) {
    var safe = Array.isArray(sections) ? sections : [];
    var sectionPayloads = [];
    for (var i = 0; i < safe.length; i++) { var s = safe[i] || {}; sectionPayloads.push([clean(s.key), String(s.text == null ? '' : s.text), s.execute === true, clean(s.destination)]); }
    /* JSON escapes every separator/control character, so two different note
       and section tuples cannot collapse into the same authorization value.
       Preserve the raw note string here: normalization is useful for editor
       readback, but may never authorize different execute-time whitespace. */
    return JSON.stringify([String(noteText == null ? '' : noteText), clean(policy || 'empty_only'), sectionPayloads]);
  }
  function urlKey(v) { return clean(v).split('#')[0]; }
  function expectedContextKey(c) { c = c || {}; return [digits(c.appointmentId), digits(c.encounterId), urlKey(c.encounterUrl), dateKey(c.visitDate), norm(c.provider)].join('|'); }
  function expectedContextShape(c, requireEncounter) {
    c = c || {};
    var hasDate = !!clean(c.visitDate), hasProvider = !!clean(c.provider);
    var hasAppointmentId = !!clean(c.appointmentId);
    var hasEncounterId = !!clean(c.encounterId), hasEncounterUrl = !!clean(c.encounterUrl);
    var hasAny = hasDate || hasProvider || hasAppointmentId || hasEncounterId || hasEncounterUrl;
    if (requireEncounter) return !!dateKey(c.visitDate) && !!norm(c.provider) &&
      ((!!digits(c.encounterId) && !!urlKey(c.encounterUrl)) || !!digits(c.appointmentId));
    /* A probe with no schedule context may safely use the driver's unique,
       labeled date/provider discovery. Once the caller supplies any context,
       it must provide a usable date/provider pair; encounter ID and URL are
       optional, but may only be supplied together. */
    if (!hasAny) return true;
    if (!dateKey(c.visitDate) || !norm(c.provider)) return false;
    if (hasAppointmentId && !digits(c.appointmentId)) return false;
    if (hasEncounterId !== hasEncounterUrl) return false;
    if (hasEncounterId && (!digits(c.encounterId) || !urlKey(c.encounterUrl))) return false;
    return true;
  }
  function lockedContextShape(c) {
    c = c || {};
    return !!norm(c.patientName) && !!dateKey(c.dob) && !!digits(c.mrn) && !!digits(c.encounterId) && !!urlKey(c.encounterUrl) &&
      !!dateKey(c.visitDate) && !!norm(c.provider) && !!clean(c.framePath) &&
      !!clean(c.encounterRootFingerprint) && !!clean(c.controlFingerprint) && !!clean(c.noteScopeFingerprint) && !!clean(c.editorFingerprint) && !!clean(c.contextHash);
  }
  function expectedContextMatches(got, expectedAtProbe, locked) {
    got = got || {}; expectedAtProbe = expectedAtProbe || {}; locked = locked || {};
    if (!expectedContextShape(got, true)) return false;
    if (expectedContextKey(got) !== expectedContextKey(expectedAtProbe)) return false;
    /* The probe may discover a stronger appointment ID than the app originally
       knew. Require every caller-supplied locator to match the immutable probe
       lock, but do not reject a valid encounter-ID+URL caller merely because
       Athena added that stronger appointment ID to the locked receipt. */
    if (dateKey(got.visitDate) !== dateKey(locked.visitDate) || norm(got.provider) !== norm(locked.provider)) return false;
    if (digits(got.appointmentId) && digits(got.appointmentId) !== digits(locked.appointmentId)) return false;
    if (digits(got.encounterId) && digits(got.encounterId) !== digits(locked.encounterId)) return false;
    if (urlKey(got.encounterUrl) && urlKey(got.encounterUrl) !== urlKey(locked.encounterUrl)) return false;
    if (dateKey(expectedAtProbe.visitDate) && dateKey(got.visitDate) !== dateKey(expectedAtProbe.visitDate)) return false;
    if (norm(expectedAtProbe.provider) && norm(got.provider) !== norm(expectedAtProbe.provider)) return false;
    if (digits(expectedAtProbe.appointmentId) && digits(got.appointmentId) !== digits(expectedAtProbe.appointmentId)) return false;
    if (digits(expectedAtProbe.encounterId) && digits(got.encounterId) !== digits(expectedAtProbe.encounterId)) return false;
    if (urlKey(expectedAtProbe.encounterUrl) && urlKey(got.encounterUrl) !== urlKey(expectedAtProbe.encounterUrl)) return false;
    return true;
  }
  function probeContextMatches(got, locked) {
    got = got || {}; locked = locked || {};
    if (!lockedContextShape(got) || !lockedContextShape(locked)) return false;
    return digits(got.mrn) === digits(locked.mrn) &&
      norm(got.patientName) === norm(locked.patientName) &&
      dateKey(got.dob) === dateKey(locked.dob) &&
      digits(got.appointmentId) === digits(locked.appointmentId) &&
      digits(got.encounterId) === digits(locked.encounterId) &&
      urlKey(got.encounterUrl) === urlKey(locked.encounterUrl) &&
      dateKey(got.visitDate) === dateKey(locked.visitDate) &&
      norm(got.provider) === norm(locked.provider) &&
      clean(got.framePath) === clean(locked.framePath) &&
      clean(got.encounterRootFingerprint) === clean(locked.encounterRootFingerprint) &&
      clean(got.controlFingerprint) === clean(locked.controlFingerprint) &&
      clean(got.noteScopeFingerprint) === clean(locked.noteScopeFingerprint) &&
      clean(got.editorFingerprint) === clean(locked.editorFingerprint) &&
      clean(got.contextHash) === clean(locked.contextHash);
  }
  function encounterProofKey(c) { c = c || {}; return [norm(c.patientName), dateKey(c.dob), digits(c.mrn), digits(c.encounterId), urlKey(c.encounterUrl), dateKey(c.visitDate), norm(c.provider), clean(c.framePath), clean(c.encounterRootFingerprint), clean(c.noteScopeFingerprint), clean(c.editorFingerprint)].join('|'); }
  function billingKey(b) { b = b || {}; var c = Array.isArray(b.cptCodes) ? b.cptCodes : [], out = []; for (var i = 0; i < c.length; i++) out.push(clean(c[i]).toUpperCase()); return JSON.stringify([clean(b.emCode).toUpperCase(), out]); }
  function canonicalTaughtDestination(v) {
    v = v && typeof v === 'object' ? v : {};
    if (!clean(v.selector)) return { ok: true, value: null, payload: '' };
    var value = {
      schema: clean(v.schema), contextHash: clean(v.contextHash), action: clean(v.action).toLowerCase(), rowId: clean(v.rowId), rowHash: clean(v.rowHash),
      manifestHash: clean(v.manifestHash), patientHash: clean(v.patientHash), visitHash: clean(v.visitHash), capturedAt: clean(v.capturedAt), expiresAt: Number(v.expiresAt || 0),
      selector: clean(v.selector), sectionLabel: clean(v.sectionLabel), label: clean(v.label), framePath: clean(v.framePath), frameUrl: clean(v.frameUrl).split('#')[0],
      tag: clean(v.tag).toLowerCase(), targetFingerprint: clean(v.targetFingerprint)
    };
    if (value.schema !== 'mls-taught-destination-v2' || !value.contextHash || !value.action || !value.rowId || !value.rowHash || !value.manifestHash || !value.patientHash || !value.visitHash ||
        !value.selector || value.selector.length > 2000 || !value.sectionLabel || value.sectionLabel.length > 240 || !value.framePath || value.framePath.length > 100 ||
        !value.frameUrl || value.frameUrl.length > 1200 || !value.tag || value.tag.length > 40 || !value.targetFingerprint || value.targetFingerprint.length > 120 ||
        !Number.isFinite(value.expiresAt) || value.expiresAt <= Date.now()) return { ok: false, reason: value.expiresAt && value.expiresAt <= Date.now() ? 'taught-destination-expired' : 'taught-destination-invalid' };
    return { ok: true, value: value, payload: JSON.stringify(value) };
  }
  function canonicalOrderPayload(value) {
    value = value && typeof value === 'object' ? value : {};
    var type = norm(value.type).replace(/ /g, '_');
    var schemas = {
      imaging: { allowed: ['study','region','indication','laterality','contrast','notes'], required: ['study','region','indication'] },
      pt: { allowed: ['dx','freq','duration','modalities','notes'], required: ['dx','freq','duration','modalities'] },
      referral: { allowed: ['specialty','reason','notes'], required: ['specialty','reason'] },
      dme: { allowed: ['item','dx','icd','notes'], required: ['item','dx','icd'] }
    };
    var schema = schemas[type];
    if (!schema) return { ok: false, reason: /^(medication|rx|injection|procedure)$/.test(type) ? 'high-risk-order-blocked' : 'unsupported-order-type' };
    var rawFields = value.fields && typeof value.fields === 'object' ? value.fields : {}, fields = {}, keys = Object.keys(rawFields).sort();
    for (var i = 0; i < keys.length; i++) {
      if (schema.allowed.indexOf(keys[i]) < 0 || !clean(rawFields[keys[i]])) return { ok: false, reason: 'unsupported-order-fields' };
      if (String(rawFields[keys[i]] == null ? '' : rawFields[keys[i]]).length > 2000) return { ok: false, reason: 'order-field-too-long' };
      fields[keys[i]] = clean(rawFields[keys[i]]);
    }
    if (schema.required.some(function (key) { return !clean(fields[key]); })) return { ok: false, reason: 'missing-order-fields' };
    var canonical = {
      clientOrderId: clean(value.clientOrderId), type: type, displayLabel: clean(value.displayLabel),
      catalogCode: clean(value.catalogCode), catalogId: clean(value.catalogId), query: clean(value.query),
      fields: fields, reviewStatus: clean(value.reviewStatus).toLowerCase(), source: clean(value.source).toLowerCase()
    };
    if (!canonical.clientOrderId || !canonical.displayLabel || !canonical.query || canonical.reviewStatus !== 'accepted') return { ok: false, reason: 'order-payload-incomplete' };
    if (!canonical.catalogCode && !canonical.catalogId) return { ok: false, reason: 'catalog-identity-required' };
    if (!/^(provider-entered|ai-suggestion-accepted|rule-suggestion-accepted)$/.test(canonical.source)) return { ok: false, reason: 'unsupported-order-source' };
    if (canonical.clientOrderId.length > 160 || canonical.displayLabel.length > 300 || canonical.query.length > 300 || canonical.catalogCode.length > 100 || canonical.catalogId.length > 160) return { ok: false, reason: 'order-field-too-long' };
    return { ok: true, order: canonical, payload: JSON.stringify(canonical) };
  }
  function appSender(sender) {
    try { var u = new URL(sender && sender.tab && sender.tab.url || ''); return u.protocol === 'https:' && /(^|\.)mlsscribe\.com$/i.test(u.hostname); } catch (e) { return false; }
  }
  function tokenValue() {
    try { var a = new Uint32Array(6); crypto.getRandomValues(a); return Array.prototype.map.call(a, function (n) { return ('00000000' + n.toString(16)).slice(-8); }).join(''); }
    catch (e) { return simpleHash(Date.now() + '|' + Math.random()) + simpleHash(Math.random()); }
  }
  function exactAthenaTabs(all) {
    return (all || []).filter(function (t) { try { return mlsAthTabHost(t) === 'athenanet.athenahealth.com' && !mlsAthIsLoginish(t); } catch (e) { return false; } });
  }
  async function pickExactAthena(sender, expectedPatient, all) {
    /* Final/financial actions are stricter than read and narrative-draft lanes:
       more than one signed-in Athena tab is always ambiguous, even if an older
       read flow remembered a target. */
    var candidates = exactAthenaTabs(all);
    if (candidates.length !== 1) return { __error: candidates.length ? 'ambiguous-athena-tabs' : 'no-athena-tab', __message: candidates.length ? 'More than one signed-in Athena tab is open. Leave exactly one Athena tab open, then retry. Nothing was changed.' : 'Open one signed-in Athena tab, then retry. Nothing was changed.' };
    return candidates[0];
  }
  async function injectOnce(tabId, payload) {
    /* Intentionally one TOP-frame injection: no allFrames, no retry/reload. */
    try {
      var r = await chrome.scripting.executeScript({ target: { tabId: tabId }, world: 'MAIN', args: [payload], func: mlsAthenaActionV2DriverFn });
      return r && r[0] && r[0].result ? r[0].result : { ok: false, reason: 'outcome-uncertain', error: 'The Athena action returned no result.' };
    } catch (e) { return { ok: false, reason: 'outcome-uncertain', error: String((e && e.message) || e) }; }
  }
  function matchingNoteWriteProof(id, senderTabId, athenaTabId, p, previewHash, noteHash, notePayload, context) {
    var proof = noteWriteProofs[clean(id)];
    if (!proof || proof.used || Date.now() > proof.expiresAt) return null;
    if (Number(proof.senderTabId) !== Number(senderTabId) || Number(proof.athenaTabId) !== Number(athenaTabId)) return null;
    /* Hashes remain useful diagnostics, but authorization uses the complete
       canonical values so a 32-bit hash collision cannot swap patient, note,
       or encounter data between probe and execute. */
    if (proof.previewHash !== previewHash || proof.patientKey !== patientKey(p) || proof.patientHash !== simpleHash(patientKey(p))) return null;
    if (proof.notePayload !== notePayload || proof.noteHash !== noteHash) return null;
    if (context && (proof.lockedContextKey !== encounterProofKey(context) || proof.lockedContextHash !== simpleHash(encounterProofKey(context)))) return null;
    return proof;
  }
  function noteWriteProofFailure(id) {
    var proofRecord = noteWriteProofs[clean(id)];
    if (proofRecord && proofRecord.used) return 'note-write-proof-used';
    if (proofRecord && Date.now() > proofRecord.expiresAt) return 'note-write-proof-expired';
    return 'verified-note-write-required';
  }

  /* DESTINATION_TEACH_HANDLER_START */
  var teachSessions = Object.create(null);
  var TEACH_GUARD_ID = 'mls-destination-teach-navigation-guard-v1';
  var teachGuardOwner = '';
  var teachGuardQueue = Promise.resolve().then(async function () {
    try { if (chrome.scripting && chrome.scripting.unregisterContentScripts) await chrome.scripting.unregisterContentScripts({ ids: [TEACH_GUARD_ID] }); } catch (eStartupGuard) {}
  });
  function teachCurrent(session) { return !!(session && teachSessions[session.requestId] === session && !session.cancelled); }
  function registerTeachGuard(session) {
    teachGuardQueue = teachGuardQueue.then(async function () {
      try { if (chrome.scripting && chrome.scripting.unregisterContentScripts) await chrome.scripting.unregisterContentScripts({ ids: [TEACH_GUARD_ID] }); } catch (eOldGuard) {}
      teachGuardOwner = '';
      if (!teachCurrent(session) || !chrome.scripting || typeof chrome.scripting.registerContentScripts !== 'function') return false;
      try {
        await chrome.scripting.registerContentScripts([{
          id: TEACH_GUARD_ID, matches: ['https://athenanet.athenahealth.com/*'],
          js: ['destination_teach_navigation_guard.js'], runAt: 'document_start',
          allFrames: true, matchOriginAsFallback: true, persistAcrossSessions: false
        }]);
      } catch (eRegisterGuard) { return false; }
      if (!teachCurrent(session)) {
        try { await chrome.scripting.unregisterContentScripts({ ids: [TEACH_GUARD_ID] }); } catch (eLateGuard) {}
        return false;
      }
      teachGuardOwner = session.requestId; return true;
    });
    return teachGuardQueue;
  }
  function releaseTeachGuard(session) {
    var requestId = clean(session && session.requestId);
    teachGuardQueue = teachGuardQueue.then(async function () {
      if (!requestId || teachGuardOwner !== requestId) return true;
      teachGuardOwner = '';
      try { await chrome.scripting.unregisterContentScripts({ ids: [TEACH_GUARD_ID] }); } catch (eReleaseGuard) {}
      return true;
    });
    return teachGuardQueue;
  }
  function teachBinding(v) {
    v = v && typeof v === 'object' ? v : {};
    return {
      schema: clean(v.schema).slice(0, 80), contextHash: clean(v.contextHash).slice(0, 160), action: clean(v.action).slice(0, 80), kind: clean(v.kind).slice(0, 80),
      rowId: clean(v.rowId).slice(0, 180), rowHash: clean(v.rowHash).slice(0, 160), manifestHash: clean(v.manifestHash).slice(0, 160), previewHash: clean(v.previewHash).slice(0, 160),
      patientHash: clean(v.patientHash).slice(0, 160), visitHash: clean(v.visitHash).slice(0, 160)
    };
  }
  function validTeachBinding(v, action) {
    return v.schema === 'mls-taught-destination-context-v2' && v.action === action && !!v.contextHash && !!v.rowId && !!v.rowHash && !!v.manifestHash && !!v.patientHash && !!v.visitHash;
  }
  function teachTarget(v) {
    v = v && typeof v === 'object' ? v : {};
    return {
      selector: clean(v.selector).slice(0, 2000), sectionLabel: clean(v.sectionLabel || v.label).slice(0, 240), label: clean(v.label || v.sectionLabel).slice(0, 240),
      framePath: clean(v.framePath).slice(0, 100), frameUrl: clean(v.frameUrl).slice(0, 1200), tag: clean(v.tag).slice(0, 40).toLowerCase(), targetFingerprint: clean(v.targetFingerprint).slice(0, 120)
    };
  }
  function validTeachTarget(v) { return !!(v.selector && v.sectionLabel && v.framePath && v.tag && v.targetFingerprint); }
  function teachProgress(session, state, details) {
    if (!session) return;
    var resp = Object.assign({ ok: state === 'captured' || state === 'connected' || state === 'waiting', state: state }, details || {});
    try { chrome.tabs.sendMessage(session.appTabId, { type: 'mlsAppTeachProgress', requestId: session.requestId, resp: resp }, function () { var ignored = chrome.runtime.lastError; }); } catch (e) {}
  }
  function clearTeachSession(session) {
    if (!session) return;
    if (session.timer) clearTimeout(session.timer); session.timer = null;
    if (teachSessions[session.requestId] === session) delete teachSessions[session.requestId];
    session.cancelled = true;
    releaseTeachGuard(session);
  }
  async function teachWatcher(tabId, config) {
    try {
      var out = await chrome.scripting.executeScript({ target: { tabId: tabId, allFrames: true }, world: 'ISOLATED', args: [config], func: mlsAthenaTeachWatcherFn });
      var results = (out || []).map(function (entry) { return entry && entry.result; }).filter(Boolean);
      var installedFrameIds = (out || []).map(function (entry) { return Number(entry && entry.frameId); }).filter(function (id) { return Number.isFinite(id); }).sort(function (a, b) { return a - b; });
      if (!results.length) {
        if (config && config.mode === 'start') try { await chrome.scripting.executeScript({ target: { tabId: tabId, allFrames: true }, world: 'ISOLATED', args: [{ mode: 'cancel', sessionId: config.sessionId }], func: mlsAthenaTeachWatcherFn }); } catch (eEmptyCleanup) {}
        return { ok: false, state: 'failed', reason: 'watcher-unavailable' };
      }
      if (config && config.mode === 'cancel') return { ok: true, state: 'failed', reason: 'cancelled', frameResults: results.length };
      if (results.some(function (result) { return result.ok !== true; })) {
        /* executeScript can report a mixed all-frame result. Always broadcast
           session-scoped cleanup before returning failure so successful frames
           cannot keep consuming Athena clicks for the remainder of the TTL. */
        try { await chrome.scripting.executeScript({ target: { tabId: tabId, allFrames: true }, world: 'ISOLATED', args: [{ mode: 'cancel', sessionId: config.sessionId }], func: mlsAthenaTeachWatcherFn }); } catch (ePartialCleanup) {}
        return { ok: false, state: 'failed', reason: 'watcher-unavailable' };
      }
      var frameCount = results.reduce(function (sum, result) { return sum + Number(result.frameCount || 0); }, 0);
      if (!frameCount) {
        try { await chrome.scripting.executeScript({ target: { tabId: tabId, allFrames: true }, world: 'ISOLATED', args: [{ mode: 'cancel', sessionId: config.sessionId }], func: mlsAthenaTeachWatcherFn }); } catch (eZeroCleanup) {}
        return { ok: false, state: 'failed', reason: 'watcher-unavailable' };
      }
      return { ok: true, state: 'waiting', frameCount: frameCount, frameResults: results.length, installedFrameIds: installedFrameIds };
    } catch (e) {
      if (config && config.mode === 'start') try { await chrome.scripting.executeScript({ target: { tabId: tabId, allFrames: true }, world: 'ISOLATED', args: [{ mode: 'cancel', sessionId: config.sessionId }], func: mlsAthenaTeachWatcherFn }); } catch (eThrowCleanup) {}
      return { ok: false, state: 'failed', reason: 'watcher-unavailable', error: String((e && e.message) || e).slice(0, 220) };
    }
  }
  async function teachFrameSnapshot(tabId) {
    try {
      if (!chrome.webNavigation || typeof chrome.webNavigation.getAllFrames !== 'function') return null;
      var frames = await chrome.webNavigation.getAllFrames({ tabId: tabId });
      if (!Array.isArray(frames) || !frames.length) return null;
      return frames.map(function (frame) {
        return {
          frameId: Number(frame.frameId), parentFrameId: Number(frame.parentFrameId),
          documentId: clean(frame.documentId), url: urlKey(frame.url)
        };
      }).sort(function (a, b) { return a.frameId - b.frameId; });
    } catch (e) { return null; }
  }
  function sameTeachFrameSnapshot(a, b, installedFrameIds) {
    if (!Array.isArray(a) || !Array.isArray(b) || !Array.isArray(installedFrameIds) || !a.length || a.length !== b.length || a.length !== installedFrameIds.length) return false;
    for (var i = 0; i < a.length; i++) {
      if (a[i].frameId !== b[i].frameId || a[i].frameId !== installedFrameIds[i] || a[i].parentFrameId !== b[i].parentFrameId ||
          (a[i].documentId && b[i].documentId && a[i].documentId !== b[i].documentId) || a[i].url !== b[i].url) return false;
    }
    return true;
  }
  function detachTeachSession(session) {
    if (!teachCurrent(session)) return false;
    session.cancelled = true;
    if (session.timer) clearTimeout(session.timer); session.timer = null;
    delete teachSessions[session.requestId];
    releaseTeachGuard(session);
    return true;
  }
  async function retireTeachSession(session, reason, message, state, skipWatcherCancel) {
    if (!detachTeachSession(session)) return false;
    teachProgress(session, state || 'failed', { ok: false, reason: reason, message: message || 'The taught destination could not be validated. Nothing was changed.' });
    if (!skipWatcherCancel && session.athenaTabId != null) await teachWatcher(session.athenaTabId, { mode: 'cancel', sessionId: session.requestId });
    return true;
  }

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || (msg.type !== 'mlsAppTeachStartRequest' && msg.type !== 'mlsAppTeachCancelRequest' && msg.type !== 'mlsAthenaTeachCaptured' && msg.type !== 'mlsAthenaTeachNavigationGuardReady')) return;
    (async function () {
      if (msg.type === 'mlsAthenaTeachNavigationGuardReady') {
        var owner = teachSessions[teachGuardOwner];
        if (owner && sender && sender.tab && (owner.athenaTabId == null || Number(sender.tab.id) === Number(owner.athenaTabId))) {
          await retireTeachSession(owner, 'athena-page-changed', 'Athena changed while teaching. Click Teach destination again; nothing was captured or changed.', 'failed', owner.athenaTabId == null);
          return { ok: true, state: 'failed', reason: 'athena-page-changed' };
        }
        return { ok: true, state: 'ignored' };
      }
      var requestId = clean(msg.requestId || msg.sessionId).slice(0, 120);
      if (!requestId) return { ok: false, state: 'failed', reason: 'missing-session' };
      if (msg.type === 'mlsAthenaTeachCaptured') {
        var capturedSession = teachSessions[requestId];
        if (!capturedSession) return { ok: false, state: 'expired', reason: 'session-expired' };
        if (!teachCurrent(capturedSession)) return { ok: false, state: 'expired', reason: 'session-expired' };
        if (!sender || !sender.tab || Number(sender.tab.id) !== Number(capturedSession.athenaTabId)) {
          await retireTeachSession(capturedSession, 'wrong-tab', 'The click came from a different tab. Nothing was captured or changed.');
          return { ok: false, state: 'failed', reason: 'wrong-tab' };
        }
        if (Date.now() > capturedSession.expiresAt) {
          await retireTeachSession(capturedSession, 'timeout', 'The read-only watcher expired. Nothing was captured or changed.', 'expired');
          return { ok: false, state: 'expired', reason: 'timeout' };
        }
        var target = teachTarget(msg.target);
        if (!validTeachTarget(target)) {
          /* v2.9.30: a non-teachable click no longer ends the session. The gesture
             was consumed (nothing ran in Athena), so keep watching and say so. */
          teachProgress(capturedSession, 'waiting', { ok: true, message: 'That element cannot be taught (no stable label). Still watching - click the exact destination field.' });
          await teachWatcher(capturedSession.athenaTabId, { mode: 'start', sessionId: requestId, timeoutMs: Math.max(5000, capturedSession.expiresAt - Date.now()) });
          return { ok: true, state: 'waiting', reason: 'invalid-target-retry' };
        }
        var checked = await injectOnce(capturedSession.athenaTabId, {
          mode: 'teach', action: capturedSession.action, expectedPatient: capturedSession.patient, expectedContext: capturedSession.context,
          billing: {}, order: {}, noteText: '', notePolicy: 'empty_only', locked: null, taughtDestination: target
        });
        if (!teachCurrent(capturedSession)) {
          await teachWatcher(capturedSession.athenaTabId, { mode: 'cancel', sessionId: requestId });
          return { ok: false, state: 'expired', reason: 'session-expired' };
        }
        if (!checked || !checked.ok || checked.targetValidated !== true || !checked.contextVerified || !lockedContextShape(checked.context)) {
          var why = clean(checked && (checked.reason || checked.error)) || 'destination-unverified';
          if (why === 'patient-mismatch') {
            await retireTeachSession(capturedSession, why, 'The open Athena chart is not the patient in this review. Nothing was captured.');
            return { ok: false, state: 'failed', reason: why };
          }
          /* v2.9.30: a wrong-spot click no longer ends the session - it was
             consumed, nothing changed in Athena. Keep watching until timeout. */
          teachProgress(capturedSession, 'waiting', { ok: true, message: 'Not the destination yet (' + why + '). Still watching - get the exact encounter screen open, then click the exact field.' });
          await teachWatcher(capturedSession.athenaTabId, { mode: 'start', sessionId: requestId, timeoutMs: Math.max(5000, capturedSession.expiresAt - Date.now()) });
          return { ok: true, state: 'waiting', reason: why + '-retry' };
        }
        var validatedTarget = teachTarget(checked.target || target);
        if (!detachTeachSession(capturedSession)) return { ok: false, state: 'expired', reason: 'session-expired' };
        /* MLS_TEACH_MEMORY_HOOK_START (tdm-1.0.0)  remember the validated,
           PHI-free layout record so this destination survives per practice/
           provider/layout. Recall is a hint only; writes still re-validate. */
        try {
          if (self.MLSTeachMemory && checked.context) {
            self.MLSTeachMemory.saveCaptured({
              practiceId: (self.MLSWriteSafety && self.MLSWriteSafety.practiceIdFromAthenaUrl(checked.context.encounterUrl)) || '',
              provider: checked.context.provider || (capturedSession.context && capturedSession.context.provider) || '',
              action: capturedSession.action,
              target: validatedTarget
            });
          }
        } catch (eTeachMemory) {}
        /* MLS_TEACH_MEMORY_HOOK_END */
        teachProgress(capturedSession, 'captured', { ok: true, message: 'Captured and validated for this exact patient and destination.', target: validatedTarget, binding: capturedSession.binding, context: checked.context });
        await teachWatcher(capturedSession.athenaTabId, { mode: 'cancel', sessionId: requestId });
        return { ok: true, state: 'captured' };
      }

      if (!appSender(sender)) return { ok: false, state: 'failed', reason: 'untrusted-sender' };
      var existing = teachSessions[requestId];
      if (msg.type === 'mlsAppTeachCancelRequest') {
        if (!existing || Number(existing.appTabId) !== Number(sender.tab.id)) return { ok: false, state: 'failed', reason: 'not-watching' };
        await retireTeachSession(existing, 'cancelled', 'Teaching was cancelled. Nothing was captured or changed.');
        return { ok: true, state: 'failed', reason: 'cancelled' };
      }

      var action = clean(msg.action).toLowerCase(), ACTIONS = { write_note: 1, stage_billing: 1, save_draft: 1, sign_encounter: 1, place_order: 1 };
      var binding = teachBinding(msg.binding), patient = msg.expectedPatient || {}, context = msg.expectedContext || {};
      if (!ACTIONS[action] || !validTeachBinding(binding, action)) return { ok: false, state: 'failed', reason: 'invalid-binding', message: 'The destination is not bound to one exact review row.' };
      if (existing) return { ok: false, state: 'failed', reason: 'duplicate-session', message: 'This teaching request is already active.' };
      if (!clean(patient.patientId) || !clean(patient.name) || !dateKey(patient.dob) || !digits(patient.mrn)) return { ok: false, state: 'failed', reason: 'patient-mismatch', message: 'An exact local patient ID, name, DOB, and Athena MRN are required before teaching.' };
      if (!expectedContextShape(context, false) || !dateKey(context.visitDate) || !norm(context.provider) ||
          (!digits(context.appointmentId) && !(digits(context.encounterId) && urlKey(context.encounterUrl)))) {
        return { ok: false, state: 'failed', reason: 'context-mismatch', message: 'The exact visit needs its date, provider, and appointment ID (or bound encounter ID and URL).' };
      }
      /* Register the pending session before the first await. An immediate Cancel
         can now mark/remove it, and every later await verifies ownership before
         it is allowed to install a watcher. */
      var timeoutMs = Math.max(5000, Math.min(300000, Number(msg.timeoutMs || 180000))), now = Date.now();
      var session = { requestId: requestId, appTabId: sender.tab.id, athenaTabId: null, action: action, binding: binding, patient: patient, context: context, issuedAt: now, expiresAt: now + timeoutMs, timer: null, cancelled: false };
      teachSessions[requestId] = session;
      /* One browser-wide teaching gesture at a time. Retire every older exact
         generation synchronously before the first tab query so an old capture
         already in flight can no longer complete while a new row is arming. */
      var priorSessions = Object.keys(teachSessions).map(function (id) { return teachSessions[id]; }).filter(function (prior) { return prior && prior !== session; });
      var retirePromises = priorSessions.map(function (prior) { return retireTeachSession(prior, 'replaced', 'A newer teaching request replaced this watcher. Nothing was captured.'); });
      if (retirePromises.length) await Promise.all(retirePromises);
      if (!teachCurrent(session)) return { ok: false, state: 'failed', reason: 'cancelled', message: 'Teaching was cancelled before the watcher started.' };
      var guardReady = await registerTeachGuard(session);
      if (!teachCurrent(session)) return { ok: false, state: 'failed', reason: 'cancelled', message: 'Teaching was cancelled before the watcher started.' };
      if (!guardReady) {
        detachTeachSession(session);
        return { ok: false, state: 'failed', reason: 'watcher-unavailable', message: 'MLS Assist could not arm the navigation-safe Athena watcher.' };
      }
      var tabs = exactAthenaTabs(await chrome.tabs.query({}));
      if (!teachCurrent(session)) return { ok: false, state: 'failed', reason: 'cancelled', message: 'Teaching was cancelled before the watcher started.' };
      if (tabs.length !== 1) {
        clearTeachSession(session);
        return { ok: false, state: 'failed', reason: tabs.length ? 'ambiguous-athena-tabs' : 'no-athena-tab', message: tabs.length ? 'Leave exactly one signed-in Athena tab open, then try again.' : 'Open one signed-in Athena tab, then try again.' };
      }
      session.athenaTabId = tabs[0].id;
      var framesBefore = await teachFrameSnapshot(session.athenaTabId);
      if (!teachCurrent(session)) return { ok: false, state: 'failed', reason: 'cancelled', message: 'Teaching was cancelled while Athena was being checked.' };
      if (!framesBefore) {
        await retireTeachSession(session, 'frame-coverage-unverified', 'MLS Assist could not verify every current Athena frame. Click Teach destination again; nothing was changed.');
        return { ok: false, state: 'failed', reason: 'frame-coverage-unverified' };
      }
      var started = await teachWatcher(session.athenaTabId, { mode: 'start', sessionId: requestId, timeoutMs: timeoutMs });
      if (!teachCurrent(session)) {
        await teachWatcher(session.athenaTabId, { mode: 'cancel', sessionId: requestId });
        return { ok: false, state: 'failed', reason: 'cancelled', message: 'Teaching was cancelled before the watcher finished attaching.' };
      }
      if (!started || !started.ok) {
        await retireTeachSession(session, clean(started && (started.reason || started.error)) || 'watcher-unavailable', 'MLS Assist could not attach the read-only Athena watcher.');
        return { ok: false, state: 'failed', reason: clean(started && (started.reason || started.error)) || 'watcher-unavailable', message: 'MLS Assist could not attach the read-only Athena watcher.' };
      }
      var framesAfter = await teachFrameSnapshot(session.athenaTabId);
      if (!teachCurrent(session)) {
        await teachWatcher(session.athenaTabId, { mode: 'cancel', sessionId: requestId });
        return { ok: false, state: 'failed', reason: 'cancelled', message: 'Teaching was cancelled while Athena was being checked.' };
      }
      if (!sameTeachFrameSnapshot(framesBefore, framesAfter, started.installedFrameIds)) {
        await retireTeachSession(session, 'frame-generation-changed', 'Athena changed while the watcher was attaching. Click Teach destination again; nothing was captured or changed.');
        return { ok: false, state: 'failed', reason: 'frame-generation-changed' };
      }
      session.timer = setTimeout(function () {
        if (!teachCurrent(session)) return;
        retireTeachSession(session, 'timeout', 'The read-only watcher expired. Nothing was captured or changed.', 'expired');
      }, timeoutMs + 50);
      teachProgress(session, 'waiting', { ok: true, message: 'Waiting for the next Athena click. That teaching click will be blocked from activating the control.' });
      return { ok: true, state: 'waiting', requestId: requestId, expiresAt: session.expiresAt, message: 'Connected. Waiting for the next Athena click.' };
    })().then(function (result) { try { sendResponse(result); } catch (e) {} }).catch(function (e) { try { sendResponse({ ok: false, state: 'failed', reason: 'watcher-error', message: String((e && e.message) || e).slice(0, 220) }); } catch (e2) {} });
    return true;
  });
  function activeTeachSessionsForTab(tabId) {
    return Object.keys(teachSessions).map(function (id) { return teachSessions[id]; }).filter(function (session) {
      return teachCurrent(session) && (Number(session.appTabId) === Number(tabId) || Number(session.athenaTabId) === Number(tabId));
    });
  }
  function retireTeachForTab(tabId, reason, message, closedTab) {
    activeTeachSessionsForTab(tabId).forEach(function (session) {
      var skipWatcher = !!closedTab && Number(session.athenaTabId) === Number(tabId);
      retireTeachSession(session, reason, message, 'failed', skipWatcher);
    });
  }
  try {
    chrome.tabs.onRemoved.addListener(function (tabId) {
      retireTeachForTab(tabId, 'teaching-tab-closed', 'The MLS or Athena tab closed while teaching. Click Teach destination again; nothing was captured or changed.', true);
    });
    chrome.tabs.onUpdated.addListener(function (tabId, changeInfo) {
      if (!changeInfo || (changeInfo.status !== 'loading' && !Object.prototype.hasOwnProperty.call(changeInfo, 'url'))) return;
      retireTeachForTab(tabId, 'teaching-tab-navigated', 'The MLS or Athena page changed while teaching. Click Teach destination again; nothing was captured or changed.', false);
    });
  } catch (eTabLifecycle) {}
  try {
    chrome.webNavigation.onBeforeNavigate.addListener(function (details) {
      if (!details || details.tabId == null) return;
      var sessions = activeTeachSessionsForTab(details.tabId).filter(function (session) { return Number(session.athenaTabId) === Number(details.tabId); });
      sessions.forEach(function (session) {
        /* onBeforeNavigate fires for every frame generation. Retire ownership
           synchronously; the document_start guard blocks the replacement frame
           until this cancellation is acknowledged. */
        retireTeachSession(session, 'athena-frame-navigated', 'Athena changed while teaching. Click Teach destination again; nothing was captured or changed.', 'failed', false);
      });
    });
  } catch (eFrameLifecycle) {}
  /* DESTINATION_TEACH_HANDLER_END */

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || msg.type !== 'mlsAppAthenaActionV2Request') return;
    (async function () {
      var mode = clean(msg.mode).toLowerCase(), action = clean(msg.action).toLowerCase();
      var ACTIONS = { write_note: 1, stage_billing: 1, save_draft: 1, sign_encounter: 1, place_order: 1 };
      if (!/^(probe|execute)$/.test(mode) || !ACTIONS[action]) return { ok: false, blocked: true, reason: 'unknown-action' };
      /* MLS_WRITE_SAFETY_GATE_START (wsg-1.0.0)  sign/order/billing lanes are
         PREVIEW-ONLY: probe stays available for the review screen; execute is
         refused here, again inside the driver, and the athenanet synthetic-click
         interceptor is the final backstop. Also enforces the Adam-only (7833832)
         TEST-content policy on note writes. Fail-closed if the guard is absent. */
      if (self.MLSWriteSafety) {
        var wsGate = self.MLSWriteSafety.gateActionRequest({ mode: mode, action: action, expectedPatient: msg.expectedPatient, noteText: msg.noteText, isTest: msg.isTest === true });
        if (wsGate) return wsGate;
      } else if (mode === 'execute' && (action === 'sign_encounter' || action === 'place_order' || action === 'stage_billing')) {
        return { ok: false, blocked: true, reason: 'write-safety-guard-missing', error: 'The write-safety guard failed to load; final actions are blocked. Nothing was changed.' };
      }
      /* MLS_WRITE_SAFETY_GATE_END */
      var actionToken = '', rec = null;
      if (mode === 'execute') {
        actionToken = clean(msg.actionToken); rec = tokens[actionToken];
        if (!rec) return { ok: false, blocked: true, reason: 'token-expired' };
        if (rec.used) return { ok: false, blocked: true, reason: 'token-used' };
        if (Date.now() > rec.expiresAt) { rec.used = true; return { ok: false, blocked: true, reason: 'token-expired' }; }
        /* ATHENA_ACTION_V2_MUTATION_BOUNDARY */
        rec.used = true; // the first execute attempt consumes the token, even on a later mismatch
      }
      var previewHash = clean(msg.previewHash), manifestHash = clean(msg.manifestHash), p = msg.expectedPatient || {}, c = msg.expectedContext || {}, b = msg.billing || {}, suppliedOrder = msg.order || {};
      var rowHash = clean(msg.rowHash), clientOrderId = clean(msg.clientOrderId);
      var noteText = String(msg.noteText == null ? '' : msg.noteText), notePolicy = clean(msg.notePolicy || 'empty_only'), noteSections = Array.isArray(msg.sections) ? msg.sections : [];
      var canonicalNotePayload = notePayloadKey(noteText, noteSections, notePolicy);
      var canonicalBillingPayload = billingKey(b);
      var checkedOrder = action === 'place_order' ? canonicalOrderPayload(suppliedOrder) : { ok: true, order: {}, payload: '' };
      var canonicalOrderKey = checkedOrder.ok ? checkedOrder.payload : '';
      var checkedTaught = canonicalTaughtDestination(msg.taughtDestination), canonicalTaughtKey = checkedTaught.ok ? checkedTaught.payload : '';
      var noteHash = simpleHash(canonicalNotePayload);
      var noteWriteProofId = clean(msg.noteWriteProof), proofRecord = null;
      if (!previewHash) return { ok: false, blocked: true, reason: 'preview-hash-mismatch' };
      if (!checkedTaught.ok) return { ok: false, blocked: true, reason: checkedTaught.reason };
      if (checkedTaught.value && (checkedTaught.value.action !== action || checkedTaught.value.rowHash !== rowHash || checkedTaught.value.manifestHash !== manifestHash)) return { ok: false, blocked: true, reason: 'taught-destination-binding-mismatch' };
      if (!clean(p.patientId)) return { ok: false, blocked: true, reason: 'local-patient-id-required' };
      if (!clean(p.name) || !dateKey(p.dob) || !digits(p.mrn)) return { ok: false, blocked: true, reason: 'patient-mismatch' };
      if (action === 'place_order' && (!rowHash || rowHash.length > 160)) return { ok: false, blocked: true, reason: 'order-row-mismatch' };
      if (!expectedContextShape(c, mode === 'execute') || !dateKey(c.visitDate) || !norm(c.provider) ||
          (!digits(c.appointmentId) && !(digits(c.encounterId) && urlKey(c.encounterUrl)))) return { ok: false, blocked: true, reason: 'context-mismatch' };
      if (action === 'place_order' && !checkedOrder.ok) return { ok: false, blocked: true, reason: checkedOrder.reason };
      if (action === 'place_order' && (!clientOrderId || clientOrderId.length > 160 || clientOrderId !== checkedOrder.order.clientOrderId)) return { ok: false, blocked: true, reason: 'order-client-id-mismatch' };
      if (action !== 'stage_billing' && action !== 'place_order' && !noteNorm(noteText)) return { ok: false, blocked: true, reason: 'note-content-required' };
      if (action === 'write_note' && notePolicy !== 'empty_only') return { ok: false, blocked: true, reason: 'unsafe-note-policy' };
      if (action === 'stage_billing') {
        var rawCodes = []; if (clean(b.emCode)) rawCodes.push(clean(b.emCode).toUpperCase()); if (Array.isArray(b.cptCodes)) rawCodes = rawCodes.concat(b.cptCodes.map(function (x) { return clean(x).toUpperCase(); }));
        if (!rawCodes.length || rawCodes.some(function (x) { return !/^(?=[A-Z0-9]*\d)[A-Z0-9]{5}$/.test(x); })) return { ok: false, blocked: true, reason: 'billing-near-match-rejected' };
        var uniq = {}; for (var ui = 0; ui < rawCodes.length; ui++) { if (uniq[rawCodes[ui]]) return { ok: false, blocked: true, reason: 'billing-duplicate-rejected' }; uniq[rawCodes[ui]] = 1; }
      }
      if (mode === 'probe') {
        if (!appSender(sender)) return { ok: false, blocked: true, reason: 'token-sender-mismatch' };
        var all = await chrome.tabs.query({}), tab = await pickExactAthena(sender, p, all);
        if (tab && tab.__error) return { ok: false, blocked: true, reason: tab.__error, error: tab.__message };
        if (action === 'sign_encounter') {
          proofRecord = matchingNoteWriteProof(noteWriteProofId, sender.tab.id, tab.id, p, previewHash, noteHash, canonicalNotePayload, null);
          if (!proofRecord) return { ok: false, blocked: true, reason: noteWriteProofFailure(noteWriteProofId), error: 'Write and verify this exact reviewed note in this encounter before signing.' };
        }
        var probe = await injectOnce(tab.id, { mode: 'probe', action: action, expectedPatient: p, expectedContext: c, billing: b, order: checkedOrder.order, noteText: noteText, notePolicy: notePolicy, locked: null, taughtDestination: checkedTaught.value });
        if (!probe || !probe.ok || !probe.contextVerified || !lockedContextShape(probe.context)) return probe && probe.ok ? { ok: false, blocked: true, reason: 'context-unverified' } : (probe || { ok: false, blocked: true, reason: 'context-unverified' });
        if (action === 'sign_encounter' && !matchingNoteWriteProof(noteWriteProofId, sender.tab.id, tab.id, p, previewHash, noteHash, canonicalNotePayload, probe.context)) return { ok: false, blocked: true, reason: 'sign-prerequisite-mismatch', error: 'The verified note write does not match this encounter.' };
        if ((dateKey(c.visitDate) && dateKey(c.visitDate) !== dateKey(probe.context.visitDate)) ||
            (norm(c.provider) && norm(c.provider) !== norm(probe.context.provider)) ||
            (digits(c.appointmentId) && digits(c.appointmentId) !== digits(probe.context.appointmentId)) ||
            (digits(c.encounterId) && digits(c.encounterId) !== digits(probe.context.encounterId)) ||
            (urlKey(c.encounterUrl) && urlKey(c.encounterUrl) !== urlKey(probe.context.encounterUrl))) return { ok: false, blocked: true, reason: 'context-mismatch' };
        /* Only the newest authorization for one manifest may remain live.
           Without this, a click intended for row B could replay an older token
           minted for row A because both rows share the manifest preview hash. */
        if (action === 'place_order') Object.keys(tokens).forEach(function (id) {
          var prior = tokens[id];
          if (prior && !prior.used && prior.action === 'place_order' && Number(prior.senderTabId) === Number(sender.tab.id) && prior.previewHash === previewHash) {
            prior.used = true; prior.invalidated = true;
          }
        });
        var tok = tokenValue(), now = Date.now();
        tokens[tok] = {
          used: false, issuedAt: now, expiresAt: now + TOKEN_TTL_MS,
          senderTabId: sender.tab.id, athenaTabId: tab.id, action: action,
          previewHash: previewHash, patientHash: simpleHash(patientKey(p)), expectedMrn: digits(p.mrn),
          expectedContextHash: simpleHash(expectedContextKey(c)), billingHash: simpleHash(canonicalBillingPayload), billingPayload: canonicalBillingPayload, orderHash: simpleHash(canonicalOrderKey), orderPayload: canonicalOrderKey, noteHash: noteHash, notePayload: canonicalNotePayload,
          manifestHash: manifestHash, taughtDestinationHash: simpleHash(canonicalTaughtKey), taughtDestinationPayload: canonicalTaughtKey,
          patientId: clean(p.patientId), clientOrderId: action === 'place_order' ? checkedOrder.order.clientOrderId : '', rowHash: action === 'place_order' ? rowHash : '',
          noteWriteProof: action === 'sign_encounter' ? noteWriteProofId : '',
          expectedContext: { appointmentId: digits(c.appointmentId), encounterId: digits(c.encounterId), encounterUrl: urlKey(c.encounterUrl), visitDate: dateKey(c.visitDate), provider: norm(c.provider) },
          lockedContextHash: simpleHash(expectedContextKey(probe.context)),
          locked: probe.context
        };
        /* ATHENA_ACTION_V2_PROBE_READ_ONLY_RETURN */
        return { ok: true, mode: 'probe', action: action, readOnly: true, actionToken: tok, expiresAt: now + TOKEN_TTL_MS, previewHash: previewHash, rowHash: action === 'place_order' ? rowHash : '', clientOrderId: action === 'place_order' ? checkedOrder.order.clientOrderId : '', context: probe.context, reason: probe.reason || 'context-verified', noAutomaticChaining: 'no-automatic-chaining' };
      }

      if (!appSender(sender)) return { ok: false, blocked: true, reason: 'token-sender-mismatch' };
      if (Number(rec.senderTabId) !== Number(sender.tab.id)) return { ok: false, blocked: true, reason: 'token-sender-mismatch' };
      if (rec.action !== action) return { ok: false, blocked: true, reason: 'token-action-mismatch' };
      if (rec.previewHash !== previewHash) return { ok: false, blocked: true, reason: 'preview-hash-mismatch' };
      if (rec.manifestHash !== manifestHash) return { ok: false, blocked: true, reason: 'taught-destination-binding-mismatch' };
      if (action === 'place_order' && rec.rowHash !== rowHash) return { ok: false, blocked: true, reason: 'order-row-mismatch' };
      if (action === 'place_order' && (rec.clientOrderId !== clientOrderId || rec.clientOrderId !== checkedOrder.order.clientOrderId)) return { ok: false, blocked: true, reason: 'order-client-id-mismatch' };
      if (rec.patientHash !== simpleHash(patientKey(p))) return { ok: false, blocked: true, reason: 'patient-mismatch' };
      if (rec.patientId !== clean(p.patientId)) return { ok: false, blocked: true, reason: 'patient-mismatch' };
      if (digits(p.mrn) && digits(p.mrn) !== digits(rec.locked && rec.locked.mrn)) return { ok: false, blocked: true, reason: 'patient-mismatch' };
      if (rec.expectedMrn && rec.expectedMrn !== digits(rec.locked && rec.locked.mrn)) return { ok: false, blocked: true, reason: 'patient-mismatch' };
      if (rec.billingPayload !== canonicalBillingPayload || rec.billingHash !== simpleHash(canonicalBillingPayload)) return { ok: false, blocked: true, reason: 'billing-payload-mismatch' };
      if (rec.orderPayload !== canonicalOrderKey || rec.orderHash !== simpleHash(canonicalOrderKey)) return { ok: false, blocked: true, reason: 'order-payload-mismatch' };
      if (rec.notePayload !== canonicalNotePayload || rec.noteHash !== noteHash) return { ok: false, blocked: true, reason: 'note-payload-mismatch' };
      if (rec.taughtDestinationPayload !== canonicalTaughtKey || rec.taughtDestinationHash !== simpleHash(canonicalTaughtKey)) return { ok: false, blocked: true, reason: 'taught-destination-binding-mismatch' };
      if (!expectedContextMatches(c, rec.expectedContext, rec.locked) || rec.expectedContextHash !== simpleHash(expectedContextKey(c)) || rec.lockedContextHash !== simpleHash(expectedContextKey(rec.locked))) return { ok: false, blocked: true, reason: 'context-mismatch' };
      if (!probeContextMatches(msg.probeContext, rec.locked)) return { ok: false, blocked: true, reason: 'context-mismatch' };
      if (msg.userGesture !== true || !clean(msg.gestureProof)) return { ok: false, blocked: true, reason: 'fresh-trusted-click-required' };
      if (action === 'place_order' && (clean(msg.gestureRowHash) !== rec.rowHash || clean(msg.gestureClientOrderId) !== rec.clientOrderId)) return { ok: false, blocked: true, reason: 'fresh-trusted-click-required' };
      /* Re-query the complete tab set at the last pre-mutation gate. A token
         cannot remain valid if another signed-in Athena tab appeared, the
         locked tab signed out, or a different Athena tab replaced it. */
      var liveCandidates = exactAthenaTabs(await chrome.tabs.query({}));
      if (liveCandidates.length !== 1 || Number(liveCandidates[0].id) !== Number(rec.athenaTabId)) return { ok: false, blocked: true, reason: 'token-tab-mismatch', error: liveCandidates.length > 1 ? 'More than one signed-in Athena tab is open. Leave exactly one Athena tab open, then retry. Nothing was changed.' : 'The locked Athena tab is no longer the only signed-in Athena tab. Nothing was changed.' };
      if (executeBusy) return { ok: false, blocked: true, reason: 'outcome-uncertain', detail: 'another-athena-action-is-running', noAutomaticChaining: 'no-automatic-chaining' };
      if (action === 'sign_encounter') {
        if (!noteWriteProofId || noteWriteProofId !== rec.noteWriteProof) return { ok: false, blocked: true, reason: 'sign-prerequisite-mismatch' };
        proofRecord = matchingNoteWriteProof(noteWriteProofId, sender.tab.id, rec.athenaTabId, p, previewHash, noteHash, canonicalNotePayload, rec.locked);
        if (!proofRecord) return { ok: false, blocked: true, reason: noteWriteProofFailure(noteWriteProofId) };
        proofRecord.used = true; // the immediate pre-injection Sign attempt consumes the proof
      }
      /* MLS_WRITE_SAFETY_CONTEXT_GATE_START (wsg-1.0.0)  verify the signed-in
         account (when the app supplied an expectation) and that the live Athena
         tab's practice id matches the locked encounter's practice id. Supplied
         expectations that cannot be verified BLOCK (fail-closed). */
      if (self.MLSWriteSafety) {
        var wsCtxGate = await self.MLSWriteSafety.verifyAccountPracticeGate({ tabId: rec.athenaTabId, expectedAccount: clean(msg.expectedAccount), expectedPracticeId: clean(msg.expectedPracticeId), lockedEncounterUrl: rec.locked && rec.locked.encounterUrl });
        if (wsCtxGate && wsCtxGate.blocked) return wsCtxGate;
      }
      /* MLS_WRITE_SAFETY_CONTEXT_GATE_END */
      executeBusy = true;
      var executed;
      try {
        /* ATHENA_ACTION_V2_EXECUTE_INJECTION */
        executed = await injectOnce(rec.athenaTabId, { mode: 'execute', action: action, expectedPatient: p, expectedContext: { appointmentId: rec.locked.appointmentId, encounterId: rec.locked.encounterId, encounterUrl: rec.locked.encounterUrl, visitDate: rec.locked.visitDate, provider: rec.locked.provider }, billing: b, order: checkedOrder.order, noteText: noteText, notePolicy: notePolicy, locked: rec.locked, taughtDestination: checkedTaught.value });
      } finally { executeBusy = false; }
      if (!executed) return { ok: false, attempted: true, verified: false, reason: 'outcome-uncertain', noAutomaticChaining: 'no-automatic-chaining' };
      if (action === 'write_note' && executed.written === true && executed.verified === true && executed.draftVerified === true && lockedContextShape(executed.context) && probeContextMatches(executed.context, rec.locked) && simpleHash(encounterProofKey(executed.context)) === simpleHash(encounterProofKey(rec.locked))) {
        var noteWriteProof = tokenValue(), proofNow = Date.now();
        noteWriteProofs[noteWriteProof] = {
          used: false, issuedAt: proofNow, expiresAt: proofNow + NOTE_PROOF_TTL_MS,
          senderTabId: sender.tab.id, athenaTabId: rec.athenaTabId,
          previewHash: previewHash, patientKey: patientKey(p), patientHash: simpleHash(patientKey(p)),
          notePayload: canonicalNotePayload, noteHash: noteHash,
          lockedContextKey: encounterProofKey(executed.context), lockedContextHash: simpleHash(encounterProofKey(executed.context))
        };
        executed.noteWriteProof = noteWriteProof;
        executed.noteWriteProofExpiresAt = proofNow + NOTE_PROOF_TTL_MS;
      }
      if (action === 'sign_encounter' && proofRecord && proofRecord.used) executed.noteWriteProofConsumed = true;
      executed.patientId = clean(p.patientId);
      if (action === 'place_order') { executed.clientOrderId = checkedOrder.order.clientOrderId; executed.rowHash = rowHash; }
      executed.actionTokenConsumed = true;
      executed.noAutomaticChaining = 'no-automatic-chaining';
      return executed;
    })().then(function (r) { sendResponse(r); }).catch(function (e) { sendResponse({ ok: false, reason: 'outcome-uncertain', error: String((e && e.message) || e), noAutomaticChaining: 'no-automatic-chaining' }); });
    return true;
  });
})();
/* ATHENA_ACTION_V2_HANDLER_END */

/* ===========================================================================
 * v2.9.5 QUIET PULL (__mlsQp) — pulls must never steal the doctor's focus.
 * Live-measured ground truth (2026-07-13, this machine): a Chrome window that
 * is fully COVERED (or minimized) is occluded — visibilityState hidden, rAF
 * 0/s, timers 1/s then 1/min. So a pull genuinely needs the athena tab VISIBLE
 * somewhere; the old approach made it visible by foregrounding it over the
 * doctor's work (tab yank) and the guardian yanked back after — the reported
 * "keeps pulling me to the athena tab". Instead:
 *   - qpEnsure(tab, senderTabId): make athena visible WITHOUT touching focus —
 *     move it once into a narrow work-strip window on the right edge (created
 *     focused:false) without resizing/unmaximizing the user's window. Already
 *     visible -> no-op. If the strip is still occluded,
 *     visible afterwards (user re-maximized over it, another app on top),
 *     return 'limp': the read proceeds throttled under the callers' existing
 *     budgets/retries, and the strip flashes the taskbar ONCE. Never focuses.
 *   - qpRelease(): put Athena back (original window+index, while preserving the
 *     user's current non-Athena tab) — fired by end-of-run mlsAppFocusMlsTab, a 120s
 *     quiet watchdog + alarms backstop (worker restarts), and before any
 *     write op (writes keep the proven foreground-for-write behavior).
 * Quiet pulls record NO focus debt, so the guardian never yanks the doctor
 * back to MLS either. Moves/resizes windows only; clicks nothing; never
 * focuses a window the doctor is using.
 * =========================================================================== */
(function () {
  'use strict';
  var QP = { active: false, winId: null, athenaTabId: null, orig: null, soloWin: false, athOrig: null,
             hostWinId: null, hostOrig: null, lastUse: 0, flashed: false, pending: null, restoring: null, epoch: 0 };
  self.__mlsQp = QP;
  var QP_QUIET_MS = 120000; /* run considered over after 2 min without op traffic */
  var QP_SERIAL_WAIT_MS = 5000;
  var QP_PENDING_RELEASE_MS = 1500;
  var QP_RESTORE_WAIT_MS = 8000;

  function qpTouch() {
    QP.lastUse = Date.now();
    if (QP.active) { try { chrome.alarms.create('mlsQpWatch', { delayInMinutes: 1 }); } catch (e) {} }
  }
  self.__mlsQpTouch = qpTouch;

  function persist() {
    try {
      chrome.storage.session.set({ mlsQpState: QP.active ? {
        winId: QP.winId, athenaTabId: QP.athenaTabId, orig: QP.orig, soloWin: QP.soloWin,
        athOrig: QP.athOrig, hostWinId: QP.hostWinId, hostOrig: QP.hostOrig, strip: QP.strip || null, at: Date.now() } : null });
    } catch (e) {}
  }

  function tabVisible(tabId) {
    return Promise.race([
      chrome.scripting.executeScript({ target: { tabId: tabId }, func: function () { return document.visibilityState; } })
        .then(function (r) { return !!(r && r[0] && r[0].result === 'visible'); })
        .catch(function () { return false; }),
      new Promise(function (res) { setTimeout(function () { res(false); }, 4000); })
    ]);
  }

  function qpSleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function qpAwaitBound(promise, ms) {
    var settled = false;
    return Promise.race([
      Promise.resolve(promise).then(function () { settled = true; return true; }, function () { settled = true; return true; }),
      qpSleep(Math.max(0, Number(ms || 0))).then(function () { return settled; })
    ]);
  }

  async function ensureBody(tab, senderTabId) {
    if (await tabVisible(tab.id)) return 'visible'; /* already on screen (incl. doctor parked on athena) */

    /* strip exists? re-assert it (user may have minimized it or covered it) —
       never focus. Live-measured: an unfocused bounds update RAISES the window
       above whatever covers it without stealing focus, so re-applying the strip
       bounds is the covered-mid-run recovery. */
    if (QP.active && QP.winId != null) {
      try {
        var w0 = await chrome.windows.get(QP.winId);
        if (w0.state === 'minimized') await chrome.windows.update(QP.winId, { state: 'normal' });
        if (QP.strip) await chrome.windows.update(QP.winId, { left: QP.strip.left, top: QP.strip.top, width: QP.strip.width, height: QP.strip.height });
      } catch (e) { QP.active = false; QP.winId = null; }
    }

    if (!QP.active) {
      /* the doctor's window = the window of the asking app tab, else last focused */
      var hostWin = null;
      try { if (senderTabId != null) { var st = await chrome.tabs.get(senderTabId); hostWin = await chrome.windows.get(st.windowId); } } catch (e) {}
      if (!hostWin) { try { hostWin = await chrome.windows.getLastFocused({ windowTypes: ['normal'] }); } catch (e) {} }
      var athWin = null;
      try { athWin = await chrome.windows.get(tab.windowId, { populate: true }); } catch (e) {}
      var soloAthena = !!(athWin && athWin.tabs && athWin.tabs.length === 1 && athWin.tabs[0].id === tab.id);
      var base = (hostWin && hostWin.state !== 'minimized') ? hostWin : athWin;
      if (!base) return 'limp';
      var b = { left: base.left | 0, top: base.top | 0, width: base.width | 0, height: base.height | 0 };
      var stripW = Math.min(780, Math.max(520, Math.floor(b.width * 0.3)));
      var strip = { left: b.left + b.width - stripW, top: b.top, width: stripW, height: b.height };

      /* Never resize/unmaximize the user's working window for a READ. The
         unfocused Athena strip overlays the right edge; if the compositor still
         occludes it, callers use their bounded limp-mode retries. */
      QP.hostWinId = null; QP.hostOrig = null;

      if (soloAthena) {
        /* athena already has its own window: just place it — never focus it */
        QP.winId = tab.windowId; QP.soloWin = true; QP.orig = null;
        QP.athOrig = athWin ? { left: athWin.left, top: athWin.top, width: athWin.width, height: athWin.height, state: athWin.state } : null;
        try {
          var aw = await chrome.windows.get(tab.windowId);
          if (aw.state !== 'normal') await chrome.windows.update(tab.windowId, { state: 'normal' });
          await chrome.windows.update(tab.windowId, { left: strip.left, top: strip.top, width: strip.width, height: strip.height });
        } catch (e) {}
      } else {
        QP.orig = { windowId: tab.windowId, index: tab.index, active: !!tab.active }; QP.soloWin = false; QP.athOrig = null;
        try {
          var nw = await chrome.windows.create({ tabId: tab.id, focused: false, type: 'normal', left: strip.left, top: strip.top, width: strip.width, height: strip.height });
          QP.winId = (nw && nw.id != null) ? nw.id : null;
        } catch (e) { QP.winId = null; }
      }
      QP.athenaTabId = tab.id; QP.active = QP.winId != null; QP.flashed = false; QP.strip = strip;
      persist();
      if (!QP.active) return 'limp';
    }

    /* The moved tab should normally already be active in the unfocused strip.
       If a human selected another tab/window after setup, never override that
       choice merely to make Athena visible; proceed throttled in limp mode. */
    try {
      var t2 = await chrome.tabs.get(tab.id);
      if (!t2.active) {
        if (await mlsReadFocusWouldYank(tab.id)) return 'limp';
        await chrome.tabs.update(tab.id, { active: true });
      }
    } catch (e) {}
    await qpSleep(400); /* let the compositor recompute occlusion */
    if (await tabVisible(tab.id)) return 'strip';
    await qpSleep(700);
    if (await tabVisible(tab.id)) return 'strip';
    /* Live 2026-07-16: after a service-worker restart the strip can sit with
       IDENTICAL bounds under the doctor's window, and a same-bounds update is
       a no-op that never raises it. Two REAL bounds changes (12px out, then
       back) force a raise + repaint without focusing anything. */
    if (QP.winId != null && QP.strip) {
      try {
        await chrome.windows.update(QP.winId, { left: QP.strip.left - 12, top: QP.strip.top, width: QP.strip.width, height: QP.strip.height });
        await qpSleep(150);
        await chrome.windows.update(QP.winId, { left: QP.strip.left, top: QP.strip.top, width: QP.strip.width, height: QP.strip.height });
      } catch (eJiggle) {}
      await qpSleep(600);
      if (await tabVisible(tab.id)) return 'strip';
    }
    /* Live 2026-07-16 (screenshot-verified): the doctor was working in a
       maximized window that fully covered the strip - occluded tabs stop
       rendering and every read stalls. When a SECOND display exists, move the
       strip to a display that does NOT contain the doctor's window and
       re-check. Never focuses anything; single-display setups keep the
       existing limp behavior. */
    try {
      if (QP.winId != null && chrome.system && chrome.system.display && chrome.system.display.getInfo) {
        var displays = await chrome.system.display.getInfo();
        if (displays && displays.length > 1) {
          var hostWin2 = null;
          try { if (senderTabId != null) { var st2 = await chrome.tabs.get(senderTabId); hostWin2 = await chrome.windows.get(st2.windowId); } } catch (eH2) {}
          if (!hostWin2) { try { hostWin2 = await chrome.windows.getLastFocused({ windowTypes: ['normal'] }); } catch (eH3) {} }
          var hx = hostWin2 ? (hostWin2.left | 0) + ((hostWin2.width | 0) / 2) : 0;
          var hy = hostWin2 ? (hostWin2.top | 0) + ((hostWin2.height | 0) / 2) : 0;
          var other = null;
          for (var di = 0; di < displays.length; di++) {
            var wa = displays[di].workArea || displays[di].bounds;
            if (!wa) continue;
            var containsHost = hx >= wa.left && hx < wa.left + wa.width && hy >= wa.top && hy < wa.top + wa.height;
            if (!containsHost) { other = wa; break; }
          }
          if (other) {
            var stripW2 = Math.min(900, Math.max(520, Math.floor(other.width * 0.45)));
            var alt = { left: other.left + other.width - stripW2, top: other.top, width: stripW2, height: other.height };
            try { var aw2 = await chrome.windows.get(QP.winId); if (aw2.state !== 'normal') await chrome.windows.update(QP.winId, { state: 'normal' }); } catch (eAw2) {}
            await chrome.windows.update(QP.winId, { left: alt.left, top: alt.top, width: alt.width, height: alt.height });
            QP.strip = alt; persist();
            await qpSleep(700);
            if (await tabVisible(tab.id)) return 'strip';
          }
        }
      }
    } catch (eAltDisplay) {}
    /* still covered (doctor re-maximized / another app on top): read anyway,
       throttled, under the callers' existing budgets. Nudge ONCE, never focus. */
    if (!QP.flashed) { QP.flashed = true; try { if (QP.winId != null) chrome.windows.update(QP.winId, { drawAttention: true }); } catch (e) {} }
    return 'limp';
  }

  async function qpEnsure(tab, senderTabId) {
    qpTouch();
    if (!tab || tab.id == null) return 'limp';
    var entryEpoch = Number(QP.epoch || 0);
    /* Never let a caller wait forever behind a browser promise that Chrome may
       never settle. More importantly, a release increments the epoch: an
       ensure which was already waiting then returns without starting a late
       window move after its caller has timed out. */
    if (QP.pending) {
      var priorPending = QP.pending;
      if (!(await qpAwaitBound(priorPending, QP_SERIAL_WAIT_MS)) || entryEpoch !== Number(QP.epoch || 0)) return 'limp';
    }
    if (QP.restoring) {
      var priorRestore = QP.restoring;
      if (!(await qpAwaitBound(priorRestore, QP_SERIAL_WAIT_MS)) || entryEpoch !== Number(QP.epoch || 0)) return 'limp';
    }
    if (entryEpoch !== Number(QP.epoch || 0)) return 'limp';
    var p = ensureBody(tab, senderTabId).catch(function () { return 'limp'; });
    QP.pending = p;
    try { return await p; } finally { if (QP.pending === p) QP.pending = null; qpTouch(); }
  }
  self.__mlsQpEnsure = qpEnsure;

  async function releaseBody() {
    /* Moving the worker Athena tab back into its original window can activate
       it. Preserve any different tab the doctor currently selected, including
       another Athena tab, and restore only if the move itself displaced it. */
    var preserveTabId = null;
    try {
      var focused = await chrome.windows.getLastFocused({ populate: true, windowTypes: ['normal'] });
      var focusedTabs = (focused && focused.tabs) || [];
      for (var pi = 0; pi < focusedTabs.length; pi++) {
        if (focusedTabs[pi].active && focusedTabs[pi].id !== QP.athenaTabId) { preserveTabId = focusedTabs[pi].id; break; }
      }
    } catch (e) {}
    /* Preserve the destination window's selected tab too. Moving the worker
       Athena tab out of its one-tab strip can otherwise activate it in the
       original (possibly unfocused) window; the user then appears to be
       "yanked" to Athena the next time that window is used. Capture the
       selection immediately before the move, so a newer human choice wins. */
    var destinationActiveTabId = null, movedHome = false;
    if (!QP.soloWin && QP.athenaTabId != null && QP.orig && QP.orig.windowId != null) {
      try {
        var destinationBefore = await chrome.windows.get(QP.orig.windowId, { populate: true });
        var destinationTabs = (destinationBefore && destinationBefore.tabs) || [];
        for (var di = 0; di < destinationTabs.length; di++) {
          if (destinationTabs[di] && destinationTabs[di].active && destinationTabs[di].id !== QP.athenaTabId) {
            destinationActiveTabId = destinationTabs[di].id;
            break;
          }
        }
        await chrome.tabs.move(QP.athenaTabId, { windowId: QP.orig.windowId, index: QP.orig.index });
        movedHome = true;
      } catch (e) { /* original window is gone — athena keeps its own window; harmless */ }
    }
    if (movedHome && destinationActiveTabId != null) {
      try {
        var destinationAfter = await chrome.windows.get(QP.orig.windowId, { populate: true });
        var destinationNow = ((destinationAfter && destinationAfter.tabs) || []).filter(function (t) { return t && t.active; })[0] || null;
        var destinationPrior = await chrome.tabs.get(destinationActiveTabId);
        if (destinationNow && destinationNow.id === QP.athenaTabId && destinationPrior && destinationPrior.windowId === QP.orig.windowId) {
          await chrome.tabs.update(destinationActiveTabId, { active: true });
        }
      } catch (e) {}
    }
    if (QP.soloWin && QP.winId != null && QP.athOrig) {
      try {
        await chrome.windows.update(QP.winId, { left: QP.athOrig.left, top: QP.athOrig.top, width: QP.athOrig.width, height: QP.athOrig.height });
        if (QP.athOrig.state === 'maximized') await chrome.windows.update(QP.winId, { state: 'maximized' });
      } catch (e) {}
    }
    /* doctor's window back exactly as it was */
    if (QP.hostWinId != null && QP.hostOrig) {
      try {
        await chrome.windows.update(QP.hostWinId, { left: QP.hostOrig.left, top: QP.hostOrig.top, width: QP.hostOrig.width, height: QP.hostOrig.height });
        if (QP.hostOrig.state === 'maximized' || QP.hostOrig.state === 'fullscreen') await chrome.windows.update(QP.hostWinId, { state: QP.hostOrig.state });
      } catch (e) {}
    }
    if (preserveTabId != null) {
      try {
        var preserved = await chrome.tabs.get(preserveTabId);
        var nowFocused = await chrome.windows.getLastFocused({ populate: true, windowTypes: ['normal'] });
        var nowTabs = (nowFocused && nowFocused.tabs) || [], nowActive = null;
        for (var ni = 0; ni < nowTabs.length; ni++) { if (nowTabs[ni].active) { nowActive = nowTabs[ni]; break; } }
        /* If the user selected something else during restoration, that newer
           choice wins. Undo only activation of our worker Athena tab. */
        if (preserved && !preserved.active && nowActive && nowActive.id === QP.athenaTabId) await chrome.tabs.update(preserveTabId, { active: true });
      } catch (e) {}
    }
  }

  async function qpRelease(reason) {
    if (!QP.active && QP.hostOrig == null && !QP.pending && !QP.restoring) return;
    /* Supersede every ensure which began before this terminal release. Calls
       that were waiting on the old promise see the epoch change and exit limp
       instead of beginning window surgery after their request has settled. */
    QP.epoch = Number(QP.epoch || 0) + 1;
    if (QP.restoring) { try { await qpAwaitBound(QP.restoring, QP_RESTORE_WAIT_MS); } catch (e) {} return; }
    if (QP.pending) {
      var pendingAtRelease = QP.pending;
      var pendingSettled = false;
      try { pendingSettled = await qpAwaitBound(pendingAtRelease, QP_PENDING_RELEASE_MS); } catch (e) {}
      if (!pendingSettled) {
        /* Chrome APIs cannot be cancelled. If the old ensure eventually wakes
           and mutates the strip, immediately run one more bounded restoration.
           Until it settles, qpEnsure itself refuses to start another surgery. */
        Promise.resolve(pendingAtRelease).finally(function () {
          if (QP.pending === pendingAtRelease) QP.pending = null;
          qpRelease('late-pending-ensure').catch(function () {});
        }).catch(function () {});
      }
    }
    var restoreTask = releaseBody().catch(function () {});
    var r = Promise.race([restoreTask, qpSleep(QP_RESTORE_WAIT_MS)]);
    QP.restoring = r;
    try { await r; } finally {
      QP.restoring = null; QP.active = false; QP.winId = null; QP.orig = null; QP.soloWin = false;
      QP.athOrig = null; QP.hostWinId = null; QP.hostOrig = null; QP.athenaTabId = null; QP.flashed = false;
      try { chrome.alarms.clear('mlsQpWatch'); } catch (e) {}
      persist();
    }
  }
  self.__mlsQpRelease = qpRelease;

  /* end-of-run detection: quiet watchdog + alarm backstop (worker restarts) */
  setInterval(function () { if (QP.active && QP.lastUse && (Date.now() - QP.lastUse) > QP_QUIET_MS) { qpRelease('quiet'); } }, 5000);
  try {
    chrome.alarms.onAlarm.addListener(function (a) {
      if (!a || a.name !== 'mlsQpWatch') return;
      if (QP.active && QP.lastUse && (Date.now() - QP.lastUse) > QP_QUIET_MS) qpRelease('alarm');
      else if (QP.active) { try { chrome.alarms.create('mlsQpWatch', { delayInMinutes: 1 }); } catch (e) {} }
    });
  } catch (e) {}
  /* adopt state across service-worker restarts so the layout is never stranded */
  try {
    chrome.storage.session.get(['mlsQpState'], function (st) {
      try {
        var s = st && st.mlsQpState;
        if (!s || QP.active) return;
        QP.active = true; QP.winId = s.winId; QP.athenaTabId = s.athenaTabId; QP.orig = s.orig || null;
        QP.soloWin = !!s.soloWin; QP.athOrig = s.athOrig || null; QP.hostWinId = s.hostWinId; QP.hostOrig = s.hostOrig || null; QP.strip = s.strip || null;
        QP.lastUse = Date.now(); qpTouch();
      } catch (e) {}
    });
  } catch (e) {}
})();

// ===========================================================================
// MLS Assist NOTE WRITE-BACK ENGINE (v1.27 — "section router + verified typing
// + patient-match gate"). Injected page-context helpers + worker-scope pure
// helpers used by the panel "Insert into chart" path and the app-driven paste.
//
// Three pillars (per Michael):
//   1) RELIABLE TYPING — one verified primitive (mlsRobustType): native value
//      setter / execCommand + framework events, then simulated paste, then
//      per-character keystrokes, RE-READING the field after each so we never
//      claim success on a controlled input that silently rejected the write.
//   2) SMART FIELD ROUTING — classify the MLS content into an athenaOne section
//      (insurance / diagnoses[ICD-10] / orders[CPT] / procedure / assessment&plan
//      / hpi / physical exam / ros / note) and find the field whose LABEL + SECTION
//      HEADING context matches — insurance never lands in the note body, codes
//      never land in free-text. Reports exactly which field each piece went to.
//   3) PATIENT SAFETY GATE — before ANY write, read the MLS active patient and the
//      open Athena chart identity (name/DOB/MRN) and MATCH. Write only on a
//      confident match; otherwise refuse and warn. (mlsReadChartIdentity /
//      mlsReadActivePatient / mlsMatchPatients.)
// NOTHING here ever clicks Save/Sign — these only fill fields.
// ===========================================================================

// ---- Section label patterns (how a field's section context is recognized) ----
// Duplicated inside injected functions because injected funcs must be self-contained.
function _mlsSectDefs() {
  return [
    { key:'insurance',       label:'Insurance',
      fieldRe:/insuranc|payer|payor|subscriber|policy|member\s*id|group\s*(number|no|#)|coverage|guarantor|plan\s*name/,
      sigs:['insurance:','primary insurance','secondary insurance','payer:','payor:','policy number','policy #','policy no','member id','group number','group #','subscriber','copay','co-pay','deductible','medicare','medicaid','bcbs','blue cross','aetna','cigna','unitedhealth','united health','umr','humana','tricare'] },
    { key:'diagnoses',       label:'Diagnoses (ICD-10)',
      fieldRe:/diagnos|\bicd\b|icd-?10|problem\s*list/,
      sigs:['icd-10','icd10','icd-10-cm','diagnosis:','diagnoses:','dx:','problem list','assessment codes'] },
    { key:'orders',          label:'Orders / Procedure codes (CPT)',
      fieldRe:/orders?\b|\bcpt\b|procedure\s*code|hcpcs|billing|charge|superbill|e&m|e\/m/,
      sigs:['cpt:','cpt code','cpt-','hcpcs','procedure code','billing code','charge:','superbill','e/m level','e&m level','order:','orders:'] },
    { key:'procedure',       label:'Procedure Documentation',
      fieldRe:/procedur|operativ|op.?note|injection|fluoro|epidural|nerve\s*block|\bblock\b|aspiration|biopsy|arthrocentesis|implant|anesthesia|\btemplate\b|\besi\b|\bmbb\b|\brfa\b|surg|document/,
      sigs:['preoperative diagnos','pre-operative diagnos','postoperative diagnos','post-operative diagnos','description of procedure','procedure performed','date of operation','indications for the procedure','indications for procedure','estimated blood loss','operative note','op note','fluorosc','needle','epidural steroid','transforaminal','medial branch','radiofrequency','local anesth','under anesthesia','informed consent was obtained','time out','sterile prep','type of anesthesia'] },
    { key:'assessment_plan', label:'Assessment & Plan',
      fieldRe:/assess|\bplan\b|impression|a&p|a\/p|decision\s*making/,
      sigs:['assessment:','impression:','plan:','differential','we will','recommend','refer to','follow up in','follow-up in','medical decision'] },
    { key:'hpi',             label:'HPI',
      fieldRe:/\bhpi\b|history of present|present illness|subjective|chief complaint|interval history/,
      sigs:['chief complaint','history of present illness','hpi:','presents with','complains of','since the last visit','interval history'] },
    { key:'physical_exam',   label:'Physical Exam',
      fieldRe:/physical exam|\bpe\b|\bexam\b|objective|findings/,
      sigs:['physical exam','on exam','inspection:','palpation','range of motion','tenderness','motor strength','reflexes','straight leg raise','gait','5/5'] },
    { key:'ros',             label:'Review of Systems',
      fieldRe:/review of systems|\bros\b/,
      sigs:['review of systems','ros:','denies fever','denies chest pain','constitutional:'] },
    { key:'progress',        label:'Note',
      fieldRe:/note|progress|narrative|free.?text|encounter|impression|document|hpi|assess|plan/,
      sigs:[] }
  ];
}

// Classify note text -> best target section key. Priority order makes a whole
// op/procedure note win when present; pure code/insurance blocks route to their field.
function mlsRouteSection(text) {
  var t = String(text || '').toLowerCase();
  var defs = _mlsSectDefs();
  var order = ['procedure','insurance','orders','diagnoses','assessment_plan','hpi','physical_exam','ros'];
  var scores = {};
  defs.forEach(function (d) { var n = 0; d.sigs.forEach(function (s) { if (t.indexOf(s) >= 0) n++; }); scores[d.key] = n; });
  // bare ICD-10 codes (e.g. M54.16) boost diagnoses; 5-digit CPT (e.g. 64483) boost orders
  if (/\b[a-tv-z][0-9][0-9ab](\.[0-9a-z]{1,4})?\b/i.test(text || '')) scores.diagnoses += 1;
  if (/\b(99[0-2]\d{2}|6[24]\d{3}|20\d{3}|72\d{3})\b/.test(text || '')) scores.orders += 1;
  var bestK = 'progress', bestN = 0;
  order.forEach(function (k) { if (scores[k] > bestN) { bestN = scores[k]; bestK = k; } });
  if (bestN < 2) bestK = 'progress';
  return { section: bestK, strength: bestN, scores: scores };
}

// Split a structured MLS note into labeled segments so each part is routed to the
// matching Athena field (insurance->insurance, ICD-10->diagnoses, CPT->orders,
// op-note narrative->Procedure Documentation, etc.). If no headers are recognized,
// returns a single segment routed by mlsRouteSection. Pure/worker-scope (testable).
function mlsSegmentNote(text) {
  var src = String(text || '');
  if (!src.trim()) return [];
  // An op/procedure note is ONE document — keep it whole, route to Procedure Documentation.
  if (mlsRouteSection(src).section === 'procedure') return [{ section: 'procedure', text: src }];
  var headerMap = [
    { re:/^\s*(insurance|primary insurance|payer|payor|coverage)\s*[:\-]/i, section:'insurance' },
    { re:/^\s*(icd-?10|icd-?10-cm|diagnos(is|es)|dx)\s*[:\-]/i, section:'diagnoses' },
    { re:/^\s*(cpt|cpt codes?|procedure codes?|hcpcs|orders?|billing|charges?)\s*[:\-]/i, section:'orders' },
    { re:/^\s*(procedure|operative note|op note|procedure note|procedure documentation|description of procedure)\s*[:\-]/i, section:'procedure' },
    { re:/^\s*(assessment( and plan| ?& ?plan)?|impression|a\/p|a&p)\s*[:\-]/i, section:'assessment_plan' },
    { re:/^\s*(plan)\s*[:\-]/i, section:'assessment_plan' },
    { re:/^\s*(hpi|history of present illness|subjective|chief complaint|cc)\s*[:\-]/i, section:'hpi' },
    { re:/^\s*(physical exam(ination)?|objective|exam)\s*[:\-]/i, section:'physical_exam' },
    { re:/^\s*(review of systems|ros)\s*[:\-]/i, section:'ros' }
  ];
  var lines = src.split(/\r?\n/);
  var segs = [], cur = null;
  for (var i = 0; i < lines.length; i++) {
    var line = lines[i];
    var matchedSection = null;
    for (var h = 0; h < headerMap.length; h++) { if (headerMap[h].re.test(line)) { matchedSection = headerMap[h].section; break; } }
    if (matchedSection) {
      if (cur) segs.push(cur);
      cur = { section: matchedSection, text: line };
    } else if (cur) {
      cur.text += '\n' + line;
    } else {
      cur = { section: null, text: line };
    }
  }
  if (cur) segs.push(cur);
  // collapse: if 0 or 1 recognized header, treat whole note as one routed segment
  var recognized = segs.filter(function (s) { return s.section; }).length;
  if (recognized <= 1) {
    var r = mlsRouteSection(src);
    return [{ section: r.section, text: src }];
  }
  // any leading unlabeled chunk -> route by its own content
  segs = segs.map(function (s) { if (!s.section) { s.section = mlsRouteSection(s.text).section; } s.text = s.text.replace(/\s+$/,''); return s; }).filter(function (s) { return s.text.trim(); });
  var merged = [];
  segs.forEach(function (s) { var last = merged[merged.length - 1]; if (last && last.section === s.section) { last.text += '\n' + s.text; } else { merged.push({ section: s.section, text: s.text }); } });
  return merged;
}

// ---- Robust, VERIFIED text entry primitive (injected). Single source of truth. ----
// v1.28 — hardened against the modes the autopilot log flagged ("read-only, masked, or a
// typeahead that needs a selection"): resolves a real EDITABLE field from a label/wrapper,
// clicks+focuses first, native-setter + bubbling input/change (execCommand insertText for
// contenteditable), simulated paste, per-character keystrokes that drive MASKED inputs,
// then SELECTS the matching item from any TYPEAHEAD list, and re-reads to CONFIRM after a
// settle + blur. Returns confirmed:false + stuck:true with a reason when nothing sticks.
async function mlsRobustType(el, txt) {
  txt = String(txt == null ? '' : txt);
  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  function _isEd(e) { if (!e || !e.tagName) return false; if (e.isContentEditable) return true; var tg = e.tagName.toUpperCase(); if (tg === 'TEXTAREA') return true; if (tg === 'INPUT') { var t = (e.getAttribute('type') || 'text').toLowerCase(); return /^(text|search|email|url|tel|number|password|date|month|week|time|datetime-local|)$/.test(t); } return false; }
  function _resolve(e) { if (_isEd(e)) return e; if (!e || !e.tagName) return e; try { if (e.tagName.toUpperCase() === 'LABEL') { var f = e.getAttribute('for'); if (f) { var byId = document.getElementById(f); if (_isEd(byId)) return byId; } var within = e.querySelector('input:not([type=hidden]),textarea,[contenteditable=""],[contenteditable="true"]'); if (_isEd(within)) return within; } } catch (e2) {} try { var n = e.querySelector && e.querySelector('input:not([type=hidden]),textarea,[contenteditable=""],[contenteditable="true"]'); if (_isEd(n)) return n; } catch (e3) {} try { var sib = e.nextElementSibling, k = 0; while (sib && k < 3) { if (_isEd(sib)) return sib; var inS = sib.querySelector && sib.querySelector('input:not([type=hidden]),textarea,[contenteditable]'); if (_isEd(inS)) return inS; sib = sib.nextElementSibling; k++; } } catch (e4) {} try { var p = e.parentElement, d = 0; while (p && d < 3) { var inp = p.querySelector && p.querySelector('input:not([type=hidden]),textarea,[contenteditable=""],[contenteditable="true"]'); if (_isEd(inp)) return inp; p = p.parentElement; d++; } } catch (e5) {} return e; }
  el = _resolve(el);
  if (!el || !_isEd(el)) return { ok: false, confirmed: false, stuck: true, method: 'none', reason: 'no-field', into: 0 };
  if (el.readOnly || el.disabled) return { ok: false, confirmed: false, stuck: true, method: 'none', reason: 'readonly', into: 0 };
  var CE = !!el.isContentEditable;
  function rd() { return CE ? (el.innerText || el.textContent || '') : (el.value || ''); }
  function norm(s) { return String(s || '').replace(/\s+/g, ' ').trim().toLowerCase(); }
  function digits(s) { return String(s || '').replace(/\D/g, ''); }
  function isMasked() { try { if (CE) return false; var t = (el.getAttribute('type') || '').toLowerCase(); if (t === 'date' || t === 'tel') return true; var ph = el.getAttribute('placeholder') || ''; if (/[\/\-.]/.test(ph) && /[mdyhMDYH#0_]/.test(ph)) return true; if (el.getAttribute('inputmode') === 'numeric') return true; if (el.getAttribute('data-mask') || el.getAttribute('pattern')) return true; var ml = el.maxLength; if (ml && ml > 0 && ml <= 12 && /[\/\-.]/.test(ph)) return true; } catch (e) {} return false; }
  var masked = isMasked();
  function landed() { var cur = rd(); if (!cur && txt) return false; var a = norm(cur), b = norm(txt); if (!b) return true; if (a.indexOf(b.slice(0, Math.min(b.length, 40))) >= 0) return true; if (masked) { var dc = digits(cur), dt = digits(txt); if (dt && dc.indexOf(dt) >= 0) return true; } return cur.replace(/\s+/g, '').length >= Math.min(txt.replace(/\s+/g, '').length, 15); }
  function setNative(v) { if (CE) { try { el.textContent = v; } catch (e) {} return; } var pr = (el.tagName === 'TEXTAREA') ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; var d = Object.getOwnPropertyDescriptor(pr, 'value'); if (d && d.set) d.set.call(el, v); else el.value = v; }
  function fireInput(data, type) { try { el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: type || 'insertText', data: data })); } catch (e) { try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch (e2) {} } }
  function clearField() { try { if (!CE && el.setSelectionRange) el.setSelectionRange(0, (el.value || '').length); } catch (e) {} setNative(''); fireInput('', 'deleteContentBackward'); }
  function _vis(e) { try { var r = e.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; var s = getComputedStyle(e); return s.display !== 'none' && s.visibility !== 'hidden'; } catch (e2) { return true; } }
  try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
  try { el.click(); } catch (e) {}
  try { el.focus(); } catch (e) {}
  await sleep(0);
  async function keystroke() { clearField(); for (var i = 0; i < txt.length; i++) { var ch = txt.charAt(i); try { el.dispatchEvent(new KeyboardEvent('keydown', { key: ch, bubbles: true })); } catch (e) {} try { el.dispatchEvent(new KeyboardEvent('keypress', { key: ch, bubbles: true })); } catch (e) {} if (CE) { var ok; try { ok = document.execCommand('insertText', false, ch); } catch (e) { ok = false; } if (!ok) setNative(rd() + ch); } else { var base = (el.value != null) ? el.value : ''; setNative(base + ch); } fireInput(ch, 'insertText'); try { el.dispatchEvent(new KeyboardEvent('keyup', { key: ch, bubbles: true })); } catch (e) {} await sleep(masked ? 18 : 6); } try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {} }
  async function pickSuggestion() { await sleep(320); var opts = []; var ac = el.getAttribute && (el.getAttribute('aria-controls') || el.getAttribute('aria-owns')); if (ac) { var box = document.getElementById(ac); if (box) opts = [].slice.call(box.querySelectorAll('[role=option],li,.option,.item')).filter(_vis); } if (!opts.length) opts = [].slice.call(document.querySelectorAll('[role=option],[role=listbox] li,.autocomplete-item,.suggestion,.typeahead-option,ul[class*=auto] li,ul[class*=suggest] li,li[class*=option]')).filter(_vis); if (!opts.length) { var lists = [].slice.call(document.querySelectorAll('ul,ol,[role=listbox],[role=menu]')).filter(_vis); for (var L = 0; L < lists.length && !opts.length; L++) { var items = [].slice.call(lists[L].querySelectorAll('li,[role=option],[role=menuitem]')).filter(_vis); if (items.length && items.length <= 25) opts = items; } } if (!opts.length) return { picked: false }; var want = norm(txt), pick = null; for (var i = 0; i < opts.length; i++) { if (norm(opts[i].textContent).indexOf(want) >= 0) { pick = opts[i]; break; } } if (!pick) pick = opts[0]; if (!pick) return { picked: false }; try { pick.scrollIntoView({ block: 'center' }); } catch (e) {} var r = pick.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2, o = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y }; ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) { try { pick.dispatchEvent(new (tp.indexOf('pointer') === 0 ? PointerEvent : MouseEvent)(tp, o)); } catch (e) {} }); try { pick.click(); } catch (e) {} try { el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true })); el.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', bubbles: true })); } catch (e) {} await sleep(150); return { picked: true, label: (pick.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 60) }; }
  var method = '';
  if (!masked) {
    try { try { el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true })); } catch (e) {} if (CE) { try { var rg = document.createRange(); rg.selectNodeContents(el); var se = window.getSelection(); se.removeAllRanges(); se.addRange(rg); } catch (e) {} try { el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: txt })); } catch (e) {} var _ec; try { _ec = document.execCommand('insertText', false, txt); } catch (e) { _ec = false; } if (!_ec) setNative(txt); } else { clearField(); setNative(txt); } fireInput(txt, 'insertText'); try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {} try { el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true })); } catch (e) {} } catch (e) {}
    await sleep(0); if (landed()) method = 'native';
    if (!method) { try { var dt = new DataTransfer(); dt.setData('text/plain', txt); el.focus(); el.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt })); fireInput(txt, 'insertFromPaste'); try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {} } catch (e) {} await sleep(0); if (landed()) method = 'paste'; }
  }
  if (!method && txt.length <= 4000) { try { await keystroke(); } catch (e) {} if (landed()) method = masked ? 'mask' : 'keystroke'; }
  var sug = { picked: false }; try { sug = await pickSuggestion(); } catch (e) {}
  if (sug.picked) { await sleep(60); method = method || (landed() ? 'typeahead' : 'typeahead-selected'); }
  await sleep(120);
  if (!landed()) { try { el.dispatchEvent(new Event('blur', { bubbles: true })); } catch (e) {} await sleep(80); }
  if (landed()) return { ok: true, confirmed: true, stuck: false, method: method || 'native', into: rd().length, picked: !!sug.picked, pickedLabel: sug.label || '' };
  if (sug.picked) return { ok: true, confirmed: false, stuck: false, method: 'typeahead-selected', into: rd().length, picked: true, pickedLabel: sug.label || '', reason: 'selected-suggestion-unconfirmed' };
  return { ok: false, confirmed: false, stuck: true, method: 'unconfirmed', into: rd().length, reason: masked ? 'masked-rejected' : 'not-stuck' };
}

// ---- Field scanner (injected, read-only): score editable fields for a target section ----
function mlsFieldScanner(noteText, forcedSection) {
  function vis(el) { try { if (el.disabled || el.readOnly) return false; var s = getComputedStyle(el); if (s.display === 'none' || s.visibility === 'hidden' || parseFloat(s.opacity || '1') < .05) return false; var r = el.getBoundingClientRect(); return r.width > 110 && r.height > 18; } catch (e) { return false; } }
  function ownLabel(el) { try { var l = (el.getAttribute && (el.getAttribute('aria-label') || el.getAttribute('placeholder') || el.getAttribute('title') || el.getAttribute('name'))) || ''; if (!l && el.id) { var lb = document.querySelector('label[for="' + el.id + '"]'); if (lb) l = (lb.textContent || '').trim(); } return String(l).replace(/\s+/g, ' ').trim().slice(0, 48); } catch (e) { return ''; } }
  function sectionHeading(el) { try { var n = el, hops = 0; while (n && hops < 5) { n = n.parentElement; hops++; if (!n) break; var hd = n.querySelector && n.querySelector('h1,h2,h3,h4,h5,h6,legend,[role="heading"]'); if (hd) { var ht = (hd.textContent || '').trim(); if (ht && ht.length <= 64) return ht.replace(/\s+/g, ' '); } var al = n.getAttribute && (n.getAttribute('aria-label') || n.getAttribute('data-section') || n.getAttribute('data-sectionname')); if (al && al.length <= 64) return String(al).replace(/\s+/g, ' '); } } catch (e) {} return ''; }
  function hay(el) { var h = ownLabel(el) + ' ' + sectionHeading(el); try { var n = el, hops = 0; while (n && hops < 4) { n = n.parentElement; hops++; if (!n) break; var al = n.getAttribute && (n.getAttribute('aria-label') || n.getAttribute('data-section') || n.getAttribute('data-sectionname') || n.getAttribute('title')); if (al) h += ' ' + al; } } catch (e) {} return String(h).toLowerCase(); }
  var DEFS = (function () { return [
    { key:'insurance', label:'Insurance', fieldRe:/insuranc|payer|payor|subscriber|policy|member\s*id|group\s*(number|no|#)|coverage|guarantor|plan\s*name/ },
    { key:'diagnoses', label:'Diagnoses (ICD-10)', fieldRe:/diagnos|\bicd\b|icd-?10|problem\s*list/ },
    { key:'orders', label:'Orders / Procedure codes (CPT)', fieldRe:/orders?\b|\bcpt\b|procedure\s*code|hcpcs|billing|charge|superbill|e&m|e\/m/ },
    { key:'procedure', label:'Procedure Documentation', fieldRe:/procedur|operativ|op.?note|injection|fluoro|epidural|nerve\s*block|\bblock\b|aspiration|biopsy|arthrocentesis|implant|anesthesia|\btemplate\b|\besi\b|\bmbb\b|\brfa\b|surg|document/ },
    { key:'assessment_plan', label:'Assessment & Plan', fieldRe:/assess|\bplan\b|impression|a&p|a\/p|decision\s*making/ },
    { key:'hpi', label:'HPI', fieldRe:/\bhpi\b|history of present|present illness|subjective|chief complaint|interval history/ },
    { key:'physical_exam', label:'Physical Exam', fieldRe:/physical exam|\bpe\b|\bexam\b|objective|findings/ },
    { key:'ros', label:'Review of Systems', fieldRe:/review of systems|\bros\b/ },
    { key:'progress', label:'Note', fieldRe:/note|progress|narrative|free.?text|encounter|impression|document|hpi|assess|plan/ }
  ]; })();
  var BAD = /search|find|lookup|filter|chat|messag|comment|reason for|\baddress\b|e-?mail|phone|\bnpi\b|\bmrn\b|patient.?id|claim|login|password|user.?name|\bzip\b|\bcity\b|\bstate\b/;
  function route(t) { t = String(t || '').toLowerCase(); var order = ['procedure','insurance','orders','diagnoses','assessment_plan','hpi','physical_exam','ros']; var SIG = {
      procedure:['preoperative diagnos','postoperative diagnos','description of procedure','date of operation','indications for procedure','estimated blood loss','operative note','op note','fluorosc','epidural steroid','medial branch','radiofrequency','under anesthesia','informed consent was obtained','type of anesthesia'],
      insurance:['insurance:','primary insurance','payer:','policy number','member id','group number','subscriber','copay','deductible','medicare','medicaid','aetna','cigna','umr'],
      orders:['cpt:','cpt code','hcpcs','procedure code','billing code','e/m level','orders:'],
      diagnoses:['icd-10','icd10','diagnosis:','diagnoses:','problem list','dx:'],
      assessment_plan:['assessment:','impression:','plan:','differential','follow up in','follow-up in','recommend'],
      hpi:['chief complaint','history of present illness','hpi:','presents with','complains of','interval history'],
      physical_exam:['physical exam','on exam','palpation','range of motion','tenderness','reflexes','straight leg raise'],
      ros:['review of systems','ros:','denies fever','constitutional:'] };
    var bestK = 'progress', bestN = 0; order.forEach(function (k) { var n = 0; (SIG[k]||[]).forEach(function (s) { if (t.indexOf(s) >= 0) n++; }); if (n > bestN) { bestN = n; bestK = k; } });
    if (bestN < 2) bestK = 'progress'; return bestK; }
  function fieldSection(h) { for (var i = 0; i < DEFS.length; i++) { if (DEFS[i].fieldRe.test(h)) return DEFS[i].key; } return 'other'; }
  var target = forcedSection || route(noteText);
  var tdef = null; for (var d = 0; d < DEFS.length; d++) { if (DEFS[d].key === target) { tdef = DEFS[d]; break; } } if (!tdef) tdef = DEFS[DEFS.length - 1];
  function score(el) { var r = el.getBoundingClientRect(); var area = Math.min(r.width * r.height, 400000); var h = hay(el); var s = area / 1000;
    if (tdef.fieldRe.test(h)) s += 2000;
    if (/note|hpi|assess|plan|soap|progress|narrative|subjective|objective|impression|free.?text|document|history of present/.test(h)) s += 400;
    if (BAD.test(h)) s -= 1800;
    if ((el.tagName || '') === 'TEXTAREA') s += 120;
    if (el.isContentEditable) s += 100;
    try { if (el === document.activeElement) s += 9000; } catch (e) {}
    return s; }
  var cs = [].slice.call(document.querySelectorAll('textarea,[contenteditable=""],[contenteditable="true"],input[type="text"],input:not([type])')).filter(vis);
  try { var act = document.activeElement; if (act && (act.tagName === 'TEXTAREA' || act.isContentEditable || act.tagName === 'INPUT') && cs.indexOf(act) < 0) { var ar = act.getBoundingClientRect(); if (ar.width > 40 && ar.height > 12) cs.push(act); } } catch (e) {}
  var ranked = cs.map(function (el) { var h = hay(el); return { el: el, sc: score(el), sec: fieldSection(h), label: (ownLabel(el) || sectionHeading(el) || (el.tagName || '').toLowerCase()) }; }).sort(function (a, b) { return b.sc - a.sc; });
  var best = ranked[0] || null;
  var cands = [], seen = {}; ranked.forEach(function (o) { var key = (o.label || '').toLowerCase(); if (o.label && !seen[key] && cands.length < 6) { seen[key] = 1; cands.push({ label: o.label, section: o.sec }); } });
  return { has: !!best, score: best ? best.sc : -1e12, count: cs.length, target: target, targetLabel: tdef.label, chosenSection: best ? best.sec : 'other', chosenLabel: best ? best.label : '', targetMatched: best ? tdef.fieldRe.test(hay(best.el)) : false, candidates: cands };
}

// ---- Field paster (injected): find best field for the target section, write+confirm ----
// v1.28 — self-contained for injection: the caller passes the precomputed `scan` (from
// mlsFieldScanner run across frames) so this function does NOT depend on out-of-scope
// helpers, and it routes the write through a NESTED copy of the hardened mlsRobustType.
// Async (executeScript awaits the result).
async function mlsNotePaster(text, forcedSection, scan) {
  if (!scan) { try { scan = mlsFieldScanner(text, forcedSection); } catch (e) { scan = { has: false }; } }
  if (!scan || !scan.has) return { ok: false, notfound: true, target: scan && scan.target, targetLabel: scan && scan.targetLabel, candidates: scan && scan.candidates };
  if (/^(insurance|diagnoses|orders|procedure)$/i.test(String(scan.chosenSection || forcedSection || ''))) return { ok: false, blocked: true, reason: 'structured-route-blocked', target: scan.target, targetLabel: scan.targetLabel, chosenSection: scan.chosenSection, candidates: scan.candidates };
  function vis(el) { try { if (el.disabled || el.readOnly) return false; var s = getComputedStyle(el); if (s.display === 'none' || s.visibility === 'hidden' || parseFloat(s.opacity || '1') < .05) return false; var r = el.getBoundingClientRect(); return r.width > 110 && r.height > 18; } catch (e) { return false; } }
  function ownLabel(el) { try { var l = (el.getAttribute && (el.getAttribute('aria-label') || el.getAttribute('placeholder') || el.getAttribute('title') || el.getAttribute('name'))) || ''; if (!l && el.id) { var lb = document.querySelector('label[for="' + el.id + '"]'); if (lb) l = (lb.textContent || '').trim(); } return String(l).replace(/\s+/g, ' ').trim().slice(0, 48); } catch (e) { return ''; } }
  function sectionHeading(el) { try { var n = el, hops = 0; while (n && hops < 5) { n = n.parentElement; hops++; if (!n) break; var hd = n.querySelector && n.querySelector('h1,h2,h3,h4,h5,h6,legend,[role="heading"]'); if (hd) { var ht = (hd.textContent || '').trim(); if (ht && ht.length <= 64) return ht.replace(/\s+/g, ' '); } } } catch (e) {} return ''; }
  async function _robustType(el, txt) {
    txt = String(txt == null ? '' : txt);
    var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    function _isEd(e) { if (!e || !e.tagName) return false; if (e.isContentEditable) return true; var tg = e.tagName.toUpperCase(); if (tg === 'TEXTAREA') return true; if (tg === 'INPUT') { var t = (e.getAttribute('type') || 'text').toLowerCase(); return /^(text|search|email|url|tel|number|password|date|month|week|time|datetime-local|)$/.test(t); } return false; }
    function _resolve(e) { if (_isEd(e)) return e; if (!e || !e.tagName) return e; try { if (e.tagName.toUpperCase() === 'LABEL') { var f = e.getAttribute('for'); if (f) { var byId = document.getElementById(f); if (_isEd(byId)) return byId; } var within = e.querySelector('input:not([type=hidden]),textarea,[contenteditable=""],[contenteditable="true"]'); if (_isEd(within)) return within; } } catch (e2) {} try { var n = e.querySelector && e.querySelector('input:not([type=hidden]),textarea,[contenteditable=""],[contenteditable="true"]'); if (_isEd(n)) return n; } catch (e3) {} try { var p = e.parentElement, d = 0; while (p && d < 3) { var inp = p.querySelector && p.querySelector('input:not([type=hidden]),textarea,[contenteditable=""],[contenteditable="true"]'); if (_isEd(inp)) return inp; p = p.parentElement; d++; } } catch (e5) {} return e; }
    el = _resolve(el);
    if (!el || !_isEd(el)) return { ok: false, confirmed: false, stuck: true, method: 'none', reason: 'no-field', into: 0 };
    if (el.readOnly || el.disabled) return { ok: false, confirmed: false, stuck: true, method: 'none', reason: 'readonly', into: 0 };
    var CE = !!el.isContentEditable;
    function rd() { return CE ? (el.innerText || el.textContent || '') : (el.value || ''); }
    function norm(s) { return String(s || '').replace(/\s+/g, ' ').trim().toLowerCase(); }
    function digits(s) { return String(s || '').replace(/\D/g, ''); }
    function isMasked() { try { if (CE) return false; var t = (el.getAttribute('type') || '').toLowerCase(); if (t === 'date' || t === 'tel') return true; var ph = el.getAttribute('placeholder') || ''; if (/[\/\-.]/.test(ph) && /[mdyhMDYH#0_]/.test(ph)) return true; if (el.getAttribute('inputmode') === 'numeric') return true; if (el.getAttribute('data-mask') || el.getAttribute('pattern')) return true; var ml = el.maxLength; if (ml && ml > 0 && ml <= 12 && /[\/\-.]/.test(ph)) return true; } catch (e) {} return false; }
    var masked = isMasked();
    function landed() { var cur = rd(); if (!cur && txt) return false; var a = norm(cur), b = norm(txt); if (!b) return true; if (a.indexOf(b.slice(0, Math.min(b.length, 40))) >= 0) return true; if (masked) { var dc = digits(cur), dt = digits(txt); if (dt && dc.indexOf(dt) >= 0) return true; } return cur.replace(/\s+/g, '').length >= Math.min(txt.replace(/\s+/g, '').length, 15); }
    function setNative(v) { if (CE) { try { el.textContent = v; } catch (e) {} return; } var pr = (el.tagName === 'TEXTAREA') ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; var d = Object.getOwnPropertyDescriptor(pr, 'value'); if (d && d.set) d.set.call(el, v); else el.value = v; }
    function fireInput(data, type) { try { el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: type || 'insertText', data: data })); } catch (e) { try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch (e2) {} } }
    function clearField() { try { if (!CE && el.setSelectionRange) el.setSelectionRange(0, (el.value || '').length); } catch (e) {} setNative(''); fireInput('', 'deleteContentBackward'); }
    function _vis(e) { try { var r = e.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; var s = getComputedStyle(e); return s.display !== 'none' && s.visibility !== 'hidden'; } catch (e2) { return true; } }
    try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
    try { el.click(); } catch (e) {}
    try { el.focus(); } catch (e) {}
    await sleep(0);
    async function keystroke() { clearField(); for (var i = 0; i < txt.length; i++) { var ch = txt.charAt(i); try { el.dispatchEvent(new KeyboardEvent('keydown', { key: ch, bubbles: true })); } catch (e) {} try { el.dispatchEvent(new KeyboardEvent('keypress', { key: ch, bubbles: true })); } catch (e) {} if (CE) { var ok; try { ok = document.execCommand('insertText', false, ch); } catch (e) { ok = false; } if (!ok) setNative(rd() + ch); } else { var base = (el.value != null) ? el.value : ''; setNative(base + ch); } fireInput(ch, 'insertText'); try { el.dispatchEvent(new KeyboardEvent('keyup', { key: ch, bubbles: true })); } catch (e) {} await sleep(masked ? 18 : 6); } try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {} }
    async function pickSuggestion() { await sleep(320); var opts = []; var ac = el.getAttribute && (el.getAttribute('aria-controls') || el.getAttribute('aria-owns')); if (ac) { var box = document.getElementById(ac); if (box) opts = [].slice.call(box.querySelectorAll('[role=option],li,.option,.item')).filter(_vis); } if (!opts.length) opts = [].slice.call(document.querySelectorAll('[role=option],[role=listbox] li,.autocomplete-item,.suggestion,.typeahead-option,ul[class*=auto] li,ul[class*=suggest] li,li[class*=option]')).filter(_vis); if (!opts.length) { var lists = [].slice.call(document.querySelectorAll('ul,ol,[role=listbox],[role=menu]')).filter(_vis); for (var L = 0; L < lists.length && !opts.length; L++) { var items = [].slice.call(lists[L].querySelectorAll('li,[role=option],[role=menuitem]')).filter(_vis); if (items.length && items.length <= 25) opts = items; } } if (!opts.length) return { picked: false }; var want = norm(txt), pick = null; for (var i = 0; i < opts.length; i++) { if (norm(opts[i].textContent).indexOf(want) >= 0) { pick = opts[i]; break; } } if (!pick) pick = opts[0]; if (!pick) return { picked: false }; try { pick.scrollIntoView({ block: 'center' }); } catch (e) {} var r = pick.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2, o = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y }; ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) { try { pick.dispatchEvent(new (tp.indexOf('pointer') === 0 ? PointerEvent : MouseEvent)(tp, o)); } catch (e) {} }); try { pick.click(); } catch (e) {} try { el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true })); el.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', bubbles: true })); } catch (e) {} await sleep(150); return { picked: true }; }
    var method = '';
    if (!masked) {
      try { try { el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true })); } catch (e) {} if (CE) { try { var rg = document.createRange(); rg.selectNodeContents(el); var se = window.getSelection(); se.removeAllRanges(); se.addRange(rg); } catch (e) {} try { el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: txt })); } catch (e) {} var _ec; try { _ec = document.execCommand('insertText', false, txt); } catch (e) { _ec = false; } if (!_ec) setNative(txt); } else { clearField(); setNative(txt); } fireInput(txt, 'insertText'); try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {} try { el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true })); } catch (e) {} } catch (e) {}
      await sleep(0); if (landed()) method = 'native';
      if (!method) { try { var dt = new DataTransfer(); dt.setData('text/plain', txt); el.focus(); el.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt })); fireInput(txt, 'insertFromPaste'); try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {} } catch (e) {} await sleep(0); if (landed()) method = 'paste'; }
    }
    if (!method && txt.length <= 4000) { try { await keystroke(); } catch (e) {} if (landed()) method = masked ? 'mask' : 'keystroke'; }
    var sug = { picked: false }; try { sug = await pickSuggestion(); } catch (e) {}
    if (sug.picked) { await sleep(60); method = method || (landed() ? 'typeahead' : 'typeahead-selected'); }
    await sleep(120);
    if (!landed()) { try { el.dispatchEvent(new Event('blur', { bubbles: true })); } catch (e) {} await sleep(80); }
    if (landed()) return { ok: true, confirmed: true, stuck: false, method: method || 'native', into: rd().length };
    if (sug.picked) return { ok: true, confirmed: false, stuck: false, method: 'typeahead-selected', into: rd().length };
    return { ok: false, confirmed: false, stuck: true, method: 'unconfirmed', into: rd().length, reason: masked ? 'masked-rejected' : 'not-stuck' };
  }
  var probeLabel = scan.chosenLabel;
  var cs = [].slice.call(document.querySelectorAll('textarea,[contenteditable=""],[contenteditable="true"],input[type="text"],input:not([type])')).filter(vis);
  try { var act = document.activeElement; if (act && (act.tagName === 'TEXTAREA' || act.isContentEditable || act.tagName === 'INPUT') && cs.indexOf(act) < 0) cs.push(act); } catch (e) {}
  var best = null; for (var i = 0; i < cs.length; i++) { var lab = (ownLabel(cs[i]) || sectionHeading(cs[i]) || (cs[i].tagName || '').toLowerCase()); if (lab === probeLabel) { best = cs[i]; break; } }
  if (!best) { try { if (document.activeElement && vis(document.activeElement)) best = document.activeElement; } catch (e) {} }
  if (!best) best = cs[0] || null;
  if (!best) return { ok: false, notfound: true, target: scan.target, targetLabel: scan.targetLabel, candidates: scan.candidates };
  var wr = await _robustType(best, text);
  try { best.dispatchEvent(new Event('blur', { bubbles: true })); } catch (e) {}
  return { ok: !!wr.ok, confirmed: !!wr.confirmed, stuck: !!wr.stuck, method: wr.method, into: scan.chosenLabel || (best.tagName || '').toLowerCase(), len: wr.into, target: scan.target, targetLabel: scan.targetLabel, chosenSection: scan.chosenSection, chosenLabel: scan.chosenLabel, targetMatched: scan.targetMatched, candidates: scan.candidates };
}

// ---- Patient identity reader: open Athena chart (injected, runs per frame) ----
function mlsReadChartIdentity() {
  /* v1.52 REWRITE (live-verification ISSUE 5): the v1.51 extractor could not
     parse athenaOne's real chart banner - "Adam J SCHAEFFER / 20yo M |
     03-24-2006 | #7833832" - because its name regexes required a label or a
     lowercase surname, its DOB regex required a "DOB" label, and its fallback
     matched ACROSS NEWLINES (producing garbage like "Schaeffer,\n\nThe").
     This version parses the banner first, matches LINE-BY-LINE only, accepts
     ALL-CAPS tokens, reads the bare date + #MRN next to the age/sex chip, and
     prefers chart-route frames. ES5 on purpose (offline-unit-testable). */
  var raw = (document.body && document.body.innerText || '').replace(/ /g, ' ');
  var lo = raw.toLowerCase();
  var lines = [];
  var rl = raw.split(/\n+/);
  for (var li = 0; li < rl.length && lines.length < 400; li++) {
    var t0 = rl[li].replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    if (t0) lines.push(t0);
  }
  var AGE_CHIP = /\b(\d{1,3})\s*(?:yo|y\/o|yrs?\.?|years?\s*old)\b/i;
  var BARE_DATE = /\b([01]?\d)[\/\-\.]([0-3]?\d)[\/\-\.](\d{4})\b/;
  var MRN_HASH = /#\s?(\d{4,})/;
  var STOP1 = /^(please|the|new|find|create|search|no|today|welcome|inbox|schedule|calendar|department|provider|patient|results|appointment|encounter|billing|orders|messages)$/i;
  /* v1.59: a candidate carrying a PROVIDER credential is the doctor, never the
     patient. athenaOne v26.3's appointment exam-prep/briefing view shows only
     "Matthew Schaeffer, MD" (no patient banner) - without this, the reader
     returned the provider as the "patient" and the pull refused everything. */
  var PROVCRED = /^(MD|DO|PA|PAC|NP|CRNA|APRN|DPM|DDS|DMD|RN|CRNP|FNP|DNP|PHD|MBBS|OD|MSN|LPN|CNM|DC|DPT|DR|PHYS|PT)$/i; /* v1.67: +PHYS/PT ("Schaeffer, Phys" live phantom) */
  function looksName(s) {
    if (!s || s.length > 60) return '';
    var m = /^([A-Z][A-Za-z'\-\.]*(?:\s+[A-Z][A-Za-z'\-\.]*){1,3})$/.exec(s) ||
            /^([A-Z][A-Za-z'\-]+\s*,\s*[A-Z][A-Za-z'\-\.]*(?:\s+[A-Z][A-Za-z'\-\.]*){0,2})$/.exec(s);
    if (!m) return '';
    var cand = m[1].replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    var toks = cand.replace(/,/g, ' ').split(/\s+/);
    for (var q = 0; q < toks.length; q++) { if (STOP1.test(toks[q])) return ''; }
    /* final-token-only credential check: kills "Schaeffer, MD" / "Matthew Schaeffer, MD"
       without false-rejecting real surnames like "Do, John" (Do = first token there). */
    if (PROVCRED.test(toks[toks.length - 1].replace(/[.\-]/g, ''))) return '';
    if (/^DR\.?$/i.test(toks[0])) return '';
    if (!/[A-Za-z]{2}/.test(cand)) return '';
    return cand;
  }
  var name = '', dob = '', mrn = '', via = '';
  function dstr(m) { return ('0' + m[1]).slice(-2) + '/' + ('0' + m[2]).slice(-2) + '/' + m[3]; }
  /* ---- pass 1: the chart banner (name on/above the "age sex | date | #id" line) ---- */
  for (var i = 0; i < lines.length && !name; i++) {
    var L = lines[i];
    var chip = AGE_CHIP.test(L);
    var hasHash = MRN_HASH.test(L), hasDate = BARE_DATE.test(L);
    if (!(chip || (hasHash && hasDate))) continue;
    var lead = L.split(/[·|]|\d/)[0].replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    name = looksName(lead);
    /* v1.64: the live encounter banner leads "LAST, First (f) -" - junk chips after
       the name break looksName's full-string match (live: "GEHRMAN, Ruth (f) -"
       yielded NO banner name, so a junk 'lastfirst' frame won). Validate a leading
       "LAST, First" PREFIX of the lead instead. */
    if (!name) {
      var pfx = /^([A-Z][A-Za-z'\-]+\s*,\s*[A-Z][A-Za-z'\-\.]+(?:\s+[A-Z][A-Za-z'\-\.]*)?)/.exec(lead);
      if (pfx) name = looksName(pfx[1].replace(/\s+$/, ''));
    }
    /* v1.60: the redesigned exam banner renders chip lines (e.g. the "ENG"
       language badge) BETWEEN the patient name and the demographics line -
       look back up to 3 lines, skipping short chip-like lines, instead of
       exactly one (this is why "Ruth GEHRMAN" was missed live). */
    if (!name) {
      for (var lb = 1; lb <= 3 && i - lb >= 0 && !name; lb++) {
        var PL = lines[i - lb];
        name = looksName(PL);
        if (name) break;
        var chippy = PL.length <= 8 || /^[A-Z]{2,4}$/.test(PL) || !/[A-Za-z]/.test(PL);
        if (!chippy) break;
      }
    }
    if (!name) continue;
    via = 'banner';
    var bd = BARE_DATE.exec(L); if (bd) dob = dstr(bd);
    var mh = MRN_HASH.exec(L); if (mh) mrn = mh[1];
    if ((!dob || !mrn) && i + 1 < lines.length) {
      if (!dob) { var bd2 = BARE_DATE.exec(lines[i + 1]); if (bd2) dob = dstr(bd2); }
      if (!mrn) { var mh2 = MRN_HASH.exec(lines[i + 1]); if (mh2) mrn = mh2[1]; }
    }
  }
  /* ---- pass 2: labeled fields + "Last, First" - SAME-LINE only (kills the
     cross-newline "Schaeffer,\n\nThe" class of garbage) ---- */
  for (var j = 0; j < lines.length && (!name || !dob || !mrn); j++) {
    var Lj = lines[j];
    if (!dob) { var dm = /(?:dob|d\.o\.b\.|date of birth|birth date)\s*[:\-]?\s*([01]?\d[\/\-\.][0-3]?\d[\/\-\.]\d{2,4})/i.exec(Lj); if (dm) dob = dm[1]; }
    if (!mrn) { var mm = /(?:mrn|medical record(?:\s*(?:no|number|#))?|chart\s*#|patient\s*id)\s*[:\-#]?\s*([a-z]?\d[a-z0-9\-]{2,})/i.exec(Lj); if (mm) mrn = mm[1]; }
    if (!name) {
      var nm = /(?:patient(?:\s*name)?|name)\s*[:\-]\s*([A-Z][A-Za-z'\-]+\s*,\s*[A-Z][A-Za-z'\-\.]+(?:\s+[A-Z]\.?)?)/.exec(Lj);
      if (nm && looksName(nm[1])) { name = nm[1]; via = via || 'label'; }
    }
    if (!name) {
      var nm2 = /\b([A-Z][A-Za-z'\-]+,\s[A-Z][A-Za-z'\-\.]+(?:\s+[A-Z]\.?)?)\b/.exec(Lj);
      if (nm2) { var cand2 = looksName(nm2[1]); if (cand2) { name = cand2; via = via || 'lastfirst'; } }
    }
  }
  /* v1.60 pass 2b: banner-style "First MIDDLE? LASTALLCAPS" line on its own
     (e.g. "Ruth GEHRMAN", "Adam J SCHAEFFER") - weakest pass, still
     credential-guarded through looksName; grabs an adjacent bare DOB when present. */
  if (!name) {
    for (var j3 = 0; j3 < lines.length && !name; j3++) {
      var m2b = /^([A-Z][a-z'\-]+(?:\s+[A-Z]\.?)?\s+[A-Z][A-Z'\-]{2,})$/.exec(lines[j3]);
      if (!m2b) continue;
      var c2b = looksName(m2b[1]);
      if (!c2b) continue;
      name = c2b; via = via || 'firstlast';
      for (var j4 = j3; j4 <= j3 + 2 && j4 < lines.length && !dob; j4++) {
        var bd3 = BARE_DATE.exec(lines[j4]); if (bd3) dob = dstr(bd3);
      }
    }
  }
  var score = (dob ? 2 : 0) + (mrn ? 2 : 0) + (name ? 1 : 0) + (via === 'banner' ? 3 : 0);
  var kws = ['problem', 'medication', 'allerg', 'vital', 'diagnos', 'assessment', 'encounter'];
  for (var k = 0; k < kws.length; k++) { if (lo.indexOf(kws[k]) >= 0) score += 0.2; }
  try {
    var href = String(location.href || '');
    if (/encounter|\/chart|briefing|clinicals|patientid=|\/patient\//i.test(href)) score += 2;
    /* v1.81: +findpatient - the search RESULTS page shows every candidate's
       name + DOB; a row must never be adopted as the open chart's identity. */
    if (/stm\.esp|globalnav|statusbar|inbox|messag|findpatient\.esp/i.test(href)) score -= 4;
    /* v1.59: letters/athenaText/communicator frames carry OTHER patients' names
       (the live "Corbin Muetterties" phantom that blocked the Adam writeback) -
       demote them hard so they can never outrank the real chart banner frame. */
    if (/letter|athenatext|communicat|\bfax|printer|documentviewer|clinicaldocument/i.test(href)) score -= 5;
  } catch (e) {}
  if (/unread messages|message thread/.test(lo)) score -= 4;
  /* v1.60: hidden/stale lurking frames (zero-size body) carry phantom patients
     ("Monterosso, ROSEMARY" / "Corbin Muetterties" 6-23-1942) - demote hard. */
  var bodyW = 0, bodyH = 0;
  try { var brc = document.body.getBoundingClientRect(); bodyW = Math.round(brc.width); bodyH = Math.round(brc.height); } catch (e) {}
  if (bodyW < 60 || bodyH < 60) score -= 6;
  /* v1.52 fix #3 (identity-DOB leak): NEVER emit a DOB/MRN without a verified
     patient NAME from the same frame - a name-less frame's labeled date (the
     live '6-23-1942' garbage) must yield a fully blank identity. */
  if (!name) { dob = ''; mrn = ''; }
  return { name: name, dob: dob, mrn: mrn, score: score, via: via, w: bodyW, h: bodyH, url: String(typeof href !== 'undefined' ? (href || '') : '') };
}

/* ---- schedule demographic normalization (worker-scope, pure, testable) ----
 * DOB/MRN proof may only come from the exact schedule row which produced the
 * appointment. The injected DOM reader attaches that proof from explicit
 * labels/known attributes. Never search flat frame text here: appointment
 * dates, reason dates, or a neighboring patient's DOB can sit next to the same
 * display name and must not become identity proof. */
function mlsPlausibleDob(s) {
  var raw = String(s || '').trim(), m = /^([01]?\d)[\/\-\.]([0-3]?\d)[\/\-\.](\d{4})$/.exec(raw);
  if (!m) { var iso = /^(\d{4})-([01]?\d)-([0-3]?\d)$/.exec(raw); if (iso) m = [iso[0], iso[2], iso[3], iso[1]]; }
  if (!m) return '';
  var y = +m[3], mo = +m[1], d = +m[2];
  if (y < 1900 || mo < 1 || mo > 12 || d < 1 || d > 31) return '';
  var now = new Date();
  if (y > now.getFullYear()) return '';
  var exact = new Date(Date.UTC(y, mo - 1, d));
  if (exact.getUTCFullYear() !== y || exact.getUTCMonth() !== mo - 1 || exact.getUTCDate() !== d || exact.getTime() > now.getTime()) return '';
  return ('0' + mo).slice(-2) + '/' + ('0' + d).slice(-2) + '/' + y;
}
function mlsPlausibleMrn(s) {
  var v = String(s || '').trim();
  if (!v || v.length > 48 || !/[0-9]/.test(v) || !/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(v)) return '';
  if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(v) || /^\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{4}$/.test(v)) return '';
  return v;
}
function mlsAttachDobs(appts, text) {
  try {
    if (!appts || !appts.length) return appts || [];
    appts.forEach(function (a) {
      if (!a) return;
      a.dob = mlsPlausibleDob(a.dob);
      var mrn = mlsPlausibleMrn(a.mrn || a.athenaId || a.athena_id || '');
      if (mrn) a.mrn = mrn;
      else { a.mrn = ''; if (a.athenaId) a.athenaId = ''; if (a.athena_id) a.athena_id = ''; }
    });
  } catch (e) {}
  return appts || [];
}

/* ---- v1.51: schedule DATE navigation (injected; runs inside athena frames) ----
 * Best-effort by design: PROBE reports whether hands-free date-nav controls are
 * recognizable on this page; non-probe tries them and the caller VERIFIES by
 * re-reading the displayed date. The app (b57 pull engine) falls back to guided
 * follow-mode whenever this reports unsupported/failed — honesty over bravado. */
function mlsAthenaReadHeaderDate() {
  try {
    var t = (document.body && document.body.innerText || '').slice(0, 8000);
    var M = { january: 1, february: 2, march: 3, april: 4, may: 5, june: 6, july: 7, august: 8, september: 9, october: 10, november: 11, december: 12 };
    var m = /(sunday|monday|tuesday|wednesday|thursday|friday|saturday)[a-z]*[,.]?\s{0,3}([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(\d{4})/i.exec(t);
    if (m) { var mo = M[String(m[2]).toLowerCase()]; if (mo) return m[4] + '-' + ('0' + mo).slice(-2) + '-' + ('0' + m[3]).slice(-2); }
    var iso = /\b(20\d\d)-(\d{2})-(\d{2})\b/.exec(t); if (iso) return iso[1] + '-' + iso[2] + '-' + iso[3];
    var us = /\b([01]?\d)\/([0-3]?\d)\/(20\d\d)\b/.exec(t); if (us) return us[3] + '-' + ('0' + us[1]).slice(-2) + '-' + ('0' + us[2]).slice(-2);
    return '';
  } catch (e) { return ''; }
}
// v1.55: click the athenaOne "Home" logo to return to the CLINICAL SCHEDULE (home),
// so the day/month history orchestrator can re-ground between patients (each patient's
// schedule row must be on screen to open the chart). Injected into ALL frames of the
// athena tab; only the GlobalNav frame carries the logo. READ-ONLY navigation — clicks
// the logo only (never Save/Sign/any chart control).
function mlsGoHomeDriverFn(requestGuard) {
  try {
    var guarded = !!(requestGuard && requestGuard.token && Number(requestGuard.deadline));
    var guard = Object.freeze({ token: String(requestGuard && requestGuard.token || ''), deadline: Number(requestGuard && requestGuard.deadline || 0) });
    function actionAllowed() { return !guarded || (!!guard.token && Number.isFinite(guard.deadline) && Date.now() < guard.deadline); }
    if (!actionAllowed()) return { clicked: false, found: false, reason: 'request-deadline-exceeded' };
    function vis(el) { try { var r = el.getBoundingClientRect(); var s = getComputedStyle(el); return r.width > 1 && r.height > 1 && s.visibility !== 'hidden' && s.display !== 'none'; } catch (e) { return false; } }
    var el = document.querySelector('.menuitemlogo')
          || document.querySelector('[title="athenaOne Home"]')
          || document.querySelector('[class*="athenaone_logo"],[class*="athenanetlogo"]');
    if (!el) return { clicked: false, found: false, frame: location.hostname };
    var target = el;
    try { if (!/menuitemlogo/.test((el.className || '') + '') && el.closest) { target = el.closest('.menuitemlogo') || el.closest('a,[onclick],[role=button]') || el; } } catch (e) {}
    if (!vis(target) && !vis(el)) return { clicked: false, found: true, hidden: true, frame: location.hostname };
    if (!actionAllowed()) return { clicked: false, found: true, reason: 'request-deadline-exceeded', frame: location.hostname };
    try { target.click(); } catch (e) { if (!actionAllowed()) return { clicked: false, found: true, reason: 'request-deadline-exceeded', frame: location.hostname }; try { el.click(); } catch (e2) { return { clicked: false, found: true, error: String((e2 && e2.message) || e2) }; } }
    return { clicked: true, found: true, frame: location.hostname };
  } catch (e) { return { clicked: false, error: String((e && e.message) || e) }; }
}

/* ===================== v1.59 CHART-READY / SELF-HEAL HELPERS =====================
 * athenaOne v26.3 changed schedule-click behavior: it now opens the appointment
 * EXAM-PREP / BRIEFING view ("...recently edited this chart... REFRESH CHART"
 * stale prompt, provider-only header) where the patient banner (name+DOB) has
 * NOT rendered. Reading there returns the provider as the "patient", so the
 * identity gate (correctly) refuses and the history pull saves nothing.
 * These helpers (a) detect that state and navigate into the REAL clinical chart
 * before any read, and (b) self-heal the documented athenaOne freeze (reload ->
 * CSRF "Continue" interstitial -> session intact). Safety gates are untouched. */
function mlsSleepW(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
/* executeScript with a hard timeout: a frozen athenaOne renderer can hang an
 * injection forever, which used to hang the whole pull ("gohome-failed" x17).
 * Resolves { r } on success, { err } on rejection, { timeout: true } on hang. */
function mlsExecTO(opts, ms) {
  return Promise.race([
    chrome.scripting.executeScript(opts).then(function (r) { return { r: r }; }, function (e) { return { err: String((e && e.message) || e) }; }),
    mlsSleepW(ms || 15000).then(function () { return { timeout: true }; })
  ]);
}
/* Prefer a BANNER-verified identity (the real chart header) over any other
 * frame's labeled/lastfirst guess - junk frames (letters/messaging) can carry
 * OTHER patients' names and must never outrank the visible chart banner. */
function mlsBestIdentityFrom(idr) {
  var banner = null, best = null;
  (idr || []).forEach(function (m) {
    var r = m && m.result; if (!r || !r.name) return;
    /* Preserve the injection frame that supplied the identity. Athena's
       patient banner can live in an open shadow root while the clinical text
       is light-DOM in that same frame; frame provenance lets the strict chart
       reader bind those two surfaces without accepting tab-wide identity. */
    if (m && typeof m.frameId === 'number' && r.frameId == null) r = Object.assign({}, r, { frameId: m.frameId });
    if (r.via === 'banner' && (!banner || (r.score || 0) > (banner.score || 0))) banner = r;
    if (!best || (r.score || 0) > (best.score || 0)) best = r;
  });
  return banner || best;
}
/* ---- v1.78: SHADOW-DOM identity reader (injected, runs per frame) ----------
 * athenaOne v26.3 renders the patient banner of some chart surfaces (the
 * clientsummary / airlock "briefing" view) inside OPEN shadow roots:
 * document.body.innerText never contains the name, so mlsReadChartIdentity
 * honestly finds nothing and every gate refuses (the live Adam write-back
 * refusal, root-caused 07-10 via mlsIdDiag: innerBanner:false, shadowBanner:true).
 * This ADDITIVE reader walks the rendered (flat) tree of each shadow host,
 * reconstructs LINES (block tags = line breaks, <slot>s flattened, nested
 * shadow roots descended), and parses ONLY text that lives inside shadow:
 *   A) the banner drawer's label block ("Legal First Name" / "Legal Last Name" /
 *      "Date of birth" / "Patient ID", value on the FOLLOWING line), else
 *   B) the demographics chip line ("20yo M | 03-24-2006 | #7833832") with the
 *      name JOINED from the 1-3 lines rendered directly above it (the banner
 *      splits "Adam J" / "SCHAEFFER" across elements - the line-based main
 *      parser can never assemble that, which is why the 07-09 shadow attempts
 *      failed).
 * Frames with NO shadow roots return blank immediately, so plain-DOM phantom
 * sources (athenaText / letters / hidden frames) can never surface here; the
 * main reader's URL/size demotions are applied on top anyway.
 * FALLBACK ONLY: call sites use this only when mlsReadChartIdentity yielded
 * nothing acceptable - the working pull path is untouched when the classic
 * banner is readable. Identity is only emitted with BOTH name and DOB. */
function mlsReadChartIdentityShadow() {
  var blank = { name: '', dob: '', mrn: '', score: 0, via: '', w: 0, h: 0, candidates: [] };
  try {
    var els = document.querySelectorAll('*');
    var hosts = [];
    var capEls = Math.min(els.length, 20000);
    for (var i = 0; i < capEls; i++) { if (els[i].shadowRoot) hosts.push(els[i]); }
    if (!hosts.length) return blank;
    var BLOCK = /^(div|p|li|tr|td|th|section|header|footer|h[1-6]|ul|ol|table|article|aside|nav|form|fieldset|dl|dt|dd|pre|address|hr|br)$/;
    var AGE_CHIP = /\b(\d{1,3})\s*(?:yo|y\/o|yrs?\.?|years?\s*old)\b/i;
    var BARE_DATE = /\b([01]?\d)[\/\-\.]([0-3]?\d)[\/\-\.](\d{4})\b/;
    var MRN_HASH = /#\s?(\d{4,})/;
    var PROVCRED = /^(MD|DO|PA|PAC|NP|CRNA|APRN|DPM|DDS|DMD|RN|CRNP|FNP|DNP|PHD|MBBS|OD|MSN|LPN|CNM|DC|DPT|DR|PHYS|PT)$/i;
    var STOP1 = /^(please|the|new|find|create|search|no|today|welcome|inbox|schedule|calendar|department|provider|patient|results|appointment|encounter|billing|orders|messages|close|camera|panel)$/i;
    function dstr(m) { return ('0' + m[1]).slice(-2) + '/' + ('0' + m[2]).slice(-2) + '/' + m[3]; }
    function okName(cand) {
      if (!cand || cand.length < 4 || cand.length > 60) return '';
      var m = /^([A-Z][A-Za-z'\-\.]*(?:\s+[A-Z][A-Za-z'\-\.]*){1,3})$/.exec(cand);
      if (!m) return '';
      var toks = cand.replace(/,/g, ' ').split(/\s+/);
      for (var q = 0; q < toks.length; q++) { if (STOP1.test(toks[q])) return ''; }
      if (PROVCRED.test(toks[toks.length - 1].replace(/[.\-]/g, ''))) return '';
      if (/^DR\.?$/i.test(toks[0])) return '';
      return cand;
    }
    function collect(root, out, depth) {
      if (depth > 25 || out.n > 4000) return;
      var kids = root.childNodes || [];
      for (var k = 0; k < kids.length; k++) {
        if (out.n > 4000) return;
        var n = kids[k];
        if (n.nodeType === 3) { var s = String(n.nodeValue || '').replace(/\s+/g, ' ').trim(); if (s) { out.items.push({ t: s }); out.n++; } }
        else if (n.nodeType === 1) {
          var tag = (n.tagName || '').toLowerCase();
          if (tag === 'script' || tag === 'style') continue;
          var isB = BLOCK.test(tag);
          if (isB) { out.items.push({ nl: 1 }); out.n++; }
          try {
            if (tag === 'slot' && n.assignedNodes) {
              var an = n.assignedNodes({ flatten: true });
              for (var a = 0; a < an.length; a++) {
                if (an[a].nodeType === 3) { var s2 = String(an[a].nodeValue || '').replace(/\s+/g, ' ').trim(); if (s2) { out.items.push({ t: s2 }); out.n++; } }
                else if (an[a].nodeType === 1) collect(an[a], out, depth + 1);
              }
            } else if (n.shadowRoot) collect(n.shadowRoot, out, depth + 1);
            else collect(n, out, depth + 1);
          } catch (e) {}
          if (isB) { out.items.push({ nl: 1 }); out.n++; }
        }
      }
    }
    function toLines(items) {
      var lines = [], cur = [];
      for (var x = 0; x < items.length; x++) {
        if (items[x].nl) { if (cur.length) { lines.push(cur.join(' ')); cur = []; } }
        else cur.push(items[x].t);
      }
      if (cur.length) lines.push(cur.join(' '));
      return lines;
    }
    function labelVal(lines, re) {
      for (var i2 = 0; i2 < lines.length - 1; i2++) { if (re.test(lines[i2])) return lines[i2 + 1]; }
      return '';
    }
    var bestR = null, allR = [];
    for (var h = 0; h < hosts.length; h++) {
      var out = { items: [], n: 0 };
      collect(hosts[h].shadowRoot, out, 0);
      var lines = toLines(out.items);
      if (!lines.length) continue;
      var name = '', dob = '', mrn = '', via = '';
      /* strategy A: the label block (most explicit).
         v1.88: prefer "First Name Used" over "Legal First Name" - schedules and
         rosters carry the USED name (live: roster "Bob Dunne" vs legal "Robert"
         made the app gate refuse a correctly-opened chart). Same banner, same
         DOB - identity strength is unchanged. */
      var first = labelVal(lines, /^first name used$/i) || labelVal(lines, /^legal first name$/i);
      var middle = labelVal(lines, /^middle name$/i);
      var last = labelVal(lines, /^legal last name$/i);
      var dobA = labelVal(lines, /^date of birth$/i);
      var pidA = (labelVal(lines, /^patient id$/i).match(/#?\s?(\d{4,})/) || [])[1] || '';
      var isVal = function (s) { return s && s.length <= 40 && /^[A-Z]/.test(s) && !/name|birth|patient|gender|age|detail/i.test(s); };
      if (isVal(first) && isVal(last)) {
        var comp = first + ((middle && middle.length <= 20 && isVal(middle)) ? ' ' + middle : '') + ' ' + last;
        var okA = okName(comp.replace(/\s+/g, ' ').trim());
        var dm = BARE_DATE.exec(dobA || '');
        if (okA && dm) { name = okA; dob = dstr(dm); mrn = pidA; via = 'shadow-labels'; }
      }
      /* strategy B: chip line + join of the lines rendered above it */
      if (!name) {
        for (var i3 = 0; i3 < lines.length; i3++) {
          if (!AGE_CHIP.test(lines[i3]) || !BARE_DATE.test(lines[i3])) continue;
          var bd = BARE_DATE.exec(lines[i3]);
          var dobB = dstr(bd);
          var mh = MRN_HASH.exec(lines[i3]);
          var nameB = '';
          for (var kk = 3; kk >= 1 && !nameB; kk--) {
            if (i3 - kk < 0) continue;
            nameB = okName(lines.slice(i3 - kk, i3).join(' ').replace(/\s+/g, ' ').trim());
          }
          if (nameB) { name = nameB; dob = dobB; mrn = (mh && mh[1]) || ''; via = 'shadow-banner'; break; }
        }
      }
      if (!name || !dob) continue; /* shadow identity must be FULL (name+dob) - never a weak guess */
      var score = 2 + (mrn ? 2 : 0) + 1 + 3; /* dob+name+banner-grade, like the main reader */
      try {
        var href = String(location.href || '');
        if (/encounter|\/chart|briefing|clinicals|patientid=|\/patient\/|clientsummary|airlock/i.test(href)) score += 2;
        if (/stm\.esp|globalnav|statusbar|inbox|messag|findpatient\.esp/i.test(href)) score -= 4;
        if (/letter|athenatext|communicat|\bfax|printer|documentviewer|clinicaldocument/i.test(href)) score -= 5;
      } catch (e) {}
      var bodyW = 0, bodyH = 0;
      try { var brc = document.body.getBoundingClientRect(); bodyW = Math.round(brc.width); bodyH = Math.round(brc.height); } catch (e) {}
      if (bodyW < 60 || bodyH < 60) score -= 6;
      var r = { name: name, dob: dob, mrn: mrn, score: score, via: via, w: bodyW, h: bodyH, url: String(typeof href !== 'undefined' ? (href || '') : '') };
      allR.push(r);
      if (!bestR || (via === 'shadow-labels' && bestR.via !== 'shadow-labels') || (r.score > bestR.score && !(bestR.via === 'shadow-labels' && via !== 'shadow-labels'))) bestR = r;
    }
    if (bestR) bestR = Object.assign({}, bestR, { candidates: allR });
    return bestR || blank;
  } catch (e) { return blank; }
}
/* v1.78 helper: run the shadow reader across all frames and return an acceptable
 * FULL identity (name+dob, non-negative score) or null. Call sites use it only
 * after mlsReadChartIdentity found nothing acceptable. */
var __mlsShadowTryLast = new Map(); /* v1.89: tabId -> { ts, found } - shadow-scan cooldown state */
async function mlsShadowIdentityTry(tabId, options) {
  options = options || {};
  /* v1.89 cooldown (review finding 8): the 8s race below ABANDONS but cannot
     CANCEL the injected querySelectorAll('*')-over-20k-elements scan, and the
     chart-ready gate re-invokes this every poll round - abandoned scans stack
     on a slow chart and worsen the very freeze the timeout guards against.
     Within ~6s of the last attempt on the SAME tab: if that attempt FOUND an
     identity, serve it from cache (a found identity may be re-requested
     freely - it just never re-injects inside the window); if it found
     NOTHING, skip and return null (no re-scan). After 6s, scan normally. */
  try {
    var prev = __mlsShadowTryLast.get(tabId);
    if (!options.noCache && prev && (Date.now() - prev.ts) < 6000) return options.all ? (prev.all || []) : (prev.found || null);
  } catch (eCd) {}
  var found = null;
  try {
    /* v1.81: soft 8s timeout - an allFrames injection can hang on a half-loaded
       airlock view; the fallback must never hang its caller past the app's
       bridge budget (that turns into a false "athena frozen" tab reload). */
    var raced = await Promise.race([
      chrome.scripting.executeScript({ target: { tabId: tabId, allFrames: true }, func: mlsReadChartIdentityShadow }).then(function (r) { return { r: r }; }, function () { return { r: null }; }),
      new Promise(function (res) { setTimeout(function () { res({ timeout: true }); }, 8000); })
    ]);
    var allFound = [];
    if (raced && !raced.timeout && raced.r) {
      (raced.r || []).forEach(function (entry) {
        var sb0 = entry && entry.result;
        if (!sb0) return;
        var frameId = (entry && typeof entry.frameId === 'number') ? entry.frameId : null;
        var frameCandidates = Array.isArray(sb0.candidates) && sb0.candidates.length ? sb0.candidates : [sb0];
        frameCandidates.forEach(function (candidate) {
          if (!candidate || !candidate.name || !candidate.dob || (candidate.score || 0) < 0) return;
          var copy = Object.assign({}, candidate);
          delete copy.candidates;
          if (frameId != null) copy.frameId = frameId;
          allFound.push(copy);
        });
      });
      var sb = mlsBestIdentityFrom(allFound.map(function (candidate) { return { frameId: candidate.frameId, result: candidate }; }));
      if (sb && sb.name && sb.dob && (sb.score || 0) >= 0) found = sb;
    }
  } catch (e) {}
  try { if (!options.noCache) __mlsShadowTryLast.set(tabId, { ts: Date.now(), found: found, all: allFound || [] }); } catch (eC2) {}
  return options.all ? (allFound || []) : found;
}
/* Injected (read-only nav): detect the exam-prep/briefing state and click ONLY a
 * safe "load the real clinical chart" control - the "REFRESH CHART" prompt or a
 * plain "Chart" link. Scans control elements via textContent (no innerText/layout
 * walk - the heavy all-frames innerText scan is what froze athenaOne at 78s).
 * NEVER clicks Save/Sign/orders/check-in/anything destructive (BAD blocklist). */
function mlsEnsureClinicalChartFn(requestGuard) {
  try {
    var out = { frame: '', url: '', briefing: false, refreshSeen: false, clicked: '', diag: '' };
    /* ChartRequest passes one immutable request token/deadline. Chrome cannot
       cancel an executeScript which resumes after the worker has already timed
       out, so every navigation gesture re-checks the same guard immediately
       before it can touch Athena. Legacy non-batch callers which omit a guard
       retain their existing behavior; the managed chart path always supplies
       one. */
    var guarded = !!(requestGuard && requestGuard.token && Number(requestGuard.deadline));
    var guard = Object.freeze({
      deadline: Number(requestGuard && requestGuard.deadline || 0),
      token: String(requestGuard && requestGuard.token || '')
    });
    function actionAllowed() {
      return !guarded || (!!guard.token && Number.isFinite(guard.deadline) && Date.now() < guard.deadline);
    }
    try { out.url = String(location.href || '').slice(0, 200); out.frame = location.hostname; } catch (e0) {}
    function vis(el) { try { var r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; var s = getComputedStyle(el); return s.display !== 'none' && s.visibility !== 'hidden'; } catch (e) { return false; } }
    function txt(el) { return String((el && el.textContent) || '').replace(/\s+/g, ' ').trim(); }
    var BAD = /save|sign|order|delete|discard|remove|void|submit|bill|charge|check\s*-?\s*(in|out)|prescri|refill|dispense|cancel|log\s*out|apptmnt|reschedul/i;
    var isBriefingUrl = /\/appointment\/\d+/i.test(out.url) || /briefing|exam-?prep|qualitypane/i.test(out.url);
    var ctrls = [].slice.call(document.querySelectorAll('button,a,[role=button],[role=link],[role=tab],input[type=button],input[type=submit]')).slice(0, 900);
    var refresh = null, chartLink = null, examPrep = false;
    for (var i = 0; i < ctrls.length; i++) {
      var el = ctrls[i]; var t = txt(el) || String(el.value || '').trim();
      if (!t || t.length > 60 || BAD.test(t)) continue;
      if (/refresh\s+chart/i.test(t)) { out.refreshSeen = true; if (!refresh && vis(el)) refresh = el; continue; }
      if (/go\s+to\s+exam\s+prep/i.test(t)) { examPrep = true; continue; }
      if (!chartLink && /^(full\s+chart|patient\s+chart|chart)$/i.test(t) && vis(el)) { chartLink = el; }
    }
    out.briefing = !!(out.refreshSeen || examPrep || isBriefingUrl);
    if (!out.briefing) return out;
    var pick = refresh || chartLink;
    if (pick) {
      if (!actionAllowed()) { out.reason = 'chart-deadline-exceeded'; return out; }
      try { pick.scrollIntoView({ block: 'center' }); } catch (e1) {}
      if (!actionAllowed()) { out.reason = 'chart-deadline-exceeded'; return out; }
      try {
        var r2 = pick.getBoundingClientRect(), x = r2.left + r2.width / 2, y = r2.top + r2.height / 2;
        var o = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y };
        /* pointer/mouse prelude for framework handlers, then ONE real click (no
           'click' in the dispatch list - that double-fired the control). */
        var events = ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup'];
        for (var ei = 0; ei < events.length; ei++) {
          if (!actionAllowed()) { out.reason = 'chart-deadline-exceeded'; return out; }
          var tp = events[ei];
          try { pick.dispatchEvent(new (tp.indexOf('pointer') === 0 ? PointerEvent : MouseEvent)(tp, o)); } catch (e2) {}
        }
        if (!actionAllowed()) { out.reason = 'chart-deadline-exceeded'; return out; }
        try { pick.click(); } catch (e3) {}
      } catch (e4) { out.diag = String((e4 && e4.message) || e4).slice(0, 80); }
      if (actionAllowed()) out.clicked = refresh ? 'refresh-chart' : 'chart-link';
    }
    return out;
  } catch (e) { return { clicked: '', briefing: false, error: String((e && e.message) || e).slice(0, 100) }; }
}
/* Injected read-only interstitial detector. Session/CSRF screens require a
 * human decision; the extension never clicks Continue, reloads, or attempts to
 * re-authenticate on the user's behalf. */
function mlsAthenaContinueFn() {
  try {
    var body = String((document.body && document.body.innerText) || '').slice(0, 12000);
    if (!/unable to complete|could not complete|session (has )?(expired|timed)|please try again/i.test(body)) return { seen: false };
    return { seen: true, clicked: false, manualActionRequired: true };
  } catch (e) { return { seen: false, error: String((e && e.message) || e).slice(0, 80) }; }
}
/* Worker-scope: session-safe recovery. Automatic reloads proved capable of
 * invalidating Athena's CSRF/session state and could also discard unsaved chart
 * work. A read timeout now leaves the user's tab and URL untouched, re-arms the
 * lightweight page heartbeat only when the tab is still signed in, and reports
 * that a manual refresh may be needed. */
var __mlsReadsSinceReload = 0;
async function mlsRecoverAthenaTab(tabId) {
  /* Central fail-closed rail: several legacy callers retain generic-EMR
     fallbacks. Athena recovery must never reload Epic/Cerner/another site and
     risk discarding the doctor's unsaved work. */
  var recoverTab = null;
  try { recoverTab = await chrome.tabs.get(tabId); } catch (eGet) {
    return { ok: false, skipped: 'tab-missing' };
  }
  if (!mlsIsAthenaTab(recoverTab)) return { ok: false, skipped: 'non-athena-tab' };
  if (mlsAthIsLoginish(recoverTab)) return { ok: false, skipped: 'athena-signed-out', manualSignIn: true };
  var sessionHealth = await mlsAthPing(tabId, 1500);
  if (sessionHealth && sessionHealth.signedOut) return { ok: false, skipped: 'athena-signed-out', manualSignIn: true, timedOut: !!sessionHealth.timedOut };
  try { await mlsArmKeepAlive(tabId, true, sessionHealth); } catch (eKa) {}
  __mlsReadsSinceReload = 0;
  return { ok: false, skipped: 'automatic-reload-disabled', manualRefresh: true, tabUntouched: true };
}
/* Session ownership stays with Athena. MLS Assist never synthesizes user input
 * or scrolling to defeat an inactivity policy; this marker is retained only so
 * older callers can safely discover that automatic keep-alive is disabled. */
self.__mlsKaArmAt = self.__mlsKaArmAt || {};
function mlsKeepAlivePageFn() {
  try { window.__mlsKeepAlive = { armed: false, disabled: 'athena-session-policy', by: 'mls-ext', stop: function () {} }; } catch (e) {}
  return 'session-owned-by-athena';
}
async function mlsArmKeepAlive(tabId, force, verifiedHealth) {
  try {
    /* A globalframeset URL remains unchanged when Athena renders its timeout
       page in a child frame, so a URL-only keep-alive decision is unsafe. */
    var tab = null; try { tab = await chrome.tabs.get(tabId); } catch (eTab) { tab = null; }
    if (!tab || mlsAthTabHost(tab) !== 'athenanet.athenahealth.com' || mlsAthIsLoginish(tab)) {
      try { mlsAthRejectSignedOut(tabId); } catch (eReject) {}
      return { armed: false, signedOut: !!tab };
    }
    var health = verifiedHealth && typeof verifiedHealth === 'object' ? verifiedHealth : await mlsAthPing(tabId, 1500);
    if (!health || !health.alive || health.signedOut) return { armed: false, signedOut: !!(health && health.signedOut) };
    var last = self.__mlsKaArmAt[tabId] || 0;
    if (!force && Date.now() - last < 8000) return { armed: true, deduped: true }; /* dedupe the load+pageshow hello burst; arming is idempotent ('already'), so stay aggressive - a 60s throttle left KA dead after back-to-back navs (live: CSRF-Continue right after a reload) */
    self.__mlsKaArmAt[tabId] = Date.now();
    await mlsExecTO({ target: { tabId: tabId }, world: 'MAIN', func: mlsKeepAlivePageFn }, 5000);
    return { armed: true };
  } catch (e) { return { armed: false }; }
}
/* ===================== end v1.59 helpers ===================== */

async function mlsAthenaGotoDate(target, probe, requestGuard) {
  /* target = 'YYYY-MM-DD' */
  var out = { found: false, via: '', done: false, schedDate: '' };
  try {
    var guarded = !!(requestGuard && requestGuard.token && Number(requestGuard.deadline));
    var guard = Object.freeze({ token: String(requestGuard && requestGuard.token || ''), deadline: Number(requestGuard && requestGuard.deadline || 0) });
    function actionAllowed() { return !guarded || (!!guard.token && Number.isFinite(guard.deadline) && Date.now() < guard.deadline); }
    function deadlineStop() { out.done = false; out.reason = 'request-deadline-exceeded'; out.error = 'date navigation deadline exceeded'; return out; }
    if (!actionAllowed()) return deadlineStop();
    function visible(el) { try { var r = el.getBoundingClientRect(); return r.width > 2 && r.height > 2; } catch (e) { return false; } }
    function hdr() {
      var t = (document.body && document.body.innerText || '').slice(0, 8000);
      var M = { january: 1, february: 2, march: 3, april: 4, may: 5, june: 6, july: 7, august: 8, september: 9, october: 10, november: 11, december: 12 };
      var m = /(sunday|monday|tuesday|wednesday|thursday|friday|saturday)[a-z]*[,.]?\s{0,3}([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(\d{4})/i.exec(t);
      if (m) { var mo = M[String(m[2]).toLowerCase()]; if (mo) return m[4] + '-' + ('0' + mo).slice(-2) + '-' + ('0' + m[3]).slice(-2); }
      return '';
    }
    /* v1.66 strategy 0: athenaOne v26.3 dashboard WEEK STRIP (.calendar-nav day tabs
       "Sun 7/05 · Mon 7/06 · Tue 7/07 …"). Live-proven: real-clicking a day tab switches
       the schedule widget to that day (38 rows rendered for 7/07). Week arrows step to
       other weeks. This is the ONLY date nav on the v26.3 dashboard - the legacy date
       input/day arrows below don't exist there ("No date control recognized"). */
    var cnav = document.querySelector('.calendar-nav');
    if (cnav) {
      var TABRE = /^(sun|mon|tue|wed|thu|fri|sat)\s+(\d{1,2}\/\d{1,2})$/i;
      function iso(d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
      function mkDate(y, m, d) { var x = new Date(y, m - 1, d, 12, 0, 0, 0); return (x.getFullYear() === y && x.getMonth() === m - 1 && x.getDate() === d) ? x : null; }
      var targetDate = mkDate(parseInt(target.slice(0, 4), 10), parseInt(target.slice(5, 7), 10), parseInt(target.slice(8, 10), 10));
      if (!targetDate) { out.error = 'weekstrip: invalid target date'; return out; }
      var targetMs = targetDate.getTime();
      /* v1.69: TODAY's own tab renders as "Today" (no date) - the date matcher
         stepped straight past the current week (live: goto today overshot to May). */
      var _now = new Date();
      _now = new Date(_now.getFullYear(), _now.getMonth(), _now.getDate(), 12, 0, 0, 0);
      var isTargetToday = (target === iso(_now));
      function todayTab() {
        var els = Array.prototype.slice.call(cnav.querySelectorAll('*')).filter(function (n) {
          var t = (n.textContent || '').replace(/\s+/g, ' ').trim();
          return /^today$/i.test(t) && visible(n);
        });
        els.sort(function (a, b) { return (a.textContent || '').length - (b.textContent || '').length; });
        return els[0] || null;
      }
      function fullDateAttr(n) {
        try {
          var s = [n.getAttribute('data-date'), n.getAttribute('date'), n.getAttribute('value'), n.getAttribute('href'), n.getAttribute('aria-label'), n.getAttribute('title'), n.getAttribute('onclick')].filter(Boolean).join(' ');
          var a = /(20\d{2}|19\d{2})[-\/]([01]?\d)[-\/]([0-3]?\d)/.exec(s);
          if (a) { var d1 = mkDate(+a[1], +a[2], +a[3]); if (d1) return d1; }
          var b = /([01]?\d)[-\/]([0-3]?\d)[-\/](20\d{2}|19\d{2})/.exec(s);
          if (b) { var d2 = mkDate(+b[3], +b[1], +b[2]); if (d2) return d2; }
        } catch (e) {}
        return null;
      }
      function rawTabs() {
        cnav = document.querySelector('.calendar-nav') || cnav;
        var els = Array.prototype.slice.call(cnav.querySelectorAll('*')).filter(function (n) {
          var t = (n.textContent || '').replace(/\s+/g, ' ').trim();
          return TABRE.test(t) && visible(n);
        });
        /* smallest element per label (the tab itself, not a wrapper) */
        var byLabel = {};
        els.forEach(function (n) { var t = (n.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase(); if (!byLabel[t] || (n.textContent || '').length < (byLabel[t].textContent || '').length) byLabel[t] = n; });
        var outTabs = [];
        for (var k in byLabel) {
          var m = TABRE.exec(k); if (!m) continue;
          var md = m[2].split('/');
          outTabs.push({ el: byLabel[k], label: k, month: +md[0], day: +md[1], date: fullDateAttr(byLabel[k]) });
        }
        var td = todayTab();
        if (td) outTabs.push({ el: td, label: 'today', month: _now.getMonth() + 1, day: _now.getDate(), date: new Date(_now.getTime()), today: true });
        return outTabs;
      }
      function nearestYearDate(month, day, anchor) {
        var best = null, bd = Infinity, ay = anchor.getFullYear();
        for (var yy = ay - 1; yy <= ay + 1; yy++) {
          var d = mkDate(yy, month, day); if (!d) continue;
          var gap = Math.abs(d.getTime() - anchor.getTime());
          if (gap < bd) { bd = gap; best = d; }
        }
        return best;
      }
      var h0 = hdr();
      var hp = /^(\d{4})-(\d{2})-(\d{2})$/.exec(h0 || '');
      var weekAnchor = hp ? mkDate(+hp[1], +hp[2], +hp[3]) : null;
      if (todayTab()) weekAnchor = new Date(_now.getTime());
      if (!weekAnchor) weekAnchor = new Date(_now.getTime());
      function datedTabs() {
        var a = rawTabs();
        for (var i = 0; i < a.length; i++) { if (!a[i].date) a[i].date = nearestYearDate(a[i].month, a[i].day, weekAnchor); }
        return a.filter(function (x) { return !!x.date; });
      }
      function rangeInfo() {
        var a = datedTabs().sort(function (x, y) { return x.date - y.date; });
        return { tabs: a, min: a.length ? a[0].date.getTime() : NaN, max: a.length ? a[a.length - 1].date.getTime() : NaN };
      }
      function stripSig() {
        return rawTabs().map(function (x) { return x.label; }).sort().join('|');
      }
      function realClk(el) {
        if (!actionAllowed()) return false;
        try { el.scrollIntoView({ block: 'center' }); } catch (e1) {}
        if (!actionAllowed()) return false;
        try {
          var r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
          var o = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y };
          var eventTypes = ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup'];
          for (var et = 0; et < eventTypes.length; et++) {
            if (!actionAllowed()) return false;
            var tp = eventTypes[et];
            try { el.dispatchEvent(new (tp.indexOf('pointer') === 0 ? PointerEvent : MouseEvent)(tp, o)); } catch (e2) {}
          }
        } catch (e3) {}
        if (!actionAllowed()) return false;
        try { el.click(); } catch (e4) {}
        return true;
      }
      function findTab() {
        var tabs = datedTabs();
        for (var k = 0; k < tabs.length; k++) { if (iso(tabs[k].date) === target) return tabs[k].el; }
        if (isTargetToday) return todayTab();
        return null;
      }
      out.found = true; out.via = 'weekstrip';
      if (probe) return out;
      var tab0 = findTab();
      if (!tab0) {
        /* Target not in the visible week. Compare FULL dates (never MMDD), then
           step a distance-derived number of weeks. The 104-week ceiling keeps a
           malformed/stale strip bounded while allowing practical cross-year and
           long-range month pulls. Each step waits for the strip signature to
           change instead of sleeping a fixed 2.6s when Athena responds quickly.
           v1.68: BOTH arrows carry "icon-streamlined-next" (live trap) - only their
           CONTAINERS (.nav-prev-week / .nav-next-week) disambiguate. Live-proven:
           3 container-targeted next-week clicks reached Jul 19-25 correctly. */
        var ri0 = rangeInfo();
        if (isFinite(ri0.min) && isFinite(ri0.max)) {
          var gap0 = targetMs < ri0.min ? (ri0.min - targetMs) : (targetMs - ri0.max);
          var maxSteps = Math.min(104, Math.max(8, Math.ceil(Math.max(0, gap0) / 604800000) + 3));
          for (var st = 0; st < maxSteps && !tab0; st++) {
            if (!actionAllowed()) return deadlineStop();
            var ri = rangeInfo();
            if (!isFinite(ri.min) || !isFinite(ri.max)) break;
            if (targetMs >= ri.min && targetMs <= ri.max) { tab0 = findTab(); break; }
            var wantNext = targetMs > ri.max;
            var box = cnav.querySelector(wantNext ? '.nav-next-week' : '.nav-prev-week');
            var arr = box ? (box.querySelector('.icon,span,a,button') || box) : null;
            if (!arr) { /* legacy fallback: labeled arrows */
              var aws = Array.prototype.slice.call(cnav.querySelectorAll('a,button,[role=button],span')).filter(function (el) {
                if (!visible(el)) return false;
                var lab = ((el.getAttribute('aria-label') || '') + ' ' + (el.title || '') + ' ' + (el.className || '')).toLowerCase();
                return (wantNext ? /next(?!.*prev)|forward|right/ : /prev|back|left/).test(lab) && (el.textContent || '').trim().length < 4;
              });
              arr = aws[0] || null;
            }
            if (!arr) break;
            var before = stripSig();
            if (!realClk(arr)) return deadlineStop();
            var deadline = Math.min(Date.now() + 2800, guarded ? guard.deadline : Date.now() + 2800);
            var changed = false;
            while (Date.now() < deadline) {
              await new Promise(function (r) { setTimeout(r, 180); });
              if (!actionAllowed()) return deadlineStop();
              cnav = document.querySelector('.calendar-nav') || cnav;
              var after = stripSig();
              if (after && after !== before) { changed = true; break; }
            }
            /* Never advance the inferred year/week when Athena ignored the click;
               doing so makes unchanged MM/DD labels look like a different year. */
            if (!changed) break;
            weekAnchor = new Date(weekAnchor.getTime() + (wantNext ? 604800000 : -604800000));
            tab0 = findTab();
          }
        }
      }
      if (tab0) {
        if (!realClk(tab0)) return deadlineStop();
        await new Promise(function (r) { setTimeout(r, 1400); });
        if (!actionAllowed()) return deadlineStop();
        var rf = rangeInfo();
        out.done = true; out.schedDate = target; out.steps = st || 0;
        out.visibleStart = isFinite(rf.min) ? iso(new Date(rf.min)) : '';
        out.visibleEnd = isFinite(rf.max) ? iso(new Date(rf.max)) : '';
        return out;
      }
      out.done = false; out.error = 'weekstrip: target day not reachable';
      return out;
    }
    /* strategy 1: a visible date input near the schedule */
    var inputs = Array.prototype.slice.call(document.querySelectorAll('input'));
    var di = null;
    for (var i = 0; i < inputs.length; i++) {
      var el = inputs[i]; if (!visible(el)) continue;
      var tp = (el.type || '').toLowerCase();
      var h = ((el.id || '') + ' ' + (el.name || '') + ' ' + (el.placeholder || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.className || '')).toLowerCase();
      if (tp === 'date') { di = el; break; }
      if ((tp === 'text' || tp === '') && /\bdate\b|caldate|scheddate|datepicker/.test(h) && !/dob|birth/.test(h)) { di = el; break; }
    }
    var arrows = Array.prototype.slice.call(document.querySelectorAll('a,button,[role="button"]')).filter(function (el) {
      if (!visible(el)) return false;
      var lab = ((el.getAttribute('aria-label') || '') + ' ' + (el.title || '') + ' ' + (el.id || '') + ' ' + (el.className || '')).toLowerCase();
      return /next\s*day|prev(ious)?\s*day|day\s*(forward|back)|nextday|prevday/.test(lab);
    });
    var cur = hdr();
    out.schedDate = cur;
    if (di) out.via = 'input'; else if (arrows.length >= 1 && cur) out.via = 'arrows';
    out.found = !!out.via;
    if (probe || !out.found) return out;
    if (out.via === 'input') {
      var mm = target.slice(5, 7), dd = target.slice(8, 10), yy = target.slice(0, 4);
      var val = ((di.type || '').toLowerCase() === 'date') ? target : (mm + '/' + dd + '/' + yy);
      if (!actionAllowed()) return deadlineStop();
      di.focus();
      if (!actionAllowed()) return deadlineStop();
      di.value = val;
      if (!actionAllowed()) return deadlineStop();
      di.dispatchEvent(new Event('input', { bubbles: true }));
      if (!actionAllowed()) return deadlineStop();
      di.dispatchEvent(new Event('change', { bubbles: true }));
      var keyTypes = ['keydown', 'keypress', 'keyup'];
      for (var kt = 0; kt < keyTypes.length; kt++) { if (!actionAllowed()) return deadlineStop(); di.dispatchEvent(new KeyboardEvent(keyTypes[kt], { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true })); }
      out.done = true;
      return out;
    }
    /* arrows: click toward the target, re-reading the header each step */
    var arrowSteps = 0;
    while (arrowSteps++ < 45) {
      if (!actionAllowed()) return deadlineStop();
      cur = hdr(); if (!cur) break;
      if (cur === target) { out.done = true; out.schedDate = cur; return out; }
      var dir = cur < target ? 1 : -1;
      var btn = null;
      for (var k = 0; k < arrows.length; k++) {
        var lab2 = ((arrows[k].getAttribute('aria-label') || '') + ' ' + (arrows[k].title || '') + ' ' + (arrows[k].id || '') + ' ' + (arrows[k].className || '')).toLowerCase();
        var isNext = /next|forward/.test(lab2);
        if ((dir === 1 && isNext) || (dir === -1 && !isNext)) { btn = arrows[k]; break; }
      }
      if (!btn) break;
      if (!actionAllowed()) return deadlineStop();
      btn.click();
      await new Promise(function (r) { setTimeout(r, 700); });
    }
    out.schedDate = hdr();
    out.done = (out.schedDate === target);
    return out;
  } catch (e) { out.error = String((e && e.message) || e); return out; }
}

// ---- Patient identity reader: MLS active patient (injected, runs on mlsscribe.com tab) ----
function mlsReadActivePatient() {
  function pick(o, keys) { for (var i = 0; i < keys.length; i++) { if (o && o[keys[i]] != null && String(o[keys[i]]).trim()) return String(o[keys[i]]).trim(); } return ''; }
  var p = null;
  try { if (window.activePatient && typeof window.activePatient === 'object') p = window.activePatient; } catch (e) {}
  /* v1.71: the live app exposes activePatient as a FUNCTION - missing it made the
     MLS-side identity fall through to a DOM scan that grabbed junk ("? (05-04-1968)"
     - another patient's DOB from the visible list). */
  try { if (!p && typeof window.activePatient === 'function') { var pf = window.activePatient(); if (pf && typeof pf === 'object') p = pf; } } catch (e) {}
  try { if (!p && typeof window.getActivePtId === 'function' && typeof window.getPatients === 'function') { var id = window.getActivePtId(); var list = window.getPatients() || []; p = list.filter(function (x) { return x && (x.id === id || x.client_id === id || x.external_id === id); })[0] || null; } } catch (e) {}
  var name = '', dob = '', mrn = '';
  if (p) { name = pick(p, ['name','fullName','patientName']); if (!name) { var fn = pick(p, ['firstName','first','givenName']); var ln = pick(p, ['lastName','last','familyName']); if (ln || fn) name = (ln ? ln + ', ' : '') + fn; } dob = pick(p, ['dob','dateOfBirth','birthDate','DOB']); mrn = pick(p, ['mrn','MRN','medicalRecordNumber','chartId']); }
  if (!name || !dob) {
    // fall back to the visible unified patient card / patient bar
    /* v1.73: prefer the app's controlled beacon ([data-mls-patient-card], well-formed
       "Last, First" + DOB) over the freeform patient card, and accept a middle
       initial ("Adam J Schaeffer" - the bare regex missed it, leaving name empty). */
    try { var bar = document.querySelector('[data-mls-patient-card], #mlsPatientCard, #patientBar') || document.body; var bt = (bar.innerText || ''); if (!dob) { var dm = /([01]?\d[\/\-\.][0-3]?\d[\/\-\.]\d{2,4})/.exec(bt); if (dm) dob = dm[1]; } if (!mrn) { var mm = /(?:mrn|a-?\d|chart)\s*[:#\-]?\s*([a-z]?\d[a-z0-9\-]{2,})/i.exec(bt); if (mm) mrn = mm[1]; } if (!name) { var nm = /\b([A-Z][a-z'\-]+,\s+[A-Z][a-zA-Z'\-\. ]{1,30}|[A-Z][a-z'\-]+(?:\s+[A-Z]\.?)?\s+[A-Z][a-z'\-]+)\b/.exec(bt); if (nm) name = nm[1].trim(); } } catch (e) {}
  }
  return { name: name, dob: dob, mrn: mrn };
}

// ---- Patient matcher (pure/worker-scope, testable). Conservative: default refuse. ----
function mlsMatchPatients(mls, ath) {
  function normName(s) { return String(s || '').toLowerCase().replace(/[^a-z\s]/g, ' ').split(/\s+/).filter(function (w) { return w.length > 1; }).sort(); }
  function normDob(s) { var m = /([01]?\d)[\/\-\.]([0-3]?\d)[\/\-\.](\d{2,4})/.exec(String(s || '')); if (!m) return ''; var y = m[3]; if (y.length === 2) y = (parseInt(y, 10) > 30 ? '19' : '20') + y; return ('0' + m[1]).slice(-2) + '/' + ('0' + m[2]).slice(-2) + '/' + y; }
  function normMrn(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9]/g, ''); }
  var mDob = normDob(mls && mls.dob), aDob = normDob(ath && ath.dob);
  var mMrn = normMrn(mls && mls.mrn), aMrn = normMrn(ath && ath.mrn);
  var mName = normName(mls && mls.name), aName = normName(ath && ath.name);
  var dobBoth = mDob && aDob, mrnBoth = mMrn && aMrn, nameBoth = mName.length && aName.length;
  var dobMatch = dobBoth && mDob === aDob;
  var mrnMatch = mrnBoth && mMrn === aMrn;
  function nameOverlap() { if (!nameBoth) return 0; var setA = {}; aName.forEach(function (w) { setA[w] = 1; }); var hit = 0; mName.forEach(function (w) { if (setA[w]) hit++; }); return hit; }
  var nameHits = nameOverlap();
  var nameMatch = nameBoth && nameHits >= 2;
  var nameContradict = nameBoth && nameHits === 0;
  // contradiction on any strong identifier => mismatch
  if ((dobBoth && !dobMatch) || (mrnBoth && !mrnMatch) || nameContradict) return { status: 'mismatch', dobMatch: dobMatch, mrnMatch: mrnMatch, nameMatch: nameMatch };
  // confident match needs a strong identifier (DOB or MRN), or a full name + one weak signal
  if (dobMatch || mrnMatch || (nameMatch && (mDob || mMrn ? false : true) && nameHits >= 2 && (mName.length >= 2))) {
    if (dobMatch || mrnMatch) return { status: 'match', dobMatch: dobMatch, mrnMatch: mrnMatch, nameMatch: nameMatch };
  }
  return { status: 'uncertain', dobMatch: dobMatch, mrnMatch: mrnMatch, nameMatch: nameMatch };
}

// ---- Procedure-template prep driver (injected, runs per frame) ----
// Drives athenaOne so the op-note has a destination: PE tab -> Procedure
// Documentation -> add the chosen procedure template (e.g. "Injection Generic
// Template") -> leaves the editable skeleton box ready. The EXISTING note paster
// (mlsNotePaster) then ERASES that skeleton and inserts the op-note. NEVER clicks
// Save/Sign. Self-contained (no out-of-scope refs) for executeScript injection.
// mode 'probe' = READ-ONLY (no clicks): report what is reachable/present.
// mode 'prep'  = perform the add-template sequence (clicks navigation only).
async function mlsAthenaPrepProcTemplate(params, mode) {
  params = params || {}; mode = mode || 'prep';
  var sectionName = String(params.sectionName || 'Procedure Documentation');
  var template = String(params.template || 'Injection Generic Template');
  var tabName = String(params.tab || 'PE');
  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  function vis(el) { try { var r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; var s = getComputedStyle(el); return s.display !== 'none' && s.visibility !== 'hidden' && parseFloat(s.opacity || '1') > 0.05; } catch (e) { return true; } }
  function txt(el) { return ((el && (el.textContent || el.innerText)) || '').replace(/\s+/g, ' ').trim(); }
  function clickEl(el) {
    try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
    var r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
    var o = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y };
    ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) {
      try { el.dispatchEvent(new (tp.indexOf('pointer') === 0 ? PointerEvent : MouseEvent)(tp, o)); } catch (e) {}
    });
    try { el.click(); } catch (e) {}
  }
  function nodes(sel) { try { return [].slice.call(document.querySelectorAll(sel)); } catch (e) { return []; } }
  // shortest visible element whose text matches re (so we hit the label, not a big container)
  function findByText(re, sel) {
    var els = nodes(sel || 'button,a,[role=button],[role=tab],[role=menuitem],[role=option],li,span,div,td');
    var hits = [];
    for (var i = 0; i < els.length; i++) { var el = els[i]; if (!vis(el)) continue; var t = txt(el); if (t && t.length <= 90 && re.test(t)) hits.push({ el: el, t: t, len: t.length }); }
    hits.sort(function (a, b) { return a.len - b.len; });
    return hits;
  }
  // the editable Injection-template skeleton box (INFORMED CONSENT / PROCEDURE / DISCUSSION)
  function findTemplateBox() {
    var eds = nodes('textarea,[contenteditable=""],[contenteditable="true"]').filter(vis);
    var best = null, bs = -1;
    for (var i = 0; i < eds.length; i++) {
      var el = eds[i];
      var c = (el.value != null ? el.value : (el.innerText || el.textContent || ''));
      var lo = String(c).toLowerCase();
      var r = el.getBoundingClientRect(), s = 0;
      if (/informed consent/.test(lo)) s += 50;
      if (/\bprocedure\b/.test(lo)) s += 18;
      if (/\bdiscussion\b/.test(lo)) s += 18;
      if (/sterile|injection|tolerated the procedure|dressing was applied/.test(lo)) s += 15;
      // a sizeable box sitting under a "Procedure Documentation" heading also counts
      try { var h = el.closest && el.closest('section,div,form'); if (h && new RegExp(sectionName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i').test(h.textContent || '')) s += 12; } catch (e) {}
      s += Math.min(r.width * r.height, 300000) / 25000;
      if (s > bs) { bs = s; best = el; }
    }
    return (best && bs >= 12) ? { el: best, score: Math.round(bs) } : null;
  }
  function sectionReachable() {
    // a visible "Procedure Documentation" heading/section already on screen
    return findByText(new RegExp(sectionName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'), 'h1,h2,h3,h4,h5,h6,legend,[role=heading],div,span,a,button').length > 0;
  }

  // ---------- PROBE (read-only) ----------
  var existing = findTemplateBox();
  var tabHit = findByText(new RegExp('^' + tabName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i'), 'a,button,[role=tab],[role=button],li,span')[0] || null;
  var observ = {
    url: location.href, frame: (function () { try { return window.top === window; } catch (e) { return false; } })(),
    templatePresent: !!existing, templateScore: existing ? existing.score : 0,
    sectionReachable: sectionReachable(), tabFound: !!tabHit, tabName: tabName,
    sectionName: sectionName, template: template
  };
  if (mode === 'probe') { return { ok: true, mode: 'probe', ready: !!existing, observed: observ }; }

  // ---------- PREP (navigation clicks only; never Save/Sign) ----------
  // 0) already there -> nothing to do; the paster will erase+fill it.
  if (existing) return { ok: true, ready: true, alreadyPresent: true, step: 'present', observed: observ };

  var steps = [];
  var secRe = new RegExp(sectionName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
  // 1) open the tab dropdown (the caret beside the tab is what opens the menu) and choose the section.
  if (!sectionReachable()) {
    var openers = [];
    nodes('[aria-haspopup],button[aria-expanded],[class*=caret],[class*=dropdown],[class*=disclosure]').filter(vis).forEach(function (e) { openers.push(e); });
    if (tabHit) openers.push(tabHit.el);  // the tab label itself, as a fallback opener
    var secItem = null;
    for (var oi = 0; oi < openers.length && !secItem; oi++) {
      clickEl(openers[oi]); steps.push('open-attempt'); await sleep(450);
      secItem = findByText(secRe, '[role=menuitem],[role=option],li,a,button,div')[0];
      if (secItem || sectionReachable()) break;
    }
    if (secItem) { clickEl(secItem.el); steps.push('clicked-section'); await sleep(700); }
    else if (!sectionReachable()) return { ok: false, ready: false, step: 'section', steps: steps, msg: 'Could not reach "' + sectionName + '" from the ' + tabName + ' tab.', observed: observ };
  }
  if (findTemplateBox()) return { ok: true, ready: true, step: 'section-had-box', steps: steps };

  // 2) open the add/picker control and select the template by typeahead.
  var addCtrl = findByText(/add|\+|procedure documentation|search|select a procedure|choose/i, 'button,[role=button],a,input,[role=combobox]')[0];
  // prefer a search/typeahead input if present
  var input = nodes('input[type=text],input:not([type]),[role=combobox] input,[contenteditable=""]').filter(vis)[0] || null;
  if (addCtrl) { clickEl(addCtrl.el); steps.push('opened-picker'); await sleep(450); input = nodes('input[type=text],input:not([type]),[role=combobox] input').filter(vis)[0] || input; }
  if (input) {
    try { input.focus(); } catch (e) {}
    try {
      var pr = (input.tagName === 'TEXTAREA') ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      var d = Object.getOwnPropertyDescriptor(pr, 'value'); if (d && d.set) d.set.call(input, template); else input.value = template;
    } catch (e) { try { input.value = template; } catch (e2) {} }
    try { input.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) {}
    steps.push('typed-template'); await sleep(800);
  }
  // 3) pick the matching option from the typeahead list.
  var opt = findByText(new RegExp(template.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'), '[role=option],li,.option,.item,td,a,button,div')[0]
         || findByText(/injection generic template|injection/i, '[role=option],li,.option,.item,td,a,button,div')[0];
  if (opt) { clickEl(opt.el); steps.push('picked-template'); await sleep(900); }
  else return { ok: false, ready: false, step: 'pick', steps: steps, msg: 'Opened Procedure Documentation but could not find the "' + template + '" option to add.', observed: observ };

  // 4) wait for the editable skeleton box to render.
  for (var w = 0; w < 8; w++) { if (findTemplateBox()) return { ok: true, ready: true, step: 'added', steps: steps }; await sleep(400); }
  return { ok: false, ready: false, step: 'render', steps: steps, msg: 'Added the template but the editable box did not appear in time.', observed: observ };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { mlsRobustType: mlsRobustType, mlsFieldScanner: mlsFieldScanner, mlsNotePaster: mlsNotePaster, mlsRouteSection: mlsRouteSection, mlsSegmentNote: mlsSegmentNote, mlsMatchPatients: mlsMatchPatients, mlsReadChartIdentity: mlsReadChartIdentity, mlsReadActivePatient: mlsReadActivePatient, mlsAthenaPrepProcTemplate: mlsAthenaPrepProcTemplate };
}

// ---- Procedure-template PREP handler (op-note writeback step 1) ----
// Drives athenaOne to add the chosen procedure template so the op-note has a
// destination box, OR (mode 'probe') reports READ-ONLY what is reachable. The
// actual op-note text is then written by the existing verified paste path
// (mlsAppPasteNote), which erases the skeleton and inserts the note. NEVER Save/Sign.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'mlsAppPrepProcTemplateRequest') return;
  (async () => {
    try {
      const params = msg.params || {};
      const mode = msg.mode === 'probe' ? 'probe' : 'prep';
      if (mode !== 'probe') {
        sendResponse({ ok: false, blocked: true, reason: 'procedure-template-mutation-disabled', error: 'Procedure-template creation is disabled until patient and encounter identity are verified before the first mutation. Read-only readiness checks are still available.' });
        return;
      }
      const isMls = (u) => /mlsscribe\.com/.test(u || '');
      let emrTab = null;
      const su = (sender && sender.tab && sender.tab.url) || '';
      if (sender && sender.tab && /^https?:/.test(su) && !isMls(su)) emrTab = sender.tab;
      if (!emrTab) { const tabs = await chrome.tabs.query({}); emrTab = await mlsPickAthenaTab(tabs, { athenaOnly: true }); if (!emrTab) { const c = tabs.filter(t => /^https?:/.test(t.url || '') && !isMls(t.url || '') && !/athena/i.test(t.url || '')); c.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0)); emrTab = c[0]; } } /* v1.90 */
      if (!emrTab) return sendResponse({ ok: false, error: 'No EMR/chart tab is open. Open the patient encounter in athenaOne, then try again.' });
      let results = [];
      /* v2.9.14 (Codex E3 classification): PROBE mode is read-only — one bounded
         retry (18s envelope, tab revalidated, short settle) on a timeout/rejected/
         empty injection. PREP mode clicks/adds a template, so an outcome-unknown
         failure must NEVER be replayed — prep runs exactly once; callers re-PROBE
         to learn whether the template is now ready before any supervised second
         attempt. */
      if (mode === 'probe') {
        for (let pTry = 0; pTry < 2 && !results.length; pTry++) {
          const px = await mlsExecTO({ target: { tabId: emrTab.id, allFrames: true }, func: mlsAthenaPrepProcTemplate, args: [params, mode] }, 18000);
          if (px && px.r && px.r.length) { results = px.r; break; }
          if (pTry === 0) { try { await chrome.tabs.get(emrTab.id); } catch (eRv) { break; } await new Promise((r) => setTimeout(r, 700)); }
        }
      } else {
        try { results = await chrome.scripting.executeScript({ target: { tabId: emrTab.id, allFrames: true }, func: mlsAthenaPrepProcTemplate, args: [params, mode] }); }
        catch (e) { results = await chrome.scripting.executeScript({ target: { tabId: emrTab.id }, func: mlsAthenaPrepProcTemplate, args: [params, mode] }); }
      }
      let best = null;
      const score = (x) => (x.ready ? 100 : 0) + (x.observed && x.observed.sectionReachable ? 5 : 0) + (x.observed && x.observed.tabFound ? 2 : 0) + ((x.steps || []).length);
      (results || []).forEach(r => { const v = r && r.result; if (!v) return; if (!best || score(v) > score(best)) best = v; });
      sendResponse(best || { ok: false, error: 'Could not run the procedure-template step in any frame.' });
    } catch (e) { sendResponse({ ok: false, error: 'Prep failed: ' + (e && e.message || e) }); }
  })();
  return true;
});


function getCfg() { return new Promise(r => chrome.storage.local.get(['mlsBackend', 'mlsKey'], r)); }

// NO-API-KEY MODE: read the doctor's LIVE MLS login token straight out of an open,
// signed-in mlsscribe.com tab (same Bearer JWT the web app uses). This means the
// extension "just works" once they're logged into MLS — nothing to generate/paste.
// Cached briefly so we don't re-scan every single agent step.
let _sessTok = '', _sessAt = 0;
async function getSessionToken() {
  if (_sessTok && (Date.now() - _sessAt) < 60000) return _sessTok;
  try {
    const tabs = await chrome.tabs.query({ url: ['https://mlsscribe.com/*', 'https://*.mlsscribe.com/*'] });
    // Prefer the most-recently-used MLS tab.
    tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
    for (const tab of tabs) {
      try {
        const [r] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => { try { return sessionStorage.getItem('sf_bk_token') || localStorage.getItem('sf_bk_token') || ''; } catch (e) { return ''; } }
        });
        const tok = (r && r.result || '').trim();
        if (tok) { _sessTok = tok; _sessAt = Date.now(); return tok; }
      } catch (e) { /* tab not scriptable (still loading / restricted) — try next */ }
    }
  } catch (e) {}
  return '';
}

async function callBackend(path, body) {
  const c = await getCfg();
  const base = (c.mlsBackend || DEFAULT_BACKEND).replace(/\/+$/, '');
  let key = (c.mlsKey || '').trim();
  let viaSession = false;
  if (!key) { key = await getSessionToken(); viaSession = true; }
  if (!key) return { error: 'Not connected. Open MLS (mlsscribe.com) in a tab and sign in — MLS Assist will use your login automatically. (Or add an API key via the toolbar icon.)' };
  try {
    const r = await fetch(base + path, {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    let d = {}; try { d = await r.json(); } catch (e) {}
    if (!r.ok) {
      // A stale session token? Drop the cache and tell them to re-sign-in.
      if (viaSession && r.status === 401) { _sessTok = ''; _sessAt = 0; return { error: 'Your MLS login expired — open mlsscribe.com and sign in again, then retry.' }; }
      return { error: d.error || ('Request failed (HTTP ' + r.status + ')') };
    }
    return d;
  } catch (e) { return { error: 'Network error: ' + e.message }; }
}
// Find the signed-in EMR/Athena tab broadly (known Athena domains, else EMR-ish host keywords,
// else the most-recently-active non-MLS http(s) tab). Shared by the Mode C search handlers; the
// real resilience is content-based scoring inside the injected driver, not the tab URL.
/* v1.50: TITLE-aware athena tab test — some athenaOne windows surface "athenaCollector
   v26.x ..." / "athenaOne" only in the TAB TITLE (URL variants the regex misses), which made
   the extension report a false "not connected". Title counts as athena too. */
function mlsTabTitleAthena(t) {
  return /athena\s*(one|net|collector|clinicals|health)|athenahealth|athenaone|athenanet/i.test((t && t.title) || '') && !/mlsscribe\.com/i.test((t && t.url) || '');
}
function mlsPickEmrTab(all) {
  return all.find((t) => /athenahealth|athenanet|athenaone|athena\.io|\.px\.athena/i.test(t.url || ''))
      || all.find((t) => mlsTabTitleAthena(t))
      || all.find((t) => /athena|epic|cerner|ecw|eclinical|nextgen|allscripts|emr|ehr|\bchart\b|report|claim|billing|practice|clinic/i.test(t.url || '') && !/mlsscribe\.com/i.test(t.url || ''))
      || (function () { const c = all.filter((t) => /^https?:/i.test(t.url || '') && !/mlsscribe\.com|chrome:\/\//i.test(t.url || '')); c.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0)); return c[0]; })();
}
/* ============================================================================
 * v1.90 UNIFIED ATHENA TAB PICKER — mlsPickAthenaTab(all, opts)
 * Live failure (07-10): with TWO windows holding athena tabs, the per-handler
 * inline sorts had NO lastAccessed tiebreak, so score ties kept
 * chrome.tabs.query() order (older window first) and gotoDate probed a dead/
 * signed-out tab -> {ok:true,supported:false}. identity.athenahealth.com also
 * passes the /athenahealth/ pick regexes while yielding no usable frames.
 * ONE picker for every athena-target handler:
 *  1) prefer tabs whose content script recently said hello (mlsAthenaHello);
 *  2) verify with a cheap READ-ONLY executeScript ping that must return a real
 *     frame result (.calendar-nav / frameset presence = signed-in tiebreak);
 *  3) EXCLUDE identity./login hosts — raw athenanet.athenahealth.com only;
 *  4) fall back to legacy scoring (and, when opts.athenaOnly is falsy, to a
 *     generic non-athena EMR pick).
 * Never throws. Every candidate, including a single/cached/pinned one, receives
 * a fresh all-frame session probe; the 10s cache preserves preference only.
 * Revert: delete this block and restore the per-site old_strings in §3.3.
 * ========================================================================== */
self.__mlsAthReg = self.__mlsAthReg || {};            /* tabId -> last hello (ms) */
self.__mlsAthPickCache = self.__mlsAthPickCache || { tabId: null, at: 0 };
try { chrome.storage.session.get(['mlsAthReg'], function (st) { try { var m = st && st.mlsAthReg; if (m && typeof m === 'object') { for (var k in m) { if (self.__mlsAthReg[k] == null) self.__mlsAthReg[k] = m[k]; } } } catch (e) {} }); } catch (e) {}
try {
  chrome.runtime.onMessage.addListener(function (msg, sender) {
    if (!msg || msg.type !== 'mlsAthenaHello' || !sender || !sender.tab || sender.tab.id == null) return;
    try {
      var h = ''; try { h = new URL(sender.tab.url || '').host.toLowerCase(); } catch (e0) {}
      if (h !== 'athenanet.athenahealth.com') return; /* registration = raw product host ONLY */
      /* A content-script hello proves only that the outer document can run JS.
         Register/label/arm it only after the exact all-frame session probe. */
      (async function (__kaTid) {
        try {
          var pr = await mlsAthPing(__kaTid, 1500);
          if (!pr.alive || pr.signedOut) return;
          self.__mlsAthReg[__kaTid] = Date.now();
          try { chrome.storage.session.set({ mlsAthReg: self.__mlsAthReg }); } catch (e1) {}
          chrome.tabs.query({ url: '*://mlsscribe.com/*' }, function (apps) {
            var pinnedHere = false; try { pinnedHere = !!(self.__mlsAthPin && self.__mlsAthPin.tabId === __kaTid); } catch (e4) {}
            try { if (((apps && apps.length) || pinnedHere) && typeof mlsArmKeepAlive === 'function') mlsArmKeepAlive(__kaTid, false, pr); } catch (e2) {}
          });
        } catch (e3) {}
      })(sender.tab.id);
    } catch (e) {}
    /* passive: no sendResponse -> port not held (v1.42 rule) */
  });
} catch (e) {}
try { chrome.tabs.onRemoved.addListener(function (tid) { try { delete self.__mlsAthReg[tid]; if (self.__mlsAthPickCache.tabId === tid) self.__mlsAthPickCache.tabId = null; chrome.storage.session.set({ mlsAthReg: self.__mlsAthReg }); } catch (e) {} }); } catch (e) {}
function mlsAthTabHost(t) { try { return new URL((t && t.url) || '').host.toLowerCase(); } catch (e) { return ''; } }
function mlsAthIsLoginish(t) {
  var h = mlsAthTabHost(t), u = ((t && t.url) || '').toLowerCase();
  if (/^(identity|login|signin|sso|auth|accounts|okta|myapps)\./.test(h)) return true;
  return /aws\.caas|\/login\b|sign-?in|\/auth\b|\/authn\b|\/oauth|\.oauth2\b|\/sso\b|accounts\.|\bwww\.athenahealth\.com\b|landing|portal|marketing/.test(u);
}
function mlsAthScore(t) {
  var u = ((t && t.url) || '').toLowerCase(), s = 0;
  if (mlsAthTabHost(t) === 'athenanet.athenahealth.com') s += 100;
  if (/athena/i.test((t && t.title) || '')) s += 60;
  if (/globalframeset|\/ax\/|dashboard|schedul|calendar|frontoffice|encounter/.test(u)) s += 40;
  if (mlsAthIsLoginish(t)) s -= 500;
  try { var hb = (self.__mlsAthReg || {})[t.id]; if (hb && (Date.now() - hb) < 300000) s += 80; } catch (e) {}
  if (t && t.active) s += 5;
  if (t && (t.discarded || t.status === 'unloaded')) s -= 300;
  return s;
}
/* Injected independently into every current frame. This is deliberately an
   exact, visible-session probe rather than a generic search for "login" or
   "timed out"; clinical/chart text can legitimately contain those words. */
function mlsAthSessionProbeFn() {
  try {
    function norm(v) { return String(v == null ? '' : v).replace(/\s+/g, ' ').trim().toLowerCase(); }
    var body = document.body;
    var rawText = String(body ? (body.innerText || body.textContent || '') : '');
    var text = norm(rawText);
    var title = norm(document.title || '');
    var combined = (title + ' ' + text).slice(0, 160000);
    var visible = true;
    try {
      if (window.top !== window) visible = Number(window.innerWidth || 0) >= 80 && Number(window.innerHeight || 0) >= 50;
      if (visible && body && typeof body.getBoundingClientRect === 'function') {
        var br = body.getBoundingClientRect();
        if (window.top !== window && (Number(br.width || 0) < 40 || Number(br.height || 0) < 20)) visible = false;
      }
    } catch (eVisible) {}
    var firstVisibleLine = '';
    try { firstVisibleLine = (rawText.split(/[\r\n]+/).map(norm).filter(Boolean)[0] || ''); } catch (eLine) {}
    var timeoutHeading = title === 'refresh timed out' || firstVisibleLine === 'refresh timed out';
    try {
      if (!timeoutHeading) timeoutHeading = Array.prototype.some.call(document.querySelectorAll('h1,h2,h3,[role="heading"]'), function (el) { return norm(el && el.textContent) === 'refresh timed out'; });
    } catch (eHeading) {}
    var timedOut = visible
      && timeoutHeading
      && /your session has timed out[.\s\u2013\u2014-]*please log in\b/.test(combined);
    var hasPassword = false;
    try { hasPassword = !!document.querySelector('input[type="password"]'); } catch (ePassword) {}
    var exactAthenaLogin = visible && hasPassword
      && /(?:^|\s)(?:log in|sign in) to athena(?:one)?(?:\s|$)/.test(combined)
      && /(?:^|\s)(?:username|user id|email)(?:\s|$)/.test(combined);
    return {
      p: 1,
      cal: !!document.querySelector('.calendar-nav'),
      fs: !!document.querySelector('frameset,frame,iframe'),
      timedOut: !!timedOut,
      login: !!exactAthenaLogin,
      visible: !!visible
    };
  } catch (e) { return { p: 1, cal: false, fs: false, timedOut: false, login: false, visible: false }; }
}
function mlsAthRejectSignedOut(tabId) {
  try { delete (self.__mlsAthReg || {})[tabId]; } catch (e0) {}
  try { if (self.__mlsAthPickCache && Number(self.__mlsAthPickCache.tabId) === Number(tabId)) self.__mlsAthPickCache = { tabId: null, at: 0 }; } catch (e1) {}
  try { if (self.__mlsAthPin && Number(self.__mlsAthPin.tabId) === Number(tabId)) mlsPinSet(null); } catch (e2) {}
  try { chrome.storage.session.set({ mlsAthReg: self.__mlsAthReg || {} }); } catch (e3) {}
}
function mlsAthPing(tabId, ms) { /* READ-ONLY all-frame probe; one exact expired frame vetoes the shell */
  return mlsExecTO({ target: { tabId: tabId, allFrames: true }, func: mlsAthSessionProbeFn }, ms || 1200).then(function (x) {
    var fr = ((x && x.r) || []).map(function (m) { return m && m.result; }).filter(Boolean);
    if (!fr.length) return { alive: false, reachable: false, signedOut: false, timedOut: false, login: false, frames: 0 };
    var timedOut = fr.some(function (f) { return f.timedOut === true; });
    var login = fr.some(function (f) { return f.login === true; });
    var signedOut = timedOut || login;
    if (signedOut) mlsAthRejectSignedOut(tabId);
    return {
      alive: !signedOut,
      reachable: true,
      signedOut: signedOut,
      timedOut: timedOut,
      login: login,
      frames: fr.length,
      cal: !signedOut && fr.some(function (f) { return f.cal; }),
      fs: !signedOut && fr.some(function (f) { return f.fs; })
    };
  }).catch(function () { return { alive: false, reachable: false, signedOut: false, timedOut: false, login: false, frames: 0 }; });
}
function mlsPickGenericEmrTab(all) { /* non-athena EMR fallback (athena candidates were already considered+rejected) */
  try {
    return all.find(function (t) { return /epic|cerner|ecw|eclinical|nextgen|allscripts|emr|ehr|\bchart\b|report|claim|billing|practice|clinic/i.test(t.url || '') && !/mlsscribe\.com|athena/i.test((t.url || '') + ' ' + (t.title || '')); })
        || (function () { var c = all.filter(function (t) { return /^https?:/i.test(t.url || '') && !/mlsscribe\.com|athena|chrome:\/\//i.test((t.url || '') + ' ' + (t.title || '')); }); c.sort(function (a, b) { return (b.lastAccessed || 0) - (a.lastAccessed || 0); }); return c[0] || null; })();
  } catch (e) { return null; }
}
async function mlsPickAthenaTab(all, opts) {
  opts = opts || {};
  try {
    /* QUIET-WORK LEASE FIRST (v2.9.25): a managed pull may span many read-only
       chart navigations. Once its quiet workspace is established, every patient
       operation in that cohort stays on the EXACT leased Athena tab - never hop
       to a second signed-in tab because recency scores changed, and never for a
       mutable explicit pin that changed mid-run. The active lease outranks the
       pin; the pin is consulted only when no active lease exists. Health is
       still re-probed on every selection: a signed-out or dead leased tab fails
       closed (returns null) instead of hopping the cohort to another tab. */
    var qpLease = self.__mlsQp;
    if (qpLease && qpLease.active && qpLease.athenaTabId != null) {
      var qt = null; try { qt = await chrome.tabs.get(qpLease.athenaTabId); } catch (eQpTab) { qt = null; }
      if (qt && mlsAthTabHost(qt) === 'athenanet.athenahealth.com' && !mlsAthIsLoginish(qt)) {
        var qpHealth = await mlsAthPing(qt.id, opts.noPing ? 1000 : 1500);
        if (qpHealth.alive && !qpHealth.signedOut) return qt;
        if (qpHealth.signedOut) mlsAthRejectSignedOut(qt.id);
      }
      return null;
    }
    /* v1.99 TAB PIN: the user explicitly handed this athena tab to MLS via the
       tab picker - with no active quiet-work lease it wins over every heuristic
       below. A pinned tab sitting on a login/identity page means the SESSION
       DROPPED: return null so athenaOnly callers fail honestly and the picker
       surfaces 'signed out' - NEVER re-auth, never silently fall back to some
       other tab the user didn't choose. A CLOSED pinned tab auto-unpins (also
       handled by onRemoved). */
    var pin = self.__mlsAthPin;
    if (pin && pin.tabId != null) {
      var pt = null; try { pt = await chrome.tabs.get(pin.tabId); } catch (eP) { pt = null; }
      if (!pt) { try { mlsPinSet(null); } catch (eP2) {} }
      else if (mlsAthTabHost(pt) === 'athenanet.athenahealth.com' && !mlsAthIsLoginish(pt)) {
        var pinnedHealth = await mlsAthPing(pt.id, 1500);
        if (pinnedHealth.alive && !pinnedHealth.signedOut) return pt;
        if (pinnedHealth.signedOut) mlsAthRejectSignedOut(pt.id);
        return null;
      } else { mlsAthRejectSignedOut(pt.id); return null; }
    }
    if (!all) { try { all = await chrome.tabs.query({}); } catch (e0) { all = []; } }
    var http = (all || []).filter(function (t) { return t && t.id != null && /^https?:/i.test(t.url || '') && !/mlsscribe\.com/i.test(t.url || ''); });
    var known = http.filter(function (t) { return /athenahealth|athenanet|athenaone|athena\.io|\.px\.athena/i.test(t.url || '') || mlsTabTitleAthena(t); });
    if (!known.length) return opts.athenaOnly ? null : mlsPickGenericEmrTab(http);
    known.sort(function (a, b) { return (mlsAthScore(b) - mlsAthScore(a)) || ((b.lastAccessed || 0) - (a.lastAccessed || 0)) || ((b.id || 0) - (a.id || 0)); });
    if (mlsAthScore(known[0]) < 0) return opts.athenaOnly ? null : mlsPickGenericEmrTab(http); /* every athena tab is an identity/login page */
    var C = self.__mlsAthPickCache;
    /* Cache preserves preference, never health. A fresh all-frame probe vetoes
       a cached globalframeset whose child frame has since timed out. */
    if (C.tabId != null && (Date.now() - C.at) < 10000) {
      var ci = known.findIndex(function (t) { return t.id === C.tabId; });
      if (ci > 0) known.unshift(known.splice(ci, 1)[0]);
    }
    var probeBudget = opts.noPing ? 1000 : 1200; /* legacy noPing is only a shorter budget, never a session-check bypass */
    var checked = await Promise.all(known.map(async function (t) {
      if (mlsAthScore(t) < 0) { mlsAthRejectSignedOut(t.id); return { tab: t, probe: { alive: false, signedOut: true } }; }
      return { tab: t, probe: await mlsAthPing(t.id, probeBudget) };
    }));
    checked.forEach(function (x) { if (x.probe && x.probe.signedOut) mlsAthRejectSignedOut(x.tab.id); });
    var usable = checked.filter(function (x) { return x.probe && x.probe.alive && !x.probe.signedOut; });
    var selectedShell = usable.find(function (x) { return x.probe.cal || x.probe.fs; });
    var pick = (selectedShell || usable[0] || {}).tab || null;
    if (!pick) return opts.athenaOnly ? null : mlsPickGenericEmrTab(http);
    C = self.__mlsAthPickCache || (self.__mlsAthPickCache = { tabId: null, at: 0 });
    C.tabId = pick.id; C.at = Date.now();
    return pick;
  } catch (e) {
    try { return opts.athenaOnly ? null : mlsPickGenericEmrTab(all || []); } catch (e2) { return null; }
  }
}
self.__mlsPickAthenaTab = mlsPickAthenaTab; /* console/diag handle */

/* ===================== v1.99 ATHENA TAB PIN (tab-picker backend) ==============
 * The user hands MLS an already-open athena tab from the in-app picker chip.
 * Pinned tab: wins every pick only after a fresh all-frame session check;
 * keep-alive is armed only after that proof and re-checked by a
 * 5-minute alarm (idempotent, gentle - the same 55s Worker keep-alive, never
 * setInterval, no heavy scans); never navigated except during a pull the user
 * started; if its session drops (login page) athena-side work pauses and the
 * picker shows 'signed out' - NEVER re-auth. Exact child-frame timeout/login
 * evidence clears the pin. Survives SW restarts (storage.session). */
self.__mlsAthPin = self.__mlsAthPin || { tabId: null, at: 0 };
try { chrome.storage.session.get(['mlsAthPin'], function (st) { try { var p = st && st.mlsAthPin; if (p && p.tabId != null && self.__mlsAthPin.tabId == null) self.__mlsAthPin = p; } catch (e) {} }); } catch (e) {}
function mlsPinSet(tabId) {
  self.__mlsAthPin = { tabId: (tabId == null ? null : tabId), at: Date.now() };
  try { chrome.storage.session.set({ mlsAthPin: self.__mlsAthPin }); } catch (e) {}
  try { if (tabId == null) chrome.alarms.clear('mlsPinWatch'); else chrome.alarms.create('mlsPinWatch', { periodInMinutes: 5 }); } catch (e) {}
}
async function mlsPinInfo() {
  var pin = self.__mlsAthPin || {};
  var out = { pinned: pin.tabId != null, tabId: pin.tabId == null ? null : pin.tabId, alive: false, connected: false, signedOut: false, timedOut: false, ka: '', title: '' };
  if (!out.pinned) return out;
  var t = null; try { t = await chrome.tabs.get(pin.tabId); } catch (e) { t = null; }
  if (!t) { mlsPinSet(null); out.pinned = false; out.tabId = null; return out; }
  out.title = String(t.title || '').slice(0, 70);
  if (mlsAthIsLoginish(t) || mlsAthTabHost(t) !== 'athenanet.athenahealth.com') { out.signedOut = true; mlsAthRejectSignedOut(t.id); out.pinned = false; out.tabId = null; return out; }
  var pr = await mlsAthPing(t.id, 1500);
  out.alive = !!pr.alive;
  out.connected = !!(pr.alive && !pr.signedOut);
  out.signedOut = !!pr.signedOut;
  out.timedOut = !!pr.timedOut;
  if (pr.signedOut) { mlsAthRejectSignedOut(t.id); out.pinned = false; out.tabId = null; return out; }
  if (!pr.alive) return out;
  try {
    var kx = await mlsExecTO({ target: { tabId: t.id }, world: 'MAIN', func: function () { try { return { armed: !!(window.__mlsKeepAlive && window.__mlsKeepAlive.armed), ticks: (window.__mlsKeepAlive && window.__mlsKeepAlive.ticks) || 0 }; } catch (e) { return { armed: false, ticks: 0 }; } } }, 2500);
    var kr = kx && kx.r && kx.r[0] && kx.r[0].result;
    if (kr) out.ka = kr.armed ? ('armed · ' + kr.ticks + ' ticks') : 'not armed';
  } catch (e) {}
  return out;
}
try { chrome.tabs.onRemoved.addListener(function (tid) { try { if (self.__mlsAthPin && self.__mlsAthPin.tabId === tid) mlsPinSet(null); } catch (e) {} }); } catch (e) {}
try {
  chrome.alarms.onAlarm.addListener(function (a) {
    if (!a || a.name !== 'mlsPinWatch') return;
    (async function () {
      try {
        var pin = self.__mlsAthPin;
        if (!pin || pin.tabId == null) { try { chrome.alarms.clear('mlsPinWatch'); } catch (e) {} return; }
        var t = null; try { t = await chrome.tabs.get(pin.tabId); } catch (e) { t = null; }
        if (!t) { mlsPinSet(null); return; }
        if (mlsAthIsLoginish(t) || mlsAthTabHost(t) !== 'athenanet.athenahealth.com') { mlsAthRejectSignedOut(t.id); return; }
        var pr = await mlsAthPing(pin.tabId, 1500);
        if (!pr.alive || pr.signedOut) return;
        await mlsArmKeepAlive(pin.tabId, false, pr); /* idempotent gentle re-arm (walk-away guarantee) */
      } catch (e) {}
    })();
  });
} catch (e) {}
/* =================== end v1.99 athena tab pin ================================ */

/*MLS_ATHENA_DRIVE_START*/
async function mlsAthenaDrive(op, params, cfg) {
  params = params || {}; cfg = cfg || {};
  var D = (typeof document !== 'undefined') ? document : null;
  if (!D) return { ok: false, error: 'no-document' };
  function arr(x) { return Array.isArray(x) ? x : []; }
  function lc(x) { return String(x == null ? '' : x).toLowerCase(); }
  var C = {
    cptFieldLabels:   arr(cfg.cptFieldLabels).length   ? cfg.cptFieldLabels   : ['cpt', 'procedure code', 'proc code', 'service code', 'hcpcs', 'code'],
    procFieldLabels:  arr(cfg.procFieldLabels).length  ? cfg.procFieldLabels  : ['procedure', 'service', 'description', 'exam', 'visit type'],
    dateFromLabels:   arr(cfg.dateFromLabels).length   ? cfg.dateFromLabels   : ['service date from', 'date of service from', 'dos from', 'date from', 'start date', 'from date', 'from', 'start', 'begin'],
    dateToLabels:     arr(cfg.dateToLabels).length     ? cfg.dateToLabels     : ['service date to', 'date of service to', 'dos to', 'date to', 'end date', 'to date', 'through', 'thru', 'to', 'end'],
    runLabels:        arr(cfg.runLabels).length        ? cfg.runLabels        : ['run report', 'run', 'search', 'view report', 'generate', 'go', 'apply', 'find', 'filter', 'submit', 'update'],
    nextLabels:       arr(cfg.nextLabels).length       ? cfg.nextLabels       : ['next page', 'next', '›', '»', '>', 'older', 'show more', 'load more', 'more results'],
    nextSelectors:    arr(cfg.nextSelectors).length    ? cfg.nextSelectors    : ['a[rel="next"]', '[aria-label*="next" i]', '.pagination .next a', 'li.next a', 'button[title*="next" i]', '[data-page="next"]', '.paging-next', '.next-page'],
    rowSelectors:     arr(cfg.rowSelectors).length     ? cfg.rowSelectors     : ['table tbody tr', '[role="row"]', '.result-row', '.report-row', '.GridRow', '.athena-row', 'tr'],
    excludeClickLabels: arr(cfg.excludeClickLabels).length ? cfg.excludeClickLabels : ['save', 'sign', 'finalize', 'close encounter', 'post', 'delete', 'remove', 'discard', 'bill', 'submit claim', 'approve', 'void', 'cancel appointment'],
    maxRowChars: cfg.maxRowChars || 44000
  };

  function vis(el) {
    try {
      if (!el) return false;
      var win = (el.ownerDocument && el.ownerDocument.defaultView) || (typeof window !== 'undefined' ? window : null);
      var s = (win && win.getComputedStyle) ? win.getComputedStyle(el) : null;
      if (s && (s.display === 'none' || s.visibility === 'hidden')) return false;
      if (el.hidden) return false;
      if (el.getAttribute && el.getAttribute('aria-hidden') === 'true') return false;
      return true;
    } catch (e) { return true; }
  }
  function cssEsc(s) { return String(s).replace(/["\\]/g, '\\$&'); }
  function labelText(el) {
    var parts = [];
    try { ['aria-label', 'placeholder', 'title', 'name', 'id'].forEach(function (k) { var v = el.getAttribute && el.getAttribute(k); if (v) parts.push(v); }); } catch (e) {}
    try { if (el.id) { var lb = D.querySelector('label[for="' + cssEsc(el.id) + '"]'); if (lb && lb.textContent) parts.push(lb.textContent); } } catch (e) {}
    try { var wrap = el.closest && el.closest('label'); if (wrap && wrap.textContent) parts.push(wrap.textContent); } catch (e) {}
    try { var prev = el.previousElementSibling, hop = 0; while (prev && hop < 2) { var pt = (prev.textContent || '').trim(); if (pt && pt.length < 40) parts.push(pt); prev = prev.previousElementSibling; hop++; } } catch (e) {}
    return parts.join(' ').replace(/\s+/g, ' ').trim().toLowerCase();
  }
  function hasAny(hay, labels) { for (var i = 0; i < labels.length; i++) { var l = lc(labels[i]); if (l && hay.indexOf(l) >= 0) return true; } return false; }
  function editableInputs() {
    var nodes = [].slice.call(D.querySelectorAll('input,textarea,[contenteditable=""],[contenteditable="true"]'));
    return nodes.filter(function (el) {
      var tg = (el.tagName || '').toUpperCase();
      if (tg === 'INPUT') { var t = lc(el.getAttribute('type') || 'text'); if (['hidden', 'checkbox', 'radio', 'button', 'submit', 'reset', 'image', 'file', 'range', 'color'].indexOf(t) >= 0) return false; }
      return vis(el);
    });
  }
  function findField(labels) {
    var ins = editableInputs(), best = null, bestS = -1;
    ins.forEach(function (el) {
      var hay = labelText(el), s = 0;
      labels.forEach(function (l, idx) { l = lc(l); if (l && hay.indexOf(l) >= 0) { s += 10 + (labels.length - idx); if (hay === l || hay.indexOf(l) === 0) s += 3; } });
      if (s > bestS) { bestS = s; best = el; }
    });
    return bestS > 0 ? best : null;
  }
  function findDateField(labels) {
    var ins = editableInputs(), best = null, bestS = -1;
    ins.forEach(function (el) {
      var hay = labelText(el), s = 0;
      labels.forEach(function (l) { l = lc(l); if (l && hay.indexOf(l) >= 0) s += 10; });
      var t = lc(el.getAttribute && el.getAttribute('type'));
      if (t === 'date') s += 4;
      if (/date|dob|dos/.test(hay)) s += 2;
      if (s > bestS) { bestS = s; best = el; }
    });
    return bestS > 0 ? best : null;
  }
  function clickables() { return [].slice.call(D.querySelectorAll('button,a,[role="button"],input[type="submit"],input[type="button"]')).filter(vis); }
  function btnText(el) { var t = (el.textContent || '') + ' ' + (el.value || '') + ' ' + labelText(el); return t.replace(/\s+/g, ' ').trim().toLowerCase(); }
  function findButton(labels) {
    var bs = clickables(), best = null, bestS = -1;
    bs.forEach(function (el) {
      var t = btnText(el); if (hasAny(t, C.excludeClickLabels)) return;
      var s = 0; labels.forEach(function (l, idx) { l = lc(l); if (!l) return; if (t === l) s += 20; else if (t.indexOf(l) >= 0) s += 10 + (labels.length - idx); });
      if (s > bestS) { bestS = s; best = el; }
    });
    return bestS > 0 ? best : null;
  }
  function isDisabled(el) {
    try {
      if (el.disabled) return true;
      if (el.getAttribute && el.getAttribute('aria-disabled') === 'true') return true;
      if (/\bdisabled\b/.test((el.className || '') + '')) return true;
      if (el.closest && el.closest('.disabled,[aria-disabled="true"]')) return true;
    } catch (e) {}
    return false;
  }
  function findNext() {
    for (var i = 0; i < C.nextSelectors.length; i++) {
      try { var el = D.querySelector(C.nextSelectors[i]); if (el && vis(el) && !isDisabled(el)) { var t = btnText(el); if (!hasAny(t, C.excludeClickLabels)) return el; } } catch (e) {}
    }
    var bs = clickables(), best = null;
    for (var j = 0; j < bs.length; j++) {
      var e = bs[j]; if (isDisabled(e)) continue; var tt = btnText(e); if (hasAny(tt, C.excludeClickLabels)) continue;
      for (var k = 0; k < C.nextLabels.length; k++) { var l = lc(C.nextLabels[k]); if (!l) continue; if (tt === l) return e; if (tt.length <= 14 && tt.indexOf(l) >= 0) { best = best || e; } }
    }
    return best;
  }
  function extractRows() {
    var bestText = '', bestCount = 0, used = '';
    for (var i = 0; i < C.rowSelectors.length; i++) {
      try {
        var rows = [].slice.call(D.querySelectorAll(C.rowSelectors[i])).filter(vis);
        if (rows.length >= 2) {
          var txt = rows.map(function (r) { return ((r.innerText || r.textContent || '') + '').replace(/\s+/g, ' ').trim(); }).filter(function (s) { return s.length > 2; }).join('\n');
          if (rows.length > bestCount && txt) { bestCount = rows.length; bestText = txt; used = C.rowSelectors[i]; }
        }
      } catch (e) {}
    }
    if (!bestText) { try { bestText = (((D.body && (D.body.innerText || D.body.textContent)) || '') + '').slice(0, C.maxRowChars); } catch (e) {} }
    return { text: bestText.slice(0, C.maxRowChars), count: bestCount, selector: used };
  }
  function sigOf(s) { s = String(s || ''); var h = 5381, i = s.length; while (i) { h = (h * 33) ^ s.charCodeAt(--i); } return ((h >>> 0).toString(36)) + ':' + s.length; }
  function scoreReportSelf() {
    try {
      var t = (((D.body && (D.body.innerText || D.body.textContent)) || '') + ''), tl = t.toLowerCase(), s = 0;
      var dates = (t.match(/\b[01]?\d[\/\-][0-3]?\d[\/\-]\d{2,4}\b/g) || []).length; s += Math.min(dates, 200) * 2;
      var cpts = (t.match(/\b\d{5}\b/g) || []).length; s += Math.min(cpts, 200) * 1.5;
      ['cpt', 'procedure', 'service date', 'dos', 'claim', 'charge', 'mrn', 'dob', 'patient'].forEach(function (k) { if (tl.indexOf(k) >= 0) s += 5; });
      return Math.round(s);
    } catch (e) { return 0; }
  }
  function fireClick(el) {
    try { el.scrollIntoView && el.scrollIntoView({ block: 'center' }); } catch (e) {}
    var V = (el.ownerDocument && el.ownerDocument.defaultView) || (typeof window !== 'undefined' ? window : null);
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) {
      try { var Ctor = (V && (tp.indexOf('pointer') === 0 ? V.PointerEvent : V.MouseEvent)) || (V && V.Event); el.dispatchEvent(new Ctor(tp, { bubbles: true, cancelable: true })); }
      catch (e) { try { el.dispatchEvent(new Event(tp, { bubbles: true })); } catch (e2) {} }
    });
    try { el.click && el.click(); } catch (e) {}
  }
  function fmtDate(el, ymd) {
    var t = lc(el.getAttribute && el.getAttribute('type'));
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(ymd || '')); if (!m) return ymd;
    if (t === 'date') return ymd; return m[2] + '/' + m[3] + '/' + m[1];
  }
  async function typeInto(el, val) {
    val = String(val == null ? '' : val);
    try { el.focus && el.focus(); } catch (e) {}
    var tg = (el.tagName || '').toUpperCase(), CE = el.isContentEditable;
    var V = (el.ownerDocument && el.ownerDocument.defaultView) || (typeof window !== 'undefined' ? window : null);
    function setNative(v) {
      if (CE) { try { el.textContent = v; } catch (e) {} return; }
      try { var proto = tg === 'TEXTAREA' ? V.HTMLTextAreaElement.prototype : V.HTMLInputElement.prototype; var d = Object.getOwnPropertyDescriptor(proto, 'value'); if (d && d.set) { d.set.call(el, v); return; } } catch (e) {}
      try { el.value = v; } catch (e) {}
    }
    function fire(type, ctor, init) { try { el.dispatchEvent(new V[ctor](type, init || { bubbles: true })); } catch (e) { try { el.dispatchEvent(new Event(type, { bubbles: true })); } catch (e2) {} } }
    setNative(''); fire('input', 'InputEvent', { bubbles: true, inputType: 'deleteContentBackward' });
    setNative(val);
    fire('keydown', 'KeyboardEvent', { bubbles: true });
    fire('input', 'InputEvent', { bubbles: true, inputType: 'insertText', data: val });
    fire('keyup', 'KeyboardEvent', { bubbles: true });
    fire('change', 'Event', { bubbles: true });
    var got = CE ? (el.textContent || '') : (el.value || '');
    var want = val.replace(/\s+/g, '');
    return (got.replace(/\s+/g, '').indexOf(want.slice(0, Math.min(want.length, 8))) >= 0) || got.length > 0;
  }

  if (op === 'read') {
    var ex = extractRows(), nx = findNext();
    return { ok: true, op: 'read', text: ex.text, count: ex.count, selector: ex.selector, sig: sigOf(ex.text), hasNext: !!nx, nextDesc: nx ? btnText(nx).slice(0, 40) : '', score: scoreReportSelf() };
  }
  if (op === 'next') {
    var n2 = findNext(); if (!n2) return { ok: true, op: 'next', clicked: false };
    var desc = btnText(n2).slice(0, 40); fireClick(n2);
    return { ok: true, op: 'next', clicked: true, nextDesc: desc };
  }
  if (op === 'fill') {
    var res = { ok: true, op: 'fill', acted: false, controls: {} };
    var cpt = (params.cpt && params.cpt[0]) || '', proc = params.procedureName || '';
    var f = null;
    if (cpt) { f = findField(C.cptFieldLabels); if (f) { res.controls.cpt = labelText(f).slice(0, 40) || '(cpt)'; if (await typeInto(f, cpt)) { res.filledCpt = true; res.acted = true; } } }
    if (proc) { var pf = findField(C.procFieldLabels); if (pf && pf !== f) { res.controls.proc = labelText(pf).slice(0, 40) || '(proc)'; if (await typeInto(pf, proc)) { res.filledProc = true; res.acted = true; } } }
    var df = findDateField(C.dateFromLabels), dt = findDateField(C.dateToLabels);
    if (df && dt && df === dt) {
      var ds = editableInputs().filter(function (el) { var t = lc(el.getAttribute && el.getAttribute('type')); var h = labelText(el); return t === 'date' || /date|dos|from|to|through|thru/.test(h); });
      if (ds.length >= 2) { df = ds[0]; dt = ds[1]; }
    }
    if (params.dateFrom && df) { res.controls.from = labelText(df).slice(0, 40); if (await typeInto(df, fmtDate(df, params.dateFrom))) { res.filledFrom = true; res.acted = true; } }
    if (params.dateTo && dt) { res.controls.to = labelText(dt).slice(0, 40); if (await typeInto(dt, fmtDate(dt, params.dateTo))) { res.filledTo = true; res.acted = true; } }
    var rb = findButton(C.runLabels);
    if (rb) { res.controls.run = btnText(rb).slice(0, 40); fireClick(rb); res.clickedRun = true; res.acted = true; } else { res.noRunButton = true; }
    return res;
  }
  return { ok: false, error: 'bad-op' };
}
/*MLS_ATHENA_DRIVE_END*/

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  // Tell the popup how we're authenticating: a saved API key, the live MLS login, or nothing yet.
  if (msg.type === 'mlsConnStatus') {
    (async () => {
      const c = await getCfg();
      if ((c.mlsKey || '').trim()) return sendResponse({ mode: 'key' });
      const tok = await getSessionToken();
      sendResponse({ mode: tok ? 'session' : 'none' });
    })();
    return true;
  }
  if (msg.type === 'mlsAssistGenerate') { callBackend('/api/assist/note', { transcript: msg.transcript }).then(sendResponse); return true; }
  if (msg.type === 'mlsAssistAgentStep') { callBackend('/api/assist/agent-step', { goal: msg.goal, pageText: msg.pageText, screenshot: msg.screenshot, history: msg.history }).then(sendResponse); return true; }
  if (msg.type === 'mlsAssistExtract') { callBackend('/api/assist/extract', { pageText: msg.pageText, url: msg.url }).then(sendResponse); return true; }
  // Pull the day's SCHEDULE from the EMR tab (Athena) → return its page text so MLS can
  // parse the appointments and pre-load today's patients. Reads every frame (Athena is iframe-based).
  
  /* === MLS provider extractor (schedule provider capture) === */
/* mlsProv — schedule provider extractor (worker side), inlined into background.js. */
var mlsProv = (function () {
  'use strict';


  var RE_TIME = /\b(\d{1,2}):(\d{2})\s*([ap]\.?\s?m\.?)?\b/i;
  var RE_TIME_G = /\b\d{1,2}:\d{2}\s*(?:[ap]\.?\s?m\.?)?\b/gi;
  var RE_CRED = /(?:^|[^A-Za-z])(MD|DO|NP|PA-?C?|APRN|FNP|DNP|AGNP|WHNP|PMHNP|RN|LPN|DPM|DDS|DMD|PHD|PSY\.?D|MBBS|CNM|CRNA|OD|LCSW|LPC)(?:[^A-Za-z]|$)/;
  var CRED_I = /^(md|do|np|pa|pac|aprn|fnp|dnp|agnp|whnp|pmhnp|rn|lpn|dpm|dds|dmd|phd|psyd|mbbs|cnm|crna|od|lcsw|lpc)$/;
  var RE_APPTWORD = /\bappointment/i;
  var RE_NAMECOMMA = /([A-Z][A-Za-z'’-]+)\s*,\s*([A-Z][A-Za-z'’-]+)/;
  var STOP = /^(am|pm|new|est|established|office|visit|tele|telehealth|video|phone|follow|followup|fu|consult|consultation|annual|physical|wellness|exam|sick|nurse|lab|labs|injection|inj|procedure|recheck|np|min|mins|minute|minutes|arrived|checkedin|checked|scheduled|confirmed|cancelled|canceled|noshow|no|show|room|status|reason|provider|patient|time|type|resource|rendering|department|dept|appt|appts|total|appointments)$/i;

  function S(x) { return x == null ? '' : String(x); }
  function clean(s) { return S(s).replace(/\s+/g, ' ').trim(); }

  function nameTokens(name) {
    return clean(name).toLowerCase().replace(/[^a-z' -]/g, ' ').split(/\s+/)
      .filter(function (t) { return t && t.length > 1 && !STOP.test(t) && !CRED_I.test(t); });
  }
  function hasTime(s) { return RE_TIME.test(S(s)); }
  function firstTime(s) { var m = S(s).match(RE_TIME_G); return m ? clean(m[0]) : ''; }

  function cleanProvider(s) {
    var t = clean(s);
    t = t.replace(/[•‣▪●>*\-–—]+\s*$/g, '');
    t = t.replace(/[-–—:|(]*\s*\d+\s*appointments?\b.*$/i, '');
    t = t.replace(/\b\d+\s*appointments?\b/i, '');
    t = t.replace(/\(\s*\d+\s*\)\s*$/, '');
    t = t.replace(/[\s,;:|–—-]+$/, '');
    t = t.replace(/\s*close\s*$/i, '');
    t = clean(t);
    return isProviderUiLabel(t) ? '' : t;
  }

  /* A provider candidate can come from either the DOM reader or the plain-text
     fallback. Keep one predicate for both paths so table chrome can never
     become the current provider (and then be stamped onto patient rows). */
  function isProviderUiLabel(s) {
    var t = clean(s).toLowerCase().replace(/[\s:|\-–—]+$/g, '').trim();
    return /^(?:(?:appointment|appt)\s+)?(?:date(?:\s*(?:\/|&|and)\s*time)?|time|type|status|duration|reason|patient(?:\s+(?:name|details?))?|provider(?:\s+name)?|rendering\s+provider|resource(?:\s+name)?|department(?:\s+name)?|schedule|scheduling|location|room)$/i.test(t);
  }

  /* Capacity cells share the same visual/time-row shape as patient visits.
     Normalize only labels that BEGIN with a capacity-state word, then require
     the remainder to contain descriptors/durations only. A real name such as
     "Block, John" therefore remains a patient. */
  function isCapacitySlotName(s) {
    var t = clean(s).toLowerCase().replace(/[\-–—_\/|]+/g, ' ').replace(/[()[\]{}:;,]+/g, ' ').replace(/\s+/g, ' ').trim();
    var head = /^(open|available|unavailable|block(?:ed)?|hold|reserved|lunch|break|admin(?:istrative)?|meeting|closed|buffer)\b/.exec(t);
    if (!head) return false;
    var rest = t.slice(head[0].length);
    rest = rest.replace(/\b\d{1,2}:\d{2}\s*(?:[ap]\.?m\.?)?\b/gi, ' ');
    rest = rest.replace(/\b\d+(?:\.\d+)?\s*(?:min(?:ute)?s?|hrs?|hours?)?\b/gi, ' ');
    rest = rest.replace(/\b(?:open|available|unavailable|block(?:ed)?|hold|reserved|lunch|break|admin(?:istrative)?|meeting|closed|buffer|slot|slots|time|appointment|appointments|appt|appts|capacity)\b/gi, ' ');
    return !clean(rest);
  }

  function looksLikeProviderHeader(line) {
    var t = clean(line);
    if (!t || t.length > 80) return false;
    if (hasTime(t)) return false;
    var hasCred = RE_CRED.test(t);
    var hasApptWord = RE_APPTWORD.test(t);
    var hasName = RE_NAMECOMMA.test(t) || /[A-Z][a-z]+[ _][A-Z][a-z]+/.test(t);
    if ((hasCred && hasName) || (hasApptWord && hasName)) return true;
    if (hasCred && RE_NAMECOMMA.test(t) && t.split(/\s+/).length <= 5) return true;
    return false;
  }

  function patientNameFromRow(line) {
    var t = clean(line);
    var mc = t.match(RE_NAMECOMMA);
    if (mc) return clean(mc[0]);
    var afterTime = t.replace(RE_TIME_G, ' ');
    var words = afterTime.split(/\s+/).filter(function (w) { return /[A-Za-z]/.test(w); });
    var picked = [];
    for (var i = 0; i < words.length && picked.length < 3; i++) {
      var w = words[i].replace(/[^A-Za-z'’-]/g, '');
      if (!w) continue;
      if (STOP.test(w) || CRED_I.test(w.toLowerCase())) { if (picked.length) break; else continue; }
      if (/^[A-Z]/.test(w)) picked.push(w); else if (picked.length) break;
    }
    return picked.join(' ');
  }

  function mlsExtractScheduleFromText(text) {
    var out = { appts: [], providers: [], diag: { strategy: 'text', lineCount: 0, headerCount: 0, apptCount: 0, providerCount: 0, credsSeen: [], providerNames: [] } };
    try {
      var raw = S(text);
      if (!raw.trim()) return out;
      var lines = raw.split(/\r?\n/).map(clean).filter(function (l) { return l.length; });
      out.diag.lineCount = lines.length;
      var current = '';
      var provSet = {}, provOrder = [], credSet = {};
      for (var i = 0; i < lines.length; i++) {
        var ln = lines[i];
        if (looksLikeProviderHeader(ln)) {
          var p = cleanProvider(ln);
          if (p) {
            current = p;
            if (!provSet[p.toLowerCase()]) { provSet[p.toLowerCase()] = 1; provOrder.push(p); }
            var cm = ln.match(RE_CRED); if (cm && cm[1]) credSet[cm[1].toUpperCase()] = 1;
            out.diag.headerCount++;
          }
          continue;
        }
        if (hasTime(ln)) {
          var nm = patientNameFromRow(ln);
          if (nm) out.appts.push({ time: firstTime(ln), name: nm, provider: current || '' });
        }
      }
      var withAppts = {};
      out.appts.forEach(function (a) { if (a.provider) withAppts[a.provider.toLowerCase()] = a.provider; });
      var provs = Object.keys(withAppts).length ? provOrder.filter(function (p) { return withAppts[p.toLowerCase()]; }) : provOrder;
      out.providers = provs;
      out.diag.apptCount = out.appts.length;
      out.diag.providerCount = provs.length;
      out.diag.providerNames = provs.slice(0, 20);
      out.diag.credsSeen = Object.keys(credSet);
    } catch (e) { out.diag.err = S(e && e.message || e).slice(0, 120); }
    return out;
  }

  function txt(el) { try { return clean(el.textContent); } catch (e) { return ''; } }

  /* Identity proof is row-scoped and label/attribute-gated. A bare date or
     number in row text is never a DOB/MRN. Conflicting explicit values clear
     that proof instead of selecting whichever value happened to render first. */
  function explicitRowIdentity(root) {
    var found = { dob: '', mrn: '', dobConflict: false, mrnConflict: false };
    function dobValue(value) {
      var raw = clean(value), m = /^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/.exec(raw);
      if (!m) { var iso = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(raw); if (iso) m = [iso[0], iso[2], iso[3], iso[1]]; }
      if (!m) return '';
      var y = +m[3], mo = +m[1], d = +m[2], now = new Date(), exact = new Date(Date.UTC(y, mo - 1, d));
      if (y < 1900 || exact.getUTCFullYear() !== y || exact.getUTCMonth() !== mo - 1 || exact.getUTCDate() !== d || exact.getTime() > now.getTime()) return '';
      return ('0' + mo).slice(-2) + '/' + ('0' + d).slice(-2) + '/' + y;
    }
    function mrnValue(value) {
      var v = clean(value);
      if (!v || v.length > 48 || !/[0-9]/.test(v) || !/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(v)) return '';
      if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(v) || /^\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{4}$/.test(v)) return '';
      return v;
    }
    function put(kind, value) {
      var v = kind === 'dob' ? dobValue(value) : mrnValue(value), conflict = kind + 'Conflict';
      if (!v || found[conflict]) return;
      if (found[kind] && found[kind].toLowerCase() !== v.toLowerCase()) { found[kind] = ''; found[conflict] = true; }
      else found[kind] = v;
    }
    function parseLabeled(value) {
      var s = clean(value);
      s.replace(/\b(?:DOB|Date\s+of\s+Birth|Birth\s+Date)\s*(?:is\s*)?[:#-]?\s*(\d{1,4}[\/\-.]\d{1,2}[\/\-.]\d{1,4})\b/gi, function (whole, v) { put('dob', v); return whole; });
      s.replace(/\b(?:MRN|Medical\s+Record(?:\s+(?:Number|No\.?|#|ID))?)\s*(?:is\s*)?[:#-]?\s*([A-Za-z0-9][A-Za-z0-9._-]{2,47})\b/gi, function (whole, v) { put('mrn', v); return whole; });
    }
    if (!root) return found;
    var nodes = [root];
    try { nodes = nodes.concat([].slice.call(root.querySelectorAll('[data-patient-dob],[data-dob],[data-date-of-birth],[data-birth-date],[data-patient-mrn],[data-mrn],[data-medical-record-number],[aria-label],[data-testid]')).slice(0, 80)); } catch (e0) {}
    nodes.forEach(function (node) {
      function attr(name) { try { return node.getAttribute && node.getAttribute(name); } catch (e1) { return ''; } }
      ['data-patient-dob', 'data-dob', 'data-date-of-birth', 'data-birth-date'].forEach(function (name) { var v = attr(name); if (v != null && clean(v)) put('dob', v); });
      ['data-patient-mrn', 'data-mrn', 'data-medical-record-number'].forEach(function (name) { var v = attr(name); if (v != null && clean(v)) put('mrn', v); });
      var aria = attr('aria-label'); if (aria) parseLabeled(aria);
      var testId = clean(attr('data-testid'));
      if (/(?:^|[-_])(patient[-_]?)?(?:dob|date[-_]?of[-_]?birth|birth[-_]?date)$/i.test(testId)) put('dob', txt(node) || attr('value'));
      if (/(?:^|[-_])(patient[-_]?)?(?:mrn|medical[-_]?record[-_]?(?:number|id))$/i.test(testId)) put('mrn', txt(node) || attr('value'));
    });
    parseLabeled(txt(root));
    return found;
  }

  function mlsExtractScheduleFromDom(doc) {
    var out = { appts: [], providers: [], diag: { strategy: 'dom', tables: 0, rowsScanned: 0, apptCount: 0, providerCount: 0, via: '', providerNames: [], credsSeen: [] } };
    try {
      if (!doc || !doc.querySelectorAll) return out;
      /* Non-PHI structure diagnostics for athenaOne's legacy day grid. These
         make it possible to distinguish one scoped provider schedule from a
         generic/mixed clinic view without exposing appointment content. */
      try {
        out.diag.legacyContainers = doc.querySelectorAll('[class~="appointments-container"]').length;
        out.diag.legacyFilledRows = doc.querySelectorAll('[class~="filled-appointment-row"]').length;
        out.diag.providerHeaderShapes = [].slice.call(doc.querySelectorAll('div,span,h1,h2,h3,h4,th,td'))
          .filter(function (el) {
            var t = txt(el);
            return t && t.length <= 90 && looksLikeProviderHeader(t) && el.querySelectorAll('*').length <= 6;
          }).slice(0, 12).map(function (el) {
            return {
              tag: String(el.tagName || '').toLowerCase(),
              cls: String(el.className || '').replace(/\s+/g, ' ').trim().slice(0, 140),
              parentTag: String(el.parentElement && el.parentElement.tagName || '').toLowerCase(),
              parentCls: String(el.parentElement && el.parentElement.className || '').replace(/\s+/g, ' ').trim().slice(0, 140)
            };
          });
      } catch (eShape) {}
      var provSet = {}, provOrder = [], credSet = {};
      function noteProv(p) {
        p = cleanProvider(p);
        if (p && /[A-Za-z]/.test(p) && p.length <= 60 && !provSet[p.toLowerCase()]) { provSet[p.toLowerCase()] = 1; provOrder.push(p); }
        if (p) { var cm = p.match(RE_CRED); if (cm && cm[1]) credSet[cm[1].toUpperCase()] = 1; }
        return p;
      }
      function sourceIds(row, providerCell) {
        var outIds = { appointmentId: '', providerId: '' };
        function attr(nodes, names) {
          for (var ni = 0; ni < nodes.length; ni++) for (var ai = 0; ai < names.length; ai++) {
            try { var v = nodes[ni].getAttribute && nodes[ni].getAttribute(names[ai]); if (v != null && String(v).trim()) return String(v).trim(); } catch (e0) {}
          }
          return '';
        }
        var rowNodes = [row], providerNodes = providerCell ? [providerCell] : [];
        try { rowNodes = rowNodes.concat([].slice.call(row.querySelectorAll('[data-appointment-id],[data-appt-id],[data-appointmentid],[appointmentid],[data-provider-id],[data-rendering-provider-id],[data-resource-id],a[href]')).slice(0, 40)); } catch (e1) {}
        try { if (providerCell) providerNodes = providerNodes.concat([].slice.call(providerCell.querySelectorAll('[data-provider-id],[data-rendering-provider-id],[data-resource-id],[providerid],a[href]')).slice(0, 20)); } catch (e2) {}
        outIds.appointmentId = attr(rowNodes, ['data-appointment-id', 'data-appt-id', 'data-appointmentid', 'appointmentid']);
        outIds.providerId = attr(providerNodes.concat(rowNodes), ['data-provider-id', 'data-rendering-provider-id', 'data-resource-id', 'providerid']);
        for (var li = 0; li < rowNodes.length && (!outIds.appointmentId || !outIds.providerId); li++) {
          var href = ''; try { href = rowNodes[li].getAttribute && rowNodes[li].getAttribute('href') || ''; } catch (e3) {}
          if (!href) continue;
          var am = String(href).match(/[?&#/](?:appointmentid|appointment_id|appointment|apptid)[=/:]([a-z0-9_-]{2,})/i);
          var pm = String(href).match(/[?&#/](?:providerid|provider_id|provider|resourceid)[=/:]([a-z0-9_-]{2,})/i);
          if (!outIds.appointmentId && am) outIds.appointmentId = am[1];
          if (!outIds.providerId && pm) outIds.providerId = pm[1];
        }
        return outIds;
      }

      /* Legacy athenaOne renders one <ul.appointments-container> per scoped
         provider list (and can duplicate that list for alternate sort modes).
         Treat the page as single-provider ONLY when every non-empty container
         has exactly one provider header, every appointment row is contained by
         such a header, and all container headers normalize to the same name. */
      try {
        var legacyLists = [].slice.call(doc.querySelectorAll('[class~="appointments-container"]'));
        var legacyNames = {}, legacyNameOrder = [], legacyRows = 0, legacyBoundRows = 0, legacySafe = !!legacyLists.length;
        legacyLists.forEach(function (list) {
          var rows = [].slice.call(list.querySelectorAll('[class~="filled-appointment-row"]'));
          if (!rows.length) return;
          legacyRows += rows.length;
          var local = {}, localOrder = [];
          [].slice.call(list.querySelectorAll('[class~="appointment-header2"]')).forEach(function (header) {
            var raw = txt(header), p = looksLikeProviderHeader(raw) ? cleanProvider(raw) : '';
            if (p && !local[p.toLowerCase()]) { local[p.toLowerCase()] = 1; localOrder.push(p); }
          });
          if (localOrder.length !== 1) { legacySafe = false; return; }
          var name = localOrder[0], nk = name.toLowerCase();
          if (!legacyNames[nk]) { legacyNames[nk] = 1; legacyNameOrder.push(name); }
          legacyBoundRows += rows.length;
        });
        if (legacySafe && legacyRows > 0 && legacyBoundRows === legacyRows && legacyNameOrder.length === 1) {
          out.diag.singleProviderScope = true;
          out.diag.singleProviderName = noteProv(legacyNameOrder[0]);
          out.diag.legacyScopeContainers = legacyLists.length;
        }
      } catch (eLegacyScope) {}

      var grids = [].slice.call(doc.querySelectorAll('table, [role="grid"], [role="table"]'));
      out.diag.tables = grids.length;
      for (var g = 0; g < grids.length && !out.appts.length; g++) {
        var grid = grids[g];
        var headerCells = [].slice.call(grid.querySelectorAll('thead th, [role="columnheader"]'));
        var rows = [].slice.call(grid.querySelectorAll('tbody tr, [role="row"]'));
        if (!rows.length) rows = [].slice.call(grid.querySelectorAll('tr'));
        if (!headerCells.length && rows.length) headerCells = [].slice.call(rows[0].querySelectorAll('th, td, [role="columnheader"], [role="cell"], [role="gridcell"]'));
        var provIdx = -1, nameIdx = -1;
        headerCells.forEach(function (h, idx) {
          var ht = txt(h).toLowerCase();
          if (provIdx < 0 && /(provider|rendering|resource|clinician|scheduling provider|doctor|seen by|with)/.test(ht) && !/patient/.test(ht)) provIdx = idx;
          if (nameIdx < 0 && /(patient|name)/.test(ht)) nameIdx = idx;
        });
        if (provIdx < 0) continue;
        rows.forEach(function (r) {
          out.diag.rowsScanned++;
          var cells = [].slice.call(r.querySelectorAll('th, td, [role="cell"], [role="gridcell"]'));
          if (!cells.length) return;
          var rowText = txt(r);
          if (!hasTime(rowText)) return;
          var providerCell = cells[provIdx] || null;
          var prov = providerCell ? noteProv(txt(providerCell)) : '';
          var nm = nameIdx >= 0 && cells[nameIdx] ? txt(cells[nameIdx]) : patientNameFromRow(rowText);
          if (nm) {
            var ids = sourceIds(r, providerCell);
            var identity = explicitRowIdentity(r);
            out.appts.push({ time: firstTime(rowText), name: clean(nm), provider: prov || '', appointmentId: ids.appointmentId || '', providerId: ids.providerId || '', dob: identity.dob || '', mrn: identity.mrn || '' });
          }
        });
        if (out.appts.length) out.diag.via = 'table-column';
      }

      if (!out.appts.length) {
        var all = [].slice.call(doc.querySelectorAll('div,li,tr,section,article,a,span,p'));
        var seq = [];
        all.forEach(function (el) {
          var own = txt(el);
          if (!own || own.length > 400) return;
          if (own.length <= 80 && looksLikeProviderHeader(own) && el.querySelectorAll('*').length <= 6) {
            seq.push({ kind: 'prov', el: el, text: own });
          } else if (hasTime(own) && own.length < 300 && patientNameFromRow(own)) {
            var childHasBoth = false;
            for (var c = 0; c < el.children.length; c++) {
              var ct = txt(el.children[c]);
              if (hasTime(ct) && patientNameFromRow(ct)) { childHasBoth = true; break; }
            }
            if (!childHasBoth) seq.push({ kind: 'appt', el: el, text: own });
          }
        });
        var cur = '';
        seq.forEach(function (n) {
          out.diag.rowsScanned++;
          if (n.kind === 'prov') { cur = noteProv(n.text); }
          else {
            var inRow = '';
            if (RE_CRED.test(n.text)) {
              var mNme = n.text.match(/([A-Z][A-Za-z'’-]+\s*,\s*[A-Z][A-Za-z'’-]+\s*(?:MD|DO|NP|PA-?C?|APRN|FNP|DNP|RN|DPM|DDS|DMD|PHD|MBBS|OD)\b)/);
              if (mNme) inRow = noteProv(mNme[1]);
            }
            var nm2 = patientNameFromRow(n.text);
            if (nm2) {
              var ids2 = sourceIds(n.el, null);
              var identity2 = explicitRowIdentity(n.el);
              out.appts.push({ time: firstTime(n.text), name: nm2, provider: inRow || cur || '', appointmentId: ids2.appointmentId || '', providerId: ids2.providerId || '', dob: identity2.dob || '', mrn: identity2.mrn || '' });
            }
          }
        });
        if (out.appts.length && !out.diag.via) out.diag.via = 'grouped-dom';
      }

      var used = {};
      out.appts.forEach(function (a) { if (a.provider) used[a.provider.toLowerCase()] = a.provider; });
      out.providers = Object.keys(used).length ? provOrder.filter(function (p) { return used[p.toLowerCase()]; }) : provOrder;
      out.diag.apptCount = out.appts.length;
      out.diag.providerCount = out.providers.length;
      out.diag.providerNames = out.providers.slice(0, 20);
      out.diag.credsSeen = Object.keys(credSet);
      out.diag.appointmentIdCount = out.appts.filter(function (a) { return !!clean(a && a.appointmentId); }).length;
      out.diag.providerIdCount = out.appts.filter(function (a) { return !!clean(a && a.providerId); }).length;
    } catch (e) { out.diag.err = S(e && e.message || e).slice(0, 120); }
    return out;
  }

  function mlsMergeSchedule(domRes, textRes) {
    var dom = domRes || { appts: [], providers: [], diag: {} };
    var text = textRes || { appts: [], providers: [], diag: {} };
    function filterSource(src) {
      var kept = [], slots = 0, empty = 0, invalid = 0;
      (src && src.appts || []).forEach(function (a) {
        var n = clean(a && a.name);
        if (!n) { empty++; return; }
        if (isCapacitySlotName(n)) { slots++; return; }
        /* Merge only validated patient rows. Schedule chrome/reason fragments
           can also contain a time; require two surviving name tokens and no
           provider credential. This rejects false rows such as "Spine,No". */
        var nt = nameTokens(n);
        if (!hasTime(a && a.time) || nt.length < 2 || isProviderUiLabel(n) || RE_CRED.test(n)) { invalid++; return; }
        kept.push(a);
      });
      return { appts: kept, slotRowsRemoved: slots, emptyRowsRemoved: empty, invalidRowsRemoved: invalid };
    }
    /* Athena virtualizes schedule rows. A provider-rich DOM result can be a
       partial viewport, so union both independently validated readers instead
       of discarding the alternate whenever DOM found one provider. */
    var domFiltered = filterSource(dom), textFiltered = filterSource(text);
    var primary = domFiltered.appts.length >= textFiltered.appts.length ? dom : text;
    var other = primary === dom ? text : dom;
    var seen = {}, providers = [];
    (primary.providers || []).concat(other.providers || []).forEach(function (p) {
      var cp = cleanProvider(p), k = cp.toLowerCase();
      if (cp && !seen[k]) { seen[k] = 1; providers.push(cp); }
    });
    var byRow = {}, rowsByBase = {}, appts = [], mergedFields = 0;
    function copyRow(a) { var b = {}; for (var k in (a || {})) { if (Object.prototype.hasOwnProperty.call(a, k)) b[k] = a[k]; } return b; }
    function rowBase(a) {
      return clean(a && a.time).toLowerCase() + '|' + clean(a && a.name).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
    }
    function rowProviderKey(a) {
      return cleanProvider(a && a.provider).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
    }
    function rowProofKey(a) {
      var appointmentId = clean(a && (a.appointmentId || a.appointment_id || a.athenaAppointmentId || a.athena_appointment_id));
      if (appointmentId) return 'appt:' + appointmentId.toLowerCase();
      var mrn = clean(a && (a.mrn || a.athenaId || a.athena_id));
      if (mrn) return 'mrn:' + mrn.toLowerCase().replace(/[^a-z0-9]/g, '');
      var dob = clean(a && a.dob);
      return dob ? ('dob:' + dob.replace(/[^0-9]/g, '')) : '';
    }
    function mergeRowFields(prior, a, lane) {
      ['provider', 'providerId', 'provider_id', 'athenaProviderId', 'athena_provider_id', 'appointmentId', 'appointment_id', 'athenaAppointmentId', 'athena_appointment_id', 'date', 'appt_date', 'reason'].forEach(function (field) {
        if (!clean(prior[field]) && clean(a && a[field])) { prior[field] = a[field]; mergedFields++; }
      });
      ['dob', 'mrn'].forEach(function (field) {
        var incoming = clean(a && (field === 'mrn' ? (a.mrn || a.athenaId || a.athena_id) : a.dob));
        if (!incoming) return;
        if (prior[field + 'Conflict']) return;
        if (clean(prior[field]) && clean(prior[field]).toLowerCase() !== incoming.toLowerCase()) { prior[field] = ''; prior[field + 'Conflict'] = true; }
        else if (!clean(prior[field])) { prior[field] = incoming; mergedFields++; }
      });
      if (prior.__lane !== lane) prior.__lane = 'both';
    }
    function addRows(rows, lane) {
      (rows || []).forEach(function (a) {
        var base = rowBase(a), providerKey = rowProviderKey(a), proofKey = rowProofKey(a), key = base + '|' + providerKey + '|' + proofKey;
        if (!base || base === '|') return;
        var bucket = rowsByBase[base] || (rowsByBase[base] = []);
        var prior = byRow[key];
        /* A proofless alternate lane may enrich one uniquely identified row
           with the same provider. Once two exact DOB/MRN/appointment variants
           exist, bucket.length prevents any name-only cross-binding. */
        if (!prior && bucket.length === 1 && (!proofKey || !rowProofKey(bucket[0])) &&
            (!providerKey || !rowProviderKey(bucket[0]) || providerKey === rowProviderKey(bucket[0]))) prior = bucket[0];
        /* A providerless alternate parser may enrich one unambiguous structured
           row, but it must never collapse the same patient/time booked under
           two different providers. Conversely, promote one lone providerless
           row when the other lane supplies its provider. */
        if (!prior && !providerKey && bucket.length === 1 && (!proofKey || !rowProofKey(bucket[0]) || proofKey === rowProofKey(bucket[0]))) prior = bucket[0];
        if (!prior && providerKey && bucket.length === 1 && !rowProviderKey(bucket[0]) && (!proofKey || !rowProofKey(bucket[0]) || proofKey === rowProofKey(bucket[0]))) {
          prior = bucket[0];
          delete byRow[base + '||' + rowProofKey(bucket[0])];
          prior.provider = a.provider;
          byRow[key] = prior;
        }
        /* A flat-text row cannot choose between multiple exact same-display
           patients already captured from the DOM. Treat it as an ambiguous
           alternate copy, not a third name-only appointment. */
        if (!prior && lane === 'text' && !proofKey && bucket.length > 1 && bucket.every(function (row) { return !!rowProofKey(row); })) return;
        if (!prior) {
          prior = copyRow(a); prior.__lane = lane; byRow[key] = prior;
          bucket.push(prior); appts.push(prior); return;
        }
        mergeRowFields(prior, a, lane);
      });
    }
    /* Structured fields win conflicts; validated text rows are additive. */
    addRows(domFiltered.appts, 'dom');
    addRows(textFiltered.appts, 'text');
    /* One recognized name is NOT proof that the page is single-provider: a
       partially parsed multi-provider grid has that same shape. Only an
       explicit parser scope assertion may fill blanks. Current readers make no
       such assertion, so unattributed rows stay honest and the app may apply
       its separately selected provider scope downstream. */
    function explicitScope(src) {
      var d = src && src.diag || {};
      if (d.singleProviderScope !== true) return '';
      return cleanProvider(d.singleProviderName || (d.providerNames && d.providerNames.length === 1 ? d.providerNames[0] : ''));
    }
    var ds = explicitScope(dom), ts = explicitScope(text);
    var scopeProvider = ds && ts && ds.toLowerCase() !== ts.toLowerCase() ? '' : (ds || ts);
    var soleProviderFilled = 0;
    if (scopeProvider && providers.length === 1 && providers[0].toLowerCase() === scopeProvider.toLowerCase()
        && appts.every(function (a) { return !clean(a && a.provider) || clean(a.provider).toLowerCase() === scopeProvider.toLowerCase(); })) {
      appts = appts.map(function (a) {
        if (!a || clean(a.provider)) return a;
        var b = {}; for (var ak in a) { if (Object.prototype.hasOwnProperty.call(a, ak)) b[ak] = a[ak]; }
        b.provider = scopeProvider; soleProviderFilled++; return b;
      });
    }
    /* v2.9.9 DEDUP (live: athenaOne renders the dashboard day list TWICE —
       sort-by-department + sort-by-time copies — so a 20-appt day arrived as 50
       rows incl. OPEN slots). Pass 1: exact provider|time|name dupes. Pass 2: a
       provider-less row whose time|name twin HAS a provider is the hidden-copy
       shadow — drop it (keeps b238's genuinely provider-less appts, which have
       no attributed twin). Count removals in diag — never silent. */
    var dropped = 0;
    try {
      var k1 = {}, p1 = [];
      appts.forEach(function (a) {
        var k = (a.provider || '') + '|' + (a.time || '') + '|' + String(a.name || '').toLowerCase() + '|' + rowProofKey(a);
        if (k1[k]) { dropped++; return; } k1[k] = 1; p1.push(a);
      });
      var hasProv = {};
      p1.forEach(function (a) { if (a.provider) hasProv[(a.time || '') + '|' + String(a.name || '').toLowerCase() + '|' + rowProofKey(a)] = 1; });
      var p2 = p1.filter(function (a) { if (!a.provider && hasProv[(a.time || '') + '|' + String(a.name || '').toLowerCase() + '|' + rowProofKey(a)]) { dropped++; return false; } return true; });
      appts = p2;
    } catch (eD) {}
    appts.forEach(function (a) { try { delete a.__lane; } catch (e) {} });
    return {
      appts: appts,
      providers: providers,
      providerDiag: {
        source: 'merged',
        primaryByCount: primary === dom ? 'dom' : 'text',
        domValidRows: domFiltered.appts.length,
        textValidRows: textFiltered.appts.length,
        mergedRows: appts.length,
        mergedFields: mergedFields,
        dupRowsRemoved: dropped,
        slotRowsRemoved: domFiltered.slotRowsRemoved + textFiltered.slotRowsRemoved,
        domSlotRowsRemoved: domFiltered.slotRowsRemoved,
        textSlotRowsRemoved: textFiltered.slotRowsRemoved,
        emptyRowsRemoved: domFiltered.emptyRowsRemoved + textFiltered.emptyRowsRemoved,
        invalidRowsRemoved: domFiltered.invalidRowsRemoved + textFiltered.invalidRowsRemoved,
        domInvalidRowsRemoved: domFiltered.invalidRowsRemoved,
        textInvalidRowsRemoved: textFiltered.invalidRowsRemoved,
        soleProviderFilled: soleProviderFilled,
        providerFillScope: scopeProvider || '',
        dom: dom.diag || {},
        text: text.diag || {},
        providerCount: providers.length,
        providerNames: providers.slice(0, 20)
      }
    };
  }
  return { fromText: mlsExtractScheduleFromText, fromDom: mlsExtractScheduleFromDom, merge: mlsMergeSchedule };
})();

  /* A schedule surface must be proven by schedule-specific structure. Generic
     subsection headings and arbitrary clock strings also occur throughout
     patient charts/messages and are not sufficient. This function is injected
     per frame both before navigation and immediately before scraping. */
  function mlsAthenaScheduleSurfaceFn() {
    try {
      var d = document, u = String(location.href || '').toLowerCase(), p = String(location.pathname || '').toLowerCase();
      if (/stm\.esp|\/coordinator\/|messaging|letters/.test(p)) return { verified: false, grid: false, via: 'excluded-frame' };
      if (/schedulenavclose|navclose|close\.esp/.test(u)) return { verified: false, grid: false, via: 'nav-plumbing' };
      var text = String(d.body && d.body.innerText || '').slice(0, 18000), tl = text.toLowerCase();
      var structure = !!d.querySelector('[class*="PatientAppointment_appointment-container"], [class*="ScheduleColumn_schedule-column"], [data-testid*="schedule-grid" i], [aria-label*="schedule grid" i], [class~="appointments-container"], [class~="filled-appointment-row"]');
      var legacyHeading = !!d.querySelector('h1.fe_c_heading--subsection');
      var appointmentEls = [].slice.call(d.querySelectorAll('[class*="appointment" i], [data-testid*="appointment" i], [aria-label*="appointment" i]'));
      var appointmentNodes = appointmentEls.length, appointmentClasses = [];
      appointmentEls.slice(0, 80).forEach(function (e) { var c = String(e.className || '').replace(/\s+/g, ' ').trim(); if (c && appointmentClasses.indexOf(c) < 0) appointmentClasses.push(c.slice(0, 180)); });
      var headings = [].slice.call(d.querySelectorAll('h1,h2,[role="heading"],[class*="heading"][class*="date"], [class*="date"][role="heading"]'));
      var dateText = '';
      for (var hi = 0; hi < headings.length && hi < 120; hi++) {
        var ht = String(headings[hi].textContent || '').replace(/\s+/g, ' ').trim();
        if (/^(?:(?:sun|mon|tues|wednes|thurs|fri|satur)day,?\s+)?(?:january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2},?\s+20\d\d$/i.test(ht)
            || /^(?:(?:sun|mon|tue|wed|thu|fri|sat)[a-z]*,?\s+)?(?:0?[1-9]|1[0-2])\/(?:0?[1-9]|[12]\d|3[01])\/20\d\d$/i.test(ht)) { dateText = ht; break; }
      }
      var table = false, grids = [].slice.call(d.querySelectorAll('table,[role="grid"],[role="table"]'));
      for (var gi = 0; gi < grids.length && !table; gi++) {
        var hdr = [].slice.call(grids[gi].querySelectorAll('thead th,[role="columnheader"],th')).map(function (e) { return String(e.textContent || '').replace(/\s+/g, ' ').trim(); }).join(' ').toLowerCase();
        if (/\bpatient(?:\s+name)?\b/.test(hdr) && /\b(?:time|provider|resource|appointment|appt)\b/.test(hdr)) table = true;
      }
      var scheduleUrl = /schedul|calendar|booking|frontoffice|viewdepartment|dashboard/.test(u);
      var urlHint = scheduleUrl || /appointment/.test(u);
      var scheduleWords = /\b(?:appointments?|schedule|scheduling|provider schedule|day sheet)\b/.test(tl);
      var empty = /\b(?:no appointments?|nothing scheduled|no patients? scheduled|no visits? scheduled)\b/.test(tl);
      var providerContext = /\b(?:provider|resource|clinician|doctor)\b/.test(tl);
      var timeCount = (text.match(/\b\d{1,2}:\d{2}\s*(?:a\.?m\.?|p\.?m\.?)\b/gi) || []).length;
      var verified = structure || (table && (scheduleUrl || (!!dateText && scheduleWords)))
        || (!!dateText && scheduleUrl && scheduleWords && (timeCount > 0 || empty || providerContext));
      var via = structure ? 'schedule-structure' : (table && (scheduleUrl || (!!dateText && scheduleWords))) ? 'schedule-table'
        : verified ? (empty ? 'dated-empty-schedule' : 'dated-schedule') : 'unverified';
      return { verified: !!verified, grid: !!verified, via: via, dateHeader: dateText.slice(0, 60), timeCount: timeCount, table: !!table, structure: !!structure, legacyHeading: !!legacyHeading, appointmentNodes: Math.min(appointmentNodes, 999), appointmentClasses: appointmentClasses.slice(0, 8), urlHint: !!urlHint, scheduleWords: !!scheduleWords, empty: !!empty, providerContext: !!providerContext };
    } catch (e) { return { verified: false, grid: false, via: 'probe-error', error: String(e && e.message || e).slice(0, 80) }; }
  }

  /* v1.47 AUTO-NAVIGATE (athenaOne-aware, two-step): when no schedule grid is showing,
     load the day view before scraping. READ-ONLY navigation: a hard deny-list blocks any
     write/sign/bill/book/reschedule control; only whitelisted schedule nav labels (or
     schedule-ish hrefs) are clicked. On athenaOne the top-nav "Calendar" is a menu-opener,
     so this (a) tries a direct schedule link/tab, else (b) clicks the Calendar menu-opener
     and then, polling this frame, clicks the schedule sub-item (e.g. "Today's Appointments").
     Runs per-frame via allFrames:true, so the frame that renders the submenu handles step 2.
     All label lists + timing are config-tunable via mls-assist-config.json's `nav` block. */
  async function mlsAthenaGotoSchedule(NAV, requestGuard){
    try{
      var guarded=!!(requestGuard&&requestGuard.token&&Number(requestGuard.deadline));
      var guard=Object.freeze({token:String(requestGuard&&requestGuard.token||''),deadline:Number(requestGuard&&requestGuard.deadline||0)});
      function actionAllowed(){return !guarded||(!!guard.token&&Number.isFinite(guard.deadline)&&Date.now()<guard.deadline);}
      function deadlineResult(did){return {clicked:false,did:did||{},reason:'request-deadline-exceeded'};}
      if(!actionAllowed())return deadlineResult({});
      var sleep=function(ms){return new Promise(function(r){setTimeout(r,ms);});};
      var cl=function(x){return String(x==null?'':x).replace(/\s+/g,' ').trim();};
      var DENY=/save|sign|bill|charge|payment|checkout|delete|remove|cancel|submit|logout|log out|new appointment|book|create|reschedul|add\b|close|back|return/i;
      var OPENER=(NAV&&NAV.openerReSource)?new RegExp(NAV.openerReSource):/OpenMenu\(\{\s*"MENUNAME":\s*"calendar"/;
      var DIRECT=(NAV&&NAV.directLabels)||['calendar','schedule','scheduling','day sheet','front office'];
      var SUB=(NAV&&NAV.subLabels)||["today's appointments","view calendar","provider schedule","daily schedule","today's schedule","staff calendar","department calendar",'schedule','appointments'];
      var HREF=(NAV&&NAV.hrefReSource)?new RegExp(NAV.hrefReSource,'i'):/schedul|calendar|frontoffice|daysheet/i;
      var maxPolls=(NAV&&NAV.subPolls)||6, pollMs=(NAV&&NAV.subPollMs)||400;
      var did={};
      function vis(e){var r;try{r=e.getBoundingClientRect();}catch(_e){return false;}return !!(r&&r.width>0&&r.height>0);}
      function oc(e){try{return e.getAttribute('onclick')||'';}catch(_e){return '';}}
      var els=[].slice.call(document.querySelectorAll('a,button,div,li,span,[role="tab"],[role="menuitem"],[onclick]'));
      // STEP 1a: a real (non-menu) direct schedule link/tab in this frame
      var directClicked=false;
      for(var i=0;i<els.length;i++){if(!actionAllowed())return deadlineResult(did);var e=els[i];var t=cl(e.textContent).toLowerCase();if(!t||t.length>28||DENY.test(t))continue;var href='';try{href=e.getAttribute('href')||'';}catch(_e){}var lm=(DIRECT.indexOf(t)>=0 && !/OpenMenu/.test(oc(e)));/* v2.9.15: never follow athena's schedulenavclose/nav-close plumbing merely because its URL contains "schedule". Require a schedule-shaped visible label as well as a safe href. */var hm=!!href&&HREF.test(href)&&!/schedulenavclose|navclose|close(?:\.esp)?/i.test(href)&&/(?:schedule|scheduling|calendar|appointments?|day sheet|front office)/i.test(t);if((lm||hm)&&vis(e)){if(!actionAllowed())return deadlineResult(did);e.click();directClicked=true;did.direct=t;break;}}
      // STEP 1b: else click the calendar menu-opener (athenaOne)
      if(!directClicked){
        for(var j=0;j<els.length;j++){if(!actionAllowed())return deadlineResult(did);var e2=els[j];if(OPENER.test(oc(e2))&&vis(e2)){if(!actionAllowed())return deadlineResult(did);e2.click();did.opener=cl(e2.textContent).slice(0,20);break;}}
      }
      // STEP 2: poll this frame for the schedule sub-item (rendered after the opener click, possibly by another frame's instance)
      if(!directClicked){
        for(var pp=0;pp<maxPolls;pp++){
          if(!actionAllowed())return deadlineResult(did);
          await sleep(Math.min(pollMs,guarded?Math.max(0,guard.deadline-Date.now()):pollMs));
          if(!actionAllowed())return deadlineResult(did);
          var cand=null, e3s=[].slice.call(document.querySelectorAll('a,div,li,span,td,[onclick]'));
          for(var k=0;k<e3s.length;k++){var e3=e3s[k];var t3=cl(e3.textContent).toLowerCase();if(!t3||t3.length>30||e3.children.length>1||DENY.test(t3))continue;var idx=SUB.indexOf(t3);if(idx>=0&&vis(e3)){ if(!cand||idx<cand.idx)cand={el:e3,idx:idx,t:t3}; }}
          if(cand){if(!actionAllowed())return deadlineResult(did);cand.el.click();did.sub=cand.t;break;}
        }
      }
      return { clicked: !!(directClicked||did.sub), did: did };
    }catch(e){ return {clicked:false,err:String(e&&e.message||e).slice(0,60)}; }
  }

  /* ---- v1.51: hands-free schedule DATE navigation (read-only nav) ---- */
  if (msg.type === 'mlsAppGotoDateRequest') {
    const __gotoStartedAt = Date.now();
    const __gotoRequestId = String(msg.requestId || msg.id || ('mlsgoto-' + __gotoStartedAt.toString(36) + '-' + Math.random().toString(36).slice(2, 9))).slice(0, 100);
    const __gotoCallerDeadline = Number(msg.deadlineAt || 0);
    let __gotoDeadlineAt = __gotoStartedAt + (msg.probe ? 4500 : 57000);
    if (Number.isFinite(__gotoCallerDeadline) && __gotoCallerDeadline > 0) __gotoDeadlineAt = Math.min(__gotoDeadlineAt, __gotoCallerDeadline);
    const __gotoGuard = Object.freeze({ token: __gotoRequestId, deadline: __gotoDeadlineAt });
    const __gotoRawRespond = sendResponse;
    let __gotoResponded = false, __gotoTimer = null, __gotoQpClaimed = false;
    function __gotoLeft() { return Math.max(0, __gotoGuard.deadline - Date.now()); }
    function __gotoCleanup(reason, immediate) {
      function start() {
        if (!__gotoQpClaimed || self.__mlsDayScheduleQpOwner !== __gotoGuard.token) return;
        self.__mlsDayScheduleQpOwner = '';
        try {
          if (!self.__mlsQpRelease) return;
          var release = Promise.resolve(self.__mlsQpRelease(reason || 'goto-date-terminal')).catch(function () {});
          Promise.race([release, mlsSleepW(5000)]).catch(function () {});
        } catch (e) {}
      }
      if (immediate) start(); else setTimeout(start, 0);
    }
    function __gotoRespond(payload) {
      if (__gotoResponded) return false;
      __gotoResponded = true;
      if (__gotoTimer != null) { try { clearTimeout(__gotoTimer); } catch (e) {} }
      if (Date.now() >= __gotoGuard.deadline && !/deadline-exceeded/.test(String(payload && payload.reason || ''))) {
        payload = { ok: false, supported: true, reason: 'goto-date-deadline-exceeded', error: 'Date navigation returned after its immutable request deadline. The late result was discarded.' };
      }
      /* A successful date nav intentionally hands the visible Athena lease to
         the immediately-following schedule/history stage. Failures/timeouts
         detach cleanup; they never hold this response open. */
      if (payload && payload.ok === true) { if (self.__mlsDayScheduleQpOwner === __gotoGuard.token) self.__mlsDayScheduleQpOwner = ''; }
      else __gotoCleanup('goto-date-terminal', false);
      __gotoRawRespond(Object.assign({}, payload || {}, { id: __gotoRequestId, requestId: __gotoRequestId, deadlineAt: __gotoGuard.deadline }));
      return true;
    }
    function __gotoDeadline(stage) {
      return __gotoRespond({ ok: false, supported: true, reason: 'goto-date-deadline-exceeded', error: 'Date navigation reached its immutable request deadline during ' + (stage || 'the request') + '. No late retry was dispatched.' });
    }
    async function __gotoSettle(promise, ceilingMs, stage) {
      var left = Math.min(__gotoLeft(), Math.max(0, Number(ceilingMs == null ? __gotoLeft() : ceilingMs)));
      if (!left || __gotoResponded) return { timeout: true, stage: stage || '' };
      var settled = await Promise.race([
        Promise.resolve(promise).then(function (value) { return { ok: true, value: value }; }, function (error) { return { error: error }; }),
        mlsSleepW(left).then(function () { return { timeout: true, stage: stage || '' }; })
      ]);
      if (__gotoResponded || Date.now() >= __gotoGuard.deadline) return { timeout: true, stage: stage || '' };
      return settled;
    }
    async function __gotoExec(opts, ceilingMs, stage) {
      var left = Math.min(__gotoLeft(), Math.max(0, Number(ceilingMs || __gotoLeft())));
      if (!left || __gotoResponded) return { timeout: true };
      return (await __gotoSettle(mlsExecTO(opts, left), left, stage)).value || { timeout: true };
    }
    async function __gotoWait(ms, stage) {
      var settled = await __gotoSettle(mlsSleepW(Math.min(Math.max(0, Number(ms || 0)), __gotoLeft())), Math.min(Math.max(0, Number(ms || 0)), __gotoLeft()), stage);
      return !!(settled && settled.ok && !__gotoResponded && Date.now() < __gotoGuard.deadline);
    }
    __gotoTimer = setTimeout(function () { __gotoDeadline('the request'); }, __gotoLeft());
    (async () => {
      try {
        const date = String(msg.date || '').slice(0, 10);
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return __gotoRespond({ ok: false, supported: false, error: 'bad date' });
        const allX = await __gotoSettle(chrome.tabs.query({}), 7000, 'Athena tab enumeration');
        if (!allX.ok) { __gotoDeadline('Athena tab enumeration'); return; }
        const all = allX.value || [];
        const tabX = await __gotoSettle(mlsPickAthenaTab(all, { athenaOnly: true, noPing: !!msg.probe }), msg.probe ? 2000 : 7000, 'Athena tab selection');
        if (!tabX.ok) { __gotoDeadline('Athena tab selection'); return; }
        const tab = tabX.value; /* a capability probe must answer inside its short app budget; the real navigation still uses the verified picker */
        if (!tab) return __gotoRespond({ ok: false, supported: false, error: 'No athenaOne tab open.' });
        const initX = await __gotoExec({ target: { tabId: tab.id, allFrames: true }, args: [date, !!msg.probe, __gotoGuard], func: mlsAthenaGotoDate }, msg.probe ? 2500 : 12000, 'initial date navigation');
        const hits = ((initX && initX.r) || []).map((r) => r && r.result).filter(Boolean);
        let found = hits.find((h) => h.found) || null;
        /* v1.93 diag (PHI-free: tab id + path + counts only) */
        const GDIAG = { tabId: tab.id, tabPath: (function () { try { return new URL(tab.url || '').pathname.slice(0, 40); } catch (e) { return ''; } })(), initFrames: hits.length, initFound: !!found, rounds: [] };
        /* v1.91 (§2.7): the driver can now ALWAYS reach the date control — when no
           frame shows one (athena parked on a chart/findpatient/letters view) the
           non-probe path below auto-recovers to the dashboard first. So a probe with
           an athena tab present is always supported; never advertise follow mode. */
        if (msg.probe) return __gotoRespond({ ok: true, supported: true, via: (found && found.via) || 'auto-recovery', controlVisible: !!found });
        if (!found) {
          /* v1.91 (§2.7): NEVER ask the user to move athena by hand. Drive athena
             back to the dashboard ourselves, then retry the weekstrip. Ladder:
             round 0 = Home-logo click (+ CSRF-Continue clear); round 1 = tab reload
             recovery + Home-logo click. Serialized with go-home via __mlsGroundBusy.
             Foregrounds athena for the dashboard render (same anti-throttle reason
             as go-home) and notes focus debt so the guardian returns MLS after. */
          if (self.__mlsGroundBusy) { while (self.__mlsGroundBusy && __gotoLeft() >= 500) { if (!(await __gotoWait(500, 'the Athena navigation lock'))) break; } }
          if (__gotoResponded || !__gotoLeft()) { __gotoDeadline('the Athena navigation lock'); return; }
          if (self.__mlsGroundBusy) return __gotoRespond({ ok: false, supported: true, reason: 'athena-navigation-busy', error: 'Another Athena navigation is still finishing. Nothing else was started; retry this day in a moment.' });
          self.__mlsGroundBusy = true;
          try {
            if (self.__mlsQpEnsure) {
              __gotoQpClaimed = true; self.__mlsDayScheduleQpOwner = __gotoGuard.token;
              var __gotoQpPromise = Promise.resolve(self.__mlsQpEnsure(tab, sender && sender.tab && sender.tab.id));
              __gotoQpPromise.finally(function () { if (__gotoResponded) __gotoCleanup('goto-date-late-ensure', true); }).catch(function () {});
              var __gotoQpX = await __gotoSettle(__gotoQpPromise, Math.min(9000, __gotoLeft()), 'the quiet Athena workspace');
              if (!__gotoQpX.ok) { __gotoCleanup('goto-date-ensure-timeout', true); __gotoDeadline('the quiet Athena workspace'); return; }
            } /* v2.9.5 quiet pull: athena made visible in its work strip, never focused, no focus debt */
            for (let rec = 0; rec < 2 && !found; rec++) {
              /* v1.92: per-round try/catch + mlsExecTO everywhere. (v1.91/v1.92 root
                 cause found live: `found` was const, so the ladder's reassignment
                 threw a TypeError into the catch on every run - now `let` above.) */
              const RD = { rec: rec, home: false, cont: false, err: '', at: [] };
              GDIAG.rounds.push(RD);
              try {
                if (!__gotoLeft() || __gotoResponded) { __gotoDeadline('date recovery'); return; }
                if (rec === 1) {
                  const recoveryX = await __gotoSettle(mlsRecoverAthenaTab(tab.id), Math.min(6000, __gotoLeft()), 'Athena recovery');
                  if (!recoveryX.ok) { __gotoDeadline('Athena recovery'); return; }
                }
                const hx = await __gotoExec({ target: { tabId: tab.id, allFrames: true }, args: [__gotoGuard], func: mlsGoHomeDriverFn }, Math.min(9000, __gotoLeft()), 'the Home navigation');
                const hHits = ((hx && hx.r) || []).map((r) => r && r.result).filter(Boolean);
                RD.home = hHits.some((h) => h && h.clicked);
                if (!RD.home) {
                  const ix = await __gotoExec({ target: { tabId: tab.id, allFrames: true }, func: mlsAthenaContinueFn }, Math.min(6000, __gotoLeft()), 'the session-state probe');
                  const seen = ((ix && ix.r) || []).map((m) => m && m.result).filter(Boolean).some((v) => v && v.seen);
                  RD.cont = seen;
                  if (seen) {
                    if (!(await __gotoWait(2400, 'the Athena session settle'))) { __gotoDeadline('the Athena session settle'); return; }
                    await __gotoExec({ target: { tabId: tab.id, allFrames: true }, args: [__gotoGuard], func: mlsGoHomeDriverFn }, Math.min(9000, __gotoLeft()), 'the Home navigation');
                  }
                  else if (rec === 0 && !(hx && hx.r)) { continue; } /* injection itself dead (frozen renderer): escalate to the reload round */
                  /* goHome found no logo but the injection ran: the dashboard may
                     already be showing - still try the weekstrip below. */
                }
                for (let at = 0; at < 3 && !found; at++) {
                  if (!(await __gotoWait(at === 0 ? 5200 : 3200, 'the schedule frameset settle'))) { __gotoDeadline('the schedule frameset settle'); return; } /* frameset rebuild settle */
                  const gx = await __gotoExec({ target: { tabId: tab.id, allFrames: true }, args: [date, false, __gotoGuard], func: mlsAthenaGotoDate }, Math.min(40000, __gotoLeft()), 'date navigation');
                  const hits2 = ((gx && gx.r) || []).map((r) => r && r.result).filter(Boolean);
                  found = hits2.find((h) => h.found) || null;
                  RD.at.push((gx && gx.timeout) ? 'TO' : (gx && gx.err) ? ('E:' + String(gx.err).slice(0, 40)) : (found ? 'found:' + (found.via || '') : 'f' + hits2.length));
                }
              } catch (eRound) { RD.err = String((eRound && eRound.message) || eRound).slice(0, 80); }
            }
          } catch (eRec) {} finally { self.__mlsGroundBusy = false; }
          if (__gotoResponded) return;
          if (!found) return __gotoRespond({ ok: false, supported: true, diag: GDIAG, error: 'athena date navigation: the calendar view could not be reached automatically after two recovery attempts — retry the pull.' });
        }
        /* verify by re-reading the displayed date after the page settles */
        if (!(await __gotoWait(3000, 'the selected-day settle'))) { __gotoDeadline('the selected-day settle'); return; }
        /* v1.68: the v26.3 dashboard has NO single-date header - the old header-date
           read grabbed junk dates from noise frames ("athena is showing 2025-09-25")
           even when the weekstrip click WORKED. Verify weekstrip navs by the SELECTED
           day tab instead. */
        if (found.via === 'weekstrip') {
          /* Live 2026-07-16: after an extension reload the quiet work-strip can
             sit occluded, so Athena's day click lands but the selection never
             renders ("no selected day" while the strip is verifiably clickable).
             Re-ensure visibility (the ensure now jiggles a covered strip), then
             re-click and re-verify - up to two extra rounds - before failing. */
          let hit = null, shown = '';
          for (let va = 0; va < 3 && !hit; va++) {
            if (va) {
              try { if (self.__mlsQpEnsure) await __gotoSettle(self.__mlsQpEnsure(tab, sender && sender.tab && sender.tab.id), Math.min(9000, __gotoLeft()), 'the strip re-render'); } catch (eVaQp) {}
              if (!(await __gotoWait(1500, 'the selected-day re-render'))) { __gotoDeadline('the selected-day re-render'); return; }
              const regx = await __gotoExec({ target: { tabId: tab.id, allFrames: true }, args: [date, false, __gotoGuard], func: mlsAthenaGotoDate }, Math.min(20000, __gotoLeft()), 'date re-click');
              const rehits = ((regx && regx.r) || []).map((r) => r && r.result).filter(Boolean);
              const refound = rehits.find((h) => h.found) || null;
              if (refound) found = refound;
              if (!(await __gotoWait(2500, 'the selected-day settle'))) { __gotoDeadline('the selected-day settle'); return; }
            }
            const chk2X = await __gotoExec({ target: { tabId: tab.id, allFrames: true }, args: [date, found.visibleStart || ''], func: function (want, expectedStart) {
            try {
              var nav = document.querySelector('.calendar-nav'); if (!nav) return null;
              function iso(d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
              function fromMd(md) {
                var p = md.split('/'), mon = parseInt(p[0], 10), day = parseInt(p[1], 10);
                var anchor = /^\d{4}-\d{2}-\d{2}$/.test(expectedStart) ? new Date(parseInt(expectedStart.slice(0, 4), 10), parseInt(expectedStart.slice(5, 7), 10) - 1, parseInt(expectedStart.slice(8, 10), 10), 12) : new Date();
                var best = null, dist = Infinity;
                for (var y = anchor.getFullYear() - 1; y <= anchor.getFullYear() + 1; y++) {
                  var d = new Date(y, mon - 1, day, 12);
                  if (d.getMonth() !== mon - 1 || d.getDate() !== day) continue;
                  var gap = Math.abs(d.getTime() - anchor.getTime());
                  if (gap < dist) { best = d; dist = gap; }
                }
                return best ? iso(best) : '';
              }
              var nw = new Date();
              var isToday = (want === iso(nw));
              var els = Array.prototype.slice.call(nav.querySelectorAll('*'));
              for (var i = 0; i < els.length; i++) {
                var t = (els[i].textContent || '').replace(/\s+/g, ' ').trim();
                var m = /^(sun|mon|tue|wed|thu|fri|sat)\s+(\d{1,2}\/\d{2})$/i.exec(t);
                var isTodayTab = /^today$/i.test(t); /* v1.69: today's tab has no date */
                if (!m && !isTodayTab) continue;
                var sel = /select|active|current/i.test(els[i].className || '') || /select|active|current/i.test((els[i].parentElement || {}).className || '');
                if (!sel) continue;
                if (isTodayTab) return { match: isToday, sel: 'Today', selectedDate: iso(nw) };
                var selectedDate = fromMd(m[2]);
                return { match: selectedDate === want, sel: m[2], selectedDate: selectedDate };
              }
              return null;
            } catch (e) { return null; }
          } }, Math.min(8000, __gotoLeft()), 'selected-day verification');
            const chk2 = (chk2X && chk2X.r) || [];
            const oks = (chk2 || []).map((r) => r && r.result).filter(Boolean);
            hit = oks.find((o) => o.match) || null;
            shown = (oks[0] && oks[0].sel) || shown;
          }
          return __gotoRespond({ ok: !!hit, supported: true, via: 'weekstrip', schedDate: hit ? date : shown, diag: GDIAG, error: hit ? '' : ('athena week strip shows ' + (shown || 'no selected day') + ' instead of ' + date + '.') });
        }
        const chkX = await __gotoExec({ target: { tabId: tab.id, allFrames: true }, func: mlsAthenaReadHeaderDate }, Math.min(8000, __gotoLeft()), 'date-header verification');
        const chk = (chkX && chkX.r) || [];
        const dates = (chk || []).map((r) => (r && r.result) || '').filter(Boolean);
        const onTarget = dates.indexOf(date) >= 0;
        return __gotoRespond({ ok: onTarget, supported: true, via: found.via, schedDate: onTarget ? date : (dates[0] || ''), error: onTarget ? '' : ('athena is showing ' + (dates[0] || 'an unreadable date') + ' instead of ' + date + '.') });
      } catch (e) { if (!__gotoResponded) __gotoRespond({ ok: false, supported: false, error: String((e && e.message) || e) }); }
    })();
    return true;
  }
  /* ---- v1.55: return athenaOne to the CLINICAL SCHEDULE (home) by clicking the
     athenaOne Home logo. Read-only navigation. Foregrounds the athena tab first (same
     anti-throttle reason as the v1.54 read fix) so the schedule renders fast, then clicks
     the logo across frames and waits for the day view to load. Lets the app-side day/month
     history orchestrator re-ground between patients. ---- */
  if (msg.type === 'mlsAppGoHomeRequest') {
    (async () => {
      try {
        const all = await chrome.tabs.query({});
        const tab = await mlsPickAthenaTab(all, { athenaOnly: true }); /* v1.90 unified picker */
        if (!tab) return sendResponse({ ok: false, error: 'No signed-in athenaOne tab found.' });
        try { await (self.__mlsQpEnsure ? self.__mlsQpEnsure(tab, sender && sender.tab && sender.tab.id) : null); } catch (e) {} /* v2.9.5 quiet pull: visible-not-focused replaces foreground-for-read; no focus debt */
        /* v1.59: serialize concurrent go-home attempts (the app retries on its own
           18s timer while a recovery may still be running - don't reload twice). */
        if (self.__mlsGroundBusy) { const tw = Date.now(); while (self.__mlsGroundBusy && Date.now() - tw < 25000) { await mlsSleepW(500); } }
        if (self.__mlsGroundBusy) return sendResponse({ ok: false, reason: 'athena-navigation-busy', error: 'Another Athena navigation is still finishing. Nothing else was started; retry in a moment.' });
        self.__mlsGroundBusy = true;
        try {
          /* v1.59: athenaOne freezes after ~7-9 consecutive chart reads. Chunk the
             day loop at its natural boundary: on go-home, once enough reads have
             accumulated, reload the tab first (fresh renderer; session survives;
             the Continue interstitial is cleared automatically), then click Home. */
          if (__mlsReadsSinceReload >= 6) { await mlsRecoverAthenaTab(tab.id); }
          let x = await mlsExecTO({ target: { tabId: tab.id, allFrames: true }, func: mlsGoHomeDriverFn }, 9000);
          let hits = ((x && x.r) || []).map((r) => r && r.result).filter(Boolean);
          let clicked = hits.some((h) => h && h.clicked);
          if (!clicked) {
            /* not found or frozen: clear a possible interstitial; if the injection
               itself hung/failed, recover the tab by reload; then retry once. */
            const ix = await mlsExecTO({ target: { tabId: tab.id, allFrames: true }, func: mlsAthenaContinueFn }, 6000);
            const seen = ((ix && ix.r) || []).map((m) => m && m.result).filter(Boolean).some((v) => v.seen);
            if (seen) { await mlsSleepW(2500); }
            else if (x.timeout || !hits.length) { await mlsRecoverAthenaTab(tab.id); }
            x = await mlsExecTO({ target: { tabId: tab.id, allFrames: true }, func: mlsGoHomeDriverFn }, 9000);
            hits = ((x && x.r) || []).map((r) => r && r.result).filter(Boolean);
            clicked = hits.some((h) => h && h.clicked);
          }
          await new Promise((r) => setTimeout(r, clicked ? 2600 : 400));
          return sendResponse({ ok: clicked, clicked: clicked, diag: hits });
        } finally { self.__mlsGroundBusy = false; }
      } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
    })();
    return true;
  }
  /* ---- v1.99 tab picker: list / pin / state (read-only toward athena) ---- */
  if (msg.type === 'mlsListAthenaTabsRequest') {
    (async () => {
      try {
        const all = await chrome.tabs.query({});
        const candidates = [];
        for (const t of all) {
          if (!t || t.id == null || !/^https?:/i.test(t.url || '')) continue;
          const athena = /athenahealth|athenanet|athenaone/i.test(t.url || '') || mlsTabTitleAthena(t);
          if (!athena) continue;
          candidates.push(t);
        }
        const rows = await Promise.all(candidates.map(async (t) => {
          const urlSignedOut = mlsAthIsLoginish(t) || mlsAthTabHost(t) !== 'athenanet.athenahealth.com';
          if (urlSignedOut) mlsAthRejectSignedOut(t.id);
          const pr = urlSignedOut ? { alive: false, signedOut: true, timedOut: false } : await mlsAthPing(t.id, 1500);
          const signedOut = urlSignedOut || !!pr.signedOut;
          if (signedOut) mlsAthRejectSignedOut(t.id);
          return {
            id: t.id,
            title: String(t.title || t.url || '').slice(0, 80),
            loginish: signedOut,
            signedOut: signedOut,
            timedOut: !!pr.timedOut,
            alive: !!pr.alive,
            connected: !!(pr.alive && !signedOut),
            active: !!t.active,
            hello: !!(pr.alive && !signedOut && (self.__mlsAthReg || {})[t.id] && Date.now() - self.__mlsAthReg[t.id] < 300000),
            pinned: !!(self.__mlsAthPin && self.__mlsAthPin.tabId === t.id)
          };
        }));
        rows.sort((a, b) => (a.loginish - b.loginish) || (b.pinned - a.pinned) || (b.hello - a.hello));
        sendResponse({ ok: true, tabs: rows.slice(0, 12) });
      } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e).slice(0, 120) }); }
    })();
    return true;
  }
  if (msg.type === 'mlsPinAthenaTabRequest') {
    (async () => {
      try {
        const tid = msg.tabId == null ? null : Number(msg.tabId);
        if (tid == null) { mlsPinSet(null); return sendResponse({ ok: true, pinned: false, note: 'auto tab selection restored' }); }
        let t = null; try { t = await chrome.tabs.get(tid); } catch (e) { t = null; }
        if (!t) return sendResponse({ ok: false, error: 'That tab no longer exists — refresh the list.' });
        if (mlsAthIsLoginish(t) || mlsAthTabHost(t) !== 'athenanet.athenahealth.com') { mlsAthRejectSignedOut(t.id); return sendResponse({ ok: false, error: 'That tab is on a sign-in page — sign in to athenaOne there first, then pick it.' }); }
        const pr = await mlsAthPing(t.id, 2000);
        if (pr.signedOut) return sendResponse({ ok: false, signedOut: true, timedOut: !!pr.timedOut, error: 'That athenaOne session has timed out — sign in there first, then pick it.' });
        if (!pr.alive) return sendResponse({ ok: false, error: 'MLS Assist could not verify a live signed-in athenaOne session in that tab. Refresh the list and try again.' });
        mlsPinSet(t.id);
        try { self.__mlsAthReg[t.id] = Date.now(); chrome.storage.session.set({ mlsAthReg: self.__mlsAthReg }); } catch (e) {}
        await mlsArmKeepAlive(t.id, true, pr);
        const info = await mlsPinInfo();
        sendResponse({ ok: true, pinned: true, tabId: t.id, alive: !!pr.alive, ka: info.ka, title: info.title });
      } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e).slice(0, 120) }); }
    })();
    return true;
  }
  if (msg.type === 'mlsPinStateRequest') {
    (async () => { try { sendResponse(Object.assign({ ok: true }, await mlsPinInfo())); } catch (e) { sendResponse({ ok: false, reason: 'pin-state-error', error: 'Could not read the pinned athena tab state: ' + String((e && e.message) || e).slice(0, 80) }); } })(); /* v2.9.9: never a bare false (Codex E3) */
    return true;
  }
  /* ---- v1.60 DEV: reload the (unpacked) extension from disk. Lets the driving
     session iterate builds without a manual chrome://extensions click. Reload
     only - no data access; the worker re-reads whatever is on disk. ---- */
  if (msg.type === 'mlsDevReloadRequest') {
    try { sendResponse({ ok: true, reloading: true }); } catch (e) {}
    setTimeout(function () { try { chrome.runtime.reload(); } catch (e) {} }, 400);
    return true;
  }
  /* ---- v2.9.11: read the accumulated shadow-parser evidence (canonical-parser
     cutover data; see mlsNameShadowTotals aggregation in the schedule handler).
     Read-only; names in samples stay in-browser like all pull data. ---- */
  if (msg.type === 'mlsNameShadowStateRequest') {
    try {
      chrome.storage.local.get(['mlsNameShadowTotals'], function (st) {
        try { sendResponse({ ok: true, totals: (st && st.mlsNameShadowTotals) || null }); } catch (e2) {}
      });
    } catch (e) { try { sendResponse({ ok: false, reason: 'storage-error', error: String((e && e.message) || e).slice(0, 80) }); } catch (e3) {} }
    return true;
  }
  /* Return focus only when a foreground write recorded exact focus ownership
     and that same Athena tab/window is still selected. Quiet reads create no
     debt, and any human tab/window change cancels the return. */
  if (msg.type === 'mlsAppFocusMlsTab') {
    (async () => {
      try {
        /* Repeated end messages are no-ops: only live, exactly-owned focus debt
           can activate the app tab. */
        const FGv = self.__mlsFg || {};
        const owed = !!FGv.debt;
        try { if (self.__mlsQpRelease) await self.__mlsQpRelease('app-end'); } catch (e) {} /* restore the work-strip before deciding whether a focus return is still safe */
        if (!owed) { return sendResponse({ ok: true, activated: false, skipped: 'no-focus-debt' }); }
        if (!self.__mlsFgFocusApp) return sendResponse({ ok: true, activated: false, skipped: 'focus-guardian-unavailable' });
        const result = await self.__mlsFgFocusApp();
        sendResponse(result || { ok: true, activated: false, skipped: 'focus-not-owned' });
      } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
    })();
    return true;
  }
  /* ---- v1.77 DIAGNOSTIC (read-only, NO PHI): what identity does the write gate
     read from the open chart, per frame? Returns initials + score + via only, so a
     refusal ("uncertain"/"mismatch") can be explained instead of guessed at.
     Reads identity; writes nothing, clicks nothing. ---- */
  if (msg.type === 'mlsIdDiag') {
    (async () => {
      try {
        const all = await chrome.tabs.query({});
        const tab = await mlsPickAthenaTab(all); /* v1.90: was raw ath[0]/c[0] in query order */
        if (!tab) return sendResponse({ ok: false, error: 'no chart tab' });
        /* v2.9.13 (Codex E3): bounded READ-ONLY retry — 20s envelope; on timeout/
           rejection/zero-frames revalidate the tab and retry ONCE. Never retries a
           completed read, an identity result, or anything write-adjacent. */
        let idr = null;
        for (let idTry = 0; idTry < 2; idTry++) {
          const idx = await mlsExecTO({ target: { tabId: tab.id, allFrames: true }, func: mlsReadChartIdentity }, 20000);
          if (idx && idx.r && idx.r.length) { idr = idx.r; break; }
          if (idTry === 0) { try { const t2 = await chrome.tabs.get(tab.id); if (!t2 || !/athenanet\.athenahealth\.com/i.test(mlsHostOnly(t2.url || ''))) break; } catch (eRv) { break; } await new Promise((r) => setTimeout(r, 700)); }
        }
        if (!idr) return sendResponse({ ok: false, error: 'identity read did not complete (renderer busy) — try again.' });
        const frames = (idr || []).map((m) => {
          const r = (m && m.result) || {};
          const nm = String(r.name || '');
          return {
            frameId: m && m.frameId,
            initials: nm ? nm.split(/[ ,]+/).filter(Boolean).map(w => w[0]).join('') : '',
            nameLen: nm.length,
            hasDob: !!r.dob, hasMrn: !!r.mrn,
            score: r.score || 0, via: r.via || ''
          };
        }).filter((f) => f.nameLen || f.hasDob || f.hasMrn);
        const best = mlsBestIdentityFrom(idr);
        /* v1.78: what does the SHADOW reader see? (initials only, no PHI) */
        let shadowBest = null;
        try {
          const sidr = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: mlsReadChartIdentityShadow });
          const sb = mlsBestIdentityFrom(sidr);
          if (sb && sb.name) shadowBest = { initials: sb.name.split(/[ ,]+/).filter(Boolean).map(w => w[0]).join(''), hasDob: !!sb.dob, hasMrn: !!sb.mrn, score: sb.score || 0, via: sb.via || '' };
        } catch (e) {}
        /* structure probe: is the banner hiding in shadow DOM? (counts only, no text) */
        let struct = [];
        try {
          const sr = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: function () {
            var it = (document.body && document.body.innerText || '');
            var tc = (document.body && document.body.textContent || '');
            var shadows = 0, hosts = 0;
            try { var els = document.querySelectorAll('*'); for (var i = 0; i < els.length; i++) { if (els[i].shadowRoot) { shadows++; if (!hosts) hosts = 1; } } } catch (e) {}
            var nameShapedInInner = /^[A-Z][A-Za-z'\-\.]*(\s+[A-Z][A-Za-z'\-\.]*){1,3}$/m.test(it);
            /* where does a chart banner live? booleans only. */
            var BANNER = /\b\d{1,3}\s*yo\b/i;              /* the age chip */
            var DATEISH = /\b[01]?\d[\/\-\.][0-3]?\d[\/\-\.]\d{4}\b/;
            var innerBanner = BANNER.test(it) && DATEISH.test(it);
            var shadowBanner = false, shadowInnerLen = 0;
            try {
              var els2 = document.querySelectorAll('*');
              for (var j = 0; j < els2.length; j++) {
                var sr = els2[j].shadowRoot;
                if (!sr) continue;
                var st = '';
                try { var kids = sr.children || []; for (var k = 0; k < kids.length; k++) { st += '\n' + (kids[k].innerText || ''); } } catch (e) {}
                shadowInnerLen += st.length;
                if (BANNER.test(st) && DATEISH.test(st)) shadowBanner = true;
              }
            } catch (e) {}
            return { innerLen: it.length, textLen: tc.length, shadowRoots: shadows, nameShapedInInner: nameShapedInInner,
                     innerBanner: innerBanner, shadowBanner: shadowBanner, shadowInnerLen: shadowInnerLen,
                     tail: String(location.pathname || '').slice(-26) };
          } });
          struct = (sr || []).map(m => Object.assign({ frameId: m.frameId }, m.result || {})).filter(f => f.innerLen != null);
        } catch (e) {}
        let mlsPt = { name: '', dob: '', mrn: '' };
        try {
          const mt = await chrome.tabs.query({ url: ['https://mlsscribe.com/*', 'https://*.mlsscribe.com/*'] });
          for (const t of mt) { const [mr] = await chrome.scripting.executeScript({ target: { tabId: t.id }, func: mlsReadActivePatient }); if (mr && mr.result && (mr.result.name || mr.result.dob)) { mlsPt = mr.result; break; } }
        } catch (e) {}
        const match = mlsMatchPatients(mlsPt, best || {});
        sendResponse({
          ok: true, frames: frames, struct: struct, shadowBest: shadowBest, readerHasShadow: (function(){ try { return typeof mlsReadChartIdentityShadow === 'function'; } catch(e){ return false; } })(),
          bestInitials: best && best.name ? best.name.split(/[ ,]+/).filter(Boolean).map(w => w[0]).join('') : '',
          bestScore: best ? (best.score || 0) : null, bestVia: best ? best.via : '', bestHasDob: !!(best && best.dob),
          mlsInitials: mlsPt.name ? mlsPt.name.split(/[ ,]+/).filter(Boolean).map(w => w[0]).join('') : '',
          mlsHasDob: !!mlsPt.dob,
          matchStatus: match.status, dobMatch: !!match.dobMatch, nameMatch: !!match.nameMatch
        });
      } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
    })();
    return true;
  }
  /* ---- v1.75 DIAGNOSTIC (read-only): report guardian state + which tab is active.
     Lets the app (and a driving session) VERIFY the doctor was returned to MLS,
     without any DOM access. Reads tab metadata only; clicks nothing. ---- */
  if (msg.type === 'mlsFgState') {
    (async () => {
      try {
        const all = await chrome.tabs.query({});
        const act = all.find((t) => t.active) || null;
        const host = (u) => { try { return new URL(u || '').host; } catch (e) { return ''; } };
        const FG = self.__mlsFg || {};
        sendResponse({
          ok: true,
          debt: !!FG.debt,
          quietMs: FG.at ? (Date.now() - FG.at) : null,
          activeHost: act ? host(act.url) : '',
          activeIsApp: !!(act && /(^|\.)mlsscribe\.com$/i.test(host(act.url)) && /ScribeFlow/i.test(act.url || '')),
          activeIsAthena: !!(act && /athenahealth|athenanet/i.test(act.url || '')),
          version: (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || ''
        });
      } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
    })();
    return true;
  }
  /* ---- v1.51: reviews scrape driver (reputation lane; public pages, no PHI) ---- */
  if (msg.type === 'mlsAppScrapeReviewsRequest') {
    (async () => {
      try {
        const targets = Array.isArray(msg.targets) ? msg.targets.slice(0, 12) : [];
        if (!targets.length) return sendResponse({ ok: false, error: 'No review pages to read.' });
        const results = [];
        for (const t0 of targets) {
          const url = String((t0 && t0.url) || t0 || '');
          if (!/^https:\/\//i.test(url)) { results.push({ url, ok: false, error: 'not https' }); continue; }
          let tab = null;
          try {
            tab = await chrome.tabs.create({ url, active: false });
            await new Promise((res) => {
              let done = false; const to = setTimeout(() => { if (!done) { done = true; res(); } }, 20000);
              const li = (id, info) => { if (id === tab.id && info && info.status === 'complete' && !done) { done = true; clearTimeout(to); chrome.tabs.onUpdated.removeListener(li); res(); } };
              chrome.tabs.onUpdated.addListener(li);
            });
            await new Promise((r) => setTimeout(r, 2500));
            const resp = await new Promise((res) => {
              let d = false; const to = setTimeout(() => { if (!d) { d = true; res(null); } }, 25000);
              try { chrome.tabs.sendMessage(tab.id, { type: 'mlsExtReadReviews' }, (r2) => { void chrome.runtime.lastError; if (!d) { d = true; clearTimeout(to); res(r2 || null); } }); }
              catch (e) { if (!d) { d = true; clearTimeout(to); res(null); } }
            });
            results.push({ url, ok: !!(resp && resp.ok !== false && (resp.listing || resp.reviews)), data: resp || null, error: resp ? '' : 'reader did not answer' });
          } catch (e) { results.push({ url, ok: false, error: String((e && e.message) || e) }); }
          finally { try { if (tab) await chrome.tabs.remove(tab.id); } catch (e2) {} }
          await new Promise((r) => setTimeout(r, 2500)); /* politeness gap between sites */
        }
        sendResponse({ ok: true, results, version: (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '' });
      } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
    })();
    return true;
  }
  /* ---- v1.51: assisted-capture relay (reader → background → mlsscribe tab) ---- */
  if (msg.type === 'mlsExtScrapeCaptured') {
    (async () => {
      try {
        const tabs = await chrome.tabs.query({ url: '*://mlsscribe.com/*' });
        for (const t of tabs) {
          try {
            await chrome.scripting.executeScript({ target: { tabId: t.id }, args: [msg.resp || null],
              func: (resp) => { try { window.postMessage({ source: 'mls-ext', type: 'mlsAppScrapeCaptured', resp: resp }, '*'); } catch (e) {} } });
          } catch (e) {}
        }
        sendResponse({ ok: true, relayed: tabs.length });
      } catch (e) { sendResponse({ ok: false, reason: 'relay-error', error: 'Could not relay the captured page to the MLS tab: ' + String((e && e.message) || e).slice(0, 80) }); } /* v2.9.9: never a bare false (Codex E3) */
    })();
    return true;
  }
  if (msg.type === 'mlsAppScheduleRequest') {
    const __schedStartedAt = Date.now();
    const __schedRequestId = String(msg.requestId || msg.id || ('mlssched-' + __schedStartedAt.toString(36) + '-' + Math.random().toString(36).slice(2, 9))).slice(0, 100);
    const __schedCallerDeadline = Number(msg.deadlineAt || 0);
    let __schedDeadline = __schedStartedAt + 27000;
    if (Number.isFinite(__schedCallerDeadline) && __schedCallerDeadline > 0) __schedDeadline = Math.min(__schedDeadline, __schedCallerDeadline);
    const __schedGuard = Object.freeze({ token: __schedRequestId, deadline: __schedDeadline });
    const __schedRawRespond = sendResponse;
    let __schedResponded = false, __schedTimer = null, __schedQpClaimed = false;
    const __schedLeft = function () { return Math.max(0, __schedGuard.deadline - Date.now()); };
    function __schedCleanup(reason, immediate) {
      function start() {
        if (!__schedQpClaimed || self.__mlsDayScheduleQpOwner !== __schedGuard.token) return;
        self.__mlsDayScheduleQpOwner = '';
        try {
          if (!self.__mlsQpRelease) return;
          var release = Promise.resolve(self.__mlsQpRelease(reason || 'schedule-terminal')).catch(function () {});
          Promise.race([release, mlsSleepW(5000)]).catch(function () {});
        } catch (e) {}
      }
      if (immediate) start(); else setTimeout(start, 0);
    }
    function __schedRespond(payload) {
      if (__schedResponded) return false;
      __schedResponded = true;
      if (__schedTimer != null) { try { clearTimeout(__schedTimer); } catch (e) {} }
      if (Date.now() >= __schedGuard.deadline && !/timeout|deadline-exceeded/.test(String(payload && payload.reason || ''))) {
        payload = { ok: false, reason: 'schedule-request-timeout', scheduleVerified: false, error: 'The schedule read returned after its immutable request deadline. The late result was discarded.' };
      }
      /* A successful schedule read hands the lease to exact-history capture;
         app-end owns the final release. Failed/expired reads clean up now. */
      if (payload && payload.ok === true) { if (self.__mlsDayScheduleQpOwner === __schedGuard.token) self.__mlsDayScheduleQpOwner = ''; }
      else __schedCleanup('schedule-terminal', false);
      __schedRawRespond(Object.assign({}, payload || {}, { id: __schedRequestId, requestId: __schedRequestId, deadlineAt: __schedGuard.deadline }));
      return true;
    }
    function __schedDeadlineResponse(stage) {
      return __schedRespond({ ok: false, reason: 'schedule-request-timeout', scheduleVerified: false, error: 'The schedule read reached its immutable request deadline during ' + (stage || 'the request') + '. No late retry was dispatched.' });
    }
    async function __schedSettle(promise, ceilingMs, stage) {
      var left = Math.min(__schedLeft(), Math.max(0, Number(ceilingMs == null ? __schedLeft() : ceilingMs)));
      if (!left || __schedResponded) return { timeout: true, stage: stage || '' };
      var settled = await Promise.race([
        Promise.resolve(promise).then(function (value) { return { ok: true, value: value }; }, function (error) { return { error: error }; }),
        mlsSleepW(left).then(function () { return { timeout: true, stage: stage || '' }; })
      ]);
      if (__schedResponded || Date.now() >= __schedGuard.deadline) return { timeout: true, stage: stage || '' };
      return settled;
    }
    async function __schedExec(opts, ceilingMs, stage) {
      var left = Math.min(__schedLeft(), Math.max(0, Number(ceilingMs || __schedLeft())));
      if (!left || __schedResponded) return { timeout: true };
      return (await __schedSettle(mlsExecTO(opts, left), left, stage)).value || { timeout: true };
    }
    async function __schedWait(ms, stage) {
      var waitMs = Math.min(Math.max(0, Number(ms || 0)), __schedLeft());
      var settled = await __schedSettle(mlsSleepW(waitMs), waitMs, stage);
      return !!(settled && settled.ok && !__schedResponded && Date.now() < __schedGuard.deadline);
    }
    __schedTimer = setTimeout(function () { __schedDeadlineResponse('the request'); }, __schedLeft());
    (async () => {
      try {
        /* The page listener gives this request 30s. Keep a hard worker budget
           below that so a slow frame returns an honest retryable error instead
           of being misreported as an old extension. */
        const allX = await __schedSettle(chrome.tabs.query({}), 7000, 'Athena tab enumeration');
        if (!allX.ok) { __schedDeadlineResponse('Athena tab enumeration'); return; }
        const all = allX.value || [];
        /* v1.90: unified verified picker (heartbeat-preferred, reachability-pinged,
           identity/login excluded); non-athena EMR keyword fallback preserved. */
        const pickedX = await __schedSettle(mlsPickAthenaTab(all, { athenaOnly: true }), 7000, 'Athena tab selection');
        if (!pickedX.ok) { __schedDeadlineResponse('Athena tab selection'); return; }
        let tab = pickedX.value || all.find((t) => /epic|cerner|ecw|eclinical|nextgen|allscripts|emr|ehr|\bchart\b|practice|clinic/i.test(t.url || '') && !/mlsscribe\.com|athena/i.test(t.url || ''));
        // v1.38 truth fix: do NOT fall back to an unrelated most-recently-active tab and report it connected (phantom-tab bug).
        if (!tab) return __schedRespond({ ok: false, reason: 'no-athena-tab', emr: 'none', host: '', error: 'Open a signed-in athenaOne tab, then try again.' });
        const isRealAthena = /athenahealth|athenanet|athenaone|athena\.io|\.px\.athena/i.test(tab.url || '');
        /* v2.9.15: schedule reads need the same focus-safe visibility lease as
           date/history reads.  Without it, an occluded athena dashboard can
           expose only the tiny schedulenavclose frame and we would honestly
           parse zero appointments while still reporting ok:true.  The quiet
           work strip lets athena render without activating its tab or yanking
           the doctor's current work. */
        if (isRealAthena) {
          if (self.__mlsQpEnsure) {
            __schedQpClaimed = true; self.__mlsDayScheduleQpOwner = __schedGuard.token;
            var __schedQpPromise = Promise.resolve(self.__mlsQpEnsure(tab, sender && sender.tab && sender.tab.id));
            __schedQpPromise.finally(function () { if (__schedResponded) __schedCleanup('schedule-late-ensure', true); }).catch(function () {});
            var __schedQpX = await __schedSettle(__schedQpPromise, Math.min(9000, __schedLeft()), 'the quiet Athena workspace');
            if (!__schedQpX.ok) { __schedCleanup('schedule-ensure-timeout', true); __schedDeadlineResponse('the quiet Athena workspace'); return; }
          }
        }
        // Read every frame WITH its URL so we can isolate the SCHEDULE/CALENDAR frame and
        // drop the noise (athenaText messaging, department lists) that would pollute parsing.
        // v1.45: fetch hosted config (data, not code) so selectors are tunable via the site w/o a store update.
        var __mlsCfg = null, __cfgAbort = (typeof AbortController === 'function') ? new AbortController() : null;
        try {
          var __cfgFetch = fetch('https://mlsscribe.com/mls-assist-config.json?cb=' + Date.now(), __cfgAbort ? { signal: __cfgAbort.signal } : undefined);
          var __cfgFetchX = await __schedSettle(__cfgFetch, Math.min(1200, __schedLeft()), 'schedule configuration');
          if (__cfgFetchX.ok && __cfgFetchX.value && __cfgFetchX.value.ok) {
            var __cfgJsonX = await __schedSettle(__cfgFetchX.value.json(), Math.min(1200, __schedLeft()), 'schedule configuration parse');
            if (__cfgJsonX.ok) __mlsCfg = __cfgJsonX.value;
          }
        } catch (e) { __mlsCfg = null; }
        finally { if (__cfgAbort) try { __cfgAbort.abort(); } catch (eAbortCfg) {} }
        // v1.47 AUTO-NAVIGATE pre-step: only when NO frame currently shows a schedule grid,
        // click the Calendar/Schedule nav and wait for the day view to load, then scrape below.
        var __surface = { verified: false, frameIds: [], hits: [], probes: [] }, __navAttempted = false, __navClicked = false, __homeClicked = false;
        try {
          var __gridProbe = async function () {
            var __left = __schedLeft();
            if (__left < 500) return { verified: false, frameIds: [], hits: [], probes: [], error: 'request-budget-exhausted' };
            var __detX = await __schedExec({ target: { tabId: tab.id, allFrames: true }, func: mlsAthenaScheduleSurfaceFn }, Math.min(6500, __left), 'schedule-surface verification');
            if (!(__detX && __detX.r)) return { verified: false, frameIds: [], hits: [], probes: [], error: (__detX && __detX.timeout) ? 'surface-probe-timeout' : String((__detX && __detX.err) || 'surface-probe-failed').slice(0, 100) };
            var __det = __detX.r;
            var __probes = (__det || []).filter(function (r) { return r && r.result; }).map(function (r) {
              var p = r.result || {};
              return { frameId: r.frameId, verified: !!p.verified, via: p.via || '', dateHeader: p.dateHeader || '', timeCount: p.timeCount || 0, table: !!p.table, structure: !!p.structure, legacyHeading: !!p.legacyHeading, appointmentNodes: p.appointmentNodes || 0, appointmentClasses: (p.appointmentClasses || []).slice(0, 8), urlHint: !!p.urlHint, scheduleWords: !!p.scheduleWords, empty: !!p.empty, providerContext: !!p.providerContext };
            }).slice(0, 40);
            var __hits = (__det || []).filter(function (r) { return r && r.result && r.result.verified; }).map(function (r) {
              return { frameId: r.frameId, via: r.result.via || '', dateHeader: r.result.dateHeader || '', timeCount: r.result.timeCount || 0 };
            });
            return { verified: __hits.length > 0, frameIds: __hits.map(function (h) { return h.frameId; }), hits: __hits, probes: __probes };
          };
          __surface = await __gridProbe();
          /* v2.9.15 self-heal: a prior/legacy pull can leave athena inside
             schedulenavclose.esp or another schedule plumbing frame.  Go Home
             first and re-probe the dashboard; only use the Calendar menu if a
             real schedule grid is still absent.  Home is read-only and the
             quiet visibility lease above keeps this from stealing focus. */
          if (!__surface.verified && isRealAthena) {
            var __homeLeft = __schedLeft();
            var __homeX = __homeLeft >= 500 ? await __schedExec({ target: { tabId: tab.id, allFrames: true }, args: [__schedGuard], func: mlsGoHomeDriverFn }, Math.min(6000, __homeLeft), 'the Home navigation') : { timeout: true };
            var __home = (__homeX && __homeX.r) || [];
            __homeClicked = (__home||[]).some(function(r){ return r && r.result && r.result.clicked; });
            if (__homeClicked) {
              if (!(await __schedWait(Math.min(5200, Math.max(0, __schedLeft() - 700)), 'the Home settle'))) { __surface.error = 'request-budget-exhausted'; }
              __surface = await __gridProbe();
            }
          }
          if (!__surface.verified) {
            __navAttempted = true;
            var __navLeft = __schedLeft();
            var __navX = __navLeft >= 500 ? await __schedExec({ target: { tabId: tab.id, allFrames: true }, args: [ (__mlsCfg && __mlsCfg.nav) || null, __schedGuard ], func: mlsAthenaGotoSchedule }, Math.min(6000, __navLeft), 'the Schedule navigation') : { timeout: true };
            var __nav = (__navX && __navX.r) || [];
            __navClicked = (__nav||[]).some(function(r){ return r && r.result && r.result.clicked; });
            if (__navClicked) { await __schedWait(Math.min((__mlsCfg && __mlsCfg.navWaitMs) || 3500, Math.max(0, __schedLeft() - 700)), 'the Schedule settle'); }
          }
          /* Verify after navigation/settling. A real empty day still passes via
             schedule structure/date+empty-state; an arbitrary chart does not. */
          for (var __pr = 0; !__surface.verified && __pr < 3; __pr++) {
            if (__schedLeft() < 500) { __surface.error = 'request-budget-exhausted'; break; }
            if (__pr || !__navAttempted) { if (!(await __schedWait(Math.min(900, Math.max(0, __schedLeft() - 500)), 'the schedule verification settle'))) { __surface.error = 'request-budget-exhausted'; break; } }
            __surface = await __gridProbe();
          }
        } catch (e) { __surface = { verified: false, frameIds: [], hits: [], probes: (__surface && __surface.probes) || [], error: String(e && e.message || e).slice(0, 100) }; }
        if (__schedResponded || !__schedLeft()) { __schedDeadlineResponse('schedule-surface verification'); return; }
        if (!__surface.verified) {
          return __schedRespond({ ok: false, reason: 'schedule-surface-unverified', scheduleVerified: false, emr: isRealAthena ? 'athena' : 'other-emr', host: mlsHostOnly(tab.url), error: 'Could not verify a real schedule surface in the EHR, so nothing was imported. Open Calendar/Schedule and try again.', surfaceDiag: { navAttempted: __navAttempted, navClicked: __navClicked, homeClicked: __homeClicked, error: __surface.error || '', probes: (__surface.probes || []).slice(0, 40) } });
        }
        let results = [];
        {
          var __scrapeLeft = __schedLeft();
          if (__scrapeLeft < 3800) return __schedRespond({ ok: false, reason: 'schedule-request-timeout', scheduleVerified: true, emr: isRealAthena ? 'athena' : 'other-emr', host: mlsHostOnly(tab.url), error: 'Athena took too long to leave a safe schedule-sweep budget. Nothing was imported; try again.' });
          var __schedCfgArg = {}, __schedCfgBase = (__mlsCfg && (__mlsCfg.schedule || __mlsCfg)) || {};
          try { Object.keys(__schedCfgBase || {}).forEach(function (k) { __schedCfgArg[k] = __schedCfgBase[k]; }); } catch (eCfgCopy) {}
          /* Pass the injected reader its share of the request's absolute
             budget. This gives the new vertical sweep real time to finish,
             while still returning before the app bridge's 30-second guard. */
          var __scrapeGuard = Object.freeze({ token: __schedGuard.token, deadline: Math.min(__schedGuard.deadline, Date.now() + Math.min(18000, __scrapeLeft)) });
          __schedCfgArg.__maxSweepMs = Math.max(0, Math.min(16500, __scrapeGuard.deadline - Date.now() - 800));
          const __scrapeX = await __schedExec({
            target: { tabId: tab.id, allFrames: true },
            args: [ __schedCfgArg, __scrapeGuard ],
            func: async (CFG, READ_GUARD) => { try {
/* The worker and every injected frame share one immutable request identity and
 * absolute deadline. executeScript cannot be cancelled after dispatch, so the
 * renderer independently refuses every late scroll/event/sleep/restore. */
var __liveScheduleGuard=Object.freeze({deadline:Number(READ_GUARD&&READ_GUARD.deadline||0),token:String(READ_GUARD&&READ_GUARD.token||'')});
function __liveScheduleAllowed(){return !!__liveScheduleGuard.token&&Number.isFinite(__liveScheduleGuard.deadline)&&Date.now()<__liveScheduleGuard.deadline;}
if(!__liveScheduleAllowed())return{u:'',t:'',s:{appts:[],providers:[],diag:{strategy:'guarded',via:'',budgetExpired:true,reason:'schedule-request-timeout',requestToken:__liveScheduleGuard.token||''}}};
/* inject_dom.js — SELF-CONTAINED DOM schedule/provider reader.
 * This exact function body is inlined into MLS Assist background.js's executeScript
 * `func` so it runs INSIDE the athenaOne schedule frame. It must reference nothing
 * outside itself. Returns { appts:[{time,name,provider}], providers:[...], diag:{} }.
 * Read-only; PHI (patient names) stays in the user's browser; diag is PHI-free. */
/* ===========================================================================
 * v2.9.13 CANONICAL NAME PARSER — SHADOW MODE ONLY (Codex E1 program, rev 3).
 * rev2 (Codex-staged) + rev3 live-shadow fix: the FIRST honest-counter pull
 * caught rev2 ingesting reason-text tails on real dashboard rows ("Tina Closs"
 * -> "Tina Closs Lumbar") — legacy's unstripped age chip accidentally FENCED
 * the name; rev2 stripped the fence to a space and sailed into "Lumbar Spine".
 * rev3: (a) debris strips (age/sex, DOB, MRN, status phrases, pipes, numbers)
 * become BOUNDARY markers, not spaces — the name cannot absorb tokens across a
 * debris site; (b) the parser tries only the FIRST TWO boundary segments
 * (leading time/status debris precedes the name; reason text follows it);
 * (c) the practice's anatomy vocabulary joins the stop list. Everything else
 * is rev2 (nickname field, age+sex unit, explicit suffix orders,
 * state/credential/one-letter rejection, suffix-free display).
 * =========================================================================== */
function mlsParseName(raw) {
  try {
    var s = String(raw == null ? '' : raw).replace(/’/g, "'").replace(/\s+/g, ' ').trim();
    if (!s) return null;
    var nickname = '';
    var NICKWORD = /^[A-Za-z][A-Za-z'.\-]*(?:\s+[A-Za-z][A-Za-z'.\-]*)?$/;
    var NICKSTOP = /^(?:jr|sr|ii|iii|iv|v|esq|junior|senior|new patient|follow[ -]?up|self[ -]?pay|(?:left|right)(?:\s+(?:knee|hip|shoulder|ankle|foot|wrist|elbow))?|knee|hip|shoulder|ankle|foot|wrist|elbow|room|status|visit|injection|procedure)$/i;
    s = s.replace(/\(([^)]*)\)/g, function (whole, inside) {
      var n = String(inside || '').trim().replace(/^["']+|["']+$/g, '');
      if (!nickname && NICKWORD.test(n) && !NICKSTOP.test(n)) nickname = n;
      return ' ';
    });
    /* BND = hard name boundary. Debris does not just vanish — it fences. */
    var B = ' ‖ ';
    s = s.replace(/\b\d{1,2}:\d{2}\s*(?:[ap]\.?\s?m\.?)?\b/gi, B);
    s = s.replace(/\b\d+\s*min(?:ute)?s?\b/gi, B);
    s = s.replace(/\b\d{1,3}\s*(?:yo|y\/o|yrs?\.?|years?(?:\s*old)?)\s*[MF]\b/gi, B);
    s = s.replace(/\b\d{1,3}\s*(?:yo|y\/o|yrs?\.?|years?(?:\s*old)?)\b/gi, B);
    s = s.replace(/\b[01]?\d[\/\-.][0-3]?\d[\/\-.]\d{2,4}\b/g, B);
    s = s.replace(/#\s?\d{3,}\b/g, B);
    s = s.replace(/\b(checked[\s-]?(?:in|out)|check[\s-]?(?:in|out)|self[\s-]?pay|walk[\s-]?in|no[\s-]?show|arrived|scheduled|confirmed|cancell?ed|copay|balance|room\s*\d*|status|new patient|follow[\s-]?up|office visit|telehealth|video visit)\b/gi, B);
    s = s.replace(/\b(?:left|right)\s+(?:knee|hip|shoulder|ankle|foot|wrist|elbow)\b.*$/i, B);
    s = s.replace(/\bgenicular\s+nerve\s+block\b.*$/i, B);
    s = s.replace(/[|•·]+/g, B);
    s = s.replace(/\b\d+\b/g, B);
    /* Split into boundary segments; the patient name lives in the first or
       second segment (leading debris precedes it; reason text follows it).
       Later segments are reason/status vocabulary — never eligible. */
    var segs = s.split(/‖/).map(function (x) { return x.replace(/\s+/g, ' ').replace(/\s*,\s*/g, ', ').replace(/^[,\s]+|[,\s]+$/g, ''); }).filter(Boolean).slice(0, 2);
    if (!segs.length) return null;
    var SFX = /^(jr|sr|ii|iii|iv|v|esq|junior|senior)\.?$/i;
    var SFXMAP = { jr: 'Jr', sr: 'Sr', ii: 'II', iii: 'III', iv: 'IV', v: 'V', esq: 'Esq', junior: 'Junior', senior: 'Senior' };
    function normSuffix(x) {
      var m = String(x || '').trim().match(SFX);
      return m ? SFXMAP[m[1].toLowerCase()] : '';
    }
    var PART = /^(de|del|della|da|di|du|van|von|der|den|la|le|los|st\.?|san|santa)$/i;
    var STOPX = /^(am|pm|open|no|show|hold|blocked|lunch|closed|unavailable|reserved|admin|administrative|est|new|office|visit|tele|telehealth|video|phone|follow|followup|fu|consult|consultation|annual|physical|wellness|exam|sick|nurse|lab|labs|injection|inj|procedure|recheck|min|mins|minute|minutes|room|status|reason|provider|patient|time|type|resource|rendering|department|dept|appt|appts|total|appointments|in|out|pay|self|md|do|np|pa|pac|aprn|fnp|dnp|rn|dpm|dds|dmd|phd|psyd|mbbs|cnm|crna|od|lcsw|lpc|lumbar|cervical|thoracic|sacral|spine|neck|back|knee|hip|shoulder|ankle|foot|wrist|elbow|epidural|facet|joint|block|nerve|steroid|cortisone)$/i;
    var STATE = /^(al|ak|az|ar|ca|co|ct|de|fl|ga|hi|id|il|in|ia|ks|ky|la|me|md|ma|mi|mn|ms|mo|mt|ne|nv|nh|nj|nm|ny|nc|nd|oh|ok|or|pa|ri|sc|sd|tn|tx|ut|vt|va|wa|wv|wi|wy|dc)$/i;
    var CRED = /^(md|do|np|pa|pac|aprn|fnp|dnp|rn|dpm|dds|dmd|phd|psyd|mbbs|cnm|crna|od|lcsw|lpc)$/i;
    var TOKRE = /^[A-Za-z][A-Za-z'.\-]*$/;
    function parseSeg(seg) {
      var s2 = seg, suffix = '';
      var commaParts = s2.split(/\s*,\s*/).filter(Boolean);
      if (commaParts.length >= 3 && normSuffix(commaParts[1])) {
        suffix = normSuffix(commaParts[1]);
        s2 = commaParts[0] + ', ' + commaParts.slice(2).join(' ');
      } else if (commaParts.length > 1 && normSuffix(commaParts[commaParts.length - 1])) {
        suffix = normSuffix(commaParts.pop());
        s2 = commaParts.join(', ');
      }
      s2 = s2.replace(/\s+(jr|sr|ii|iii|iv|v|esq|junior|senior)\.?(?=[\s,]|$)/gi, function (whole, value) {
        if (!suffix) suffix = normSuffix(value);
        return ' ';
      });
      s2 = s2.replace(/\s+/g, ' ').replace(/\s*,\s*/g, ', ').replace(/^[,\s]+|[,\s]+$/g, '');
      if (!s2) return null;
      var first = '', middle = '', last = '';
      var cm = s2.split(/\s*,\s*/).filter(Boolean);
      if (cm.length >= 2) {
        last = cm[0];
        var rawGiven = cm.slice(1).join(' ').split(/\s+/).filter(Boolean), given = [];
        if (rawGiven.length === 1 && (STATE.test(rawGiven[0].replace(/\./g, '')) || CRED.test(rawGiven[0].replace(/\./g, '')))) return null;
        for (var gi = 0; gi < rawGiven.length && given.length < 3; gi++) {
          var gt = rawGiven[gi];
          if (!TOKRE.test(gt) || STOPX.test(gt)) break;
          given.push(gt);
        }
        first = given[0] || '';
        middle = given.slice(1).join(' ');
      } else {
        var t = s2.split(/\s+/).filter(Boolean);
        while (t.length > 1 && /^[MF]$/.test(t[0]) && t[1] && t[1].length > 1) t.shift();
        var w = [];
        for (var i = 0; i < t.length; i++) {
          var tok = t[i];
          if (!TOKRE.test(tok)) { if (w.length) break; else continue; }
          if (STOPX.test(tok)) { if (w.length) break; else continue; }
          if (!/^[A-Z]/.test(tok) && !(w.length && PART.test(tok))) { if (w.length) break; else continue; }
          w.push(tok);
          if (w.length >= 3 && !PART.test(w[w.length - 1])) break;
          if (w.length >= 6) break;
        }
        if (!w.length) return null;
        if (w.length === 1) last = w[0];
        else {
          var li = w.length - 1;
          while (li - 1 > 0 && PART.test(w[li - 1])) li--;
          last = w.slice(li).join(' ');
          first = w[0];
          middle = w.slice(1, li).join(' ');
        }
      }
      var okTok = function (x) { return !x || /^[A-Za-z][A-Za-z' .\-]*$/.test(x); };
      if (!last || last.replace(/[^A-Za-z]/g, '').length < 2 || !okTok(last)) return null;
      /* Status/anatomy vocabulary can survive the comma fast path as a whole
         name (live 2026-07-15: a 'Spine,No' hold row minted patient 'No
         Spine'). A given or family name is never schedule vocabulary. */
      if (STOPX.test(last.replace(/[.]/g, '')) || (first && STOPX.test(first.replace(/[.]/g, '')))) return null;
      if (!okTok(first) || (first && first.replace(/[^A-Za-z]/g, '').length < 2)) return null;
      if (!okTok(middle)) middle = '';
      var display = ((first ? first + ' ' : '') + (middle ? middle + ' ' : '') + last).replace(/\s+/g, ' ').trim();
      return { first: first, middle: middle, last: last, suffix: suffix, nickname: nickname, display: display, confident: !!(first && last) };
    }
    var bestRes = null;
    for (var si = 0; si < segs.length; si++) {
      var r = parseSeg(segs[si]);
      if (r && r.confident) return r;
      if (r && !bestRes) bestRes = r;
    }
    return bestRes;
  } catch (e) { return null; }
}

async function mlsSchedDomInline(doc, CFG){
  var out={appts:[],providers:[],diag:{strategy:'dom',via:'',tables:0,rowsScanned:0,apptCount:0,providerCount:0,providerNames:[],credsSeen:[],nameShadow:{checked:0,differs:0,canonicalRejected:0,canonicalAdded:0,samples:[]}}};
  var ACTION_GUARD=arguments.length>2?arguments[2]:null;
  var __scheduleGuarded=ACTION_GUARD!=null;
  var __scheduleGuard=Object.freeze({deadline:Number(ACTION_GUARD&&ACTION_GUARD.deadline||0),token:String(ACTION_GUARD&&ACTION_GUARD.token||'')});
  var __scheduleSweepRaw=(CFG&&CFG.__maxSweepMs!=null)?Number(CFG.__maxSweepMs):30000;
  if(!Number.isFinite(__scheduleSweepRaw))__scheduleSweepRaw=30000;
  var __scheduleSweepMs=Math.max(0,Math.min(45000,__scheduleSweepRaw));
  var __scheduleSweepDeadline=Date.now()+__scheduleSweepMs;
  if(__scheduleGuarded)__scheduleSweepDeadline=Math.min(__scheduleSweepDeadline,__scheduleGuard.deadline);
  function __scheduleActionAllowed(){return (!__scheduleGuarded||!!__scheduleGuard.token&&Number.isFinite(__scheduleGuard.deadline)&&Date.now()<__scheduleGuard.deadline)&&Date.now()<__scheduleSweepDeadline;}
  function __scheduleActionSleep(ms){if(!__scheduleActionAllowed())return Promise.resolve(false);var left=Math.max(0,__scheduleSweepDeadline-Date.now()),wait=Math.min(left,Math.max(0,Number(ms||0)));return new Promise(function(r){setTimeout(function(){r(__scheduleActionAllowed());},wait);});}
  if(!__scheduleActionAllowed()){out.diag.budgetExpired=true;out.diag.reason='schedule-request-timeout';out.diag.requestToken=__scheduleGuard.token||'';return out;}
  var _nameShadowSeen={}; /* v2.9.13: checked = DISTINCT raw rows, not parser invocations (Codex counter fix) */
  try{
    var RT=/\b(\d{1,2}):(\d{2})\s*([ap]\.?\s?m\.?)?\b/i, RTG=/\b\d{1,2}:\d{2}\s*(?:[ap]\.?\s?m\.?)?\b/gi;
    var RC=/(?:^|[^A-Za-z])(MD|DO|NP|PA-?C?|APRN|FNP|DNP|AGNP|WHNP|PMHNP|RN|LPN|DPM|DDS|DMD|PHD|PSY\.?D|MBBS|CNM|CRNA|OD|LCSW|LPC)(?:[^A-Za-z]|$)/;
    var CI=/^(md|do|np|pa|pac|aprn|fnp|dnp|agnp|whnp|pmhnp|rn|lpn|dpm|dds|dmd|phd|psyd|mbbs|cnm|crna|od|lcsw|lpc)$/;
    var RA=/\bappointment/i, RN=/([A-Z][A-Za-z'’-]+)\s*,\s*([A-Z][A-Za-z'’-]+)/;
    var STOP=/^(am|pm|new|est|established|office|visit|tele|telehealth|video|phone|follow|followup|fu|consult|consultation|annual|physical|wellness|exam|sick|nurse|lab|labs|injection|inj|procedure|recheck|np|min|mins|minute|minutes|arrived|checkedin|checked|scheduled|confirmed|cancelled|canceled|noshow|no|show|room|status|reason|provider|patient|time|type|resource|rendering|department|dept|appt|appts|total|appointments)$/i;
    /* v2.9.7: generational suffixes after a comma are NOT a first name. Live bug:
       dashboard row "Lawrence J Dipietrae, Jr 82yo M | 07-29-1943 ..." -> the
       "Last, First" regex matched "Dipietrae, Jr" and the FIRST NAME WAS LOST
       (downstream open/identity honestly refused). Strip ", Jr"-style suffixes
       BEFORE any name-shape matching. */
    var SFXRE=/,\s*(?:jr|sr|ii|iii|iv|esq|junior|senior)\.?(?=[^A-Za-z]|$)/gi;
    function cl(s){return String(s==null?'':s).replace(/\s+/g,' ').trim();}
    function ht(s){return RT.test(String(s));}
    /* v2.9.12 TIME NORMALIZATION (owner bar: "times always accurate"): every
       meridian-bearing time leaves the scrape as canonical "H:MM AM/PM"
       ("4:00 pm" / "2:00PM" / "4:15 p.m." were all escaping in source format —
       the app's b242 meridian handling gets one consistent shape). Meridian-less
       times are NEVER guessed: passed through bare + counted in diag.bareTimes
       so the app's time_display/start_local enrichment knows to take over. */
    function ft(s){var m=String(s).match(RTG);if(!m)return '';var t=cl(m[0]);var p=/^(\d{1,2}):(\d{2})\s*([ap])/i.exec(t);if(p)return String(+p[1])+':'+p[2]+' '+p[3].toUpperCase()+'M';out.diag.bareTimes=(out.diag.bareTimes||0)+1;return t;}
    function cp(s){var t=cl(s);t=t.replace(/[•‣▪●>*\-–—]+\s*$/g,'');t=t.replace(/[-–—:|(]*\s*\d+\s*appointments?\b.*$/i,'');t=t.replace(/\b\d+\s*appointments?\b/i,'');t=t.replace(/\(\s*\d+\s*\)\s*$/,'');t=t.replace(/[\s,;:|–—-]+$/,'');t=t.replace(/\s*[Cc]lose\s*$/,'');return cl(t);}
    function pui(s){var t=cl(s).toLowerCase().replace(/[\s:|\-–—]+$/g,'').trim();return /^(?:(?:appointment|appt)\s+)?(?:date(?:\s*(?:\/|&|and)\s*time)?|time|type|status|duration|reason|patient(?:\s+(?:name|details?))?|provider(?:\s+name)?|rendering\s+provider|resource(?:\s+name)?|department(?:\s+name)?|schedule|scheduling|location|room)$/i.test(t);}
    function lh(line){var t=cl(line);if(!t||t.length>80)return false;if(ht(t))return false;var hc=RC.test(t),ha=RA.test(t),hn=RN.test(t)||/[A-Z][a-z]+[ _][A-Z][a-z]+/.test(t);if((hc&&hn)||(ha&&hn))return true;if(hc&&RN.test(t)&&t.split(/\s+/).length<=5)return true;return false;}
    /* v2.9.13 shadow (Codex counter fix): checked counts DISTINCT normalized raw
       rows once; canonical FALSE NEGATIVES count as disagreements (kind:
       canonical-reject) instead of vanishing; canonical-only names are
       canonical-add. samples hold patient names -> BROWSER-LOCAL ONLY, never
       telemetry/server logs. NEVER changes output. */
    function _pnShadow(line,r){try{
      if(typeof mlsParseName!=='function')return;
      var raw=String(line||'').replace(/\s+/g,' ').trim();
      var key=raw.toLowerCase();
      if(!key||_nameShadowSeen[key])return;
      _nameShadowSeen[key]=1;
      var N=out.diag.nameShadow,ps=mlsParseName(raw);
      var oldName=String(r||'').replace(/\s+/g,' ').trim();
      var newName=(ps&&ps.confident)?ps.display:'';
      N.checked++;
      if(oldName.toLowerCase()!==newName.toLowerCase()){
        N.differs++;
        if(!newName)N.canonicalRejected++;
        if(!oldName)N.canonicalAdded++;
        if(N.samples.length<10)N.samples.push({kind:!newName?'canonical-reject':(!oldName?'canonical-add':'rename'),o:oldName,n:newName});
      }
    }catch(_eS){}}
    function pn(line){var r=_pnCore(line);_pnShadow(line,r);return r;}
    function _pnCore(line){var t=cl(line).replace(SFXRE,' ').replace(/\s+/g,' ');var mc=t.match(RN);if(mc)return cl(mc[0]);var af=t.replace(RTG,' ');var ws=af.split(/\s+/).filter(function(w){return /[A-Za-z]/.test(w);});var pk=[];for(var i=0;i<ws.length&&pk.length<3;i++){var w=ws[i].replace(/[^A-Za-z'’-]/g,'');if(!w)continue;if(STOP.test(w)||CI.test(w.toLowerCase())){if(pk.length)break;else continue;}if(/^[A-Z]/.test(w))pk.push(w);else if(pk.length)break;}return pk.join(' ');}
    function tx(el){try{return cl(el.textContent);}catch(e){return '';}}
    /* Schedule demographics are identity proof, so they are stricter than
       display parsing: only this exact row's semantic attributes or explicit
       DOB/MRN labels qualify. Bare dates/numbers (including appointment and
       reason dates) are ignored. Conflicting values fail closed. */
    function _scheduleRowProofD(root){
      var outD={dob:'',mrn:'',dobConflict:false,mrnConflict:false};
      function dobD(value){var raw=cl(value),m=/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/.exec(raw);if(!m){var iso=/^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(raw);if(iso)m=[iso[0],iso[2],iso[3],iso[1]];}if(!m)return '';var y=+m[3],mo=+m[1],d=+m[2],now=new Date(),exact=new Date(Date.UTC(y,mo-1,d));if(y<1900||exact.getUTCFullYear()!==y||exact.getUTCMonth()!==mo-1||exact.getUTCDate()!==d||exact.getTime()>now.getTime())return '';return('0'+mo).slice(-2)+'/'+('0'+d).slice(-2)+'/'+y;}
      function mrnD(value){var v=cl(value);if(!v||v.length>48||!/[0-9]/.test(v)||!/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(v))return '';if(/^\d{4}-\d{1,2}-\d{1,2}$/.test(v)||/^\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{4}$/.test(v))return '';return v;}
      function putD(kind,value){var v=kind==='dob'?dobD(value):mrnD(value),conflict=kind+'Conflict';if(!v||outD[conflict])return;if(outD[kind]&&outD[kind].toLowerCase()!==v.toLowerCase()){outD[kind]='';outD[conflict]=true;}else outD[kind]=v;}
      function labelsD(value){var s=cl(value);s.replace(/\b(?:DOB|Date\s+of\s+Birth|Birth\s+Date)\s*(?:is\s*)?[:#-]?\s*(\d{1,4}[\/\-.]\d{1,2}[\/\-.]\d{1,4})\b/gi,function(whole,v){putD('dob',v);return whole;});s.replace(/\b(?:MRN|Medical\s+Record(?:\s+(?:Number|No\.?|#|ID))?)\s*(?:is\s*)?[:#-]?\s*([A-Za-z0-9][A-Za-z0-9._-]{2,47})\b/gi,function(whole,v){putD('mrn',v);return whole;});
        /* Archive-proven legacy chip (every classic grid, live receipts 44/52 and
           30/38): "NNyo M|F … MM-DD-YYYY" renders DOB UNLABELED next to age+sex.
           The pair is SELF-VALIDATING — accept the date only when the printed
           age equals the age computed from it (±1 yr, handles the birthday
           straddle). Appointment/reason dates never ride an age+sex chip, so
           the bare-date fail-close is preserved. */
        s.replace(/\b(\d{1,3})\s*(?:yo|y\/o|yrs?\.?|years?(?:\s*old)?)\s*[MF]\b[^0-9A-Za-z]{0,12}(\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{4}|\d{4}-\d{1,2}-\d{1,2})/gi,function(whole,age,v){
          var norm=dobD(v);if(!norm)return whole;
          var pm=/^(\d{2})\/(\d{2})\/(\d{4})$/.exec(norm);if(!pm)return whole;
          var now=new Date(),born=new Date(Date.UTC(+pm[3],+pm[1]-1,+pm[2]));
          var years=Math.floor((now.getTime()-born.getTime())/31557600000);
          if(Math.abs(years-(+age))<=1)putD('dob',v);
          return whole;
        });}
      if(!root)return outD;
      var nodes=[root];try{nodes=nodes.concat([].slice.call(root.querySelectorAll('[data-patient-dob],[data-dob],[data-date-of-birth],[data-birth-date],[data-patient-mrn],[data-mrn],[data-medical-record-number],[aria-label],[data-testid]')).slice(0,80));}catch(_eDn){}
      nodes.forEach(function(node){function attrD(name){try{return node.getAttribute&&node.getAttribute(name);}catch(_eDa){return '';}}['data-patient-dob','data-dob','data-date-of-birth','data-birth-date'].forEach(function(name){var v=attrD(name);if(v!=null&&cl(v))putD('dob',v);});['data-patient-mrn','data-mrn','data-medical-record-number'].forEach(function(name){var v=attrD(name);if(v!=null&&cl(v))putD('mrn',v);});var aria=attrD('aria-label');if(aria)labelsD(aria);var testId=cl(attrD('data-testid'));if(/(?:^|[-_])(patient[-_]?)?(?:dob|date[-_]?of[-_]?birth|birth[-_]?date)$/i.test(testId))putD('dob',tx(node)||attrD('value'));if(/(?:^|[-_])(patient[-_]?)?(?:mrn|medical[-_]?record[-_]?(?:number|id))$/i.test(testId))putD('mrn',tx(node)||attrD('value'));});
      labelsD(tx(root));return outD;
    }
    function _mergeScheduleProofD(target,proof){if(!target||!proof)return target;['dob','mrn'].forEach(function(kind){var conflict=kind+'Conflict';if(target[conflict]||proof[conflict]){target[kind]='';target[conflict]=true;return;}if(proof[kind]&&target[kind]&&String(proof[kind]).toLowerCase()!==String(target[kind]).toLowerCase()){target[kind]='';target[conflict]=true;}else if(!target[kind]&&proof[kind])target[kind]=proof[kind];});return target;}
    function _scheduleProofKeyD(row){if(row&&row.mrn)return'mrn:'+String(row.mrn).toLowerCase().replace(/[^a-z0-9]/g,'');if(row&&row.dob)return'dob:'+String(row.dob).replace(/[^0-9]/g,'');return'';}
    var provSet={},provOrder=[],credSet={};
    function np(p){p=cp(p);
      /* v2.9.15 live pull: dashboard table headers such as "Appointment Date"
         are column labels, never clinicians.  Keep unattributed rows honest
         instead of poisoning provider filters with UI chrome. */
      if(pui(p))return '';
      /* v2.9.7 LOCATION GUARD: "PA"/"MD" are US states AND credentials, so a
         location line like "Newtown Square, PA" passed the credential test and
         became a PROVIDER (live capture). If the candidate is exactly
         "<words>, PA|MD" and the part before the comma carries NO OTHER
         credential and no middle initial, treat it as a location and emit '' —
         an unattributed appt is honest; a location-provider poisons every
         provider dropdown. (Tradeoff: a plain "Marcus Welby, MD" header in this
         LAST-RESORT lane is also skipped; the primary structure/coord lanes
         match providers by credential-anchored header patterns and are
         unaffected.) */
      var lm=/^([A-Za-z .'’\-]+),\s*(PA|MD)\.?$/.exec(p||'');
      if(lm){var pre=lm[1];var hasCred=RC.test(pre);var hasMI=/\b[A-Z]\.?\s/.test(pre.replace(/^[A-Z]/,'x'));if(!hasCred&&!hasMI)return '';}
      if(p&&/[A-Za-z]/.test(p)&&p.length<=60&&!provSet[p.toLowerCase()]){provSet[p.toLowerCase()]=1;provOrder.push(p);}if(p){var cm=p.match(RC);if(cm&&cm[1])credSet[cm[1].toUpperCase()]=1;}return p;}
    if(!doc||!doc.querySelectorAll)return out;
    try{out.diag.scheduleStructure=!!doc.querySelector('[class*="PatientAppointment_appointment-container"], [class*="ScheduleColumn_schedule-column"], [data-testid*="schedule-grid" i], [aria-label*="schedule grid" i], [class~="appointments-container"], [class~="filled-appointment-row"]');}catch(_eSs){out.diag.scheduleStructure=false;}
    /* Non-PHI structure diagnostics for athenaOne's legacy day grid. */
    try{
      out.diag.legacyContainers=doc.querySelectorAll('[class~="appointments-container"]').length;
      out.diag.legacyFilledRows=doc.querySelectorAll('[class~="filled-appointment-row"]').length;
      out.diag.providerHeaderShapes=[].slice.call(doc.querySelectorAll('div,span,h1,h2,h3,h4,th,td')).filter(function(el){var t=tx(el);return t&&t.length<=90&&lh(t)&&el.querySelectorAll('*').length<=6;}).slice(0,12).map(function(el){return{tag:String(el.tagName||'').toLowerCase(),cls:String(el.className||'').replace(/\s+/g,' ').trim().slice(0,140),parentTag:String(el.parentElement&&el.parentElement.tagName||'').toLowerCase(),parentCls:String(el.parentElement&&el.parentElement.className||'').replace(/\s+/g,' ').trim().slice(0,140)};});
    }catch(_eShape){}
    /* Strong legacy provider-scope proof: every non-empty legacy schedule
       container owns exactly one provider header and every container agrees. */
    try{
      var _legacyLists=[].slice.call(doc.querySelectorAll('[class~="appointments-container"]')),_legacyNames={},_legacyNameOrder=[],_legacyRows=0,_legacyBoundRows=0,_legacySafe=!!_legacyLists.length;
      _legacyLists.forEach(function(list){var rows=[].slice.call(list.querySelectorAll('[class~="filled-appointment-row"]'));if(!rows.length)return;_legacyRows+=rows.length;var local={},localOrder=[];[].slice.call(list.querySelectorAll('[class~="appointment-header2"]')).forEach(function(header){var raw=tx(header),p=lh(raw)?cp(raw):'';if(p&&!local[p.toLowerCase()]){local[p.toLowerCase()]=1;localOrder.push(p);}});if(localOrder.length!==1){_legacySafe=false;return;}var name=localOrder[0],nk=name.toLowerCase();if(!_legacyNames[nk]){_legacyNames[nk]=1;_legacyNameOrder.push(name);}_legacyBoundRows+=rows.length;});
      if(_legacySafe&&_legacyRows>0&&_legacyBoundRows===_legacyRows&&_legacyNameOrder.length===1){var _legacyName=_legacyNameOrder[0],_legacyKey=_legacyName.toLowerCase();out.diag.singleProviderScope=true;out.diag.singleProviderName=_legacyName;out.diag.legacyScopeContainers=_legacyLists.length;if(!provSet[_legacyKey]){provSet[_legacyKey]=1;provOrder.push(_legacyName);}var _legacyCred=_legacyName.match(RC);if(_legacyCred&&_legacyCred[1])credSet[_legacyCred[1].toUpperCase()]=1;}
    }catch(_eLegacyScope){}
    /* v2.9.8: NEVER parse schedule data out of the staff-messaging/coordinator/
       letters frames. Live catch: the stm.esp staff-message thread "LAURA
       ZAKORCHEMNY 4:00 pm meeting Matthew Schaeffer" was parsed into a 4:00 PM
       APPOINTMENT for the office manager — a fabricated patient on the pulled
       schedule. Schedule data may only come from schedule-shaped frames (the
       chart-identity readers already treat these frames as junk). */
    try{var _pth=String((doc.location&&doc.location.pathname)||'');if(/stm\.esp|\/coordinator\/|messaging|letters/i.test(_pth)){out.diag.skipped='non-schedule-frame';return out;}}catch(_eFx){}
    /* v2.9.21 LEGACY DAY-GRID STRATEGY. The live Athena dashboard can render
       the same <ul.appointments-container> twice (alternate sort modes). The
       generic grouped-DOM fallback both counted those hidden copies and
       discarded unusually detailed appointment rows at 300 characters. Read
       only Athena's explicit legacy appointment rows here, with no arbitrary
       text-length ceiling; remove capacity slots; reconcile duplicate copies;
       and keep every unresolved non-slot row in candidate accounting so an
       ambiguous roster fails closed instead of silently importing a subset. */
    try{
      var _legacyGridListsL=[].slice.call(doc.querySelectorAll('[class~="appointments-container"]'));
      var _legacyGridRowsL=[].slice.call(doc.querySelectorAll('[class~="filled-appointment-row"]'));
      if(_legacyGridListsL.length&&_legacyGridRowsL.length){
        var _legacyObsL=[],_legacyUnresolvedL=[],_legacyProvidersL={},_legacyProviderOrderL=[];
        var _legacyRawObsL=0,_legacySlotsL=0,_legacyAllBoundL=true,_legacyHeaderProofL=true;
        function _legacyNormL(v){return cl(v).toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();}
        function _legacyProviderL(raw){
          var p=lh(raw)?cp(raw):'';if(!p)return '';
          var k=_legacyNormL(p);if(k&&!_legacyProvidersL[k]){_legacyProvidersL[k]=p;_legacyProviderOrderL.push(p);}
          if(k&&!provSet[k]){provSet[k]=1;provOrder.push(p);}var cm=p.match(RC);if(cm&&cm[1])credSet[cm[1].toUpperCase()]=1;return p;
        }
        function _legacyAttrL(row,names){
          var nodes=[row];try{nodes=nodes.concat([].slice.call(row.querySelectorAll('[data-appointment-id],[data-appt-id],[data-appointmentid],[appointmentid],[data-provider-id],[data-rendering-provider-id],[data-resource-id],a[href]')).slice(0,40));}catch(_eAN){}
          for(var ni=0;ni<nodes.length;ni++)for(var ai=0;ai<names.length;ai++){try{var av=nodes[ni].getAttribute&&nodes[ni].getAttribute(names[ai]);if(av!=null&&String(av).trim())return String(av).trim();}catch(_eAV){}}
          for(var hi=0;hi<nodes.length;hi++){var href='';try{href=nodes[hi].getAttribute&&nodes[hi].getAttribute('href')||'';}catch(_eAH){}if(!href)continue;var re=names[0]==='data-provider-id'?/[?&#/](?:providerid|provider_id|provider|resourceid)[=\/:]([a-z0-9_-]{2,})/i:/[?&#/](?:appointmentid|appointment_id|appointment|apptid)[=\/:]([a-z0-9_-]{2,})/i;var hm=String(href).match(re);if(hm)return hm[1];}
          return '';
        }
        function _legacyReasonL(row){
          try{var re=row.querySelector('[class*="reason"], [data-testid*="reason"], [aria-label*="reason"]');var rt=re&&tx(re);return rt&&rt.length<=500?rt:'';}catch(_eLR){return '';}
        }
        function _legacySlotL(raw){
          var tail=cl(String(raw||'').replace(RTG,' '));
          return /^(?:(?:\d+\s*(?:min(?:ute)?s?|mins?)\s*)?)(?:open|blocked?|hold|unavailable|lunch|closed|administrative|admin|reserved|no\b[\s,]*(?:spine|surger(?:y|ies)|clinic|cases?|appts?|appointments?|patients?|add[\s-]?ons?)|(?:spine|surger(?:y|ies)|clinic|cases?|appts?|appointments?)\s*,\s*no)(?:\b|\s|$)/i.test(tail);
        }
        _legacyGridListsL.forEach(function(list){
          var rows=[];try{rows=[].slice.call(list.querySelectorAll('[class~="filled-appointment-row"]'));}catch(_eLRs){}
          if(!rows.length)return;
          var local=[],localSeen={};try{[].slice.call(list.querySelectorAll('[class~="appointment-header2"]')).forEach(function(h){var p=_legacyProviderL(tx(h)),k=_legacyNormL(p);if(k&&!localSeen[k]){localSeen[k]=1;local.push(p);}});}catch(_eLH){}
          if(local.length!==1)_legacyHeaderProofL=false;
          var provider=local.length===1?local[0]:(out.diag.singleProviderName||'');
          if(!provider)_legacyAllBoundL=false;
          rows.forEach(function(row){
            out.diag.rowsScanned++;
            var raw=tx(row),tm=ft(raw),appointmentId=_legacyAttrL(row,['data-appointment-id','data-appt-id','data-appointmentid','appointmentid']),providerId=_legacyAttrL(row,['data-provider-id','data-rendering-provider-id','data-resource-id','providerid']);
            if(_legacySlotL(raw)){_legacySlotsL++;return;}
            _legacyRawObsL++;
            var parsed=null,name='';try{parsed=mlsParseName(raw);}catch(_ePN){}
            if(parsed&&parsed.confident)name=cl(parsed.display);else name=cl(pn(raw));
            var nameTokens=name.replace(/[^A-Za-z'â€™\-]+/g,' ').trim().split(/\s+/).filter(Boolean);
            if(!tm||nameTokens.length<2){_legacyUnresolvedL.push({time:tm||'',provider:provider||'',appointmentId:appointmentId||'',rawKey:_legacyNormL(raw)});return;}
            var rowProof=_scheduleRowProofD(row);
            _legacyObsL.push({time:tm,name:name,provider:provider||'',providerKey:_legacyNormL(provider),appointmentId:appointmentId||'',providerId:providerId||'',reason:_legacyReasonL(row),dob:rowProof.dob||'',mrn:rowProof.mrn||'',dobConflict:rowProof.dobConflict===true,mrnConflict:rowProof.mrnConflict===true});
          });
        });
        var _legacyByIdL={},_legacyByKeyL={},_legacyRowsFinalL=[];
        _legacyObsL.forEach(function(a){
          var base=a.time+'|'+_legacyNormL(a.name),key=base+'|'+(a.providerKey||'')+'|'+_scheduleProofKeyD(a),prior=null;
          if(a.appointmentId&&_legacyByIdL[a.appointmentId])prior=_legacyByIdL[a.appointmentId];
          if(!prior&&_legacyByKeyL[key])prior=_legacyByKeyL[key];
          if(prior){if(!prior.provider&&a.provider){prior.provider=a.provider;prior.providerKey=a.providerKey;}if(!prior.providerId&&a.providerId)prior.providerId=a.providerId;if(!prior.appointmentId&&a.appointmentId)prior.appointmentId=a.appointmentId;if(!prior.reason&&a.reason)prior.reason=a.reason;_mergeScheduleProofD(prior,a);return;}
          _legacyByKeyL[key]=a;if(a.appointmentId)_legacyByIdL[a.appointmentId]=a;_legacyRowsFinalL.push(a);
        });
        var _legacyAttributedL={};_legacyRowsFinalL.forEach(function(a){if(a.providerKey)_legacyAttributedL[a.time+'|'+_legacyNormL(a.name)+'|'+_scheduleProofKeyD(a)]=1;});
        _legacyRowsFinalL=_legacyRowsFinalL.filter(function(a){return !!a.providerKey||!_legacyAttributedL[a.time+'|'+_legacyNormL(a.name)+'|'+_scheduleProofKeyD(a)];});
        var _legacyUnresolvedSeenL={},_legacyUnresolvedCountL=0;
        _legacyUnresolvedL.forEach(function(a){var k=a.appointmentId?('id:'+a.appointmentId):('row:'+a.time+'|'+_legacyNormL(a.provider)+'|'+a.rawKey);if(!_legacyUnresolvedSeenL[k]){_legacyUnresolvedSeenL[k]=1;_legacyUnresolvedCountL++;}});
        out.appts=_legacyRowsFinalL.map(function(a){return{time:a.time,name:a.name,provider:a.provider||'',providerId:a.providerId||'',appointmentId:a.appointmentId||'',reason:a.reason||'',dob:a.dob||'',mrn:a.mrn||''};});
        out.providers=_legacyProviderOrderL.slice();
        var _legacyRosterCompleteL=_legacyHeaderProofL&&_legacyAllBoundL&&out.providers.length>0;
        out.providerRoster=out.providers.map(function(raw){return{stableKey:'athena:'+_legacyNormL(raw),raw:raw,name:raw,source:'athena-schedule-header'};});
        out.providerRosterReceipt={complete:!!_legacyRosterCompleteL,partial:!_legacyRosterCompleteL,reason:_legacyRosterCompleteL?'complete':(!out.providers.length?'no-provider-headers':'legacy-unverified'),expectedCount:_legacyRosterCompleteL?out.providers.length:null,observedCount:out.providers.length,horizontalScrollable:false,reachedEnd:true,capReached:false,budgetExpired:false,restored:true,boundsStable:true,steps:1};
        out.diag.via='legacy-day-grid';out.diag.strategy='legacy-day-grid';out.diag.apptCount=out.appts.length;out.diag.candidateCount=out.appts.length+_legacyUnresolvedCountL;out.diag.parsedCount=out.appts.length;out.diag.unnamedCount=_legacyUnresolvedCountL;
        out.diag.rawCandidateObservations=_legacyRawObsL;out.diag.confidentCandidateCount=_legacyObsL.length;out.diag.duplicateRowsRemoved=Math.max(0,_legacyRawObsL-out.diag.candidateCount);out.diag.slotRowsRemoved=_legacySlotsL;
        out.diag.providerCount=out.providers.length;out.diag.providerNames=out.providers.slice();out.diag.providerRosterReceipt=out.providerRosterReceipt;
        if(out.appts.length||_legacyUnresolvedCountL)return out;
      }
    }catch(_legacyGridErrL){out.diag.legacyGridErr=String(_legacyGridErrL&&_legacyGridErrL.message||_legacyGridErrL).slice(0,100);}
    // === v1.48 STRUCTURE STRATEGY (athenaOne): appts are .PatientAppointment_appointment-container
    // buttons (UNIQUE id) inside per-provider .ScheduleColumn_schedule-column sections. Dedup by button id
    // (scroll-invariant); assign provider via the appt's ancestor column SECTION matched to its header by
    // the SECTION's x-center. Far more reliable than per-cell coordinate bucketing on the virtualized grid. ===
    try{
      if(doc.querySelector && doc.querySelector('[class*="PatientAppointment_appointment-container"], [class*="ScheduleColumn_schedule-column"]')){
        function _sleepS(ms){return __scheduleActionSleep(ms);}
        var _prS=(CFG&&CFG.provReSource)?new RegExp(CFG.provReSource):/^[A-Z][A-Za-z'’.\-]+_[A-Za-z].*_(MD|DO|PA-?C|NP|CRNA|APRN|DPM|DDS|DMD|CRNP)\b/;
        var _prCS=/([A-Z][A-Za-z'’.\-]+_[A-Za-z][A-Za-z'’.\-]*_(?:MD|DO|PA-?C|NP|CRNA|APRN|DPM|DDS|DMD|CRNP))\b/;
        function _nmS(t0){
          var r='';
          /* The live Athena grid renders names as "Last, First".  The legacy
             structure-lane regex captured only the text after the comma, so
             virtualized/offscreen rows were left with a one-token name and
             silently rejected later.  Use the shared, adversarially-tested
             parser first and retain the legacy parser only as a compatibility
             fallback for older Athena markup. */
          try{var p=mlsParseName(t0);if(p&&p.confident&&p.display)r=cl(p.display);}catch(_eN){}
          if(!r)r=_nmSCore(t0);
          _pnShadow(t0,r);return r;
        } /* v2.9.20 canonical live schedule names */
        function _nmSCore(t){t=cl(t).replace(SFXRE,' ').replace(/\s+/g,' ');var m=t.match(/,\s*([A-Z][A-Za-z'’.\-]+(?:\s+[A-Z][A-Za-z'’.\-]*)?)\s*(?:\(|$)/);if(m)return cl(m[1]);var m2=t.match(/([A-Z][A-Za-z'’-]+)\s*,\s*([A-Z][A-Za-z'’-]+)/);if(m2)return cl(m2[0]);return _pnCore(t);/* v2.9.9 (Codex E1 follow-up): comma-less container names no longer come back EMPTY — fall through to the suffix/stop-word-aware token parser */}
        /* v2.9.3 (owner: op-note auto-match): the appointment container also holds
           the appointment TYPE / reason-for-visit (e.g. "Left Knee Injection",
           "Genicular Nerve Block", "New Patient"). We keep it as `reason` so the
           app's op-note template auto-matcher (which scores against reason) has
           something to score. Read-only, additive; strips time/name/age/dob/mrn/
           status, leaving the type text. Per-container so it is not confused with
           another patient's row (unlike a flat-text parse). */
        function _reasonS(t){try{var nm=_nmS(t);var s=' '+cl(t)+' ';s=s.replace(RTG,' ');if(nm){nm.split(/[\s,]+/).forEach(function(w){w=w.replace(/[^A-Za-z]/g,'');if(w.length>1){try{s=s.replace(new RegExp('\\b'+w+'\\b','ig'),' ');}catch(_e){}}});}s=s.replace(/\b[01]?\d[\/\-.][0-3]?\d[\/\-.]\d{2,4}\b/g,' ');s=s.replace(/\b\d{1,3}\s*(?:yo|y\/o|yrs?|years?\s*old)\b/gi,' ');s=s.replace(/#\s?\d{3,}/g,' ').replace(/\b\d{2,}\b/g,' ');s=s.replace(/\b(arrived|checked\s*in|checked\s*out|scheduled|confirmed|cancell?ed|no\s*show|room|status|self\s*pay|copay|balance|male|female|mins?|minutes?)\b/gi,' ');s=s.replace(/[^A-Za-z0-9\/&'\- ]/g,' ').replace(/\s+/g,' ').trim();return s.slice(0,120);}catch(_e){return '';}}
        function _hdrsS(){var hs=[].slice.call(doc.querySelectorAll('*')).filter(function(e){var t=cl(e.textContent);return _prS.test(t)&&t.replace(/\s/g,'').length<48&&e.children.length<=4;});var o=[],sn={};hs.forEach(function(e){try{var r=e.getBoundingClientRect();if(r.width>20&&r.width<520){var mm=cl(e.textContent).match(_prCS);if(mm){var nm=mm[1];if(!sn[nm]){sn[nm]=1;o.push({nm:nm,cx:r.left+r.width/2});}}}}catch(_e){}});return o;}
        var _candS={},_pendingS={},_provAllS={},_provOrderS=[],_rawCandidateObsS=0;
        function _noteProvS(raw){var n=cl(raw);if(!n)return '';var k=n.toLowerCase();if(!_provAllS[k]){_provAllS[k]=n;_provOrderS.push(n);}return n;}
        function _slotS(n){var z=cl(n).toLowerCase().replace(/[\-_\/|]+/g,' ').replace(/[()[\]{}:;,]+/g,' ').replace(/\s+/g,' ').trim();var h=/^(open|available|unavailable|block(?:ed)?|hold|reserved|lunch|break|admin(?:istrative)?|meeting|closed|buffer)\b/.exec(z);if(!h)return false;var rest=z.slice(h[0].length).replace(/\b\d{1,2}:\d{2}\s*(?:[ap]\.?m\.?)?\b/gi,' ').replace(/\b\d+(?:\.\d+)?\s*(?:min(?:ute)?s?|hrs?|hours?)?\b/gi,' ').replace(/\b(?:open|available|unavailable|block(?:ed)?|hold|reserved|lunch|break|admin(?:istrative)?|meeting|closed|buffer|slot|slots|time|appointment|appointments|appt|appts|capacity)\b/gi,' ').replace(/\s+/g,' ').trim();return !rest;}
        function _normS(v){return cl(v).toLowerCase().replace(/[^a-z0-9'\- ]+/g,' ').replace(/\s+/g,' ').trim();}
        function _anchorS(b,tm){
          var aid='';try{aid=cl(b.getAttribute('data-appointment-id')||b.getAttribute('data-appointmentid')||b.getAttribute('data-appt-id'));}catch(_eA){}
          if(aid)return{key:'appt:'+aid,strong:true,appointmentId:aid};
          var did='';try{did=cl(b.id||b.getAttribute('data-testid'));}catch(_eD){}
          if(did)return{key:'node:'+did+'|'+tm,strong:false,appointmentId:''};
          var pos='';try{var br=b.getBoundingClientRect();pos=Math.round(Number(br.top||0)/4)+'|'+Math.round(Number(br.left||0)/4);}catch(_eP){}
          return{key:'pos:'+tm+'|'+pos,strong:false,appointmentId:''};
        }
        function _visibleSigS(){
          var parts=[];try{[].slice.call(doc.querySelectorAll('[class*="PatientAppointment_appointment-container"]')).forEach(function(b){parts.push(cl(b.textContent).slice(0,160));});}catch(_eSig){}
          return parts.sort().join('\u001f');
        }
        function _collectS(forcedHdr){
          var hdr=(forcedHdr&&forcedHdr.length)?forcedHdr:_hdrsS(),valid=0,unresolved=0;
          hdr.forEach(function(h){_noteProvS(h.nm);});
          [].slice.call(doc.querySelectorAll('[class*="ScheduleColumn_schedule-column"]')).forEach(function(col){
            var r;try{r=col.getBoundingClientRect();}catch(_e){return;}if(r.width<40)return;
            var ccx=r.left+r.width/2,best='',bd=1e9;
            hdr.forEach(function(h){var dd=Math.abs(ccx-h.cx);if(dd<bd){bd=dd;best=h.nm;}});
            var prov=(best&&bd<r.width)?_noteProvS(best):'',provKey=_normS(prov);
            [].slice.call(col.querySelectorAll('[class*="PatientAppointment_appointment-container"]')).forEach(function(b){
              var t=cl(b.textContent),tm=ft(t),nm=_nmS(t);if(!tm||_slotS(nm||t))return;
              var anchor=_anchorS(b,tm),nameKey=_normS(nm);
              if(!nm||nameKey.split(/\s+/).filter(Boolean).length<2){
                var pend=_pendingS[anchor.key]||{time:tm,prov:prov,seen:0,strong:anchor.strong,appointmentId:anchor.appointmentId};
                pend.seen++;pend.prov=pend.prov||prov;_pendingS[anchor.key]=pend;unresolved++;return;
              }
              delete _pendingS[anchor.key];valid++;_rawCandidateObsS++;
              var proof=_scheduleRowProofD(b),logicalKey=anchor.appointmentId?('appt:'+anchor.appointmentId):('person:'+tm+'|'+nameKey+'|'+provKey+'|'+_scheduleProofKeyD(proof));
              var prior=_candS[logicalKey];
              if(!prior)_candS[logicalKey]={prov:prov,time:tm,name:nm,reason:_reasonS(t),appointmentId:anchor.appointmentId||'',base:tm+'|'+nameKey,providerKey:provKey,dob:proof.dob||'',mrn:proof.mrn||'',dobConflict:proof.dobConflict===true,mrnConflict:proof.mrnConflict===true};
              else{if(!prior.prov&&prov){prior.prov=prov;prior.providerKey=provKey;}if(!prior.reason)prior.reason=_reasonS(t);_mergeScheduleProofD(prior,proof);}
            });
          });
          return{valid:valid,unresolved:unresolved,signature:_visibleSigS()};
        }
        /* Athena virtualizes both provider columns and time rows. A horizontal
           pass followed by a vertical pass misses the bottom-right cells. Walk
           a bounded Cartesian product instead; success is impossible unless
           both bounds stay stable, every planned cell is visited, and both axes
           restore to the user's original position. */
        function _axisS(max,step,cap){max=Math.max(0,Number(max||0));step=Math.max(1,Number(step||1));var raw=[];for(var p=0;p<=max;p+=step)raw.push(Math.min(p,max));if(!raw.length||raw[raw.length-1]!==max)raw.push(max);var capped=raw.length>cap;if(capped)raw=raw.slice(0,cap-1).concat([max]);return{values:raw,capped:capped,max:max};}
        /* The caller's remaining absolute budget is authoritative. A short
           budget is never widened to the former 12-second minimum. */
        var _budgetEndS=__scheduleSweepDeadline;
        var _settleMaxS=Math.max(300,Math.min(1200,Number(CFG&&CFG.scrollWaitMs||780))),_settleBaseS=Math.min(220,_settleMaxS);
        var _scS=null,_allS=[].slice.call(doc.querySelectorAll('*')),_dvS=(doc.defaultView||window);
        for(var _si=0;_si<_allS.length;_si++){try{var _csS=_dvS.getComputedStyle(_allS[_si]);if(/(auto|scroll)/.test(_csS.overflowX)&&_allS[_si].scrollWidth>_allS[_si].clientWidth+50&&_allS[_si].clientWidth>300){if(!_scS||_allS[_si].scrollWidth>_scS.scrollWidth)_scS=_allS[_si];}}catch(_e){}}
        var _ogS=_scS?(_scS.scrollLeft||0):0,_hMaxS=_scS?Math.max(0,_scS.scrollWidth-_scS.clientWidth):0,_hAxisS=_axisS(_hMaxS,_scS?Math.max(160,Math.round(_scS.clientWidth*((CFG&&CFG.scrollStepFrac)||0.55))):1,24);
        var _vS=[],_vSeenS=[];
        _allS.forEach(function(el){try{var cs=_dvS.getComputedStyle(el),sh=el.scrollHeight||0,ch=el.clientHeight||0,shaped=!!el.querySelector('[class*="PatientAppointment_appointment-container"], [class~="filled-appointment-row"]');if(shaped&&/(auto|scroll)/.test(cs.overflowY)&&sh>ch+40&&ch>100)_vS.push({el:el,score:(sh-ch)+1000000});}catch(_e){}});
        try{var _deS=doc.scrollingElement;if(_deS&&_deS.scrollHeight>_deS.clientHeight+40&&_deS.querySelector('[class*="PatientAppointment_appointment-container"], [class~="filled-appointment-row"]'))_vS.push({el:_deS,score:(_deS.scrollHeight-_deS.clientHeight)+500000});}catch(_e){}
        _vS.sort(function(a,b){return b.score-a.score;});_vS=_vS.filter(function(v){if(_vSeenS.indexOf(v.el)>=0)return false;_vSeenS.push(v.el);return true;});
        var _vContainerCapS=_vS.length>2,_vWorkS=_vS.slice(0,2);if(!_vWorkS.length)_vWorkS=[{el:null,score:0}];
        var _coverageS={complete:false,reason:'unverified',horizontalScrollable:!!_scS,horizontalMax:_hMaxS,horizontalSteps:_hAxisS.values.length,verticalContainers:_vS.length,verticalContainersSwept:0,cellsPlanned:0,cellsVisited:0,positionsReached:0,settleRetries:0,axisCap:!!_hAxisS.capped,containerCap:_vContainerCapS,budgetExpired:false,boundsStable:true,restored:true};
        var _hSeenS={},_hReachedS=!_scS;
        for(var _viS=0;_viS<_vWorkS.length;_viS++){var _vsS=_vWorkS[_viS].el,_voyS=_vsS?(_vsS.scrollTop||0):0,_vmaxS=_vsS?Math.max(0,(_vsS.scrollHeight||0)-(_vsS.clientHeight||0)):0,_vAxisS=_axisS(_vmaxS,_vsS?Math.max(120,Math.round((_vsS.clientHeight||240)*0.65)):1,24);_coverageS.axisCap=_coverageS.axisCap||_vAxisS.capped;_coverageS.cellsPlanned+=_hAxisS.values.length*_vAxisS.values.length;var _finishedS=true;
          for(var _xiS=0;_xiS<_hAxisS.values.length&&_finishedS;_xiS++){
            if(!__scheduleActionAllowed()||Date.now()>=_budgetEndS){_finishedS=false;break;}
            var _xPosS=_hAxisS.values[_xiS],_xBeforeSigS=_visibleSigS(),_xBeforeActualS=_scS?Number(_scS.scrollLeft||0):0;
            if(_scS){if(!__scheduleActionAllowed()){_finishedS=false;break;}_scS.scrollLeft=_xPosS;if(!__scheduleActionAllowed()){_finishedS=false;break;}_scS.dispatchEvent(new Event('scroll',{bubbles:true}));}
            var _cachedHdrS=null;
            for(var _yiS=0;_yiS<_vAxisS.values.length;_yiS++){
              if(!__scheduleActionAllowed()||Date.now()>=_budgetEndS){_finishedS=false;break;}
              var _yPosS=_vAxisS.values[_yiS],_beforeSigS=_yiS===0?_xBeforeSigS:_visibleSigS(),_beforeXS=_yiS===0?_xBeforeActualS:(_scS?Number(_scS.scrollLeft||0):0),_beforeYS=_vsS?Number(_vsS.scrollTop||0):0;
              if(_vsS){if(!__scheduleActionAllowed()){_finishedS=false;break;}_vsS.scrollTop=_yPosS;if(!__scheduleActionAllowed()){_finishedS=false;break;}_vsS.dispatchEvent(new Event('scroll',{bubbles:true}));}
              if(!(await _sleepS(_settleBaseS))){_finishedS=false;break;}
              if(!__scheduleActionAllowed()){_finishedS=false;break;}
              var _liveHdrS=_hdrsS();if(_liveHdrS.length)_cachedHdrS=_liveHdrS;
              var _cellMetaS=_collectS(_cachedHdrS),_actualXS=_scS?Number(_scS.scrollLeft||0):0,_actualYS=_vsS?Number(_vsS.scrollTop||0):0;
              var _movedS=Math.abs(_actualXS-_beforeXS)>2||Math.abs(_actualYS-_beforeYS)>2;
              var _reachedS=(!_scS||Math.abs(_actualXS-_xPosS)<=4)&&(!_vsS||Math.abs(_actualYS-_yPosS)<=4);
              var _needsSettleS=_cellMetaS.unresolved>0||(_movedS&&_cellMetaS.signature===_beforeSigS)||!_reachedS;
              var _extraS=_settleMaxS-_settleBaseS;
              if(_needsSettleS&&_extraS>0&&Date.now()+_extraS<_budgetEndS&&__scheduleActionAllowed()){
                _coverageS.settleRetries++;if(!(await _sleepS(_extraS))){_finishedS=false;break;}
                if(!__scheduleActionAllowed()){_finishedS=false;break;}
                _liveHdrS=_hdrsS();if(_liveHdrS.length)_cachedHdrS=_liveHdrS;
                _cellMetaS=_collectS(_cachedHdrS);_actualXS=_scS?Number(_scS.scrollLeft||0):0;_actualYS=_vsS?Number(_vsS.scrollTop||0):0;
                _reachedS=(!_scS||Math.abs(_actualXS-_xPosS)<=4)&&(!_vsS||Math.abs(_actualYS-_yPosS)<=4);
              }
              _hSeenS[String(Math.round(_actualXS))]=1;if(Math.abs(_actualXS-_hMaxS)<=4)_hReachedS=true;
              if(_reachedS)_coverageS.positionsReached++;
              _coverageS.cellsVisited++;
            }
          }
          _coverageS.verticalContainersSwept++;if(!_finishedS)_coverageS.budgetExpired=true;
          if(_vsS){var _vEndMaxS=Math.max(0,(_vsS.scrollHeight||0)-(_vsS.clientHeight||0));if(_vEndMaxS!==_vmaxS)_coverageS.boundsStable=false;if(__scheduleActionAllowed()){_vsS.scrollTop=_voyS;if(__scheduleActionAllowed())_vsS.dispatchEvent(new Event('scroll',{bubbles:true}));else _coverageS.restored=false;if(Math.abs(Number(_vsS.scrollTop||0)-Number(_voyS||0))>2)_coverageS.restored=false;}else _coverageS.restored=false;}
          if(!_finishedS)break;
        }
        if(_scS){var _hEndMaxS=Math.max(0,_scS.scrollWidth-_scS.clientWidth);if(_hEndMaxS!==_hMaxS)_coverageS.boundsStable=false;if(__scheduleActionAllowed()){_scS.scrollLeft=_ogS;if(__scheduleActionAllowed())_scS.dispatchEvent(new Event('scroll',{bubbles:true}));else _coverageS.restored=false;if(Math.abs(Number(_scS.scrollLeft||0)-Number(_ogS||0))>2)_coverageS.restored=false;}else _coverageS.restored=false;}
        _coverageS.complete=!_coverageS.axisCap&&!_coverageS.containerCap&&!_coverageS.budgetExpired&&_coverageS.boundsStable&&_coverageS.restored&&_coverageS.cellsVisited===_coverageS.cellsPlanned&&_coverageS.positionsReached===_coverageS.cellsPlanned&&_coverageS.verticalContainersSwept===_vWorkS.length;_coverageS.reason=_coverageS.complete?'complete':(_coverageS.budgetExpired?'sweep-budget':(_coverageS.axisCap?'axis-cap':(_coverageS.containerCap?'container-cap':(!_coverageS.boundsStable?'bounds-changed':(!_coverageS.restored?'restore-failed':(_coverageS.positionsReached!==_coverageS.cellsPlanned?'scroll-position-unreached':'incomplete-cross-product'))))));
        var _hMetaS={scrollable:!!_scS,steps:Object.keys(_hSeenS).length,reachedEnd:!!_hReachedS,capReached:!!_hAxisS.capped,budgetExpired:!!(_coverageS.budgetExpired&&!_hReachedS),restored:!!_coverageS.restored,boundsStable:!!_coverageS.boundsStable,maxScroll:_hMaxS};
        try{var _dhS=doc.querySelector((CFG&&CFG.dateHdrSel)||'h1.fe_c_heading--subsection');if(_dhS){var _dS=new Date(cl(_dhS.textContent).replace(/^[A-Za-z]+,\s*/,''));if(!isNaN(_dS.getTime())){var _p2S=function(n){n=String(n);return n.length<2?'0'+n:n;};out.schedDate=_dS.getFullYear()+'-'+_p2S(_dS.getMonth()+1)+'-'+_p2S(_dS.getDate());}}}catch(_e){}
        var _rawRowsS=Object.keys(_candS).map(function(k){return _candS[k];}),_finalRowsS=[],_apptRowsS={},_baseRowsS={};
        _rawRowsS.forEach(function(a){
          if(a.appointmentId){
            var old=_apptRowsS[a.appointmentId];
            if(!old)_apptRowsS[a.appointmentId]=a;
            else{if(!old.prov&&a.prov){old.prov=a.prov;old.providerKey=a.providerKey;}if(!old.reason&&a.reason)old.reason=a.reason;_mergeScheduleProofD(old,a);}
          }else{var baseProof=a.base+'|'+_scheduleProofKeyD(a),g=_baseRowsS[baseProof]||(_baseRowsS[baseProof]={});var pk=a.providerKey||'';if(!g[pk])g[pk]=a;else{if(!g[pk].reason&&a.reason)g[pk].reason=a.reason;_mergeScheduleProofD(g[pk],a);}}
        });
        Object.keys(_apptRowsS).forEach(function(k){_finalRowsS.push(_apptRowsS[k]);});
        Object.keys(_baseRowsS).forEach(function(k){
          var g=_baseRowsS[k],ks=Object.keys(g),named=ks.filter(function(pk){return !!pk;});
          /* Athena often leaves a providerless hidden twin next to the same
             attributed appointment.  Discard that proven twin, but preserve
             two real provider keys for legitimate same-time cross-provider
             appointments. */
          (named.length?named:ks.slice(0,1)).forEach(function(pk){_finalRowsS.push(g[pk]);});
        });
        var _resolvedTPsS={};_finalRowsS.forEach(function(a){_resolvedTPsS[a.time+'|'+(a.providerKey||'')]=1;_resolvedTPsS[a.time+'|']=1;});
        var _unmS=0;Object.keys(_pendingS).forEach(function(k){var p=_pendingS[k],pk=_normS(p.prov);if(p.appointmentId&&_apptRowsS[p.appointmentId])return;if(!p.strong&&_resolvedTPsS[p.time+'|'+pk])return;if(p.strong||p.seen>=2)_unmS++;});
        out.appts=_finalRowsS.map(function(a){return{time:a.time,name:a.name,provider:a.prov||'',reason:a.reason||'',appointmentId:a.appointmentId||'',dob:a.dob||'',mrn:a.mrn||''};});
        if(out.appts.length||_unmS||_provOrderS.length){
          out.appts.forEach(function(a){if(a.provider)_noteProvS(a.provider);});
          var _declProvS=0;try{var _pmS,_ptS=String(doc.body&&doc.body.innerText||''),_preS=/\b(\d{1,3})\s+providers?\b/gi;while((_pmS=_preS.exec(_ptS)))_declProvS=Math.max(_declProvS,Number(_pmS[1]||0));}catch(_e){}
          out.providers=_provOrderS.slice();out.providerRoster=out.providers.map(function(raw){return{stableKey:'athena:'+raw.toLowerCase().replace(/\s+/g,' ').trim(),raw:raw,name:raw,source:'athena-schedule-header'};});
          var _provObservedS=out.providers.length,_provCompleteS=_provObservedS>0&&_hMetaS.reachedEnd&&_hMetaS.restored&&_hMetaS.boundsStable&&!_hMetaS.capReached&&!_hMetaS.budgetExpired&&(!_declProvS||_provObservedS>=_declProvS);
          var _provReasonS=_provCompleteS?'complete':(!_provObservedS?'no-provider-headers':(_hMetaS.capReached?'scroll-cap':(_hMetaS.budgetExpired?'scroll-budget':(!_hMetaS.boundsStable?'bounds-changed':(!_hMetaS.reachedEnd?'scroll-incomplete':(_declProvS&&_provObservedS<_declProvS?'declared-count-mismatch':'unverified'))))));
          /* A whole-body text scan ('N providers') is weak corroboration, not an authoritative total: it may only confirm an exactly matching observed sweep. On any mismatch the proven bounds sweep carries completeness and expectedCount stays null (observed>=declared still gates _provCompleteS above). */
          out.providerRosterReceipt={complete:!!_provCompleteS,partial:!_provCompleteS,reason:_provReasonS,expectedCount:(_declProvS&&_provObservedS===_declProvS)?_declProvS:null,observedCount:_provObservedS,horizontalScrollable:_hMetaS.scrollable,reachedEnd:_hMetaS.reachedEnd,capReached:_hMetaS.capReached,budgetExpired:_hMetaS.budgetExpired,restored:_hMetaS.restored,boundsStable:_hMetaS.boundsStable,steps:_hMetaS.steps};
          out.diag.via='structure-id';out.diag.strategy='structure-id';out.diag.apptCount=out.appts.length;out.diag.candidateCount=out.appts.length+_unmS;out.diag.parsedCount=out.appts.length;out.diag.unnamedCount=_unmS;
          out.diag.rawCandidateObservations=_rawCandidateObsS;out.diag.confidentCandidateCount=_rawRowsS.length;out.diag.duplicateRowsRemoved=Math.max(0,_rawRowsS.length-out.appts.length);
          out.diag.providerCount=out.providers.length;out.diag.providerNames=out.providers.slice();out.diag.providerRosterReceipt=out.providerRosterReceipt;out.diag.viewportCoverage=_coverageS;
          /* Provider headers alone must not suppress the older table/grouped
             fallbacks.  A non-empty structure result is returned only after
             at least one appointment (or a persistent unresolved row) exists. */
          if(out.appts.length||_unmS)return out;
        }
      }
    }catch(_seS){out.diag.structErr=String(_seS&&_seS.message||_seS).slice(0,100);}
    // === v1.46 COORD STRATEGY (scroll-scrape): athenaOne Day grid VIRTUALIZES columns — only appts
    // in the visible viewport are in the DOM. So scroll the grid horizontally in steps and at each
    // step read the currently-visible provider headers + appt cells, bucketing each appt to the
    // column whose x-range contains it. Dedupe across steps by provider|time|name. Captures ALL
    // providers. Falls through to the old strategies if this isn't that kind of grid. ===
    try{
      function mlsPad2(n){n=String(n);return n.length<2?('0'+n):n;}
      function mlsParseDate(s){try{var d=new Date(String(s).replace(/^[A-Za-z]+,\s*/,''));if(!isNaN(d.getTime()))return d.getFullYear()+'-'+mlsPad2(d.getMonth()+1)+'-'+mlsPad2(d.getDate());}catch(e){}return '';}
      function mlsSleep(ms){return __scheduleActionSleep(ms);}
      var _dh=doc.querySelector((CFG&&CFG.dateHdrSel)||'h1.fe_c_heading--subsection');
      if(!_dh){var _hs=[].slice.call(doc.querySelectorAll('h1,h2,[class*="heading"],[class*="date"]'));for(var _i=0;_i<_hs.length;_i++){var _t0=cl(_hs[_i].textContent);if(/^[A-Z][a-z]+day,\s+[A-Z][a-z]+\s+\d{1,2},\s+20\d\d/.test(_t0)){_dh=_hs[_i];break;}}}
      if(_dh)out.schedDate=mlsParseDate(cl(_dh.textContent));
      var _provRe=(CFG&&CFG.provReSource)?new RegExp(CFG.provReSource):/^[A-Z][A-Za-z'’.\-]+_[A-Za-z].*_(MD|DO|PA-?C|NP|CRNA|APRN|DPM|DDS|DMD)\b/;
      function _headCols(){
        var hs=[].slice.call(doc.querySelectorAll('*')).filter(function(e){var t=cl(e.textContent);return _provRe.test(t)&&t.replace(/\s/g,'').length<48&&e.children.length<=4;});
        var cols=[],seen={};
        hs.forEach(function(e){try{var r=e.getBoundingClientRect();if(r.width>20&&r.width<520){var nm=cp(cl(e.textContent));var key=nm.toLowerCase();if(nm&&!seen[key]){seen[key]=1;cols.push({name:nm,lo:r.left,rr:r.right});}}}catch(_e){}});
        cols.sort(function(a,b){return a.lo-b.lo;});
        for(var c=0;c<cols.length;c++){var nx=(c+1<cols.length)?cols[c+1].lo:(cols[c].rr+(cols[c].rr-cols[c].lo));cols[c].hi=(cols[c].rr<nx)?nx:cols[c].rr;}
        return cols;
      }
      var _cols0=_headCols();
      if(_cols0.length>=2){
        var _scroller=null,_all=[].slice.call(doc.querySelectorAll('*')),_dv=(doc.defaultView||window);
        for(var _s=0;_s<_all.length;_s++){try{var _cs=_dv.getComputedStyle(_all[_s]);if(/(auto|scroll)/.test(_cs.overflowX)&&_all[_s].scrollWidth>_all[_s].clientWidth+50&&_all[_s].clientWidth>300){if(!_scroller||_all[_s].scrollWidth>_scroller.scrollWidth)_scroller=_all[_s];}}catch(_e){}}
        var _seenA={};
        function _collect(){
          var cols=_headCols();
          var cells=[].slice.call(doc.querySelectorAll('div,li,a')).filter(function(e){var t=cl(e.textContent);return ht(t)&&t.length>10&&t.length<140&&pn(t)&&e.querySelectorAll('*').length<=8;});
          cells.forEach(function(e){try{var r=e.getBoundingClientRect();if(r.width<8||r.width>460)return;var t=cl(e.textContent);var nm=pn(t);if(!nm)return;var cx=r.left+Math.min(18,r.width/2);var prov='';for(var k=0;k<cols.length;k++){if(cx>=cols[k].lo-6&&cx<cols[k].hi){prov=cols[k].name;break;}}var tm=ft(t),proof=_scheduleRowProofD(e);var key=(prov||'')+'|'+tm+'|'+nm+'|'+_scheduleProofKeyD(proof);if(_seenA[key]){_mergeScheduleProofD(_seenA[key],proof);return;}var row={time:tm,name:cl(nm),provider:prov||'',dob:proof.dob||'',mrn:proof.mrn||'',dobConflict:proof.dobConflict===true,mrnConflict:proof.mrnConflict===true};_seenA[key]=row;out.appts.push(row);}catch(_e){}});
        }
        if(_scroller){
          var _frac=(CFG&&CFG.scrollStepFrac)||0.55;
          var _waitMs=(CFG&&CFG.scrollWaitMs)||780;
          var _stepPx=Math.max(200,Math.round(_scroller.clientWidth*_frac));
          var _steps=Math.min(40,Math.ceil(_scroller.scrollWidth/_stepPx)+2);
          var _orig=_scroller.scrollLeft;
          for(var _st=0;_st<_steps;_st++){
            if(!__scheduleActionAllowed())break;
            try{_scroller.scrollLeft=_st*_stepPx;if(__scheduleActionAllowed())_scroller.dispatchEvent(new Event('scroll',{bubbles:true}));}catch(_e){}
            if(!(await mlsSleep(_waitMs))||!__scheduleActionAllowed())break;
            _collect();
          }
          if(__scheduleActionAllowed()){
            try{_scroller.scrollLeft=0;if(__scheduleActionAllowed())_scroller.dispatchEvent(new Event('scroll',{bubbles:true}));}catch(_e){}
            if((await mlsSleep(400))&&__scheduleActionAllowed())_collect();
          }
          if(__scheduleActionAllowed())try{_scroller.scrollLeft=_orig;}catch(_e){}
        } else { _collect(); }
        var _u={};out.appts.forEach(function(a){if(a.provider)_u[a.provider]=1;});
        out.providers=_cols0.map(function(c){return c.name;}).filter(function(n){return _u[n];});
        if(!out.providers.length)out.providers=_cols0.map(function(c){return c.name;});
        out.diag.via='coord-scroll';out.diag.strategy='coord-scroll';out.diag.apptCount=out.appts.length;out.diag.providerCount=out.providers.length;out.diag.providerNames=out.providers.slice(0,20);out.diag.scrolled=!!_scroller;
        if(out.appts.length) return out;
      }
    }catch(_ce){out.diag.coordErr=String(_ce&&_ce.message||_ce).slice(0,100);}
    var grids=[].slice.call(doc.querySelectorAll('table, [role="grid"], [role="table"]'));
    out.diag.tables=grids.length;
    for(var g=0;g<grids.length&&!out.appts.length;g++){
      var grid=grids[g];
      var hc=[].slice.call(grid.querySelectorAll('thead th, [role="columnheader"]'));
      var rows=[].slice.call(grid.querySelectorAll('tbody tr, [role="row"]'));
      if(!rows.length)rows=[].slice.call(grid.querySelectorAll('tr'));
      if(!hc.length&&rows.length)hc=[].slice.call(rows[0].querySelectorAll('th, td, [role="columnheader"], [role="cell"], [role="gridcell"]'));
      var pi=-1,ni=-1;
      hc.forEach(function(h,idx){var t=tx(h).toLowerCase();if(pi<0&&/(provider|rendering|resource|clinician|scheduling provider|doctor|seen by|with)/.test(t)&&!/patient/.test(t))pi=idx;if(ni<0&&/(patient|name)/.test(t))ni=idx;});
      if(pi<0)continue;
      rows.forEach(function(r){out.diag.rowsScanned++;var cells=[].slice.call(r.querySelectorAll('th, td, [role="cell"], [role="gridcell"]'));if(!cells.length)return;var rt=tx(r);if(!ht(rt))return;var prov=cells[pi]?np(tx(cells[pi])):'';var nm=ni>=0&&cells[ni]?tx(cells[ni]):pn(rt),proof=_scheduleRowProofD(r);if(nm)out.appts.push({time:ft(rt),name:cl(nm),provider:prov||'',dob:proof.dob||'',mrn:proof.mrn||''});});
      if(out.appts.length)out.diag.via='table-column';
    }
    if(!out.appts.length){
      var all=[].slice.call(doc.querySelectorAll('div,li,tr,section,article,a,span,p'));
      var seq=[];
      all.forEach(function(el){var own=tx(el);if(!own||own.length>400)return;if(own.length<=80&&lh(own)&&el.querySelectorAll('*').length<=6){seq.push({k:'p',t:own,el:el});}else if(ht(own)&&own.length<300&&pn(own)){var cb=false;for(var c=0;c<el.children.length;c++){var ct=tx(el.children[c]);if(ht(ct)&&pn(ct)){cb=true;break;}}if(!cb)seq.push({k:'a',t:own,el:el});}});
      var cur='';
      seq.forEach(function(n){out.diag.rowsScanned++;if(n.k==='p'){cur=np(n.t);}else{var inRow='';if(RC.test(n.t)){var mN=n.t.match(/([A-Z][A-Za-z'’-]+\s*,\s*[A-Z][A-Za-z'’-]+\s*(?:MD|DO|NP|PA-?C?|APRN|FNP|DNP|RN|DPM|DDS|DMD|PHD|MBBS|OD)\b)/);if(mN)inRow=np(mN[1]);}var nm2=pn(n.t),proof=_scheduleRowProofD(n.el);if(nm2)out.appts.push({time:ft(n.t),name:nm2,provider:inRow||cur||'',dob:proof.dob||'',mrn:proof.mrn||''});}});
      if(out.appts.length&&!out.diag.via)out.diag.via='grouped-dom';
    }
    var used={};out.appts.forEach(function(a){if(a.provider)used[a.provider.toLowerCase()]=a.provider;});
    out.providers=Object.keys(used).length?provOrder.filter(function(p){return used[p.toLowerCase()];}):provOrder;
    out.diag.apptCount=out.appts.length;out.diag.providerCount=out.providers.length;out.diag.providerNames=out.providers.slice(0,20);out.diag.credsSeen=Object.keys(credSet);
    /* v2.9.7: ALWAYS stamp which lane produced the result (grouped-dom/table-column
       previously set via but left strategy='dom' — consumers could not tell which
       parser ran). */
    if(out.diag.via&&out.diag.strategy==='dom')out.diag.strategy=out.diag.via;
  }catch(e){out.diag.err=String(e&&e.message||e).slice(0,120);}
  return out;
}
 if (/stm\.esp|\/coordinator\/|messaging|letters/i.test(location.pathname || '')) { return { u: location.href, t: '', s: null }; } /* v2.9.8: messaging/coordinator frames are NOT schedule sources (fabricated-appt guard) */ var T = (document.body && document.body.innerText || '').slice(0, 22000); var s = null; try { s = await mlsSchedDomInline(document, CFG, __liveScheduleGuard); } catch (e) { s = { diag: { err: String(e && e.message || e).slice(0,120) } }; } return { u: location.href, t: T, s: s }; } catch (e) { return { u: '', t: '', s: null }; } }
          }, Math.max(0, __scrapeGuard.deadline - Date.now()), 'the exact schedule scrape');
          if (__scrapeX && __scrapeX.r) results = __scrapeX.r;
          else {
            return __schedRespond({ ok: false, reason: 'schedule-surface-changed', scheduleVerified: false, emr: isRealAthena ? 'athena' : 'other-emr', host: mlsHostOnly(tab.url), error: 'The verified schedule stopped responding before it could be read. Nothing was imported; try again.', surfaceDiag: { verifiedFrames: (__surface.frameIds || []).length, scrapeTimeout: !!(__scrapeX && __scrapeX.timeout), scrapeError: String((__scrapeX && __scrapeX.err) || '').slice(0, 100) } });
          }
        }
        var __verifiedFrameIds = {};
        (__surface.frameIds || []).forEach(function (id) { __verifiedFrameIds[String(id)] = 1; });
        let frames = results.map((r) => {
          if (!(r && r.result)) return null;
          var f = {}; Object.keys(r.result).forEach(function (k) { f[k] = r.result[k]; }); f.__frameId = r.frameId;
          return f;
        }).filter((r) => r && __verifiedFrameIds[String(r.__frameId)] && ((r.t && r.t.trim()) || (r.s && r.s.diag && r.s.diag.scheduleStructure)));
        /* Never score or return an unrelated chart/message frame just because it
           contains many clock strings. If the proven schedule frame navigated
           away during the scrape, fail honestly and let the caller retry. */
        if (!frames.length) {
          return __schedRespond({ ok: false, reason: 'schedule-surface-changed', scheduleVerified: false, emr: isRealAthena ? 'athena' : 'other-emr', host: mlsHostOnly(tab.url), error: 'The verified schedule surface changed or stopped responding before it could be read. Nothing was imported; try again.', surfaceDiag: { verifiedFrames: (__surface.frameIds || []).length } });
        }
        // CONTENT-SCORE each frame for "looks like a schedule" — appointment times, day/date
        // labels, scheduling words. This is what makes us resilient to Athena changing their
        // frame names / URLs: we find the schedule by what's IN it, not where it lives.
        const scoreSched = (f) => {
          const u = (f.u || '').toLowerCase(), t = (f.t || ''), tl = t.toLowerCase();
          let s = 0;
          if (/schedul|calendar|appointment|booking|frontoffice|dashboard/.test(u)) s += 25;     // URL hint = bonus, not required
          s += Math.min((t.match(/\b\d{1,2}:\d{2}\s*(a\.?m\.?|p\.?m\.?)?/gi) || []).length, 60) * 2; // clock times = strongest signal
          ['appointment', 'schedul', 'provider', 'booking', 'arrived', 'checked in', 'check-in', 'exam room', 'no show', 'walk-in'].forEach((k) => { if (tl.indexOf(k) >= 0) s += 6; });
          ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday', 'jan', 'feb', 'mar', 'apr', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'].forEach((d) => { if (tl.indexOf(d) >= 0) s += 2; });
          s -= /conversation|colleague|inbox|message/.test(tl) ? 20 : 0;                            // de-rank the messaging frame
          if (/stm\.esp|\/coordinator\/|messaging|letters/.test(u)) s -= 500;                       // v2.9.8: HARD-exclude staff-messaging frames (fabricated-appt guard)
          s += Math.min(t.length, 14000) / 500;                                                     // size as a minor tiebreaker
          return s;
        };
        let pick = null, best = -1;
        frames.forEach((f) => { const s = scoreSched(f); if (s > best) { best = s; pick = f; } });
        pick = pick || { u: tab.url, t: '' };
        // Include the page title so the parser can anchor the date range of a multi-day view.
        var __mlsTS = (typeof mlsProv!=='undefined') ? mlsProv.fromText((pick && pick.t) || '') : {appts:[],providers:[],diag:{}}; var __mlsM = (typeof mlsProv!=='undefined') ? mlsProv.merge(pick && pick.s, __mlsTS) : {appts:[],providers:[],diag:{}};
        /* Keep the provider roster separate from appointment reconciliation.
           A provider may legitimately have zero appointments, so deriving the
           selector only from merged appointment rows silently drops them. */
        var __providerRoster = [], __providerRosterSeen = {};
        function __addProviderRosterEntry(entry) {
          var e = entry && typeof entry === 'object' ? entry : { raw: String(entry || ''), name: String(entry || '') };
          var raw = String(e.raw || e.name || '').replace(/\s+/g, ' ').trim();
          var id = String(e.id || e.providerId || '').trim();
          var stableKey = String(e.stableKey || (id ? ('athena-id:' + id) : (raw ? ('athena:' + raw.toLowerCase()) : ''))).trim();
          if (!stableKey || __providerRosterSeen[stableKey]) return;
          __providerRosterSeen[stableKey] = 1;
          __providerRoster.push({ stableKey: stableKey, id: id, raw: raw, name: String(e.name || raw).replace(/\s+/g, ' ').trim(), source: String(e.source || 'athena-schedule-header') });
        }
        (((pick && pick.s && pick.s.providerRoster) || [])).forEach(__addProviderRosterEntry);
        /* Older structure lanes do not yet emit structured entries. Preserve
           exact raw header identity as an explicitly unverified fallback -
           ONLY when the picked lane supplied no structured roster. Appending
           merged display-string echoes beside a lane roster mints a phantom
           comma-variant twin of the same clinician and contradicts the sweep
           receipt count, failing every pull (live 2026-07-15). */
        if (!__providerRoster.length) (__mlsM.providers || []).forEach(__addProviderRosterEntry);
        var __providerRosterReceipt = (pick && pick.s && pick.s.providerRosterReceipt) || {
          complete: false, partial: true, reason: __providerRoster.length ? 'legacy-unverified' : 'no-provider-headers',
          expectedCount: null, observedCount: __providerRoster.length, horizontalScrollable: null,
          reachedEnd: false, capReached: false, budgetExpired: false, restored: null, steps: 0
        };
        /* Batch provenance at the source (v2.9.25): bind this sweep receipt to
           the exact schedule request and the served date, so a stale or
           replayed roster receipt can never satisfy a later batch. */
        __providerRosterReceipt = Object.assign({}, __providerRosterReceipt, { requestId: __schedRequestId, targetDate: (pick && pick.s && pick.s.schedDate) || '' });
        /* Completeness receipt: a verified surface is not enough to claim a
           verified result. Reconcile every appointment-shaped candidate the
           virtualized sweep observed with the validated merged rows. A real
           empty day is accepted only when the schedule surface itself exposes
           an explicit empty-state signal. Partial rows are returned only as
           retry diagnostics and are never advertised as a successful pull. */
        var __pd = (__mlsM && __mlsM.providerDiag) || {};
        var __dd = (pick && pick.s && pick.s.diag) || {};
        /* Structure-id supplies a de-duplicated rendered-candidate count. Do
           not re-inflate it with hidden duplicate DOM copies; older lanes do
           not expose candidateCount and fall back to their validated rows. */
        var __candidateCount = (__dd.candidateCount != null)
          ? Number(__dd.candidateCount || 0)
          : Math.max(Number(__dd.apptCount || 0), Number(__pd.domValidRows || 0));
        var __parsedCount = (__mlsM.appts || []).length;
        var __unnamedCount = Number(__dd.unnamedCount || 0);
        var __declaredCount = 0;
        try {
          var __dm, __dre = /\b(\d{1,3})\s+appointments?\b/gi, __dt = String((pick && pick.t) || '');
          while ((__dm = __dre.exec(__dt))) __declaredCount = Math.max(__declaredCount, Number(__dm[1] || 0));
        } catch (eDc) {}
        /* A per-provider declaration is an authoritative total only for a
           single-provider surface; on a multi-provider grid it is merely one
           column's count and candidate coverage remains the invariant. */
        var __providerCount = (__mlsM.providers || []).length;
        /* The legacy day grid exposes explicit appointment rows and OPEN slots.
           Its free-text header count can include capacity slots, so the
           reconciled class-specific candidate count is authoritative here. */
        var __legacyExactCount = __dd.strategy === 'legacy-day-grid' || __dd.via === 'legacy-day-grid';
        var __declaredCountAuthoritative = !__legacyExactCount && __providerCount <= 1 && __declaredCount > 0;
        var __countStrategy = __legacyExactCount
          ? 'legacy-grid-candidate-rows'
          : (__declaredCountAuthoritative ? 'single-provider-declared-total' : ((__dd.strategy === 'structure-id' || __dd.via === 'structure-id') ? 'verified-viewport-candidates' : 'verified-rendered-candidates'));
        var __declaredCountReason = __declaredCountAuthoritative
          ? 'single-provider-surface-total'
          : (__legacyExactCount ? 'legacy-header-may-include-capacity' : (__providerCount > 1 && __declaredCount > 0 ? 'multi-provider-column-count-not-total' : 'no-authoritative-declared-total'));
        var __expectedCount = __legacyExactCount ? __candidateCount : Math.max(__candidateCount, __declaredCountAuthoritative ? __declaredCount : 0);
        var __authoritativeEmpty = __parsedCount === 0 && (__surface.probes || []).some(function (p) { return p && p.verified && p.empty; });
        var __viewportCoverage = __dd.viewportCoverage || null;
        var __coverageRequired = __dd.strategy === 'structure-id' || __dd.via === 'structure-id';
        var __coverageComplete = !__coverageRequired || !!(__viewportCoverage && __viewportCoverage.complete === true);
        var __complete = __coverageComplete && (__authoritativeEmpty || (__parsedCount > 0 && __parsedCount >= __expectedCount && __unnamedCount === 0));
        var __receipt = {
          scheduleVerified: true, requestId: __schedRequestId, complete: !!__complete, authoritativeEmpty: !!__authoritativeEmpty,
          expectedCount: __expectedCount, candidateCount: __candidateCount, parsedCount: __parsedCount,
          countStrategy: __countStrategy,
          declaredCount: __declaredCount, declaredCountAuthoritative: __declaredCountAuthoritative, declaredCountReason: __declaredCountReason, unnamedCount: __unnamedCount,
          domValidRows: Number(__pd.domValidRows || 0), textValidRows: Number(__pd.textValidRows || 0),
          mergedRows: Number(__pd.mergedRows || __parsedCount), invalidRowsRemoved: Number(__pd.invalidRowsRemoved || 0),
          viewportCoverage: __viewportCoverage, viewportCoverageComplete: __coverageComplete
        };
        /* v2.9.11: ACCUMULATE the shadow-parser evidence across pulls/days — the per-pull
           nameShadow would otherwise evaporate with the response, and the canonical-parser
           cutover needs durable counts (>=3 days incl. month pull + structure lane,
           checked>=1000, differs=0 or reviewed). Stays in chrome.storage.local (same
           in-browser boundary as the rest of the pull data); samples capped at 40. */
        try {
          var __sh = pick && pick.s && pick.s.diag && pick.s.diag.nameShadow;
          if (__sh && __sh.checked) {
            var __strat = (pick.s.diag.strategy || pick.s.diag.via || 'unknown');
            chrome.storage.local.get(['mlsNameShadowTotals'], function (st) {
              try {
                /* v2.9.13 schema:2 (Codex): the pre-fix call-count totals are smoke
                   evidence only — reset rather than mixing semantics. days key on the
                   SCHEDULE date (a month pull must prove distinct schedule days);
                   wall-clock fallback counts land in daysUnknown, which never
                   satisfies the 3-schedule-day cutover gate. */
                var T = (st && st.mlsNameShadowTotals && st.mlsNameShadowTotals.schema === 3)
                  ? st.mlsNameShadowTotals
                  : { schema: 3, checked: 0, differs: 0, canonicalRejected: 0, canonicalAdded: 0, samples: [], days: {}, daysUnknown: 0, strategies: {} };
                T.checked += __sh.checked; T.differs += __sh.differs;
                T.canonicalRejected += (__sh.canonicalRejected || 0);
                T.canonicalAdded += (__sh.canonicalAdded || 0);
                (__sh.samples || []).forEach(function (sm) { if (T.samples.length < 40) T.samples.push(sm); });
                var schedDay = (pick && pick.s && pick.s.schedDate) || '';
                if (schedDay) T.days[schedDay] = (T.days[schedDay] || 0) + __sh.checked;
                else T.daysUnknown = (T.daysUnknown || 0) + __sh.checked;
                T.strategies[__strat] = (T.strategies[__strat] || 0) + __sh.checked;
                T.updatedAt = Date.now();
                chrome.storage.local.set({ mlsNameShadowTotals: T });
              } catch (e2) {}
            });
          }
        } catch (eSh) {}
        if (!__complete) {
          var __incompleteError = !__coverageComplete ? ('MLS could not finish the full two-dimensional Athena schedule sweep (' + String(__viewportCoverage && __viewportCoverage.reason || 'coverage-unverified').replace(/-/g, ' ') + '). Nothing was imported; keep the full Day schedule open and retry.') : ('Athena showed ' + __expectedCount + ' appointment row' + (__expectedCount === 1 ? '' : 's') + ', but MLS could verify only ' + __parsedCount + '. Nothing was imported; keep Athena on this day and retry.');
          return __schedRespond({ ok: false, reason: 'schedule-incomplete', scheduleVerified: true, receipt: __receipt, emr: isRealAthena ? 'athena' : 'other-emr', host: mlsHostOnly(pick.u || tab.url), text: '', url: pick.u || tab.url, title: tab.title, frames: frames.length, appts: mlsAttachDobs(__mlsM.appts, (pick && pick.t) || ''), providers: __mlsM.providers, providerRoster: __providerRoster, providerRosterReceipt: __providerRosterReceipt, providerDiag: __mlsM.providerDiag, schedDate: (pick && pick.s && pick.s.schedDate) || '', error: __incompleteError, surfaceDiag: { via: (__surface.hits || []).map(function (h) { return h.via; }).filter(Boolean).slice(0, 6), verifiedFrames: (__surface.frameIds || []).length } });
        }
        __schedRespond({ ok: true, scheduleVerified: true, receipt: __receipt, emr: isRealAthena ? 'athena' : 'other-emr', host: mlsHostOnly(pick.u || tab.url), text: ((tab.title ? ('[' + tab.title + ']\n') : '') + (pick.t || '')).slice(0, 22000), url: pick.u || tab.url, title: tab.title, frames: frames.length, appts: mlsAttachDobs(__mlsM.appts, (pick && pick.t) || ''), providers: __mlsM.providers, providerRoster: __providerRoster, providerRosterReceipt: __providerRosterReceipt, providerDiag: __mlsM.providerDiag, schedDate: (pick && pick.s && pick.s.schedDate) || '', surfaceDiag: { via: (__surface.hits || []).map(function (h) { return h.via; }).filter(Boolean).slice(0, 6), verifiedFrames: (__surface.frameIds || []).length } });
      } catch (e) { if (!__schedResponded) __schedRespond({ ok: false, error: String((e && e.message) || e) }); }
    })();
    return true;
  }
  // READ-ONLY: read the open Athena REPORT / claims / procedure / patient LIST tab so MLS can
  // enumerate patients by procedure/CPT (Study cohort, Mode B). Resilient by design: it finds
  // the EMR tab broadly, reads EVERY frame, and CONTENT-SCORES each for "looks like a report
  // table" (many dated rows, CPT-like 5-digit codes, $ charges, claim/procedure/service-date
  // headers). It returns the richest table frame PLUS a capped concatenation of the top frames
  // (a report can span frames), so the app's parser sees the whole list. It never writes.
  if (msg.type === 'mlsAppReportRequest') {
    (async () => {
      try {
        const all = await chrome.tabs.query({});
        /* v1.90: unified verified picker; non-athena EMR keyword fallback preserved. */
        let tab = await mlsPickAthenaTab(all, { athenaOnly: true })
               || all.find((t) => /epic|cerner|ecw|eclinical|nextgen|allscripts|emr|ehr|\bchart\b|report|claim|billing|practice|clinic/i.test(t.url || '') && !/mlsscribe\.com|athena/i.test(t.url || ''));
        // v1.38 truth fix: no arbitrary-tab fallback for a positive result (phantom-tab bug).
        if (!tab) return sendResponse({ ok: false, reason: 'no-athena-tab', emr: 'none', host: '', id: msg.id, error: 'Open a signed-in athenaOne report tab, then try again.' });
        const isRealAthena = /athenahealth|athenanet|athenaone|athena\.io|\.px\.athena/i.test(tab.url || '');
        let results = [];
        /* v2.9.14 (Codex E3 residual): HARD 45s envelope so a permanently hung
           executeScript can no longer hang this handler; a double rejection or
           timeout falls through to the existing zero-frames settle+re-read
           (single retry, NO reload — POST-generated report views must survive). */
        {
          const rx = await mlsExecTO({ target: { tabId: tab.id, allFrames: true }, func: () => { try { return { u: location.href, t: (document.body && document.body.innerText || '').slice(0, 60000) }; } catch (e) { return { u: '', t: '' }; } } }, 45000);
          if (rx && rx.r) results = rx.r;
          else { try { results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => ({ u: location.href, t: (document.body && document.body.innerText || '').slice(0, 60000) }) }); } catch (e) { results = []; } }
        }
        let frames = results.map((r) => r && r.result).filter((r) => r && r.t && r.t.trim());
        /* v2.9.11 (Codex E3 p3): zero readable frames on a live tab = transient injection/
           render state — settle and re-read ONCE. Deliberately NO tab reload here: a
           POST-generated report view would not survive a reload (unlike the schedule,
           which recovers to the dashboard safely). Never loops. */
        if (!frames.length && tab && tab.id != null) {
          try {
            await new Promise((r) => setTimeout(r, 1200));
            const r2 = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: () => { try { return { u: location.href, t: (document.body && document.body.innerText || '').slice(0, 60000) }; } catch (e) { return { u: '', t: '' }; } } });
            const f2 = (r2 || []).map((r) => r && r.result).filter((r) => r && r.t && r.t.trim());
            if (f2.length) frames = f2;
          } catch (eR2) {}
        }
        // CONTENT-SCORE each frame for "looks like a report/claims/procedure LIST" — what makes
        // us resilient to Athena renaming frames/URLs: we find the report by what's IN it.
        const scoreReport = (f) => {
          const u = (f.u || '').toLowerCase(), t = (f.t || ''), tl = t.toLowerCase();
          let s = 0;
          if (/report|claim|billing|procedure|encounter|export|analy|registr|worklist|patient.?list/.test(u)) s += 20; // URL hint = bonus, not required
          const dates = (t.match(/\b[01]?\d[\/\-][0-3]?\d[\/\-]\d{2,4}\b/g) || []).length;          // dated rows (DOB / service date)
          s += Math.min(dates, 200) * 2;
          const cpts = (t.match(/\b\d{5}\b/g) || []).length;                                         // CPT-like 5-digit codes
          s += Math.min(cpts, 200) * 1.5;
          const money = (t.match(/\$\s?\d/g) || []).length;                                          // charges
          s += Math.min(money, 100);
          ['cpt', 'procedure', 'service date', 'date of service', 'dos', 'claim', 'charge', 'billed', 'units', 'modifier', 'rendering', 'diagnosis', 'icd', 'mrn', 'date of birth', 'dob', 'patient name'].forEach((k) => { if (tl.indexOf(k) >= 0) s += 5; });
          s -= /conversation|colleague|inbox|message|chat/.test(tl) ? 25 : 0;                         // de-rank the messaging frame
          s += Math.min(t.length, 40000) / 600;                                                       // size as a minor tiebreaker
          return s;
        };
        const scored = frames.map((f) => ({ f: f, s: scoreReport(f) })).sort((a, b) => b.s - a.s);
        const best = scored[0] || { f: { u: tab.url, t: '' }, s: 0 };
        // A report can render across sibling frames; concat the top few scoring frames (capped)
        // so the app parser sees every patient row, not just the single best frame.
        let concat = '';
        for (const sc of scored) { if (sc.s <= 0) break; if (concat.length > 44000) break; concat += (concat ? '\n\n' : '') + (sc.f.t || ''); }
        const text = ((tab.title ? ('[' + tab.title + ']\n') : '') + (concat || best.f.t || '')).slice(0, 46000);
        sendResponse({ ok: true, emr: isRealAthena ? 'athena' : 'other-emr', host: mlsHostOnly(best.f.u || tab.url), id: msg.id, text: text, url: best.f.u || tab.url, title: tab.title, frames: frames.length, bestScore: Math.round(best.s) });
      } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
    })();
    return true;
  }
  // ===== Mode C: DRIVE the athenaOne procedure search + paginate (READ-ONLY) =====
  // The injected mlsAthenaDrive runs in EVERY frame; we pick the frame that actually has the
  // controls / the report, so it is resilient to Athena's frames. It only operates the search
  // controls (CPT/procedure + dates + Run/Next) and NEVER clicks Save/Sign (excludeClickLabels).
  // FILL + RUN the search.
  if (msg.type === 'mlsAppSearchFill') {
    (async () => {
      try {
        const all = await chrome.tabs.query({});
        const tab = await mlsPickAthenaTab(all); /* v1.90 unified picker (generic-EMR fallback built in) */
        if (!tab) return sendResponse({ ok: false, error: 'Open your signed-in athenaOne in another tab (a procedure/claims report or charge-search screen), then try again.' });
        let results = [];
        try { results = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: mlsAthenaDrive, args: ['fill', msg.params || {}, msg.cfg || {}] }); }
        catch (e) { results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: mlsAthenaDrive, args: ['fill', msg.params || {}, msg.cfg || {}] }); }
        const vals = results.map((r) => r && r.result).filter(Boolean);
        let acted = null;
        vals.forEach((v) => { if (v && v.acted) { if (!acted || (v.clickedRun && !acted.clickedRun)) acted = v; } });
        sendResponse({ ok: true, tabId: tab.id, acted: acted || { acted: false }, frames: vals.length });
      } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
    })();
    return true;
  }
  // READ the current result page (best-scoring frame) + detect a Next control.
  if (msg.type === 'mlsAppSearchRead') {
    (async () => {
      try {
        const all = await chrome.tabs.query({});
        const tab = (msg.tabId && all.find((t) => t.id === msg.tabId)) || await mlsPickAthenaTab(all); /* v1.90; SearchFill's tabId still wins */
        if (!tab) return sendResponse({ ok: false, error: 'No athenaOne tab found.' });
        let results = [];
        try { results = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: mlsAthenaDrive, args: ['read', {}, msg.cfg || {}] }); }
        catch (e) { results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: mlsAthenaDrive, args: ['read', {}, msg.cfg || {}] }); }
        const vals = results.map((r) => r && r.result).filter((v) => v && v.ok).sort((a, b) => (b.score || 0) - (a.score || 0));
        const best = vals[0] || { text: '', sig: '', hasNext: false, count: 0, score: 0, nextDesc: '' };
        let concat = '';
        for (const v of vals) { if ((v.score || 0) <= 0) break; if (concat.length > 44000) break; if (v.text) concat += (concat ? '\n\n' : '') + v.text; }
        sendResponse({ ok: true, tabId: tab.id, text: (concat || best.text || '').slice(0, 46000), sig: best.sig, hasNext: vals.some((v) => v.hasNext), nextDesc: best.nextDesc || '', rowCount: best.count || 0, bestScore: best.score || 0, frames: vals.length });
      } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
    })();
    return true;
  }
  // CLICK the Next-page control in the best report frame.
  if (msg.type === 'mlsAppSearchNext') {
    (async () => {
      try {
        const all = await chrome.tabs.query({});
        const tab = (msg.tabId && all.find((t) => t.id === msg.tabId)) || await mlsPickAthenaTab(all); /* v1.90; SearchFill's tabId still wins */
        if (!tab) return sendResponse({ ok: false, error: 'No athenaOne tab found.' });
        let results = [];
        try { results = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: mlsAthenaDrive, args: ['next', {}, msg.cfg || {}] }); }
        catch (e) { results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: mlsAthenaDrive, args: ['next', {}, msg.cfg || {}] }); }
        const clicked = results.map((r) => r && r.result).filter(Boolean).some((v) => v.clicked);
        sendResponse({ ok: true, tabId: tab.id, clicked: clicked });
      } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
    })();
    return true;
  }

  // Open + read ONE PATIENT'S CHART from Athena. If a patient name is given, try to

  // click that patient (in the schedule/search) to open their chart, then read the
  // frame that scores highest on clinical-chart keywords (so we never grab the schedule).
  if (msg.type === 'mlsAppChartRequest') {
    /* One request, one immutable deadline, one terminal response. The caller's
       deadline always wins when it is sooner than this handler's safety cap.
       Every browser/renderer await below is raced against this same value; a
       late executeScript may finish inside Chrome, but its injected action
       guard prevents any post-timeout click/navigation. */
    const chartRequestStartedAt = Date.now();
    const chartRequestId = String(msg.requestId || ('mlschart-' + chartRequestStartedAt.toString(36) + '-' + Math.random().toString(36).slice(2, 9))).slice(0, 100);
    const chartCallerDeadline = Number(msg.deadlineAt || 0);
    let chartDeadlineAt = chartRequestStartedAt + 105000;
    if (Number.isFinite(chartCallerDeadline) && chartCallerDeadline > 0) chartDeadlineAt = Math.min(chartDeadlineAt, chartCallerDeadline);
    const chartRequestGuard = Object.freeze({ deadline: chartDeadlineAt, token: chartRequestId });
    let chartResponseSent = false;
    let chartDeadlineTimer = null;
    const chartRespond = (payload) => {
      if (chartResponseSent) return false;
      chartResponseSent = true;
      if (chartDeadlineTimer != null) { try { clearTimeout(chartDeadlineTimer); } catch (eClearChartTimer) {} }
      sendResponse(Object.assign({}, payload || {}, { requestId: chartRequestGuard.token, deadlineAt: chartRequestGuard.deadline }));
      return true;
    };
    const chartExpired = () => chartResponseSent || Date.now() >= chartRequestGuard.deadline;
    const chartFailDeadline = (stage) => chartRespond({
      ok: false, reason: 'chart-deadline-exceeded',
      error: 'The Athena chart read reached its absolute deadline during ' + (stage || 'the read') + '. No retry or fallback was dispatched after the timeout.'
    });
    const chartSettle = async (promise, ceilingMs) => {
      const hardLeft = Math.max(0, chartRequestGuard.deadline - Date.now());
      const left = Math.max(0, Math.min(hardLeft, Number.isFinite(Number(ceilingMs)) ? Number(ceilingMs) : hardLeft));
      if (!left || chartResponseSent) return { timeout: true, deadline: hardLeft <= 0 || chartResponseSent };
      return Promise.race([
        Promise.resolve(promise).then((value) => ({ ok: true, value: value }), (error) => ({ error: error })),
        mlsSleepW(left).then(() => ({ timeout: true, deadline: Date.now() >= chartRequestGuard.deadline }))
      ]);
    };
    const chartExec = async (opts, ceilingMs) => {
      if (chartExpired()) return { timeout: true, deadline: true };
      let op;
      try { op = chrome.scripting.executeScript(opts); } catch (eExecStart) { return { err: String((eExecStart && eExecStart.message) || eExecStart) }; }
      const settled = await chartSettle(op, ceilingMs);
      if (!settled || settled.timeout || chartExpired()) return { timeout: true, deadline: chartExpired() || !!(settled && settled.deadline) };
      if (settled.error) return { err: String((settled.error && settled.error.message) || settled.error) };
      return { r: settled.value || [] };
    };
    const chartWait = async (ms) => {
      const wanted = Math.max(0, Number(ms || 0));
      const left = Math.max(0, chartRequestGuard.deadline - Date.now());
      if (!left || chartResponseSent) return false;
      await mlsSleepW(Math.min(left, wanted));
      return wanted <= left && !chartExpired();
    };
    chartDeadlineTimer = setTimeout(() => { chartFailDeadline('the read'); }, Math.max(0, chartRequestGuard.deadline - Date.now()));
    (async () => {
      try {
        if (chartExpired()) { chartFailDeadline('request start'); return; }
        const allSettled = await chartSettle(chrome.tabs.query({}), 10000);
        if (!allSettled || !allSettled.ok) { chartFailDeadline('Athena tab selection'); return; }
        const all = allSettled.value || [];
        const want = String(msg.patient || '').trim();
        const wantDob = String(msg.patientDob || '').trim();
        const wantMrn = String(msg.patientMrn || '').trim();
        const preopened = msg.preopened === true;
        const bootstrapIdentity = msg.bootstrapIdentity === true;
        const expectedAppointmentId = String(msg.appointmentId || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 40);
        const expectedScheduleDate = /^\d{4}-\d{2}-\d{2}$/.test(String(msg.scheduleDate || '')) ? String(msg.scheduleDate) : '';
        const expectedAthenaTabId = Number(msg.athenaTabId);
        const expectedNavigationFrameIds = Array.isArray(msg.appointmentNavigationFrameIds)
          ? msg.appointmentNavigationFrameIds.map((value) => Number(value)).filter((value) => Number.isInteger(value) && value >= 0).slice(0, 24)
          : [];
        let tab = null, exactOpenLease = null;
        if (preopened) {
          /* The DOB-gated findpatient opener records the exact Athena tab it
             navigated. Bind this read to that tab; generic re-picking can cross
             into another open Athena chart. Missing/stale receipts fail closed. */
          const lease = self.__mlsExpectOpen || null;
          const leaseNameKey = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
          if (!lease || !lease.tabId || (Date.now() - Number(lease.at || 0)) > 180000 || leaseNameKey(lease.name) !== leaseNameKey(want)) {
            return chartRespond({ ok: false, reason: 'preopened-tab-unverified', error: 'The exact Athena chart-open receipt was missing or stale. Nothing was read.' });
          }
          if (bootstrapIdentity && (!expectedAppointmentId || lease.appointmentIdBound !== true ||
              String(lease.requestId || '') !== chartRequestId || String(lease.appointmentId || '') !== expectedAppointmentId ||
              (expectedScheduleDate && String(lease.scheduleDate || '') !== expectedScheduleDate) ||
              (!Number.isFinite(expectedAthenaTabId) || Number(lease.tabId) !== expectedAthenaTabId) ||
              !expectedNavigationFrameIds.length ||
              JSON.stringify((lease.appointmentNavigationFrameIds || []).slice().sort((a, b) => a - b)) !== JSON.stringify(expectedNavigationFrameIds.slice().sort((a, b) => a - b)))) {
            return chartRespond({ ok: false, reason: 'appointment-open-lease-mismatch', error: 'The exact appointment, date, tab, and request receipt did not match. Nothing was read.' });
          }
          exactOpenLease = Object.freeze({ tabId: Number(lease.tabId), requestId: String(lease.requestId || ''), appointmentId: String(lease.appointmentId || ''), scheduleDate: String(lease.scheduleDate || ''), appointmentIdBound: lease.appointmentIdBound === true, appointmentNavigationFrameIds: expectedNavigationFrameIds.slice() });
          const leaseTab = await chartSettle(chrome.tabs.get(Number(lease.tabId)), 8000);
          tab = (leaseTab && leaseTab.ok) ? leaseTab.value : null;
          if (chartExpired()) { chartFailDeadline('the exact-tab lease'); return; }
          if (!tab || !mlsIsAthenaTab(tab) || mlsAthIsLoginish(tab)) {
            return chartRespond({ ok: false, reason: 'preopened-tab-unavailable', error: 'The exact signed-in Athena tab is no longer available. Nothing was read.' });
          }
        } else {
          const pickedTab = await chartSettle(mlsPickAthenaTab(all, { athenaOnly: true }), 8000);
          if (!pickedTab || !pickedTab.ok) { chartFailDeadline('Athena tab selection'); return; }
          tab = pickedTab.value; /* v1.90 unified picker */
        }
        if (!tab) { const cand = all.filter((t) => /^https?:/i.test(t.url || '') && !/mlsscribe\.com|chrome:\/\/|athena/i.test(t.url || '')); cand.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0)); tab = cand[0]; }
        if (!tab) return chartRespond({ ok: false, error: 'Open the patient in your Athena tab, then try again.' });
        let opened = preopened;
        try { self.__mlsVerifiedReadTarget = null; } catch (eClearReadLease) {}
        // Click a visible patient name, OR type the name into an Athena search box, so we
        // can OPEN the chart without the doctor having to click it themselves.
        const openFn = (name, expectedDob, expectedMrn, requestGuard) => {
          try {
            const guard = Object.freeze({ deadline: Number(requestGuard && requestGuard.deadline || 0), token: String(requestGuard && requestGuard.token || '') });
            const actionAllowed = () => !!guard.token && Number.isFinite(guard.deadline) && Date.now() < guard.deadline;
            if (!actionAllowed()) return 'open-deadline-exceeded';
            const cleanedName = name.toLowerCase().replace(/[^a-z\s,]/g, '');
            const parts = cleanedName.split(/[\s,]+/).filter(Boolean);
            if (!parts.length) return 'no';
            const commaName = cleanedName.split(',');
            const last = commaName.length > 1 ? (commaName[0].trim().split(/\s+/).filter(Boolean).pop() || '') : parts[parts.length - 1];
            const first = commaName.length > 1 ? ((commaName[1] || '').trim().split(/\s+/).filter(Boolean)[0] || '') : parts[0];
            const idDigits = (v) => String(v || '').replace(/\D/g, '');
            const dateKey = (v) => {
              const m = String(v || '').match(/\b(\d{1,4})[\/\-.](\d{1,2})[\/\-.](\d{1,4})\b/); if (!m) return '';
              let y, mo, d;
              if (m[1].length === 4) { y = m[1]; mo = m[2]; d = m[3]; } else { mo = m[1]; d = m[2]; y = m[3]; }
              if (String(y).length === 2) y = (+y > 40 ? '19' : '20') + y;
              return String(y).padStart(4, '0') + String(+mo).padStart(2, '0') + String(+d).padStart(2, '0');
            };
            const dobDigits = dateKey(expectedDob), mrnDigits = idDigits(expectedMrn);
            const textHasExactDob = (raw) => {
              if (!dobDigits) return false;
              const re = /(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/g;
              let m;
              while ((m = re.exec(String(raw || '')))) {
                let y = m[3]; if (y.length === 2) y = (+y > 40 ? '19' : '20') + y;
                const got = y + String(+m[1]).padStart(2, '0') + String(+m[2]).padStart(2, '0');
                if (got === dobDigits) return true;
              }
              return false;
            };
            const textHasExactMrn = (raw) => {
              if (!mrnDigits) return false;
              return new RegExp('(?:^|\\D)' + mrnDigits + '(?:\\D|$)').test(String(raw || ''));
            };
            const rowProof = (raw) => textHasExactDob(raw) || textHasExactMrn(raw);
            /* v1.62: athenaOne v26.3 schedule rows are React-wired <div>s - a bare
               el.click() never navigates. Dispatch the real pointer/mouse sequence. */
            const realClick = (el) => {
              if (!actionAllowed()) return false;
              try { el.scrollIntoView({ block: 'center' }); } catch (e1) {}
              if (!actionAllowed()) return false;
              try {
                const r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
                const o = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y };
                ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach((tp) => {
                  if (!actionAllowed()) return;
                  try { el.dispatchEvent(new (tp.indexOf('pointer') === 0 ? PointerEvent : MouseEvent)(tp, o)); } catch (e2) {}
                });
              } catch (e3) {}
              if (!actionAllowed()) return false;
              try { el.click(); } catch (e4) { return false; }
              return true;
            };
            const clickName = () => {
              /* v1.59 perf: textContent (no innerText layout-forcing walk) + element cap.
                 The all-frames innerText walk is what froze athenaOne for 78s. */
              const els = Array.from(document.querySelectorAll('a,button,[role="link"],[role="button"],[onclick],td,li,span,div')).slice(0, 5000);
              /* Group nested name nodes by patient/result row. Never choose an
                 arbitrary duplicate display name: a unique DOB/MRN row wins;
                 multiple unproved rows fall through to search/refusal. */
              const rows = [];
              for (const el of els) {
                const t = (el.textContent || '').trim().toLowerCase();
                if (t && t.length < 70 && t.indexOf(last) >= 0 && (parts.length < 2 || t.indexOf(first) >= 0)) {
                  const r = el.getBoundingClientRect();
                  if (!(r.width > 0 && r.height > 0)) continue;
                  let root = null;
                  try { root = el.closest('tr,[role="row"],li,[data-patient-id],[data-patientid],[data-testid*="patient" i]'); } catch (e0) {}
                  if (!root) { try { root = el.closest('a,button,[role="link"],[role="button"],[onclick]'); } catch (e1) {} }
                  root = root || el;
                  let entry = rows.find((x) => x.root === root || (x.root.contains && x.root.contains(root)) || (root.contains && root.contains(x.root)));
                  if (!entry) { entry = { root: root, el: el, len: t.length, text: String(root.textContent || t).slice(0, 800) }; rows.push(entry); }
                  else if (t.length < entry.len) { entry.el = el; entry.len = t.length; }
                }
              }
              const proved = rows.filter((x) => rowProof(x.text));
              if (proved.length === 1) { return realClick(proved[0].el) ? 'clicked' : 'open-deadline-exceeded'; }
              if (proved.length > 1) return 'ambiguous';
              if (rows.length === 1) { return realClick(rows[0].el) ? 'clicked' : 'open-deadline-exceeded'; }
              return rows.length > 1 ? 'ambiguous' : 'no';
            };
            if (clickName() === 'clicked') return 'clicked';
            const inputs = Array.from(document.querySelectorAll('input[type="text"],input[type="search"],input:not([type])'));
            const box = inputs.find((i) => {
              const h = ((i.placeholder || '') + ' ' + (i.name || '') + ' ' + (i.getAttribute('aria-label') || '') + ' ' + (i.id || '')).toLowerCase();
              const r = i.getBoundingClientRect(); const t = (i.type || '').toLowerCase();
              if (r.width <= 0 || r.height <= 0) return false;
              // NEVER type a patient NAME into a numeric / ID field — that's what throws Athena's
              // "Patient ID must be numeric" error. Skip number/tel/date fields and any ID-ish label.
              if (t === 'number' || t === 'tel' || t === 'date' || t === 'email' || t === 'password') return false;
              if ((i.inputMode || '').toLowerCase() === 'numeric') return false;
              if (/patient\s*id|patientid|\bid\b|\bmrn\b|chart\s*(id|no|num)|\bnpi\b|account|claim|invoice|\bnumber\b|ssn|\bdob\b/.test(h)) return false;
              return /search|name|find|look\s*up|lookup|filter|patient/.test(h);
            });
            if (box) {
              if (!actionAllowed()) return 'open-deadline-exceeded';
              box.focus(); box.value = name;
              if (!actionAllowed()) return 'open-deadline-exceeded';
              box.dispatchEvent(new Event('input', { bubbles: true })); box.dispatchEvent(new Event('change', { bubbles: true }));
              ['keydown', 'keypress', 'keyup'].forEach((tp) => { if (actionAllowed()) box.dispatchEvent(new KeyboardEvent(tp, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true })); });
              return 'searched';
            }
            return 'no';
          } catch (e) { return 'no'; }
        };
        if (want && !preopened) {
          const chartOpenStartedAt = Date.now();
          const chartOpenGuard = Object.freeze({ deadline: Math.min(chartRequestGuard.deadline, chartOpenStartedAt + 20000), token: chartRequestGuard.token });
          const chartExecOpen = async () => {
            const left = Math.max(0, chartOpenGuard.deadline - Date.now());
            if (!left) return { timeout: true };
            const x = await chartExec({ target: { tabId: tab.id, allFrames: true }, func: openFn, args: [want, wantDob, wantMrn, chartOpenGuard] }, left);
            return (x && (x.timeout || Date.now() >= chartOpenGuard.deadline || chartExpired())) ? { timeout: true } : x;
          };
          const chartWaitOpen = async (ms) => {
            const left = Math.max(0, chartOpenGuard.deadline - Date.now());
            if (!left || chartExpired()) return false;
            const wanted = Math.max(0, Number(ms || 0));
            await mlsSleepW(Math.min(left, wanted));
            return wanted <= left && Date.now() < chartOpenGuard.deadline && !chartExpired();
          };
          let statuses = [];
          const firstOpen = await chartExecOpen();
          if (firstOpen.timeout) return chartRespond({ ok: false, opened: false, reason: 'open-deadline-exceeded', error: 'The bounded chart fallback open did not return before its absolute deadline. No retry was dispatched.' });
          statuses = (firstOpen.r || []).map((r) => r && r.result);
          if (statuses.indexOf('open-deadline-exceeded') >= 0) return chartRespond({ ok: false, opened: false, reason: 'open-deadline-exceeded', error: 'The chart fallback deadline expired before a navigation action.' });
          if (statuses.indexOf('clicked') >= 0) { opened = true; if (!(await chartWaitOpen(1900))) return chartRespond({ ok: false, opened: false, reason: 'open-deadline-exceeded', error: 'The chart fallback deadline expired while the chart was opening.' }); }
          else if (statuses.indexOf('searched') >= 0) {
            // gave Athena the name — wait for results, then click the matching result.
            if (!(await chartWaitOpen(2600))) return chartRespond({ ok: false, opened: false, reason: 'open-deadline-exceeded', error: 'The chart fallback deadline expired while search results rendered.' });
            const secondOpen = await chartExecOpen();
            if (secondOpen.timeout) return chartRespond({ ok: false, opened: false, reason: 'open-deadline-exceeded', error: 'The bounded chart fallback result open timed out. No further retry was dispatched.' });
            const secondStatuses = (secondOpen.r || []).map((r) => r && r.result);
            if (secondStatuses.indexOf('open-deadline-exceeded') >= 0) return chartRespond({ ok: false, opened: false, reason: 'open-deadline-exceeded', error: 'The chart fallback deadline expired before the result click.' });
            if (secondStatuses.indexOf('clicked') >= 0) { opened = true; if (!(await chartWaitOpen(1900))) return chartRespond({ ok: false, opened: false, reason: 'open-deadline-exceeded', error: 'The chart fallback deadline expired while the selected chart opened.' }); }
          }
        }
        /* ===== v1.59 CHART-READY GATE =====
           athenaOne v26.3 lands schedule-clicks on the appointment EXAM-PREP /
           BRIEFING view where the patient banner (name+DOB) has not rendered, so
           reads there captured the PROVIDER as the "patient" and the identity
           gate refused everything (the 0-of-23 pull). Before reading: poll the
           chart identity; when the exam-prep view is detected, click its read-only
           "REFRESH CHART" / "Chart" control and WAIT for the real patient banner.
           Fails honestly if the clinical chart never loads. Gates untouched. */
        let ident = null, sawBriefing = false, navClicked = '', clickAt = 0, polls = 0, injFails = 0, noClickRounds = 0, fgByUs = false, identDiag = [], identityFrameResults = [];
        const T0 = Date.now(), BUDGET_MS = Math.max(0, Math.min(52000, chartRequestGuard.deadline - Date.now()));
        /* v1.60: EXPECTED patient - a bare read that follows a search-open (the
           day/month pull pattern) must wait for THAT patient's banner, not accept
           whatever identity some stale/lurking frame still carries. */
        const expectName = want || ((self.__mlsExpectOpen && (Date.now() - self.__mlsExpectOpen.at) < 180000) ? self.__mlsExpectOpen.name : '');
        const nmm = (a, b) => { const nz = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim(); const ta = nz(a).split(' ').filter(x => x.length > 1), tb = nz(b).split(' ').filter(x => x.length > 1); const o = ta.filter(x => tb.indexOf(x) >= 0).length; return o >= 2 || (o >= 1 && Math.min(ta.length, tb.length) === 1); };
        const bootstrapTokens = (value) => {
          const suffix = /^(?:jr|sr|ii|iii|iv|v|esq|junior|senior)$/i;
          return String(value || '').replace(/\([^)]*\)/g, ' ').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim().split(/\s+/).filter((token) => token && !suffix.test(token) && token.length > 1);
        };
        const exactBootstrapName = (observed, expected) => {
          const have = bootstrapTokens(observed), need = bootstrapTokens(expected);
          if (have.length < 2 || need.length < 2) return false;
          const counts = {}; have.forEach((token) => { counts[token] = Number(counts[token] || 0) + 1; });
          for (let index = 0; index < need.length; index++) { if (!counts[need[index]]) return false; counts[need[index]]--; }
          return true;
        };
        const validBootstrapDob = (value) => {
          const match = /^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/.exec(String(value || '').trim());
          if (!match) return false;
          const month = Number(match[1]), day = Number(match[2]), year = Number(match[3]);
          if (year < 1900 || year > new Date().getFullYear() || month < 1 || month > 12 || day < 1 || day > 31) return false;
          const parsed = new Date(Date.UTC(year, month - 1, day));
          return parsed.getUTCFullYear() === year && parsed.getUTCMonth() === month - 1 && parsed.getUTCDate() === day && parsed.getTime() <= Date.now();
        };
        const bootstrapIdentityReady = (selected, frames) => {
          if (!bootstrapIdentity || !exactOpenLease || !selected || !/^(?:banner|shadow-labels|shadow-banner)$/.test(String(selected.via || '')) || !exactBootstrapName(selected.name, want) || !validBootstrapDob(selected.dob)) return false;
          const selectedDob = String(selected.dob || '').replace(/\D/g, '');
          const visible = (frames || []).map((entry) => {
            const raw = entry && entry.result; if (!raw) return null;
            const copy = Object.assign({}, raw); if (copy.frameId == null && entry && typeof entry.frameId === 'number') copy.frameId = entry.frameId; return copy;
          }).filter((candidate) => candidate && candidate.name && (candidate.score || 0) >= 0 && Number(candidate.w || 0) >= 60 && Number(candidate.h || 0) >= 60 && /^(?:banner|shadow-labels|shadow-banner)$/.test(String(candidate.via || '')));
          if (!visible.length || !visible.every((candidate) => exactBootstrapName(candidate.name, want) && validBootstrapDob(candidate.dob) && String(candidate.dob || '').replace(/\D/g, '') === selectedDob)) return false;
          return visible.some((candidate) => typeof candidate.frameId === 'number' && exactOpenLease.appointmentNavigationFrameIds.indexOf(candidate.frameId) >= 0);
        };
        /* v2.9.27 SPEED (schedule lane): when round 1 already proves the FULL bootstrap identity (banner-grade, all frames agree, appointment-frame-bound), the mandatory second confirmation round follows after a SHORT settle instead of the full 2.4s  acceptance semantics unchanged (round 2 re-probes and must re-pass). */
        let bootstrapReadyEarly = false;
        while (!chartExpired() && Date.now() - T0 < BUDGET_MS) {
          polls++;
          /* v1.63: 15s -> 20s. A heavy-but-alive chart load could eat two 15s injection
             timeouts and trigger a false automatic-recovery path (v1.61 live
             finding). 2 x 20s + sleep still fits the 52s budget. */
          const ix = await chartExec({ target: { tabId: tab.id, allFrames: true }, func: mlsReadChartIdentity }, 20000);
          if (ix.timeout) {
            if (chartExpired() || ix.deadline) { chartFailDeadline('patient identity verification'); return; }
            injFails++;
            if (injFails >= 2) { /* frozen renderer - documented recovery, then honest fail (the app retries) */
              return chartRespond({ ok: false, reason: 'athena-read-stalled', opened: opened, error: 'athenaOne stopped responding mid-read. MLS Assist left the Athena tab untouched; check it, then retry.' });
            }
            if (!(await chartWait(1800))) { chartFailDeadline('patient identity verification'); return; }
            continue;
          }
          injFails = 0;
          identityFrameResults = (ix && ix.r) || [];
          const idrArr = identityFrameResults.map((m) => m && m.result).filter(Boolean);
          identDiag = idrArr.map((r) => ({ via: r.via || '', named: !!r.name, sc: Math.round((r.score || 0) * 10) / 10, w: r.w || 0, h: r.h || 0 })).slice(0, 24);
          let cand = mlsBestIdentityFrom((ix && ix.r) || []);
          /* v1.78: shadow-DOM banner fallback (clientsummary/airlock surfaces) -
             fires ONLY when the classic reader found nothing acceptable, so the
             proven schedule-click -> clinical-chart path is untouched. The shadow
             reader emits identity only with BOTH name and DOB.
             v1.81: give the proven REFRESH-CHART/briefing nudge (below) the FIRST
             round - when the nudge can load the full clinical chart, its light-DOM
             banner is the best surface for BOTH identity and the text read; accept
             a shadow identity only from round 2, or once a nudge was clicked. */
          if (bootstrapIdentity || ((polls >= 2 || navClicked) && (!cand || !cand.name || (cand.score || 0) < 0
              /* v1.86: ...or the classic identity is a WEAK non-banner grep that is
                 NOT the expected patient - on shadow-banner charts the classic
                 reader can only find care-team/provider names in the light DOM
                 (live: Barbara Clardy's chart kept reading "Mainline, Lauren M."
                 via lastfirst, so the shadow fallback never ran and the gate
                 refused her every pull). A banner-grade shadow identity beats a
                 lastfirst guess; if shadow finds nothing, behavior is unchanged. */
              || (cand.via !== 'banner' && expectName && !nmm(cand.name, expectName))))) {
            const shadowSettled = await chartSettle(mlsShadowIdentityTry(tab.id, bootstrapIdentity ? { noCache: true, all: true } : null), 8000);
            if (!shadowSettled || !shadowSettled.ok) {
              if (chartExpired()) { chartFailDeadline('shadow patient identity verification'); return; }
            }
            const shadowValue = shadowSettled && shadowSettled.ok ? shadowSettled.value : null;
            const shadowCandidates = bootstrapIdentity ? (Array.isArray(shadowValue) ? shadowValue : []) : (shadowValue ? [shadowValue] : []);
            if (shadowCandidates.length) {
              shadowCandidates.forEach((candidate) => {
                identityFrameResults.push({ frameId: candidate.frameId, result: candidate });
                identDiag.push({ via: candidate.via || 'shadow', named: true, sc: Math.round((candidate.score || 0) * 10) / 10, w: candidate.w || 0, h: candidate.h || 0 });
              });
              const sIdent = mlsBestIdentityFrom(shadowCandidates.map((candidate) => ({ frameId: candidate.frameId, result: candidate })));
              if (sIdent && (!cand || cand.via !== 'banner' || (sIdent.score || 0) > (cand.score || 0))) cand = sIdent;
            }
          }
          bootstrapReadyEarly = !!(bootstrapIdentity && cand && cand.name && expectName && nmm(cand.name, expectName) && bootstrapIdentityReady(cand, identityFrameResults));
          /* the RIGHT patient found (any via) -> done */
          if (cand && cand.name && expectName && nmm(cand.name, expectName) && (!bootstrapIdentity || (polls >= 2 && bootstrapIdentityReady(cand, identityFrameResults)))) { ident = cand; if (!bootstrapIdentity) try { self.__mlsExpectOpen = null; } catch (e) {} break; }
          /* no expectation: a banner IS the open chart -> done (pre-v1.60 behavior, banner-only) */
          if (cand && cand.name && !expectName && cand.via === 'banner') { ident = cand; break; }
          /* catch-all: budget nearly spent - return the best we have; the app-side
             gate makes the final call (honest refuse on mismatch).
             v1.67: NEVER return a junk-frame identity (negative score = demoted
             letters/messaging/hidden frame - the live "Monterosso, ROSEMARY" phantom
             refused 5 of 15 on the 7/07 pull). Returning NO identity lets the app
             gate fall back to name-tokens-in-chart-text + schedule-DOB, which SAVES
             correctly when the real chart is on screen. */
          if (Date.now() - T0 > 42000 && cand && cand.name && (cand.score || 0) >= 0 && (!bootstrapIdentity || bootstrapIdentityReady(cand, identityFrameResults))) { ident = cand; break; }
          if (Date.now() - T0 > 42000) { ident = null; break; }
          /* not the right identity yet: is this the exam-prep/briefing view? nudge it. */
          const ex = await chartExec({ target: { tabId: tab.id, allFrames: true }, func: mlsEnsureClinicalChartFn, args: [chartRequestGuard] }, 10000);
          if (ex.timeout && (chartExpired() || ex.deadline)) { chartFailDeadline('clinical chart navigation'); return; }
          const evs = ((ex && ex.r) || []).map((m) => m && m.result).filter(Boolean);
          const briefingNow = evs.some((v) => v && v.briefing);
          sawBriefing = sawBriefing || briefingNow;
          const clickedNow = evs.find((v) => v && v.clicked);
          if (clickedNow) {
            navClicked = navClicked || clickedNow.clicked; clickAt = Date.now(); noClickRounds = 0;
            /* the chart load runs page JS; a hidden tab is throttled ~9x - foreground
               it for the load (day pulls already run foregrounded via go-home; when
               we take focus ourselves we hand it back to MLS below). */
            if (self.__mlsQpEnsure) {
              const qpSettled = await chartSettle(self.__mlsQpEnsure(tab, sender && sender.tab && sender.tab.id), 8000);
              if (!qpSettled || !qpSettled.ok || chartExpired()) { chartFailDeadline('quiet Athena work-tab setup'); return; }
            }
            if (!(await chartWait(3200))) { chartFailDeadline('clinical chart load'); return; }
            continue;
          }
          if (navClicked) {
            /* we clicked into the clinical chart and it is loading (briefing markers
               gone) - keep waiting; accept a weaker identity only after settle AND
               only when nothing specific was expected (else wait for the match). */
            if (cand && cand.name && !expectName && (cand.score || 0) >= 0 && clickAt && (Date.now() - clickAt) > 12000) { ident = cand; break; } /* v1.67: junk-frame guard */
          } else if (!briefingNow) {
            if (cand && cand.name && !expectName && (cand.score || 0) >= 0) { ident = cand; break; } /* ordinary chart, name-only identity; v1.67: junk-frame guard */
            if (!expectName && polls >= (sawBriefing ? 8 : 3)) { ident = cand || null; break; } /* nothing more to wait for */
          }
          noClickRounds++;
          if (briefingNow && noClickRounds >= 5 && !navClicked) break; /* exam-prep with nothing safe to click -> fail honestly below */
          if (!(await chartWait(bootstrapReadyEarly ? 900 : 2400))) { chartFailDeadline('clinical chart readiness'); return; }
        }
        if (chartExpired()) { chartFailDeadline('clinical chart readiness'); return; }
        const V59 = (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '';
        const restoreFocus = async () => {
          if (!fgByUs || !self.__mlsFgFocusApp || chartExpired()) return false;
          const settled = await chartSettle(self.__mlsFgFocusApp(), 3000);
          return !!(settled && settled.ok && !chartExpired());
        };
        if (sawBriefing && !(ident && ident.name)) {
          __mlsReadsSinceReload++;
          await restoreFocus();
          return chartRespond({ ok: false, reason: 'exam-prep-stuck', opened: opened, briefing: true, navClicked: navClicked, polls: polls, identDiag: identDiag, version: V59, error: 'athenaOne stayed on the appointment exam-prep view (no patient banner) - the clinical chart never loaded, so nothing was captured.' });
        }
        if (bootstrapIdentity) {
          var bannerGrade = !!(ident && /^(?:banner|shadow-labels|shadow-banner)$/.test(String(ident.via || '')));
          var exactNameMatched = !!(bannerGrade && exactBootstrapName(ident.name, want));
          var validBannerDob = !!(bannerGrade && validBootstrapDob(ident.dob));
          var chosenDobKey = String(ident && ident.dob || '').replace(/\D/g, '');
          var bannerCandidates = (identityFrameResults || []).map(function (entry) {
            var candidate = entry && entry.result;
            if (!candidate) return null;
            var copy = Object.assign({}, candidate);
            if (copy.frameId == null && entry && typeof entry.frameId === 'number') copy.frameId = entry.frameId;
            return copy;
          }).filter(function (candidate) {
            return candidate && candidate.name && (candidate.score || 0) >= 0 && Number(candidate.w || 0) >= 60 && Number(candidate.h || 0) >= 60 && /^(?:banner|shadow-labels|shadow-banner)$/.test(String(candidate.via || ''));
          });
          var bannerCandidatesAgree = bannerCandidates.length > 0 && bannerCandidates.every(function (candidate) {
            var candidateDobKey = String(candidate.dob || '').replace(/\D/g, '');
            return exactBootstrapName(candidate.name, want) && validBootstrapDob(candidate.dob) && candidateDobKey === chosenDobKey;
          });
          var routeBoundBannerSeen = !!(exactOpenLease && bannerCandidates.some(function (candidate) {
            return typeof candidate.frameId === 'number' && exactOpenLease.appointmentNavigationFrameIds.indexOf(candidate.frameId) >= 0;
          }));
          if (!(exactOpenLease && exactOpenLease.appointmentIdBound && exactOpenLease.requestId === chartRequestId && exactOpenLease.appointmentId === expectedAppointmentId && exactNameMatched && validBannerDob && bannerCandidatesAgree && routeBoundBannerSeen)) {
            try { self.__mlsExpectOpen = null; } catch (eClearBootstrapLease) {}
            return chartRespond({ ok: false, reason: !bannerGrade ? 'banner-identity-unverified' : (!exactNameMatched ? 'banner-name-mismatch' : (!validBannerDob ? 'banner-dob-unverified' : (!bannerCandidatesAgree ? 'banner-identity-conflict' : 'banner-navigation-frame-unverified'))), opened: opened, error: 'The exact appointment opened, but its changed Athena frame did not prove one consistent expected name and DOB. Nothing was stored.' });
          }
          try { self.__mlsExpectOpen = null; } catch (eClearBootstrapLease2) {}
          return chartRespond({
            ok: true, opened: true, bootstrapIdentity: true,
            stageMs: { total: Date.now() - chartRequestStartedAt, identity: Date.now() - T0, polls: polls },
            appointmentId: expectedAppointmentId, athenaTabId: exactOpenLease.tabId,
            chartName: String(ident.name || ''), chartDob: String(ident.dob || ''), chartMrn: String(ident.mrn || ''), via: String(ident.via || ''),
            identityBootstrapReceipt: {
              kind: 'athena-appointment-banner-identity', complete: true,
              requestId: chartRequestId, appointmentId: expectedAppointmentId,
              scheduleDate: expectedScheduleDate, athenaTabId: exactOpenLease.tabId,
              appointmentIdBound: true, navigationProven: true,
              navigationFrameIds: exactOpenLease.appointmentNavigationFrameIds.slice(),
              exactNameMatched: true, bannerIdentity: true, dobVerified: true
            }
          });
        }
        const __identDoneAt = Date.now(); /* v2.9.27 stage timing: identity loop ended, text read begins */
        let results = [];
        {
          const tx = await chartExec({ target: { tabId: tab.id, allFrames: true }, func: () => {
            const PER_FRAME_CAP = 90000;
            let u = ''; try { u = location.href; } catch (e0) {}
            try {
              if (!document.body) return { u: u, t: '', fullLen: 0, truncated: false, readOk: false, reason: 'body-missing' };
              const raw = String(document.body.innerText || '');
              return { u: u, t: raw.slice(0, PER_FRAME_CAP), fullLen: raw.length, truncated: raw.length > PER_FRAME_CAP, readOk: true };
            } catch (e) { return { u: u, t: '', fullLen: 0, truncated: false, readOk: false, reason: 'frame-read-failed' }; }
          } }, 25000);
          if (tx.timeout) { /* frozen mid-read - recover and fail honestly (the app retries) */
            if (chartExpired() || tx.deadline) { chartFailDeadline('clinical chart text read'); return; }
            await restoreFocus();
            return chartRespond({ ok: false, reason: 'athena-read-stalled', opened: opened, version: V59, error: 'athenaOne stopped responding during the chart read. MLS Assist left the Athena tab untouched; check it, then retry.' });
          }
          if (tx.r) results = tx.r;
          else {
            const fallbackTx = await chartExec({ target: { tabId: tab.id }, func: () => { const raw = String(document.body && document.body.innerText || ''); return { u: location.href, t: raw.slice(0, 90000), fullLen: raw.length, truncated: raw.length > 90000, readOk: !!document.body }; } }, 5000);
            if (fallbackTx.timeout) {
              await restoreFocus();
              if (chartExpired() || fallbackTx.deadline) { chartFailDeadline('clinical chart fallback read'); return; }
              return chartRespond({ ok: false, reason: 'athena-read-stalled', opened: opened, version: V59, error: 'athenaOne did not finish the bounded chart fallback read. Nothing was captured.' });
            }
            results = fallbackTx.r || [];
          }
        }
        __mlsReadsSinceReload++;
        {
          /* A complete chart read requires every contributing clinical frame to be
             read in full and independently bound to the requested patient. */
          const NOISE_FRAME_RE = /stm\.esp|coordinator\/enterprise|globalnav\.esp|globalframeset\.esp|globaliframe\.esp|framecontent\.esp|statusbar\.esp|schedulenavclose|findpatient\.esp|(?:static\/)?blank\.html/i;
          const rawFrames = (results || []).map((r) => {
            const x = (r && r.result) || {};
            return { frameId: (r && typeof r.frameId === 'number') ? r.frameId : -1, u: x.u || '', t: x.t || '', fullLen: Number(x.fullLen || 0), truncated: x.truncated === true, readOk: x.readOk === true, reason: x.reason || '' };
          });
          const textDiagStrict = rawFrames.map((f) => ({ n: f.fullLen, got: f.t.length, ok: f.readOk, cut: f.truncated })).slice(0, 24);
          const eligibleFrames = rawFrames.filter((f) => !NOISE_FRAME_RE.test(f.u || ''));
          const unreadFrames = eligibleFrames.filter((f) => !f.readOk).length;
          const oversizeFrames = eligibleFrames.filter((f) => f.truncated || (f.readOk && f.fullLen !== f.t.length)).length;
          const readableFrames = eligibleFrames.filter((f) => f.readOk && f.t && f.t.trim());
          const scoreStrict = (txt) => { const s = (txt || '').toLowerCase(); let n = 0; ['problem', 'medication', 'allerg', 'history', 'vital', 'diagnos', 'assessment', 'date of birth', 'dob', 'surg', 'imaging', 'mri', 'immuniz'].forEach((k) => { if (s.indexOf(k) >= 0) n++; }); ['full encounter summary', 'encounter summary', 'performed by', 'reason for visit', 'follow-up', 'assessment & plan'].forEach((k) => { if (s.indexOf(k) >= 0) n += 3; }); if (/inbox|unread messages|message thread/.test(s)) n -= 4; return n; };
          const nrmStrict = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
          const nameTokensStrict = (s) => nrmStrict(s).split(' ').filter((x) => x.length > 1);
          const strictNameMatch = (observed, expected) => {
            /* Live 2026-07-16: athena's banner abbreviates long names - observed
               "Cubbage-Reilly A" for stored "Ann Cubbage-Reilly" (full surname +
               first-name INITIAL). Both the first and last stored tokens may
               match an observed token by exact text, a >=4-char prefix in either
               direction, or a single-letter initial. Single-letter observed
               tokens are RETAINED for this check. Every DOB/MRN gate plus the
               strong-mismatch veto are unchanged, so a genuinely different
               patient (same surname, different DOB) still fails closed. */
            const haveAll = nrmStrict(observed).split(' ').filter(Boolean);
            const need = nameTokensStrict(expected);
            if (haveAll.length < 2 || need.length < 2) return false;
            const tokMatch = (h, n) => h === n ||
              (h.length >= 4 && n.length >= 4 && (h.indexOf(n) === 0 || n.indexOf(h) === 0)) ||
              (h.length === 1 && h === n.charAt(0));
            const firstOk = haveAll.some((h) => tokMatch(h, need[0]));
            const lastOk = haveAll.some((h) => tokMatch(h, need[need.length - 1]));
            return firstOk && lastOk;
          };
          const dobPartsStrict = (s) => {
            const m = String(s || '').match(/\b(\d{1,4})[\/.\-](\d{1,2})[\/.\-](\d{1,4})\b/);
            if (!m) return null;
            let y, mo, d;
            if (m[1].length === 4) { y = m[1]; mo = m[2]; d = m[3]; } else { mo = m[1]; d = m[2]; y = m[3]; }
            if (String(y).length !== 4) return null;
            return { y: String(y), m: String(Number(mo)), d: String(Number(d)) };
          };
          const sameDobStrict = (a, b) => { const aa = dobPartsStrict(a), bb = dobPartsStrict(b); return !!(aa && bb && aa.y === bb.y && aa.m === bb.m && aa.d === bb.d); };
          const mrnKeyStrict = (s) => String(s || '').replace(/\D/g, '');
          const textHasDobStrict = (txt, expectedDob) => {
            const p = dobPartsStrict(expectedDob); if (!p) return false;
            const sep = '[\\/\\.\\-\\s]+';
            return new RegExp('(?:\\b0?' + p.m + sep + '0?' + p.d + sep + p.y + '\\b|\\b' + p.y + sep + '0?' + p.m + sep + '0?' + p.d + '\\b)').test(String(txt || ''));
          };
          const textHasMrnStrict = (txt, expectedMrn) => { const k = mrnKeyStrict(expectedMrn); return !!(k && new RegExp('(?:^|\\D)' + k + '(?:\\D|$)').test(String(txt || ''))); };
          const identityMatchesTarget = (who) => {
            if (!who || !strictNameMatch(who.name, want)) return false;
            const observedDob = String(who.dob || '').trim(), observedMrn = mrnKeyStrict(who.mrn);
            if (wantDob && observedDob && !sameDobStrict(observedDob, wantDob)) return false;
            if (wantMrn && observedMrn && observedMrn !== mrnKeyStrict(wantMrn)) return false;
            return !!((wantDob && observedDob && sameDobStrict(observedDob, wantDob)) || (wantMrn && observedMrn && observedMrn === mrnKeyStrict(wantMrn)));
          };
          const frameIdentity = {};
          (identityFrameResults || []).forEach((r) => { if (r && typeof r.frameId === 'number' && r.result) frameIdentity[r.frameId] = r.result; });
          const frameBoundToTarget = (f) => {
            if (!want || (!wantDob && !wantMrn)) return false;
            if (identityMatchesTarget(frameIdentity[f.frameId])) return true;
            if (!strictNameMatch(f.t, want)) return false;
            return !!((wantDob && textHasDobStrict(f.t, wantDob)) || (wantMrn && textHasMrnStrict(f.t, wantMrn)));
          };
          const rankedStrict = readableFrames.map((f) => ({ f: f, s: scoreStrict(f.t) })).filter((r) => r.s > 0).sort((a, b) => b.s - a.s);
          const chosenStrict = [];
          const MERGE_CAP = 85000;
          let mergedStrict = '', unboundClinicalFrames = 0, oversizeClinicalFrames = oversizeFrames, omittedForCap = 0;
          rankedStrict.forEach((r) => {
            const f = r.f;
            if (!frameBoundToTarget(f)) { unboundClinicalFrames++; return; }
            if (f.truncated || f.fullLen !== f.t.length) return;
            const separator = mergedStrict ? '\n\n===== (next chart frame) =====\n\n' : '';
            if (mergedStrict.length + separator.length + f.t.length > MERGE_CAP) { omittedForCap++; return; }
            mergedStrict += separator + f.t;
            chosenStrict.push(f);
          });
          const pickStrict = (chosenStrict[0] || (rankedStrict.length ? rankedStrict[0].f : null)) || { u: tab.url, t: '' };
          const versionStrict = (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '';
          const globalNameMatches = !!(want && ident && ident.name && strictNameMatch(ident.name, want));
          const globalStrongMismatch = !!(globalNameMatches && ((wantDob && ident.dob && !sameDobStrict(ident.dob, wantDob)) || (wantMrn && ident.mrn && mrnKeyStrict(ident.mrn) !== mrnKeyStrict(wantMrn))));
          if (want && ident && ident.name && (!globalNameMatches || globalStrongMismatch)) {
            await restoreFocus();
            return chartRespond({ ok: false, reason: 'wrong-chart', chartName: ident.name, chartDob: ident.dob || '', opened: opened, version: versionStrict, error: 'The open athenaOne chart identity does not match ' + want + '. Nothing was captured for ' + want + '.' });
          }
          if (want && !opened && !(ident && ident.name)) {
            await restoreFocus();
            return chartRespond({ ok: false, reason: 'unverified', opened: false, version: versionStrict, error: 'Could not open or verify ' + want + '\u2019s chart (no patient identity readable on the open page). Open the patient\u2019s chart in athenaOne, then pull again \u2014 nothing was captured.' });
          }
          await restoreFocus();
          const exactGlobalIdentity = identityMatchesTarget(ident);
          const chartTextStrict = mergedStrict;
          const expectedClinicalFramesStrict = rankedStrict.length;
          const chartTruncatedStrict = oversizeClinicalFrames > 0 || omittedForCap > 0;
          const chartReceiptStrict = {
            kind: 'athena-chart-coverage', requestId: chartRequestGuard.token, deadlineAt: chartRequestGuard.deadline,
            complete: !!(chartTextStrict.trim() && chosenStrict.length && exactGlobalIdentity && !chartTruncatedStrict && unreadFrames === 0 && unboundClinicalFrames === 0 && chosenStrict.length === expectedClinicalFramesStrict),
            readerVersion: '2.9.19-chart-r3', capturedAt: Date.now(),
            expectedClinicalFrames: expectedClinicalFramesStrict, readClinicalFrames: chosenStrict.length,
            boundClinicalFrames: chosenStrict.length, unboundClinicalFrames: unboundClinicalFrames,
            oversizeClinicalFrames: oversizeClinicalFrames, unreadFrames: unreadFrames, omittedForCap: omittedForCap,
            consideredFrames: eligibleFrames.length, textChars: chartTextStrict.length, truncated: chartTruncatedStrict,
            identityObserved: exactGlobalIdentity, identityVia: (ident && ident.via) || ''
          };
          if (chartReceiptStrict.complete) {
            try { self.__mlsVerifiedReadTarget = { tabId: tab.id, name: want, dob: wantDob, mrn: wantMrn, at: Date.now(), requestId: chartReceiptStrict.requestId }; } catch (eReadLease) {}
          }
          return chartRespond({ ok: true, text: chartTextStrict, receipt: chartReceiptStrict, url: pickStrict.u || tab.url, title: tab.title, opened: opened, frames: eligibleFrames.length, stageMs: { total: Date.now() - chartRequestStartedAt, identity: __identDoneAt - T0, text: Date.now() - __identDoneAt, polls: polls }, chartName: (ident && ident.name) || '', chartDob: (ident && ident.dob) || '', chartMrn: (ident && ident.mrn) || '', version: versionStrict, via: (ident && ident.via) || '', briefingNav: navClicked || '', identDiag: identDiag, textDiag: textDiagStrict, expected: expectName ? 1 : 0 });
        }
      } catch (e) { chartRespond({ ok: false, error: String((e && e.message) || e) }); }
    })();
    return true;
  }
  /* ---- v1.51: read the OPEN athena chart's identity (for the writeback pre-gate) ---- */
  if (msg.type === 'mlsAssistChartIdentity') {
    (async () => {
      try {
        const all = await chrome.tabs.query({});
        const tab = await mlsPickAthenaTab(all, { athenaOnly: true }); /* v1.90 unified picker */
        if (!tab) return sendResponse({ ok: false, error: 'no athena tab' });
        const idr = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: mlsReadChartIdentity });
        let ident = mlsBestIdentityFrom(idr); /* v1.59: banner-preferred */
        /* v1.78/v1.86: shadow-DOM banner fallback (see mlsReadChartIdentityShadow);
           a banner-grade shadow identity also replaces a weak non-banner grep. */
        if (!ident || !ident.name || (ident.score || 0) < 0 || ident.via !== 'banner') { const sI = await mlsShadowIdentityTry(tab.id); if (sI && (!ident || ident.via !== 'banner')) ident = sI; }
        sendResponse({ ok: true, identity: ident ? { name: ident.name, dob: ident.dob || '', mrn: ident.mrn || '' } : null });
      } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
    })();
    return true;
  }
  // Read the innerText of whatever tab is ACTIVE right now (so the agent sees the
  // tab it is currently on, even after a tab switch).
  if (msg.type === 'mlsAssistPageText') {
    (async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) return sendResponse({ text: '' });
        // Read EVERY frame (top + iframes) so the agent can see iframe-based EMRs.
        let results = [];
        try { results = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: () => (document.body && document.body.innerText || '').slice(0, 6000) }); }
        catch (e) { results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => (document.body && document.body.innerText || '').slice(0, 9000) }); }
        let text = '';
        for (const fr of results) { const t = fr && fr.result; if (t) { text += (text ? '\n---- (frame) ----\n' : '') + t; } if (text.length > 12000) break; }
        sendResponse({ text: text.slice(0, 12000), url: tab.url, title: tab.title });
      } catch (e) { sendResponse({ text: '' }); }
    })();
    return true;
  }
  // Numbered inventory of the interactive controls on the ACTIVE tab. The agent
  // targets these by #index, which is far more reliable than guessing labels.
  // MUST stay in lock-step with _inv() inside mlsAssistExec (same selector/order).
  if (msg.type === 'mlsAssistElements') {
    (async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) return sendResponse({ list: [] });
        const perFrame = () => {
          function vis(el) { try { if (el.disabled) return false; if (el.getAttribute && el.getAttribute('aria-hidden') === 'true') return false; var st = getComputedStyle(el); if (st.display === 'none' || st.visibility === 'hidden' || parseFloat(st.opacity || '1') < 0.05) return false; var r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; return true; } catch (e) { return true; } }
          function lab(e) { var s = (e.innerText || e.value || (e.getAttribute && (e.getAttribute('aria-label') || e.getAttribute('title') || e.getAttribute('placeholder') || e.getAttribute('name'))) || e.id || ''); return String(s).replace(/\s+/g, ' ').trim().slice(0, 60); }
          var sel = 'button,a[href],[role=button],[role=link],[role=menuitem],[role=tab],[role=option],input:not([type=hidden]),textarea,select,[contenteditable=""],[contenteditable="true"],[onclick]';
          var nodes = Array.prototype.slice.call(document.querySelectorAll(sel)).filter(vis).slice(0, 120);
          return nodes.map(function (e) { var tag = (e.tagName || '').toLowerCase(); var ty = e.getAttribute && e.getAttribute('type'); var role = e.getAttribute && e.getAttribute('role'); var ph = e.getAttribute && e.getAttribute('placeholder'); return tag + (ty ? ('[' + ty + ']') : '') + (role ? (' role=' + role) : '') + ' «' + (lab(e) || ph || '') + '»'; });
        };
        let results = [];
        try { results = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: perFrame }); }
        catch (e) { results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: perFrame }); }
        const list = [], map = [];
        for (const fr of results) {
          const arr = (fr && fr.result) || [];
          for (let li = 0; li < arr.length; li++) {
            if (list.length >= 120) break;
            map.push({ frameId: fr.frameId || 0, localIndex: li });
            list.push(list.length + ': ' + arr[li]);
          }
          if (list.length >= 120) break;
        }
        _mlsFrameMap[tab.id] = map;
        sendResponse({ list });
      } catch (e) { sendResponse({ list: [] }); }
    })();
    return true;
  }
  // Execute a single agent action on the ACTIVE tab (or switch tabs). This lets the
  // autopilot act on whatever tab it is on, including after switching.
  if (msg.type === 'mlsAssistExec') {
    (async () => {
      try {
        const action = msg.action || {};
        /* Defense in depth for the generic AI executor. Dedicated typed
           adapters never use this route. A model/prompt may navigate and fill
           ordinary text, but it can never finalize clinical/financial actions
           or type into structured order/code destinations through this API. */
        const _finalAction = /\b(save|sign|submit|approve|post|transmit|authorize|finali[sz]e|place\s+(?:the\s+)?order|send\s+(?:the\s+)?(?:rx|prescription)|e-?prescribe|file\s+(?:the\s+)?claim|check\s*-?\s*out|delete|remove|void)\b/i;
        const _structuredTarget = /\b(order|prescri(?:ption|be)?|\brx\b|medication\s+order|pharmacy|diagnos(?:is|es|tic)|\bicd(?:-?10)?\b|\bcpt\b|billing|charge|superbill|claim|referral|imaging\s+order|lab(?:oratory)?\s+order)\b/i;
        const _outerHay = String(action.target || '') + ' ' + String(action.text || '');
        if (/^(click|confirm|select)$/i.test(String(action.type || '')) && _finalAction.test(_outerHay)) {
          return sendResponse({ ok: false, blocked: true, reason: 'final-action-blocked', msg: 'MLS Assist cannot Save, Sign, Submit, Post, approve, delete, transmit, or place an order.' });
        }
        if (/^type$/i.test(String(action.type || '')) && _structuredTarget.test(String(action.target || ''))) {
          return sendResponse({ ok: false, blocked: true, reason: 'structured-route-blocked', msg: 'Generic AI typing into diagnoses, billing, prescription or order fields is disabled. Use the typed preview workflow.' });
        }
        if (action.type === 'switchtab') {
          const tabs = await chrome.tabs.query({});
          const t = String(action.target || '').toLowerCase().trim();
          const http = tabs.filter(x => /^https?:/.test(x.url || ''));
          let tab = t ? http.find(x => ((x.title || '').toLowerCase().includes(t) || (x.url || '').toLowerCase().includes(t))) : null;
          if (!tab) { const others = http.filter(x => !x.active).sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0)); tab = others[0]; }
          if (!tab) return sendResponse({ ok: false, msg: 'No other tab to switch to.' });
          await chrome.tabs.update(tab.id, { active: true });
          try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (e) {}
          return sendResponse({ ok: true, msg: 'Switched to: ' + (tab.title || tab.url || 'tab') });
        }
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) return sendResponse({ ok: false, msg: 'No active tab.' });
        // Frame routing: a "#index" target may live inside an iframe (Athena, etc.).
        // Look it up in the map built by mlsAssistElements and run the action in THAT
        // frame, passing the element's local index so it resolves the exact control.
        let _execTarget = { tabId: tab.id };
        let _act = action;
        const _im = /^#(\d+)$/.exec(String(action.target || '').trim());
        if (_im && _mlsFrameMap[tab.id] && _mlsFrameMap[tab.id][+_im[1]]) {
          const _ent = _mlsFrameMap[tab.id][+_im[1]];
          if (_ent.frameId) _execTarget = { tabId: tab.id, frameIds: [_ent.frameId] };
          _act = Object.assign({}, action, { _localIdx: _ent.localIndex });
        }
        // Retry wrapper: web EMRs render asynchronously, so a target may not exist on
        // the first try. We re-run the injected executor a few times with a short
        // settle delay — but ONLY when the failure was "couldn't find it" (notfound).
        // Success returns immediately, so the happy path stays fast.
        const tries = (action && /^(click|confirm|type|select|pastenote)$/.test(action.type || '')) ? 5 : 1;
        let r = null;
        for (let i = 0; i < tries; i++) {
          [r] = await chrome.scripting.executeScript({
          target: _execTarget,
          args: [_act],
          func: async (act) => {
            function visible(el) {
              if (!el) return false;
              try {
                if (el.disabled) return false;
                if (el.getAttribute && el.getAttribute('aria-hidden') === 'true') return false;
                const st = getComputedStyle(el);
                if (st.display === 'none' || st.visibility === 'hidden' || parseFloat(st.opacity || '1') < 0.05) return false;
                const rc = el.getBoundingClientRect();
                if (rc.width < 1 || rc.height < 1) return false;
                return true;
              } catch (e) { return true; }
            }
            function labelOf(e) {
              return ((e.innerText || e.value || (e.getAttribute && (e.getAttribute('aria-label') || e.getAttribute('title') || e.getAttribute('placeholder') || e.getAttribute('name') || e.id)) || '') + '').toLowerCase().replace(/\s+/g, ' ').trim();
            }
            var FINAL_ACTION = /\b(save|sign|submit|approve|post|transmit|authorize|finali[sz]e|place\s+(?:the\s+)?order|send\s+(?:the\s+)?(?:rx|prescription)|e-?prescribe|file\s+(?:the\s+)?claim|check\s*-?\s*out|delete|remove|void)\b/i;
            var STRUCTURED_TARGET = /\b(order|prescri(?:ption|be)?|\brx\b|medication\s+order|pharmacy|diagnos(?:is|es|tic)|\bicd(?:-?10)?\b|\bcpt\b|billing|charge|superbill|claim|referral|imaging\s+order|lab(?:oratory)?\s+order)\b/i;
            // Rebuild the SAME ordered inventory the agent saw, so a "#index" target
            // maps to the exact element. Must match mlsAssistElements above.
            function _inv() {
              function vis(el) { try { if (el.disabled) return false; if (el.getAttribute && el.getAttribute('aria-hidden') === 'true') return false; var st = getComputedStyle(el); if (st.display === 'none' || st.visibility === 'hidden' || parseFloat(st.opacity || '1') < 0.05) return false; var r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; return true; } catch (e) { return true; } }
              var sel = 'button,a[href],[role=button],[role=link],[role=menuitem],[role=tab],[role=option],input:not([type=hidden]),textarea,select,[contenteditable=""],[contenteditable="true"],[onclick]';
              return Array.prototype.slice.call(document.querySelectorAll(sel)).filter(vis).slice(0, 120);
            }
            function _byIdx(t) { var m = /^#(\d+)$/.exec(String(t || '').trim()); if (!m) return null; var el = _inv()[+m[1]]; return (el && visible(el)) ? el : (el || null); }
            // When frame-routed, the background passes the element's LOCAL index in this frame.
            function _local() { try { return (typeof act._localIdx === 'number') ? (_inv()[act._localIdx] || null) : null; } catch (e) { return null; } }
            // Scored finder — prefers an exact label, a visible & enabled element, an
            // interactive role, and one inside the viewport. Far more accurate than the
            // old "first substring match", which often clicked the wrong control.
            function findEl(target) {
              if (!target) return null;
              try { const el = document.querySelector(target); if (el && visible(el)) return el; } catch (e) {}
              const t = String(target).toLowerCase().replace(/\s+/g, ' ').trim();
              if (!t) return null;
              const cand = [...document.querySelectorAll('button,a,[role=button],[role=link],[role=menuitem],[role=tab],[role=option],input,textarea,select,label,[onclick],[contenteditable=""],[contenteditable="true"]')];
              const tc = t.replace(/[^a-z0-9 ]/g, '').trim();
              let best = null, bestScore = 19;
              for (const e of cand) {
                const lab = labelOf(e);
                if (!lab) continue;
                let s = -1;
                if (lab === t) s = 100;
                else if (lab.replace(/[^a-z0-9 ]/g, '').trim() === tc) s = 90;
                else if (lab.startsWith(t) || lab.endsWith(t)) s = 70;
                else if (lab.includes(t)) s = 50 - Math.min(40, Math.abs(lab.length - t.length));
                if (s < 0) continue;
                if (visible(e)) s += 30; else s -= 25;
                const tag = (e.tagName || '').toLowerCase();
                if (tag === 'button' || (e.getAttribute && e.getAttribute('role') === 'button') || tag === 'a') s += 6;
                try { const rc = e.getBoundingClientRect(); if (rc.top >= 0 && rc.top < innerHeight) s += 4; } catch (er) {}
                if (s > bestScore) { bestScore = s; best = e; }
              }
              return best;
            }
            function fireClick(el) {
              try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) {}
              const r = el.getBoundingClientRect();
              const x = r.left + r.width / 2, y = r.top + r.height / 2;
              const opt = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y };
              for (const t of ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
                try { el.dispatchEvent(new (t.startsWith('pointer') ? PointerEvent : MouseEvent)(t, opt)); } catch (e) {}
              }
              try { el.click(); } catch (e) {}
            }
            // v1.28 — hardened, VERIFIED text entry (same logic as top-level mlsRobustType):
            // resolves a real editable field from a label/wrapper, clicks+focuses, native
            // setter -> simulated paste -> per-character keystrokes that drive MASKED inputs,
            // then SELECTS a matching TYPEAHEAD suggestion, and re-reads after settle + blur.
            // Returns {ok, confirmed, stuck, picked, method, reason} so the loop can stop.
            async function typeInto(el, text) {
              var txt = String(text == null ? '' : text);
              var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
              function _isEd(e) { if (!e || !e.tagName) return false; if (e.isContentEditable) return true; var tg = e.tagName.toUpperCase(); if (tg === 'TEXTAREA') return true; if (tg === 'INPUT') { var t = (e.getAttribute('type') || 'text').toLowerCase(); return /^(text|search|email|url|tel|number|password|date|month|week|time|datetime-local|)$/.test(t); } return false; }
              function _resolve(e) { if (_isEd(e)) return e; if (!e || !e.tagName) return e; try { if (e.tagName.toUpperCase() === 'LABEL') { var f = e.getAttribute('for'); if (f) { var byId = document.getElementById(f); if (_isEd(byId)) return byId; } var within = e.querySelector('input:not([type=hidden]),textarea,[contenteditable=""],[contenteditable="true"]'); if (_isEd(within)) return within; } } catch (e2) {} try { var n = e.querySelector && e.querySelector('input:not([type=hidden]),textarea,[contenteditable=""],[contenteditable="true"]'); if (_isEd(n)) return n; } catch (e3) {} try { var sib = e.nextElementSibling, k = 0; while (sib && k < 3) { if (_isEd(sib)) return sib; var inS = sib.querySelector && sib.querySelector('input:not([type=hidden]),textarea,[contenteditable]'); if (_isEd(inS)) return inS; sib = sib.nextElementSibling; k++; } } catch (e4) {} try { var p = e.parentElement, d = 0; while (p && d < 3) { var inp = p.querySelector && p.querySelector('input:not([type=hidden]),textarea,[contenteditable=""],[contenteditable="true"]'); if (_isEd(inp)) return inp; p = p.parentElement; d++; } } catch (e5) {} return e; }
              el = _resolve(el);
              if (!el || !_isEd(el)) return { ok: false, confirmed: false, stuck: true, method: 'none', reason: 'no-field', into: 0 };
              if (el.readOnly || el.disabled) return { ok: false, confirmed: false, stuck: true, method: 'none', reason: 'readonly', into: 0 };
              var CE = !!el.isContentEditable;
              function rd() { return CE ? (el.innerText || el.textContent || '') : (el.value || ''); }
              function norm(s) { return String(s || '').replace(/\s+/g, ' ').trim().toLowerCase(); }
              function digits(s) { return String(s || '').replace(/\D/g, ''); }
              function isMasked() { try { if (CE) return false; var t = (el.getAttribute('type') || '').toLowerCase(); if (t === 'date' || t === 'tel') return true; var ph = el.getAttribute('placeholder') || ''; if (/[\/\-.]/.test(ph) && /[mdyhMDYH#0_]/.test(ph)) return true; if (el.getAttribute('inputmode') === 'numeric') return true; if (el.getAttribute('data-mask') || el.getAttribute('pattern')) return true; var ml = el.maxLength; if (ml && ml > 0 && ml <= 12 && /[\/\-.]/.test(ph)) return true; } catch (e) {} return false; }
              var masked = isMasked();
              function landed() { var cur = rd(); if (!cur && txt) return false; var a = norm(cur), b = norm(txt); if (!b) return true; if (a.indexOf(b.slice(0, Math.min(b.length, 40))) >= 0) return true; if (masked) { var dc = digits(cur), dt = digits(txt); if (dt && dc.indexOf(dt) >= 0) return true; } return cur.replace(/\s+/g, '').length >= Math.min(txt.replace(/\s+/g, '').length, 15); }
              function setNative(v) { if (CE) { try { el.textContent = v; } catch (e) {} return; } var pr = (el.tagName === 'TEXTAREA') ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; var d = Object.getOwnPropertyDescriptor(pr, 'value'); if (d && d.set) d.set.call(el, v); else el.value = v; }
              function fireInput(data, type) { try { el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: type || 'insertText', data: data })); } catch (e) { try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch (e2) {} } }
              function clearField() { try { if (!CE && el.setSelectionRange) el.setSelectionRange(0, (el.value || '').length); } catch (e) {} setNative(''); fireInput('', 'deleteContentBackward'); }
              function _vis(e) { try { var r = e.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; var s = getComputedStyle(e); return s.display !== 'none' && s.visibility !== 'hidden'; } catch (e2) { return true; } }
              try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
              try { el.click(); } catch (e) {}
              try { el.focus(); } catch (e) {}
              await sleep(0);
              async function keystroke() { clearField(); for (var i = 0; i < txt.length; i++) { var ch = txt.charAt(i); try { el.dispatchEvent(new KeyboardEvent('keydown', { key: ch, bubbles: true })); } catch (e) {} try { el.dispatchEvent(new KeyboardEvent('keypress', { key: ch, bubbles: true })); } catch (e) {} if (CE) { var ok; try { ok = document.execCommand('insertText', false, ch); } catch (e) { ok = false; } if (!ok) setNative(rd() + ch); } else { var base = (el.value != null) ? el.value : ''; setNative(base + ch); } fireInput(ch, 'insertText'); try { el.dispatchEvent(new KeyboardEvent('keyup', { key: ch, bubbles: true })); } catch (e) {} await sleep(masked ? 18 : 6); } try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {} }
              async function pickSuggestion() { await sleep(320); var opts = []; var ac = el.getAttribute && (el.getAttribute('aria-controls') || el.getAttribute('aria-owns')); if (ac) { var box = document.getElementById(ac); if (box) opts = [].slice.call(box.querySelectorAll('[role=option],li,.option,.item')).filter(_vis); } if (!opts.length) opts = [].slice.call(document.querySelectorAll('[role=option],[role=listbox] li,.autocomplete-item,.suggestion,.typeahead-option,ul[class*=auto] li,ul[class*=suggest] li,li[class*=option]')).filter(_vis); if (!opts.length) { var lists = [].slice.call(document.querySelectorAll('ul,ol,[role=listbox],[role=menu]')).filter(_vis); for (var L = 0; L < lists.length && !opts.length; L++) { var items = [].slice.call(lists[L].querySelectorAll('li,[role=option],[role=menuitem]')).filter(_vis); if (items.length && items.length <= 25) opts = items; } } if (!opts.length) return { picked: false }; var want = norm(txt), pick = null; for (var i = 0; i < opts.length; i++) { if (norm(opts[i].textContent).indexOf(want) >= 0) { pick = opts[i]; break; } } if (!pick) pick = opts[0]; if (!pick) return { picked: false }; try { pick.scrollIntoView({ block: 'center' }); } catch (e) {} var r = pick.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2, o = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y }; ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) { try { pick.dispatchEvent(new (tp.indexOf('pointer') === 0 ? PointerEvent : MouseEvent)(tp, o)); } catch (e) {} }); try { pick.click(); } catch (e) {} try { el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true })); el.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', bubbles: true })); } catch (e) {} await sleep(150); return { picked: true, label: (pick.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 60) }; }
              var method = '';
              if (!masked) {
                try { try { el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true })); } catch (e) {} if (CE) { try { var rg = document.createRange(); rg.selectNodeContents(el); var se = window.getSelection(); se.removeAllRanges(); se.addRange(rg); } catch (e) {} try { el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: txt })); } catch (e) {} var _ec; try { _ec = document.execCommand('insertText', false, txt); } catch (e) { _ec = false; } if (!_ec) setNative(txt); } else { clearField(); setNative(txt); } fireInput(txt, 'insertText'); try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {} try { el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true })); } catch (e) {} } catch (e) {}
                await sleep(0); if (landed()) method = 'native';
                if (!method) { try { var dt = new DataTransfer(); dt.setData('text/plain', txt); el.focus(); el.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt })); fireInput(txt, 'insertFromPaste'); try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {} } catch (e) {} await sleep(0); if (landed()) method = 'paste'; }
              }
              if (!method && txt.length <= 4000) { try { await keystroke(); } catch (e) {} if (landed()) method = masked ? 'mask' : 'keystroke'; }
              var sug = { picked: false }; try { sug = await pickSuggestion(); } catch (e) {}
              if (sug.picked) { await sleep(60); method = method || (landed() ? 'typeahead' : 'typeahead-selected'); }
              await sleep(120);
              if (!landed()) { try { el.dispatchEvent(new Event('blur', { bubbles: true })); } catch (e) {} await sleep(80); }
              if (landed()) return { ok: true, confirmed: true, stuck: false, method: method || 'native', into: rd().length, picked: !!sug.picked, pickedLabel: sug.label || '' };
              if (sug.picked) return { ok: true, confirmed: false, stuck: false, method: 'typeahead-selected', into: rd().length, picked: true, pickedLabel: sug.label || '', reason: 'selected-suggestion-unconfirmed' };
              return { ok: false, confirmed: false, stuck: true, method: 'unconfirmed', into: rd().length, reason: masked ? 'masked-rejected' : 'not-stuck' };
            }
            function setSelectByText(sel, text) {
              const t = String(text || '').toLowerCase().trim();
              let opt = [...sel.options].find(o => (o.textContent || '').toLowerCase().trim() === t || (o.value || '').toLowerCase().trim() === t);
              if (!opt) opt = [...sel.options].find(o => ((o.textContent || '').toLowerCase().trim().includes(t)) || ((o.value || '').toLowerCase().trim() === t));
              if (!opt) return false;
              sel.value = opt.value; sel.dispatchEvent(new Event('input', { bubbles: true })); sel.dispatchEvent(new Event('change', { bubbles: true })); return true;
            }
            const a = act || {};
            if (a.type === 'select') {
              const t = String(a.target || '').toLowerCase().trim();
              let sel = null;
              var _bi = _local() || _byIdx(a.target); if (_bi && _bi.tagName === 'SELECT') sel = _bi;
              try { if (!sel) { const q = document.querySelector(a.target); if (q && q.tagName === 'SELECT') sel = q; } } catch (e) {}
              if (!sel) sel = [...document.querySelectorAll('select')].find(s => (((s.id || '') + ' ' + (s.name || '') + ' ' + (s.getAttribute('aria-label') || '') + ' ' + (s.getAttribute('title') || '')).toLowerCase().includes(t)));
              if (!sel) sel = [...document.querySelectorAll('select')].find(s => [...s.options].some(o => (o.textContent || '').toLowerCase().includes(String(a.text || '').toLowerCase().trim())));
              if (!sel) return { ok: false, notfound: true, msg: 'No dropdown found for: ' + (a.target || '') };
              if (FINAL_ACTION.test(labelOf(sel) + ' ' + String(a.target || '') + ' ' + String(a.text || ''))) return { ok: false, blocked: true, reason: 'final-action-blocked', msg: 'Final clinical and financial actions are blocked.' };
              return setSelectByText(sel, a.text) ? { ok: true, msg: 'Set ' + (a.target || 'dropdown') + ' to ' + (a.text || '') } : { ok: false, msg: 'Option not found: ' + (a.text || '') };
            }
            if (a.type === 'click' || a.type === 'confirm') {
              const el = _local() || _byIdx(a.target) || findEl(a.target);
              if (!el) {
                const t = String(a.target || '').toLowerCase().trim();
                for (const s of document.querySelectorAll('select')) { const o = [...s.options].find(o => (o.textContent || '').toLowerCase().trim().includes(t)); if (o) { s.value = o.value; s.dispatchEvent(new Event('input', { bubbles: true })); s.dispatchEvent(new Event('change', { bubbles: true })); return { ok: true, msg: 'Selected option: ' + (a.target || '') }; } }
                return { ok: false, notfound: true, msg: 'Could not find: ' + (a.target || '') };
              }
              if (FINAL_ACTION.test(labelOf(el) + ' ' + String(a.target || ''))) return { ok: false, blocked: true, reason: 'final-action-blocked', msg: 'MLS Assist cannot Save, Sign, Submit, Post, approve, delete, transmit, or place an order.' };
              fireClick(el); return { ok: true, msg: 'Clicked: ' + (a.target || '') };
            }
            if (a.type === 'type') {
              // findEl may return a <label>/wrapper for a label-style target like
              // "Name / label *"; typeInto._resolve() climbs to the real <input>.
              const el = _local() || _byIdx(a.target) || findEl(a.target) || (visible(document.activeElement) ? document.activeElement : null);
              if (!el) return { ok: false, notfound: true, msg: 'No field to type into.' };
              if (STRUCTURED_TARGET.test(labelOf(el) + ' ' + String(a.target || ''))) return { ok: false, blocked: true, reason: 'structured-route-blocked', msg: 'Generic AI typing into diagnoses, billing, prescription or order fields is disabled.' };
              if (el.tagName === 'SELECT') return setSelectByText(el, a.text) ? { ok: true, confirmed: true, msg: 'Selected ' + (a.text || '') + ' in ' + (a.target || 'dropdown') } : { ok: false, msg: 'Option not found in dropdown.' };
              var _tr = await typeInto(el, a.text || '');
              if (_tr && _tr.confirmed) return { ok: true, confirmed: true, msg: 'Typed "' + String(a.text || '').slice(0, 40) + '" into ' + (a.target || 'field') + ' — verified (' + _tr.method + ').' };
              if (_tr && _tr.picked) return { ok: true, confirmed: false, picked: true, msg: 'Selected "' + (_tr.pickedLabel || a.text || '') + '" from the suggestion list for ' + (a.target || 'field') + ' — please confirm it shows in the field.' };
              return { ok: false, stuck: true, reason: (_tr && _tr.reason) || 'not-stuck', msg: 'Tried to type into ' + (a.target || 'the field') + ' every way (clicked it, native set, simulated paste, key-by-key, and looked for a suggestion list)' + ((_tr && _tr.reason === 'readonly') ? ', but it is read-only/disabled' : (_tr && _tr.reason === 'no-field') ? ', but it is not an editable field' : '') + ' and the text did not stick. Please click the field and type ' + (a.text ? '"' + String(a.text).slice(0, 40) + '"' : 'the value') + ' yourself.' };
            }
            if (a.type === 'pastenote') {
              function isEd(el2) { if (!el2) return false; var tg = (el2.tagName || '').toUpperCase(); if (tg === 'TEXTAREA') return true; if (tg === 'INPUT') return /^(text|search|email|url|tel|)$/i.test(el2.type || ''); return !!el2.isContentEditable; }
              var cs = [...document.querySelectorAll('textarea,[contenteditable=""],[contenteditable="true"]')].filter(function (el2) { if (!visible(el2) || STRUCTURED_TARGET.test(labelOf(el2))) return false; var rr = el2.getBoundingClientRect(); return rr.width > 120 && rr.height > 36; });
              cs.sort(function (x, y) { var rx = x.getBoundingClientRect(), ry = y.getBoundingClientRect(); return (ry.width * ry.height) - (rx.width * rx.height); });
              var pe = cs[0] || (isEd(document.activeElement) ? document.activeElement : null);
              if (!pe) return { ok: false, notfound: true, msg: 'No note field found to paste into.' };
              pe.scrollIntoView({ block: 'center' }); var _pr = await typeInto(pe, a.text || '');
              if (_pr && _pr.confirmed) return { ok: true, confirmed: true, msg: 'Pasted the note into the chart field (' + ((a.text || '').length) + ' chars) — verified.' };
              return { ok: false, stuck: true, msg: 'Tried to paste the note every way but could not confirm it landed — click the note field in the EMR, or use the panel Insert/Copy.' };
            }
            if (a.type === 'scroll') { window.scrollBy(0, a.dir === 'up' ? -600 : 600); return { ok: true, msg: 'Scrolled.' }; }
            if (a.type === 'read') { return { ok: true, msg: 'Read the screen.' }; }
            return { ok: false, msg: 'Unknown action.' };
          }
          });
          const res = (r && r.result) || {};
          if (res.ok || !res.notfound || i === tries - 1) break; // stop on success, hard error, or last try
          await new Promise(res2 => setTimeout(res2, 350)); // settle, then retry
        }
        sendResponse((r && r.result) || { ok: false, msg: 'No result.' });
      } catch (e) { sendResponse({ ok: false, msg: 'Action failed: ' + e.message }); }
    })();
    return true;
  }
  // Paste the drafted note into the note field of the CURRENT tab, searching EVERY
  // frame (top + iframes) so iframe-based EMRs like athenaOne/Epic work. v1.26: picks
  // the best frame by note-field SCORE (identity + size), confirms the paste landed,
  // and retries once if it didn't. Returns {ok, confirmed, into}. Never clicks Save/Sign.
  if (msg.type === 'mlsPasteHere') {
    (async () => {
      try {
        const note = String(msg.note || '');
        if (!note.trim()) return sendResponse({ ok: false, error: 'empty' });
        let tabId = sender && sender.tab && sender.tab.id;
        if (!tabId) { const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); tabId = t && t.id; }
        if (!tabId) return sendResponse({ ok: false, reason: 'no-tab', error: 'No target tab for the paste — click into the EMR tab first.' }); /* v2.9.9 */
        let last = { ok: false };
        for (let attempt = 0; attempt < 2; attempt++) {
          let measure = [];
          try { measure = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, args: [note], func: mlsFieldScanner }); }
          catch (e) { measure = await chrome.scripting.executeScript({ target: { tabId }, args: [note], func: mlsFieldScanner }); }
          let winnerFrame = null, bestScore = -1e12, winnerScan = null;
          (measure || []).forEach(function (m) { if (m && m.result && m.result.has && m.result.score > bestScore) { bestScore = m.result.score; winnerFrame = (m.frameId != null ? m.frameId : 0); winnerScan = m.result; } });
          if (winnerFrame === null) { last = { ok: false, notfound: true }; await new Promise(r => setTimeout(r, 450)); continue; }
          if (winnerScan && /^(insurance|diagnoses|orders|procedure)$/i.test(String(winnerScan.chosenSection || ''))) { last = { ok: false, blocked: true, reason: 'structured-route-blocked', chosenSection: winnerScan.chosenSection }; break; }
          const [r] = await chrome.scripting.executeScript({ target: { tabId, frameIds: [winnerFrame] }, args: [note, null, winnerScan], func: mlsNotePaster });
          last = (r && r.result) || { ok: false };
          if (last.ok && last.confirmed) break;
          await new Promise(res2 => setTimeout(res2, 450));
        }
        if (last.blocked) sendResponse({ ok: false, blocked: true, reason: last.reason || 'structured-route-blocked', chosenSection: last.chosenSection || '', error: 'Generic paste is narrative-only; use the typed destination preview for structured content.' });
        else if (last.ok) sendResponse({ ok: true, confirmed: !!last.confirmed, into: last.into, method: last.method, target: last.target, targetLabel: last.targetLabel, chosenSection: last.chosenSection, chosenLabel: last.chosenLabel, targetMatched: !!last.targetMatched, candidates: last.candidates });
        else sendResponse({ ok: false, reason: last.notfound ? 'no-note-field' : 'paste-failed', error: last.notfound ? 'No note field was found on this page — open the note area, then try again.' : 'Found a note field but the paste did not land — click into the note area, then try again.' }); /* v2.9.9: never a bare false (Codex E3) */
      } catch (e) { sendResponse({ ok: false, error: e.message }); }
    })();
    return true;
  }
  // VERIFIED WRITE (v1.27) — the patient-safety gate + smart multi-field routing +
  // reliable typing, tied together. Flow: identify the open Athena chart's patient and
  // the MLS active patient, MATCH them, and ONLY write on a confident match (unless the
  // doctor explicitly overrides after seeing the mismatch). Then segment the note and
  // route each part to its matching Athena field (insurance->insurance, ICD-10->diagnoses,
  // CPT->orders, op-note->Procedure Documentation, ...), confirming each. Never Save/Sign.
  if (msg.type === 'mlsVerifiedWrite') {
    sendResponse({ ok: false, blocked: true, reason: 'legacy-segment-writer-disabled', error: 'The older generic multi-field writer is disabled. Use the typed destination workflow; unknown, diagnosis, billing and order routes fail closed.' });
    return;
    (async () => {
      try {
        const note = String(msg.note || '');
        const force = !!msg.force;
        if (!note.trim()) return sendResponse({ ok: false, error: 'Nothing to insert yet.' });
        const isMls = (u) => /mlsscribe\.com/.test(u || '');
        // 1) Find the EMR (Athena) tab — prefer the tab the panel is on, else newest non-MLS tab.
        let emrTab = null;
        const su = (sender && sender.tab && sender.tab.url) || '';
        if (sender && sender.tab && /^https?:/.test(su) && !isMls(su)) emrTab = sender.tab;
        if (!emrTab) { const tabs = await chrome.tabs.query({});
          /* v1.90: unified verified picker (identity/login excluded, reachability-pinged);
             newest non-athena tab stays the generic-EMR fallback. Identity gate below unchanged. */
          emrTab = await mlsPickAthenaTab(tabs, { athenaOnly: true });
          if (!emrTab) { const c = tabs.filter(t => /^https?:/.test(t.url || '') && !isMls(t.url || '') && !/athena/i.test((t.url || '') + ' ' + (t.title || ''))); c.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0)); emrTab = c[0]; } }
        if (!emrTab) return sendResponse({ ok: false, error: 'No EMR/chart tab is open. Open the patient chart in your EMR, then try again.' });
        // 2) Read the open chart's patient identity (banner-preferred; v1.59).
        let chartId = { name: '', dob: '', mrn: '', score: 0 };
        for (let idTry = 0; idTry < 3; idTry++) {
          /* v1.71: junk-frame guard (same as the v1.67 read-path fix) - a negative-scored
             identity is a demoted messaging/letters/hidden frame phantom ("Monterosso,
             ROSEMARY"); never adopt it as the chart identity. No identity -> honest
             'uncertain' refusal instead of a phantom mismatch. */
          try { const idr = await chrome.scripting.executeScript({ target: { tabId: emrTab.id, allFrames: true }, func: mlsReadChartIdentity }); const bb = mlsBestIdentityFrom(idr); if (bb && (bb.score || 0) >= 0) chartId = bb; }
          catch (e) { try { const [ir] = await chrome.scripting.executeScript({ target: { tabId: emrTab.id }, func: mlsReadChartIdentity }); if (ir && ir.result && ir.result.name && (ir.result.score || 0) >= 0) chartId = ir.result; } catch (e2) {} }
          /* v1.78: shadow-DOM banner fallback - the v26.3 clientsummary banner is
             invisible to the classic reader (the live Adam refusal); the shadow
             reader supplies a FULL (name+dob) identity or nothing. The HARD GATE
             below is unchanged - this only gives it something real to match.
             v1.86: also let a banner-grade shadow identity REPLACE a weak
             non-banner grep (lastfirst care-team phantoms). */
          if (!(chartId.name && (chartId.via === 'banner' || chartId.via === 'shadow-labels' || chartId.via === 'shadow-banner'))) { const sI = await mlsShadowIdentityTry(emrTab.id); if (sI) chartId = sI; }
          if (chartId.name && (chartId.via === 'banner' || chartId.via === 'shadow-labels' || chartId.via === 'shadow-banner' || chartId.dob)) break;
          /* v1.59: the chart may be sitting on the exam-prep/briefing view (no patient
             banner) - nudge it onto the real clinical chart (read-only) and re-read.
             No foregrounding (v1.56 no-yank rule); the HARD GATE below is unchanged. */
          try { await chrome.scripting.executeScript({ target: { tabId: emrTab.id, allFrames: true }, func: mlsEnsureClinicalChartFn }); } catch (e3) {}
          await mlsSleepW(2600);
        }
        // 3) Read the MLS active patient — v1.72: from the REQUESTING tab first (with
        // two app tabs open, the old newest-tab loop read the OTHER tab's patient /
        // page junk), then fall back to the newest signed-in mlsscribe.com tab.
        let mlsPt = { name: '', dob: '', mrn: '' };
        try { if (sender && sender.tab && /mlsscribe\.com/.test(sender.tab.url || '')) { const [mr0] = await chrome.scripting.executeScript({ target: { tabId: sender.tab.id }, func: mlsReadActivePatient }); if (mr0 && mr0.result && (mr0.result.name || mr0.result.dob)) mlsPt = mr0.result; } } catch (e) {}
        if (!mlsPt.name && !mlsPt.dob) try { const mt = await chrome.tabs.query({ url: ['https://mlsscribe.com/*', 'https://*.mlsscribe.com/*'] }); mt.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0)); for (const t of mt) { try { const [mr] = await chrome.scripting.executeScript({ target: { tabId: t.id }, func: mlsReadActivePatient }); if (mr && mr.result && (mr.result.name || mr.result.dob || mr.result.mrn)) { mlsPt = mr.result; break; } } catch (e) {} } } catch (e) {}
        // 4) Match (conservative — default refuse). Names appear only in the doctor's own browser.
        const match = mlsMatchPatients(mlsPt, chartId);
        const patient = { mlsName: mlsPt.name || '', mlsDob: mlsPt.dob || '', mlsMrn: mlsPt.mrn || '', athName: chartId.name || '', athDob: chartId.dob || '', athMrn: chartId.mrn || '' };
        // 5) HARD GATE.
        if (match.status !== 'match' && !force) {
          return sendResponse({ ok: false, blocked: true, patientStatus: match.status, match: match, patient: patient,
            reason: match.status === 'mismatch' ? 'Patient mismatch — refusing to write into this chart.' : 'Could not confidently verify the patient — refusing to write.' });
        }
        // 6) Segment + route each piece to its matching field, confirming each.
        const segs = mlsSegmentNote(note);
        const wrote = [];
        for (const seg of segs) {
          let last = { ok: false };
          for (let attempt = 0; attempt < 2; attempt++) {
            let measure = [];
            try { measure = await chrome.scripting.executeScript({ target: { tabId: emrTab.id, allFrames: true }, args: [seg.text, seg.section], func: mlsFieldScanner }); }
            catch (e) { measure = await chrome.scripting.executeScript({ target: { tabId: emrTab.id }, args: [seg.text, seg.section], func: mlsFieldScanner }); }
            let wf = null, bs = -1e12, wfScan = null;
            (measure || []).forEach(m => { if (m && m.result && m.result.has && m.result.score > bs) { bs = m.result.score; wf = (m.frameId != null ? m.frameId : 0); wfScan = m.result; } });
            if (wf === null) { last = { ok: false, notfound: true, targetLabel: (measure[0] && measure[0].result && measure[0].result.targetLabel) || seg.section }; await new Promise(r => setTimeout(r, 400)); continue; }
            const [r] = await chrome.scripting.executeScript({ target: { tabId: emrTab.id, frameIds: [wf] }, args: [seg.text, seg.section, wfScan], func: mlsNotePaster });
            last = (r && r.result) || { ok: false };
            if (last.ok && last.confirmed) break;
            await new Promise(r => setTimeout(r, 400));
          }
          wrote.push({ section: seg.section, targetLabel: last.targetLabel || seg.section, chosenLabel: last.chosenLabel || '', confirmed: !!last.confirmed, written: !!last.ok, notfound: !!last.notfound, method: last.method || '' });
        }
        sendResponse({ ok: true, forced: force, patientStatus: match.status, match: match, patient: patient, wrote: wrote });
      } catch (e) { sendResponse({ ok: false, error: 'Verified write failed: ' + e.message }); }
    })();
    return true;
  }

  if (msg.type === 'mlsAppCaptureRequest') {
    (async () => {
      try {
        const tabs = await chrome.tabs.query({});
        const tab = (await mlsPickAthenaTab(tabs, { athenaOnly: true })) || (function () { const c = tabs.filter(t => /^https?:/.test(t.url || '') && !/mlsscribe\.com|athena/i.test(t.url || '')); c.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0)); return c[0]; })(); /* v1.90 */
        if (!tab) return sendResponse({ error: 'No EMR tab is open. Open the patient in your EMR in another tab, then try again.' });
        let pageText = '';
        try {
          const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => (document.body && document.body.innerText || '').slice(0, 20000) });
          pageText = (r && r.result) || '';
        } catch (e) { return sendResponse({ error: 'Could not read the EMR tab (' + e.message + ').' }); }
        if (!pageText.trim()) return sendResponse({ error: 'The EMR tab had no readable text.' });
        const res = await callBackend('/api/assist/extract', { pageText, url: tab.url });
        sendResponse(Object.assign({ fromTab: tab.url }, res));
      } catch (e) { sendResponse({ error: 'Capture failed: ' + e.message }); }
    })();
    return true;
  }
  // Send a finished MLS note INTO the EMR: find the patient's note field (across
  // frames, so Athena's iframes work), then paste. v1.26: scores frames by note-field
  // identity+size, confirms the text landed, and retries once. Never clicks Save/Sign.
  if (msg.type === 'mlsAppPasteRequest') {
    (async () => {
      try {
        const note = String(msg.note || '');
        if (!note.trim()) return sendResponse({ error: 'Nothing to send.' });
        const tabs = await chrome.tabs.query({});
        /* v1.90: unified verified picker; newest non-athena tab stays the generic-EMR fallback. */
        const tab = (await mlsPickAthenaTab(tabs, { athenaOnly: true })) || (function () { const c = tabs.filter(t => /^https?:/.test(t.url || '') && !/mlsscribe\.com|athena/i.test((t.url || '') + ' ' + (t.title || ''))); c.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0)); return c[0]; })();
        if (!tab) return sendResponse({ error: 'No EMR tab is open. Open the patient in your EMR in another tab, then try again.' });
        if (mlsAthTabHost(tab) === 'athenanet.athenahealth.com') return sendResponse({ ok: false, blocked: true, reason: 'legacy-untyped-write-disabled', error: 'Use Review Athena actions for an exact patient, encounter, and note confirmation. Nothing was written.' });

        // v1.57: same identity gate mlsVerifiedWrite already uses -- read the open chart's
        // identity + the MLS active patient, and refuse (unless the doctor explicitly forces)
        // if they are not a confident match. Runs in the background; no tab switch yet.
        let chartId = { name: '', dob: '', mrn: '', score: 0 };
        for (let idTry = 0; idTry < 3; idTry++) {
          /* v1.71: junk-frame guard (see mlsVerifiedWrite) */
          try { const idr = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: mlsReadChartIdentity }); const bb = mlsBestIdentityFrom(idr); if (bb && (bb.score || 0) >= 0) chartId = bb; } catch (e) {}
          /* v1.78/v1.86: shadow-DOM banner fallback (see mlsVerifiedWrite) - gate unchanged;
             a banner-grade shadow identity also replaces a weak non-banner grep. */
          if (!(chartId.name && (chartId.via === 'banner' || chartId.via === 'shadow-labels' || chartId.via === 'shadow-banner'))) { const sI = await mlsShadowIdentityTry(tab.id); if (sI) chartId = sI; }
          if (chartId.name && (chartId.via === 'banner' || chartId.via === 'shadow-labels' || chartId.via === 'shadow-banner' || chartId.dob)) break;
          /* v1.59: chart may be on the exam-prep/briefing view (no patient banner) -
             nudge it onto the real clinical chart (read-only) and re-read. No
             foregrounding (v1.56 no-yank rule); the identity gate below is unchanged. */
          try { await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: mlsEnsureClinicalChartFn }); } catch (e3) {}
          await mlsSleepW(2600);
        }
        let mlsPt = { name: '', dob: '', mrn: '' };
        /* v1.72: requesting-tab first (see mlsVerifiedWrite) */
        try { if (sender && sender.tab && /mlsscribe\.com/.test(sender.tab.url || '')) { const [mr0] = await chrome.scripting.executeScript({ target: { tabId: sender.tab.id }, func: mlsReadActivePatient }); if (mr0 && mr0.result && (mr0.result.name || mr0.result.dob)) mlsPt = mr0.result; } } catch (e) {}
        if (!mlsPt.name && !mlsPt.dob) try { const mt = await chrome.tabs.query({ url: ['https://mlsscribe.com/*', 'https://*.mlsscribe.com/*'] }); mt.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0)); for (const t of mt) { try { const [mr] = await chrome.scripting.executeScript({ target: { tabId: t.id }, func: mlsReadActivePatient }); if (mr && mr.result && (mr.result.name || mr.result.dob || mr.result.mrn)) { mlsPt = mr.result; break; } } catch (e) {} } } catch (e) {}
        const match = mlsMatchPatients(mlsPt, chartId);
        if (match.status !== 'match' && !msg.force) {
          return sendResponse({ error: match.status === 'mismatch' ? 'Patient mismatch — refusing to write into this chart.' : 'Could not confidently verify the patient — refusing to write.', blocked: true, patientStatus: match.status });
        }

        /* MLS_WRITE_SAFETY_PASTE_GATE_START (wsg-1.0.0)  Adam-only TEST policy
           on the generic paste lane (athenanet targets are already refused
           above): test-marked content may only reach Adam J Schaeffer
           (7833832); any write to Adam must be TEST-marked and free of real
           medication/order/instruction language. */
        if (self.MLSWriteSafety) {
          const wsPasteGate = self.MLSWriteSafety.checkTestWritePolicy({ patient: { name: chartId.name || mlsPt.name, mrn: chartId.mrn || mlsPt.mrn }, noteText: note });
          if (wsPasteGate) return sendResponse(wsPasteGate);
        }
        /* MLS_WRITE_SAFETY_PASTE_GATE_END */
        // v1.56: do NOT foreground the EMR tab until a note field is confirmed on it. Foregrounding
        // before the field check meant a failed send yanked the doctor to Athena and stranded them
        // there. Measure first (in the background); foreground only to paste; and return focus to MLS
        // if a field was found but the paste failed.
        var _focusMls = async function () {
          try {
            var fw = await chrome.windows.getLastFocused({ populate: true, windowTypes: ['normal'] });
            var cur = ((fw && fw.tabs) || []).find(function (t) { return t && t.active; }) || null;
            if (!_fg || !fw || fw.focused !== true || fw.id !== tab.windowId || !cur || cur.id !== tab.id) return false;
            var _all = await chrome.tabs.query({});
            var _app = (sender && sender.tab && _all.find(function (t) { return t.id === sender.tab.id; })) || _all.find(function (t) { try { return /(^|\.)mlsscribe\.com$/i.test(new URL(t.url || '').host) && /ScribeFlow/i.test(t.url || ''); } catch (e) { return false; } });
            if (!_app) return false;
            await chrome.tabs.update(_app.id, { active: true });
            if (_app.windowId != null) await chrome.windows.update(_app.windowId, { focused: true });
            return true;
          } catch (e) { return false; }
        };
        let last = { ok: false }, foundField = false, _fg = false;
        for (let attempt = 0; attempt < 2; attempt++) {
          let measure = [];
          try { measure = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, args: [note], func: mlsFieldScanner }); }
          catch (e) { measure = await chrome.scripting.executeScript({ target: { tabId: tab.id }, args: [note], func: mlsFieldScanner }); }
          let winnerFrame = null, bestScore = -1e12, winnerScan = null;
          (measure || []).forEach(function (m) { if (m && m.result && m.result.has && m.result.score > bestScore) { bestScore = m.result.score; winnerFrame = (m.frameId != null ? m.frameId : 0); winnerScan = m.result; } });
          if (winnerFrame === null) { await new Promise(r => setTimeout(r, 450)); continue; }

          // Generic paste is narrative-only. Structured destinations require
          // dedicated exact adapters and are never inferred from note text.
          if (winnerScan && /^(insurance|diagnoses|orders|procedure)$/i.test(String(winnerScan.chosenSection || ''))) {
            return sendResponse({ error: 'This destination requires the typed preview workflow and is disabled for generic paste.', blocked: true, reason: 'structured-route-blocked', chosenSection: winnerScan.chosenSection });
          }

          foundField = true;
          if (!_fg) { try { if (self.__mlsQp && self.__mlsQp.active) await self.__mlsQpRelease('write'); } catch (eQ) {} try { await chrome.tabs.update(tab.id, { active: true }); await chrome.windows.update(tab.windowId, { focused: true }); } catch (e) {} _fg = true; } /* v2.9.5: paste keeps foreground-for-write; strip released first */
          const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id, frameIds: [winnerFrame] }, args: [note, null, winnerScan], func: mlsNotePaster });
          last = (r && r.result) || { ok: false };
          if (last.ok && last.confirmed) break;
          await new Promise(res2 => setTimeout(res2, 450));
        }
        if (last.ok && last.confirmed) sendResponse({ ok: true, confirmed: true, into: last.into, method: last.method, target: last.target, targetLabel: last.targetLabel, chosenSection: last.chosenSection, chosenLabel: last.chosenLabel, targetMatched: !!last.targetMatched, candidates: last.candidates });
        else if (last.ok) sendResponse({ ok: true, confirmed: false, into: last.into, method: last.method, target: last.target, targetLabel: last.targetLabel, chosenSection: last.chosenSection, chosenLabel: last.chosenLabel, targetMatched: !!last.targetMatched, candidates: last.candidates, warn: 'Wrote to the field but could not confirm the text landed — please check the EMR before signing.' });
        else if (foundField) { await _focusMls(); sendResponse({ error: 'Found a note field but could not paste. Click into the EMR note area, then try again.' }); }
        else sendResponse({ error: 'Could not find a note field on the EMR page. Open the patient and click into the note area, then try again.' });
      } catch (e) { sendResponse({ error: 'Send failed: ' + e.message }); }
    })();
    return true;
  }
  if (msg.type === 'mlsAssistCapture') {
    try { chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: 'png' }, (dataUrl) => sendResponse({ dataUrl: dataUrl || '' })); }
    catch (e) { sendResponse({ dataUrl: '' }); }
    return true;
  }
});


// Self-update notifier: badge the icon when a newer version is published.
async function mlsCheckBadge() {
  try {
    const cur = chrome.runtime.getManifest().version;
    const r = await fetch('https://mlsscribe.com/extension-version.json?t=' + Date.now());
    const d = await r.json();
    const cmp = (a, b) => { a = String(a).split('.').map(Number); b = String(b).split('.').map(Number); for (let i = 0; i < Math.max(a.length, b.length); i++) { const x = a[i] || 0, y = b[i] || 0; if (x > y) return 1; if (x < y) return -1; } return 0; };
    if (d && d.version && cmp(d.version, cur) > 0) { chrome.action.setBadgeText({ text: '↑' }); chrome.action.setBadgeBackgroundColor({ color: '#1f7ae0' }); }
    else chrome.action.setBadgeText({ text: '' });
  } catch (e) {}
}
try { mlsCheckBadge(); } catch (e) {}
try { chrome.runtime.onStartup.addListener(mlsCheckBadge); } catch (e) {}
try { chrome.runtime.onInstalled.addListener(mlsCheckBadge); } catch (e) {}


// ===========================================================================
// NIGHTLY BACKUP (browser-side). At the chosen local time, the extension may
// capture only the chart already open in the signed-in EMR tab; it never walks
// patient links or changes the user's Athena URL. Captures remain encrypted.
// REQUIRES: this computer ON, Chrome running, and the EMR tab still SIGNED IN.
// Best-effort by design: web-UI scraping can miss patients an API sync wouldn't.
// ===========================================================================
const BK_KEY = 'mlsBackup';
function getBackup() { return new Promise(r => chrome.storage.local.get([BK_KEY], c => r(Object.assign({ enabled: false, hour: 2, minute: 0, maxPatients: 250 }, c[BK_KEY] || {})))); }
function setBackup(v) { return new Promise(r => chrome.storage.local.set({ [BK_KEY]: v }, () => r(v))); }

async function scheduleBackupAlarm() {
  try { await chrome.alarms.clear('mlsNightlyBackup'); } catch (e) {}
  const b = await getBackup();
  if (!b.enabled) return;
  const now = new Date();
  const next = new Date(now.getFullYear(), now.getMonth(), now.getDate(), (b.hour | 0), (b.minute | 0), 0, 0);
  if (next.getTime() <= now.getTime() + 5000) next.setDate(next.getDate() + 1);
  try { chrome.alarms.create('mlsNightlyBackup', { when: next.getTime(), periodInMinutes: 1440 }); } catch (e) {}
}
try { chrome.alarms.onAlarm.addListener(a => { if (a && a.name === 'mlsNightlyBackup') runNightlyBackup('schedule'); }); } catch (e) {}
try { chrome.runtime.onStartup.addListener(scheduleBackupAlarm); } catch (e) {}
try { chrome.runtime.onInstalled.addListener(scheduleBackupAlarm); } catch (e) {}
scheduleBackupAlarm();

function findEmrTab(tabs) {
  const c = tabs.filter(t => /^https?:/.test(t.url || '') && !/mlsscribe\.com|\/\/github\.com|mail\.google\.com|console\.twilio|dashboard\.stripe/.test(t.url || ''));
  const ath = c.find(t => /athena/i.test((t.url || '') + ' ' + (t.title || '')));
  if (ath) return ath;
  c.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  return c[0] || null;
}
async function tabInnerText(tabId, max) {
  try { const [r] = await chrome.scripting.executeScript({ target: { tabId }, args: [max || 20000], func: (m) => (document.body && document.body.innerText || '').slice(0, m) }); return (r && r.result) || ''; }
  catch (e) { return ''; }
}
function waitTabComplete(tabId, timeout) {
  return new Promise(res => {
    let done = false;
    const to = setTimeout(() => { if (!done) { done = true; try { chrome.tabs.onUpdated.removeListener(l); } catch (e) {} res(); } }, timeout || 15000);
    function l(id, info) { if (id === tabId && info.status === 'complete') { done = true; clearTimeout(to); try { chrome.tabs.onUpdated.removeListener(l); } catch (e) {} res(); } }
    chrome.tabs.onUpdated.addListener(l);
  });
}
async function collectRoster(tabId) {
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: () => {
      const out = [], seen = new Set();
      const re = /patient|chart|clinical|encounter|\bexam\b|chartid|enc=|patientid|deptid|pat_id/i;
      for (const a of document.querySelectorAll('a[href]')) {
        const href = a.href || '', raw = a.getAttribute('href') || '', txt = (a.innerText || '').trim();
        if (!/^https?:/.test(href)) continue;
        if (!re.test(href) && !re.test(raw)) continue;
        if (seen.has(href)) continue; seen.add(href);
        out.push({ href, txt: txt.slice(0, 80) });
        if (out.length >= 400) break;
      }
      return out;
    }});
    return (r && r.result) || [];
  } catch (e) { return []; }
}
async function runNightlyBackup(trigger) {
  const started = Date.now();
  const cfg = await getBackup();
  const finish = async (res) => { await setBackup(Object.assign(await getBackup(), { lastRun: res.at, lastResult: res })); return res; };
  const tabs = await chrome.tabs.query({});
  const emr = findEmrTab(tabs);
  if (!emr) return finish({ ok: false, error: 'No EMR tab is open. Leave an Athena tab open and signed in.', at: new Date().toISOString() });
  const firstText = await tabInnerText(emr.id, 6000);
  if (firstText.length < 1500 && /\b(log\s?in|sign\s?in|password|username)\b/i.test(firstText)) {
    return finish({ ok: false, error: 'The EMR tab looks signed out — nothing was backed up. Stay signed in to Athena overnight.', at: new Date().toISOString() });
  }
  let captured = 0, patients = 0, errors = 0;
  // 1) capture the chart currently open
  if (firstText.trim()) {
    const c = await callBackend('/api/assist/extract', { pageText: firstText, url: emr.url });
    if (c && c.ok) { captured++; if (c.patient) patients++; } else if (c && c.error) { errors++; }
  }
  /* The legacy backup walked every chart link by repeatedly changing the
     user's Athena tab URL. That could yank focus, disturb unsaved work, and
     invalidate the signed-in session. Backups are now non-navigating: they may
     capture only the chart that is already open. Full-history imports use the
     separate supervised read-only visit pipeline. */
  return finish({ ok: true, captured, patients, errors, scanned: firstText.trim() ? 1 : 0,
    navigationDisabled: true, trigger: trigger || 'manual', at: new Date().toISOString(),
    seconds: Math.round((Date.now() - started) / 1000) });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  if (msg.type === 'mlsGetBackup') { getBackup().then(sendResponse); return true; }
  if (msg.type === 'mlsSetBackup') { setBackup(Object.assign({ enabled: false, hour: 2, minute: 0, maxPatients: 250 }, msg.value || {})).then(scheduleBackupAlarm).then(() => sendResponse({ ok: true })); return true; }
  if (msg.type === 'mlsRunBackupNow') { runNightlyBackup('manual').then(sendResponse); return true; }
});

/* === MLS Assist visit-reader lineage (active: v2.9.22 r4) ===
 * Self-contained. Adds its own chrome.runtime.onMessage handler for
 * mlsAppAllVisitsRequest; does not modify existing handlers. Genuinely walks the
 * OPEN patient's encounters/visits list in athenaOne (frame-aware, content-scored),
 * reads each encounter's real content, and returns {ok, identity, visits[], diag}.
 *
 * Historical v1.34 notes (superseded by the active v2.9.22 r4 reader below):
 *  - r4 treats every list row as index-only, binds a stable source key, and clicks
 *    each exact row before accepting encounter-scoped clinical detail.
 *  - r4 returns visits only when the patient identity, complete index, every body,
 *    and all unique source keys are independently verified in its receipt.
 *  - Frame-aware enumeration: scores every frame's candidate row-groups by
 *    encounter-likeness (date + type-keyword + clickable + code signals), not just
 *    "has a date", and picks the single best frame+group.
 *  - Two read paths: (A) EXPANDED — if rows already carry real content, read them
 *    in place with NO clicks (safest, read-only); (B) CLICK — only for thin rows,
 *    open each row, read the detail pane (content-scored across frames). Falls back
 *    A->B per-row when an expanded row is too thin.
 *  - HONEST progress: emits a per-visit line ONLY after a visit with REAL content
 *    is actually read; total M is the real enumerated count. Never a pre-counted
 *    "reading N of M" with no data behind it.
 *  - HONEST failure: if no encounters list is recognized, returns ok:false with a
 *    clear message — never a fabricated count.
 *  - SELF-DIAGNOSTIC: always attaches result.diag, a fully REDACTED structural
 *    fingerprint of the chart DOM (frame hosts, candidate selectors, row tag/class
 *    signatures, counts, and date/CPT/ICD booleans) — NO patient text, names, DOBs,
 *    dates, or codes — so the selectors can be tuned to a real chart from one run.
 *    The redacted diag is also saved to chrome.storage.local 'mlsAthenaVisitsDiag'.
 *  - READ-ONLY: clicks ONLY dated encounter rows; never Save/Sign/Submit/etc.
 *    (excludeClickLabels guard). Selectors tunable via chrome.storage.local
 *    'mlsAthenaVisitsCfg'. */
(function () {
  'use strict';
  try { if (self.__mlsAllVisitsHandler) return; self.__mlsAllVisitsHandler = 1; } catch (e) {}

  var ORCH_DEFAULT = { maxVisits: 500, waitMs: 1400, initialWaitMs: 1000, visitTabWaitMs: 2200, maxReadMs: 165000, detailPollMs: 180 };
  var EMR_RE = /(athenahealth|athenanet|athenaone|athena\.io|\.px\.athena)/i;

  /* CANONICAL self-contained injected driver. Passed to chrome.scripting
   * .executeScript({func: mlsVisitsDriverFn}) — must reference no outer scope and
   * no eval (athenaOne CSP-safe). Read-only: only clicks dated encounter rows,
   * never Save/Sign/Submit. Embedded verbatim in background.js. */
  function mlsVisitsDriverFn(op, cfg, idx, expectedBinding) {
    cfg = cfg || {};
    /* Every click-capable visit operation carries the orchestrator's one
       immutable absolute deadline + request token. executeScript cannot be
       cancelled after Chrome accepts it, so a renderer that resumes after the
       worker timed out must observe this guard immediately before every click
       and take no action. Read-only probes remain usable without a guard. */
    var __visitActionGuard = Object.freeze({
      deadline: Number(cfg.__readDeadline || 0),
      token: String(cfg.__requestToken || '')
    });
    function visitActionAllowed() {
      return !!__visitActionGuard.token && Number.isFinite(__visitActionGuard.deadline) && Date.now() < __visitActionGuard.deadline;
    }
    function visitDeadlineFailure(extra) {
      var out = { ok: false, clicked: false, reason: 'read-deadline-exceeded', requestToken: __visitActionGuard.token || '' };
      if (extra) for (var ek in extra) out[ek] = extra[ek];
      return out;
    }
    var DEFAULT = {
      rowSelectors: [
        'li.encounter-list-item',
        'tr', '[role="row"]', 'li',
        '.encounter', '.encounter-row', '.encounterrow', '[data-encounter-id]',
        '[data-encounterid]', '[id*="encounter" i]', '[class*="encounter" i]',
        '.visit', '.visit-row', '[class*="visit" i]', '[class*="timeline" i] li',
        '.athena-encounter', '.chart-encounter', '.documentencounter'
      ],
      detailSelectors: [
        '.encounter-detail', '.encounterdetail',
        '.documentation[data-encounter-id]', '.chart-detail[data-encounter-id]', '.notesection',
        '[class*="encounterbody" i]', '[class*="notebody" i]',
        '[id*="encounter-detail" i]'
      ],
      typeKeywords: [
        'office visit', 'encounter', 'telehealth', 'follow', 'follow-up', 'f/u',
        'new patient', 'established', 'consult', 'procedure', 'injection', 'block',
        'ablation', 'epidural', 'facet', 'esi', 'rfa', 'evaluation', 'eval',
        'visit', 'exam', 'phone', 'lab', 'imaging', 'mri', 'x-ray', 'progress note',
        'preop', 'postop', 'pre-op', 'post-op', 'surgery'
      ],
      excludeClickLabels: [
        'save', 'sign', 'finalize', 'post', 'bill', 'submit claim', 'submit',
        'delete', 'lock', 'addend', 'amend', 'discard', 'cancel appointment',
        'close encounter', 'check out', 'checkout'
      ],
      maxVisits: 500,
      minRealLen: 60,
      visitTabWaitMs: 2200
    };
    for (var k in DEFAULT) { if (cfg[k] == null) cfg[k] = DEFAULT[k]; }
    var DATE_RE = /(?:^|[^\d])(\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}|\d{4}-\d{1,2}-\d{1,2})(?!\d)/;
    var CPT_RE = /\b\d{5}\b/g, ICD_RE = /\b[A-TV-Z]\d[0-9A-Z](?:\.[0-9A-Z]{1,4})?\b/g;
    function txt(el) { return (el && (el.innerText || el.textContent) || '').replace(/\s+/g, ' ').trim(); }
    function low(s) { return String(s || '').toLowerCase(); }
    function excluded(s) { s = low(s); for (var i = 0; i < cfg.excludeClickLabels.length; i++) { if (s.indexOf(cfg.excludeClickLabels[i]) >= 0) return true; } return false; }
    function hasType(s) { s = low(s); for (var i = 0; i < cfg.typeKeywords.length; i++) { if (s.indexOf(cfg.typeKeywords[i]) >= 0) return true; } return false; }
    function hasDate(s) { return DATE_RE.test(String(s || '')); }
    function hasCpt(s) { CPT_RE.lastIndex = 0; return CPT_RE.test(String(s || '')); }
    function hasIcd(s) { ICD_RE.lastIndex = 0; return ICD_RE.test(String(s || '')); }
    function codes(s, re) { var out = [], m; re.lastIndex = 0; while ((m = re.exec(String(s || '')))) { var c = m[0].toUpperCase(); if (out.indexOf(c) < 0) out.push(c); if (out.length > 40) break; } return out; }
    function hashText(s) {
      s = String(s || ''); var h = 2166136261;
      for (var hi = 0; hi < s.length; hi++) { h ^= s.charCodeAt(hi); h = Math.imul(h, 16777619); }
      return (h >>> 0).toString(36);
    }
    function visible(n) {
      if (!n) return false;
      try {
        if (n.hidden || n.getAttribute('aria-hidden') === 'true') return false;
        var cs = getComputedStyle(n); if (cs && (cs.display === 'none' || cs.visibility === 'hidden')) return false;
        var r = n.getBoundingClientRect(); return r.width > 1 && r.height > 1;
      } catch (e) { return true; }
    }
    function encounterId(n) {
      var cur = n, depth = 0, keys = ['data-encounter-id', 'data-encounterid', 'data-case-id', 'data-visit-id'];
      while (cur && depth++ < 3) {
        for (var ki = 0; ki < keys.length; ki++) {
          try { var av = cur.getAttribute && cur.getAttribute(keys[ki]); if (av) return String(av).trim(); } catch (e0) {}
        }
        cur = cur.parentElement;
      }
      try {
        var a = n.querySelector && n.querySelector('a[href*="encounter" i],a[href*="patientcase" i],a[href*="case" i],a[href*="visit" i]');
        var href = a && (a.getAttribute('href') || '');
        var hm = String(href).match(/(?:encounter|patientcase|case|visit)(?:id)?[=\/#:-]+([a-z0-9_-]{2,})/i);
        if (hm) return hm[1];
      } catch (e1) {}
      return '';
    }
    function indexText(n) {
      var head = null;
      try { head = n.querySelector && n.querySelector('.accordion-header,.encounter-header,[class*="encounter-header" i],[aria-expanded],a[href],button,[role="button"],[role="link"]'); } catch (e0) {}
      var s = txt(head || n);
      /* When Athena offers no explicit header element, keep only the leading
         index-sized text so expanding the detail does not mutate row identity. */
      return s.slice(0, 260);
    }
    function stableRowAnchor(n) {
      var vals = [], cur = n, depth = 0, keys = ['data-case-id', 'data-visit-id', 'data-document-id', 'aria-controls', 'data-target', 'id'];
      while (cur && depth++ < 2) {
        for (var ai = 0; ai < keys.length; ai++) {
          try { var v = cur.getAttribute && cur.getAttribute(keys[ai]); if (v) vals.push(keys[ai] + '=' + String(v)); } catch (e0) {}
        }
        cur = cur.parentElement;
      }
      try {
        var link = n.querySelector && n.querySelector('a[href]');
        var href = link && link.getAttribute('href'); if (href) vals.push('href=' + String(href));
      } catch (e1) {}
      return vals.join('|').toLowerCase().replace(/\s+/g, ' ').trim();
    }
    function rowBinding(n, index) {
      var raw = indexText(n), dm = raw.match(DATE_RE), eid = encounterId(n);
      var normalized = raw.toLowerCase().replace(/\s+/g, ' ').trim();
      var anchor = stableRowAnchor(n);
      return {
        index: Number(index), encounterId: eid, date: dm && dm[1] ? dm[1] : '',
        /* rowKey/sourceVisitKey must survive list reordering. Never mix the
           volatile rendered index into persistent encounter identity. */
        rowKey: (eid ? ('enc:' + eid) : ('row:' + hashText(anchor + '|' + normalized))),
        indexTextHash: hashText(normalized), indexTextLen: raw.length
      };
    }
    function sameBinding(actual, expected) {
      if (!actual || !expected) return false;
      if (Number(actual.index) !== Number(expected.index)) return false;
      if (!actual.rowKey || actual.rowKey !== expected.rowKey) return false;
      if (expected.encounterId && actual.encounterId !== expected.encounterId) return false;
      if (expected.date && actual.date && expected.date !== actual.date) return false;
      return true;
    }
    function clinicalBody(s) {
      s = String(s || '').replace(/\s+/g, ' ').trim();
      if (s.length < Math.max(60, Number(cfg.minRealLen || 60))) return false;
      var clinical = /\b(?:assessment|plan|history|hpi|chief complaint|diagnos|medication|allerg|physical exam|examination|imaging|procedure|findings|impression|follow[- ]?up|review of systems|ros|past medical|past surgical|social history|family history|vitals?)\b/i.test(s);
      return clinical || hasCpt(s) || hasIcd(s);
    }
    function clickable(n) {
      try {
        if (n.matches && n.matches('a[href],button,[role="link"],[role="button"],[onclick],.clickable,.accordion-trigger')) return true;
        return !!(n.querySelector && n.querySelector('a[href],button,[role="link"],[role="button"],[onclick],td a, td'));
      } catch (e) { return false; }
    }
    /* v2.9.22: live Athena v26.3 prior-visit rows toggle `accordion-open` on the
       li itself (or aria-expanded on their toggle) when their body renders in
       place. Open-state is a REQUIRED gate before the exact row's own text can
       be considered an encounter body. */
    function isOpenRow(n) {
      try {
        var cls = String(n.className && n.className.baseVal != null ? n.className.baseVal : (n.className || ''));
        if (/(^|\s)(accordion-open|is-open|expanded)(\s|$)/.test(cls)) return true;
        if (n.getAttribute && n.getAttribute('aria-expanded') === 'true') return true;
        return !!(n.querySelector && n.querySelector('[aria-expanded="true"]'));
      } catch (e) { return false; }
    }
    /* v2.9.22 REDACTED failure forensics: structural booleans/counts/class
       tokens only — never patient text, names, dates, or codes. */
    function noRowDiag(expected) {
      var out = { keyStyle: String(expected && expected.rowKey || '').slice(0, 4) };
      try {
        out.liTotal = document.querySelectorAll('li.encounter-list-item').length;
        var eid = String(expected && expected.encounterId || '').replace(/[^a-zA-Z0-9_-]/g, '');
        out.eidHit = eid ? !!document.querySelector('li.encounter-list-item[data-encounter-id="' + eid + '"]') : null;
      } catch (eNr) {}
      return out;
    }
    function rowFailDiag(exactRow, expectedBinding, marker, candidates) {
      try {
        var rowNow = txt(exactRow);
        var rowNorm = rowNow.toLowerCase().replace(/\s+/g, ' ').trim();
        var kidCls = [];
        try {
          var ch = exactRow.querySelectorAll('*');
          for (var q = 0; q < ch.length && kidCls.length < 12; q++) {
            String((ch[q].className && ch[q].className.baseVal != null ? ch[q].className.baseVal : ch[q].className) || '').split(/\s+/).forEach(function (c) { if (c && kidCls.indexOf(c) < 0 && kidCls.length < 12) kidCls.push(c); });
          }
        } catch (eKid) {}
        return {
          open: isOpenRow(exactRow), rowLen: rowNow.length, idxLen: Number(expectedBinding && expectedBinding.indexTextLen) || 0,
          cands: (candidates || []).length, candLens: (candidates || []).slice(0, 6).map(function (c) { return txt(c).length; }),
          already: !!(marker && marker.alreadyOpen), preLen: (marker && marker.preRowLen) || 0,
          rowClin: clinicalBody(rowNow), hashEqIdx: hashText(rowNorm) === (expectedBinding && expectedBinding.indexTextHash),
          rowCls: String(exactRow.className || '').split(/\s+/).filter(Boolean).slice(0, 8),
          kidCls: kidCls, ariaKids: (function () { try { return exactRow.querySelectorAll('[aria-expanded]').length; } catch (eA) { return -1; } })()
        };
      } catch (eD2) { return null; }
    }
    /* v2.9.22: an expanded row can change length/position classification between
       ops. Recover the exact row by its FROZEN stable key (encounterId-first)
       instead of trusting the rendered index; positional lookup stays the fast
       path. Returns null when no row carries the frozen key — fail closed. */
    function resolveRow(g, index, expected) {
      var rows = (g && g.rows) || [];
      var positional = rows[Number(index)] || null;
      if (!expected || !expected.rowKey) return positional;
      if (positional && rowBinding(positional, index).rowKey === expected.rowKey) return positional;
      var pool = rows.slice();
      try { pool = pool.concat(Array.prototype.slice.call(document.querySelectorAll('li.encounter-list-item'))); } catch (e0) {}
      for (var pi = 0; pi < pool.length; pi++) {
        var b = rowBinding(pool[pi], index);
        if (b.rowKey === expected.rowKey && (!expected.encounterId || b.encounterId === expected.encounterId)) return pool[pi];
      }
      return null;
    }

    // Score a single candidate row's text for "looks like an encounter row".
    function rowScore(t) {
      if (!t) return 0;
      var s = 0;
      if (hasDate(t)) s += 3;
      if (hasType(t)) s += 2;
      if (hasCpt(t)) s += 1;
      if (hasIcd(t)) s += 1;
      if (t.length >= 12 && t.length <= 400) s += 1;
      return s;
    }

    // Build candidate groups: for each selector, group matching nodes by parent,
    // keep groups whose members look like dated encounter rows; return scored groups.
    function candidateGroups() {
      var groups = [];
      for (var s = 0; s < cfg.rowSelectors.length; s++) {
        var nodes;
        try { nodes = Array.prototype.slice.call(document.querySelectorAll(cfg.rowSelectors[s])); } catch (e) { continue; }
        /* Live Athena's Visits surface mixes vitals, future appointments,
           patient cases/documents, and real historical encounters under the
           same `li.encounter-list-item` class. Only previous-visit rows with a
           stable encounter id own a full encounter-summary frame. Counting the
           other row types made a 9-visit chart look like 15 encounters and made
           body completeness impossible by construction. */
        if (cfg.rowSelectors[s] === 'li.encounter-list-item') {
          var priorEncounterRows = nodes.filter(function (node) {
            try { return !!(node.matches && node.matches('li.encounter-list-item.previous-visit[data-encounter-id]')); } catch (ePrior) { return false; }
          });
          if (priorEncounterRows.length) nodes = priorEncounterRows;
        }
        if (!nodes.length) continue;
        var byParent = new Map();
        for (var i = 0; i < nodes.length; i++) {
          var n = nodes[i], t = txt(n);
          /* v2.9.22: a clicked li.encounter-list-item expands its clinical body
             IN PLACE (accordion-open), so the explicit Athena encounter selector
             must keep rows that outgrew the generic 1200-char row ceiling.
             Otherwise the expanded row silently drops out of the group and every
             later positional lookup rebinds to the wrong row. */
          var maxRowLen = (cfg.rowSelectors[s] === 'li.encounter-list-item') ? 400000 : 1200;
          if (t.length < 8 || t.length > maxRowLen) continue;
          if (!hasDate(t)) continue;
          /* A canonical Athena encounter row is a read-only accordion owner, not
             a write control. Its clinical label may legitimately contain
             "post-op" or its expanded body may mention "signed". Keep the
             mutation-label filter for generic fallback rows; the explicit
             encounter row is still bound by patient + encounter ID and its
             actual child click target is checked separately below. */
          if (cfg.rowSelectors[s] !== 'li.encounter-list-item' && excluded(t)) continue;
          var par = n.parentElement || n;
          if (!byParent.has(par)) byParent.set(par, []);
          byParent.get(par).push(n);
        }
        byParent.forEach(function (rows, par) {
          /* A real chart may have exactly one historical encounter. Require a
             multi-row list only for generic selectors; Athena's explicit
             encounter contract is authoritative even at count=1. */
          if (rows.length < 2 && cfg.rowSelectors[s] !== 'li.encounter-list-item') return;
          var sc = 0, withType = 0, withCode = 0, withClick = 0, strongRows = 0, lens = [], uniqueDates = {};
          for (var j = 0; j < rows.length; j++) {
            var rt = txt(rows[j]);
            sc += rowScore(rt);
            if (hasType(rt)) withType++;
            if (hasCpt(rt) || hasIcd(rt)) withCode++;
            if (clickable(rows[j])) withClick++;
            try { if (rows[j].matches && rows[j].matches('li.encounter-list-item,.encounter-row,[data-encounter-id],[data-encounterid],.previous-visit,.patient-case')) strongRows++; } catch (e0) {}
            var dm = rt.match(DATE_RE); if (dm && dm[1]) uniqueDates[dm[1]] = 1;
            lens.push(rt.length);
          }
          lens.sort(function (a, b) { return a - b; });
          var median = lens[Math.floor(lens.length / 2)] || 0;
          /* Repeated structural descendants can all inherit the same date and
             masquerade as dozens of visits. Reward unique dated rows and Athena's
             real encounter-row classes; penalize repeated dates aggressively. */
          var uniqueDateCount = Object.keys(uniqueDates).length;
          var duplicateDates = Math.max(0, rows.length - uniqueDateCount);
          var groupScore = sc + uniqueDateCount * 6 + withType + Math.min(withClick, rows.length) + strongRows * 4 - duplicateDates * 7;
          groups.push({
            selector: cfg.rowSelectors[s], parent: par, rows: rows,
            count: rows.length, score: groupScore, withType: withType,
            withCode: withCode, withClick: withClick, strongRows: strongRows,
            uniqueDates: uniqueDateCount, median: median
          });
        });
      }
      groups.sort(function (a, b) { return b.score - a.score; });
      return groups;
    }

    function bestGroup() {
      var g = candidateGroups();
      /* Current Athena briefing charts expose a stable, patient-scoped visit
         contract. When present, it is authoritative; generic class/row scans
         are only fallbacks for other layouts and may contain dated descendants. */
      for (var i0 = 0; i0 < g.length; i0++) {
        if (g[i0].selector === 'li.encounter-list-item' && g[i0].strongRows === g[i0].count) return g[i0];
      }
      return g.length ? g[0] : null;
    }

    function declaredEncounterCount(group) {
      if (!group || !group.parent) return null;
      var scopes = [group.parent, group.parent.parentElement, group.parent.parentElement && group.parent.parentElement.parentElement];
      for (var si0 = 0; si0 < scopes.length; si0++) {
        var st = txt(scopes[si0]); if (!st) continue;
        var m = st.match(/(?:visits|encounters|events|cases)\s*(?:\(|:|-)?\s*(\d{1,4})(?![\/\-.]\d)/i) || st.match(/\b(\d{1,4})\s+(?:visits|encounters|events|cases)\b/i);
        if (m && Number(m[1]) >= group.count) return Number(m[1]);
      }
      return null;
    }

    function explicitEmptyVisits() {
      /* A zero-row result is complete only when the active patient-scoped Visits
         surface itself says zero/none. Page-wide text is deliberately excluded. */
      var nodes = [];
      try { nodes = Array.prototype.slice.call(document.querySelectorAll('[data-testid*="visit" i],[data-testid*="encounter" i],[aria-label*="visit" i],[aria-label*="encounter" i],[class*="visit" i],[id*="visit" i],[class*="encounter" i],[id*="encounter" i],[class*="empty-state" i],[data-empty-state]')); } catch (e) { nodes = []; }
      for (var ei = 0; ei < nodes.length && ei < 500; ei++) {
        var n = nodes[ei], hidden = false;
        try { var cs = getComputedStyle(n); hidden = n.hidden || cs.display === 'none' || cs.visibility === 'hidden'; } catch (e2) {}
        if (hidden) continue;
        var value = txt(n).replace(/\s+/g, ' ').trim();
        if (!value || value.length > 260) continue;
        if (/^(?:(?:there (?:are|is) )?no (?:prior |previous |historical )?(?:visits|encounters|events|cases)(?: (?:found|available|recorded|on file|to display|have been recorded|were found|are available))?|0\s+(?:visits|encounters|events|cases)|(?:visits|encounters|events|cases)\s*(?:\(\s*0\s*\)|:\s*0|-\s*0))\.?$/i.test(value)) return true;
      }
      return false;
    }

    // ---- redacted structural fingerprint (NO PHI) ----------------------------
    function sigOf(node) {
      var classes = [];
      try { classes = (node.className && node.className.baseVal != null ? node.className.baseVal : (node.className || '')).toString().split(/\s+/).filter(Boolean).slice(0, 6); } catch (e) {}
      var childTags = {};
      try {
        var ch = node.children || [];
        for (var i = 0; i < ch.length && i < 30; i++) { var tg = (ch[i].tagName || '').toLowerCase(); if (tg) childTags[tg] = (childTags[tg] || 0) + 1; }
      } catch (e) {}
      var attrKeys = [];
      try { for (var a = 0; a < node.attributes.length && a < 12; a++) { var an = node.attributes[a].name; if (an !== 'class' && an !== 'style') attrKeys.push(an); } } catch (e) {}
      var t = txt(node);
      return {
        tag: (node.tagName || '').toLowerCase(),
        classes: classes,            // CSS class NAMES only (structural, no PHI)
        childTags: childTags,        // counts of child element tags
        attrKeys: attrKeys,          // attribute NAMES only (no values)
        textLen: t.length,           // length only (no text)
        hasDate: hasDate(t), hasCpt: hasCpt(t), hasIcd: hasIcd(t), hasType: hasType(t)
      };
    }
    function diagnose() {
      var host = '';
      try { host = location.hostname || ''; } catch (e) {}
      var groups = candidateGroups();
      var cands = groups.slice(0, 4).map(function (g) {
        return {
          selector: g.selector, count: g.count, score: g.score,
          withType: g.withType, withCode: g.withCode, withClick: g.withClick,
          medianLen: g.median, rowSig: g.rows[0] ? sigOf(g.rows[0]) : null
        };
      });
      // generic counts to see what's present even when no group qualified
      function cnt(sel) { try { return document.querySelectorAll(sel).length; } catch (e) { return -1; } }
      return {
        host: host,
        frameDepth: (function () { try { return window.top === window ? 0 : 1; } catch (e) { return 1; } })(),
        counts: { tr: cnt('tr'), role_row: cnt('[role="row"]'), li: cnt('li'), tables: cnt('table'), iframes: cnt('iframe'), encounterish: cnt('[class*="encounter" i],[id*="encounter" i]'), visitish: cnt('[class*="visit" i]') },
        groupCount: groups.length, candidates: cands
      };
    }

    // ---- operations ----------------------------------------------------------
    if (op === 'openVisits') {
      /* The briefing chart opens on whichever chart tab was last active. Drive
         the icon-identified Visits tab explicitly before enumerating; this is a
         read-only chart navigation and avoids mistaking Problems/Documents rows
         for encounters. */
      var icons = [];
      try { icons = Array.prototype.slice.call(document.querySelectorAll('.nimbus-icon-visits.chart-tab-icon,.nimbus-icon-visits')); } catch (e0) {}
      var tab = null;
      for (var oi = 0; oi < icons.length; oi++) {
        try {
          var cand = icons[oi].closest && icons[oi].closest('li.chart-tabs__list-item');
          if (!cand) continue;
          var rr = cand.getBoundingClientRect();
          if (rr.width > 1 && rr.height > 1) { tab = cand; break; }
          if (!tab) tab = cand;
        } catch (e1) {}
      }
      if (!tab) return { ok: false, reason: 'visits-tab-not-found' };
      if (/(^|\s)active(\s|$)/.test(String(tab.className || ''))) return { ok: true, active: true };
      if (!visitActionAllowed()) return visitDeadlineFailure();
      try { tab.click(); return { ok: true, clicked: true }; } catch (e2) { return { ok: false, reason: 'visits-tab-click-failed' }; }
    }
    if (op === 'identity') {
      var body = txt(document.body), dob = '', name = '', mrn = '';
      var dm = body.match(/\b(?:DOB|D\.O\.B\.|Date of Birth|Born)\D{0,8}(\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4})/i); if (dm) dob = dm[1];
      var mm = body.match(/\b(?:MRN|Medical Record(?: Number| No\.?| ID)?|Patient ID)\s*[:#\-]?\s*([A-Z0-9\-]{4,})/i); if (mm) mrn = mm[1];
      var nm = body.match(/\bPatient\D{0,4}([A-Z][a-z]+(?:\s+[A-Z]\.?)?\s+[A-Z][a-z]+)/); if (nm) name = nm[1];
      if (!name) { var h = document.querySelector('h1,h2,[data-patient-name],.patient-name,[class*="patientname" i]'); if (h) name = txt(h).slice(0, 60); }
      return { name: name, dob: dob, mrn: mrn };
    }
    if (op === 'diagnose') { return diagnose(); }
    if (op === 'enumerate') {
      var g = bestGroup();
      if (!g) {
        if (explicitEmptyVisits()) return { ok: true, selector: 'verified-empty-state', count: 0, renderedCount: 0, declaredCount: 0, score: 0, rows: [], indexComplete: true, authoritativeEmpty: true };
        return { ok: false, count: 0, score: 0 };
      }
      var rows = g.rows.map(function (n, i) {
        var t = txt(n); var d = t.match(DATE_RE);
        var binding = rowBinding(n, i);
        return {
          index: i, date: d ? d[1] : '',
          type: t.replace(DATE_RE, '').slice(0, 80).trim(),
          /* rowText is INDEX metadata only; an already-expanded row (re-pull in
             the same session) must not push its whole body through this index. */
          rowText: t.slice(0, 1200), textLen: t.length, hasCode: (hasCpt(t) || hasIcd(t)),
          /* Rich list rows remain INDEX metadata. They can help a human find an
             encounter but are never accepted as its clinical body. */
          rich: false, indexOnly: true, binding: binding, rowKey: binding.rowKey,
          encounterId: binding.encounterId || ''
        };
      });
      var keySet = {}, uniqueBindings = true;
      for (var ri0 = 0; ri0 < rows.length; ri0++) {
        if (!rows[ri0].rowKey || keySet[rows[ri0].rowKey]) uniqueBindings = false;
        keySet[rows[ri0].rowKey] = 1;
      }
      /* Athena's nearby declared count includes non-visit artifacts sharing
         the list (future appointments, vitals and patient cases). The exact
         previous-visit encounter rows are the authoritative body count. */
      var declaredCount = g.selector === 'li.encounter-list-item' ? g.count : declaredEncounterCount(g);
      var expectedCount = declaredCount == null ? g.count : declaredCount;
      return {
        ok: true, selector: g.selector, count: expectedCount, renderedCount: g.count, declaredCount: declaredCount, score: g.score,
        median: g.median, withClick: g.withClick, strongRows: g.strongRows || 0,
        uniqueDates: g.uniqueDates || 0, richCount: 0, rows: rows,
        indexComplete: uniqueBindings && rows.length === expectedCount
      };
    }
    if (op === 'readExpanded') {
      /* Expose list rows only as an honest encounter index. This operation is
         retained for backwards diagnostics, but its output can never satisfy
         the full-detail receipt. */
      var g2 = bestGroup(); if (!g2) return { ok: false, visits: [] };
      var visits = g2.rows.map(function (n, i) {
        var raw = txt(n); var d = raw.match(DATE_RE);
        return {
          date: d ? d[1] : '',
          type: raw.replace(DATE_RE, '').slice(0, 80).trim(),
          textHead: raw.slice(0, 500), raw: '', cpt: [], icd10: [],
          source: 'athena-copy', indexOnly: true, fullDetail: false,
          binding: rowBinding(n, i)
        };
      });
      return { ok: true, visits: visits, indexOnly: true, fullDetail: false };
    }
    if (op === 'click') {
      if (!visitActionAllowed()) return visitDeadlineFailure();
      var g3 = bestGroup();
      var row = resolveRow(g3, idx, expectedBinding);
      if (!row) return g3 ? { clicked: false, reason: 'no-row', count: g3.rows.length, d2: noRowDiag(expectedBinding) } : { clicked: false, reason: 'no-group', d2: noRowDiag(expectedBinding) };
      var liveBinding = rowBinding(row, idx);
      if (!sameBinding(liveBinding, expectedBinding)) {
        return { clicked: false, reason: 'row-binding-changed', binding: liveBinding };
      }
      /* Guard on the row's INDEX/header label: an already-expanded row's
         clinical body can legitimately contain words like "signed"/"post"
         without making the row itself a destructive control. */
      var canonicalEncounterRow = false;
      try { canonicalEncounterRow = !!(row.matches && row.matches('li.encounter-list-item')); } catch (eGuard) {}
      if (!canonicalEncounterRow && excluded(indexText(row))) return { clicked: false, reason: 'excluded' };
      var rowTextPre = txt(row);
      var preRowHash = hashText(rowTextPre.toLowerCase().replace(/\s+/g, ' ').trim());
      /* A row left open by an earlier read already exposes its read-only
         slideout trigger. Clicking it again would collapse it. The accordion
         itself carries only metadata; the full body arrives in the second-stage
         encounter-summary iframe opened below. */
      var alreadyOpen = isOpenRow(row);
      var preDetailHashes = {};
      if (!alreadyOpen) {
        try {
          var preSel = cfg.detailSelectors.concat(['.accordion-content', '.accordion-body', '[role="region"]', '[class*="detail" i]', '[class*="note" i]', '[class*="documentation" i]', '[class*="summary" i]', '[data-section]']).join(',');
          var preNodes = Array.prototype.slice.call(row.querySelectorAll(preSel));
          for (var pi0 = 0; pi0 < preNodes.length; pi0++) if (visible(preNodes[pi0])) {
            var preText = txt(preNodes[pi0]).toLowerCase().replace(/\s+/g, ' ').trim();
            if (preText) preDetailHashes[hashText(preText)] = 1;
          }
        } catch (ePre) {}
        var target = row;
        if (canonicalEncounterRow) {
          /* The li itself is not an interactive control in Athena v26.3. Only
             its visible descendant opens the exact historical encounter row. */
          target = null;
          try {
            var rowToggles = Array.prototype.slice.call(row.querySelectorAll('div.clickable.accordion-trigger'));
            for (var rt0 = 0; rt0 < rowToggles.length; rt0++) if (visible(rowToggles[rt0])) { target = rowToggles[rt0]; break; }
          } catch (eToggle) {}
          if (!target) return { clicked: false, reason: 'accordion-trigger-missing', binding: liveBinding };
        } else {
          try { var c = row.querySelector && row.querySelector('.accordion-header,[aria-expanded],a[href],button,[role="link"],[role="button"],td a,td'); if (c && !excluded(txt(c))) target = c; } catch (e) {}
        }
        if (!visitActionAllowed()) return visitDeadlineFailure({ binding: liveBinding });
        try { target.click(); } catch (e2) { return { clicked: false, reason: 'click-failed', error: String(e2) }; }
      }
      if (!visitActionAllowed()) return visitDeadlineFailure({ binding: liveBinding });
      try { window.__mlsVisitReadBinding = { index: idx, rowKey: liveBinding.rowKey, encounterId: liveBinding.encounterId || '', date: liveBinding.date || '', preDetailHashes: preDetailHashes, preRowHash: alreadyOpen ? '' : preRowHash, preRowLen: alreadyOpen ? (Number(liveBinding.indexTextLen) || 0) : rowTextPre.length, alreadyOpen: alreadyOpen, stage: 'accordion-requested', at: Date.now() }; } catch (e3) {}
      return { clicked: true, alreadyOpen: alreadyOpen, len: txt(row).length, binding: liveBinding };
    }
    if (op === 'openDetailFrame') {
      if (!visitActionAllowed()) return visitDeadlineFailure();
      var gOpen = bestGroup(), exactOpenRow = resolveRow(gOpen, idx, expectedBinding), openMarker = null;
      if (!exactOpenRow) return { clicked: false, reason: 'no-row', d2: noRowDiag(expectedBinding) };
      var openBinding = rowBinding(exactOpenRow, idx);
      try { openMarker = window.__mlsVisitReadBinding || null; } catch (eOpenMarker) {}
      if (!sameBinding(openBinding, expectedBinding) || !sameBinding(openMarker, expectedBinding)) return { clicked: false, reason: 'detail-binding-mismatch', binding: openBinding };
      if (!isOpenRow(exactOpenRow)) return { clicked: false, reason: 'accordion-not-open', binding: openBinding };
      try { if (document.querySelector('.slideout.chart-component.slideout-open')) return { clicked: false, reason: 'detail-slideout-already-open', binding: openBinding }; } catch (eOpenExisting) {}
      var slideTrigger = null;
      try {
        var slideTriggers = Array.prototype.slice.call(exactOpenRow.querySelectorAll('span.slideout-trigger-open'));
        for (var st0 = 0; st0 < slideTriggers.length; st0++) if (visible(slideTriggers[st0])) { slideTrigger = slideTriggers[st0]; break; }
      } catch (eSlideFind) {}
      if (!slideTrigger) return { clicked: false, reason: 'slideout-trigger-missing', binding: openBinding };
      if (!visitActionAllowed()) return visitDeadlineFailure({ binding: openBinding });
      try { slideTrigger.click(); } catch (eSlideClick) { return { clicked: false, reason: 'slideout-click-failed', binding: openBinding }; }
      if (!visitActionAllowed()) return visitDeadlineFailure({ binding: openBinding });
      try { openMarker.stage = 'slideout-requested'; openMarker.slideoutAt = Date.now(); window.__mlsVisitReadBinding = openMarker; } catch (eOpenStore) {}
      return { clicked: true, binding: openBinding, stage: 'slideout-requested' };
    }
    if (op === 'closeDetailFrame') {
      if (!visitActionAllowed()) return visitDeadlineFailure();
      /* This is the sole cleanup click: the direct close child of Athena's
         currently open read-only chart slideout. It cannot match a Save, Sign,
         Bill, order, or other mutation control. */
      var openSlideout = null, closeControl = null;
      try { openSlideout = document.querySelector('.slideout.chart-component.slideout-open'); } catch (eCloseFind) {}
      if (!openSlideout) return { ok: true, closed: true, hadOpen: false };
      try {
        var directKids = openSlideout.children || [];
        for (var ck0 = 0; ck0 < directKids.length; ck0++) {
          if (directKids[ck0].tagName === 'SPAN' && /(^|\s)close(\s|$)/.test(String(directKids[ck0].className || ''))) { closeControl = directKids[ck0]; break; }
        }
      } catch (eCloseChild) {}
      if (!closeControl) return { ok: false, closed: false, reason: 'detail-close-control-missing' };
      if (!visitActionAllowed()) return visitDeadlineFailure();
      try { closeControl.click(); } catch (eCloseClick) { return { ok: false, closed: false, reason: 'detail-close-click-failed' }; }
      if (!visitActionAllowed()) return visitDeadlineFailure();
      try { window.__mlsVisitReadBinding = null; } catch (eCloseClear) {}
      return { ok: true, closed: true, hadOpen: true };
    }
    if (op === 'detailSurfaceState') {
      var surfaceSlideout = null, surfaceIframe = null, surfaceSrc = '';
      try { surfaceSlideout = document.querySelector('.slideout.chart-component.slideout-open'); } catch (eSurfaceOpen) {}
      try { surfaceIframe = document.querySelector('iframe#classic-full-encounter-summary-iframe'); surfaceSrc = surfaceIframe && surfaceIframe.getAttribute('src') || ''; } catch (eSurfaceFrame) {}
      return {
        open: !!surfaceSlideout, iframePresent: !!surfaceIframe,
        iframeContract: !!(surfaceIframe && /encounter/i.test(surfaceSrc) && /summary/i.test(surfaceSrc) && /(?:\?|&)FROMSTREAMLINED=/i.test(surfaceSrc) && /(?:\?|&)CROSSFRAMEID=/i.test(surfaceSrc))
      };
    }
    if (op === 'slideoutDetail') {
      /* Live 2026-07-16 CONFIRMED by run-2 forensics: appointment-type rows
         (est/post/epnp) render their clinical body directly in the slideout
         DOM while the embedded classic_summary iframe never navigates (pre/
         post content hashes identical on every such row). Read that DOM body
         as the row's honest full detail. Fail-closed: the read-binding marker
         must match the exact expected row (set by the bound click), the
         slideout must be open (it was proven CLOSED before our click, so any
         open slideout is ours), the text must read clinical, and it must
         differ from the frozen index text. txt() never crosses the iframe's
         document boundary, so a stale iframe can never leak another
         encounter's text into this body. */
      var sdMarker = null;
      try { sdMarker = window.__mlsVisitReadBinding || null; } catch (eSdM) {}
      if (!sameBinding(sdMarker, expectedBinding)) return { raw: '', len: 0, fullDetail: false, reason: 'slideout-binding-mismatch', binding: expectedBinding || null };
      var sdOpen = null;
      try { sdOpen = document.querySelector('.slideout.chart-component.slideout-open'); } catch (eSdF) {}
      if (!sdOpen) return { raw: '', len: 0, fullDetail: false, reason: 'slideout-not-open', binding: expectedBinding || null };
      /* Live 2026-07-16: on an occluded tab innerText degrades to textContent,
         so athena sketchpad <script> code (window.Original/Jotter) leaked into
         saved bodies. Extract from a clone with script/style/svg/iframe removed
         - deterministic regardless of tab visibility. */
      var sdRaw = '';
      try {
        var sdClone = sdOpen.cloneNode(true);
        var sdJunk = sdClone.querySelectorAll('script,style,noscript,template,svg,iframe');
        for (var sj = sdJunk.length - 1; sj >= 0; sj--) { try { sdJunk[sj].parentNode.removeChild(sdJunk[sj]); } catch (eSj) {} }
        sdRaw = String(sdClone.textContent || '').replace(/\s+/g, ' ').trim();
      } catch (eSdClone) { sdRaw = txt(sdOpen); }
      var sdNorm = String(sdRaw || '').toLowerCase().replace(/\s+/g, ' ').trim();
      if (!clinicalBody(sdRaw)) return { raw: '', len: sdNorm.length, fullDetail: false, reason: 'slideout-body-not-clinical', binding: expectedBinding || null };
      if (hashText(sdNorm) === expectedBinding.indexTextHash) return { raw: '', len: sdNorm.length, fullDetail: false, reason: 'slideout-body-equals-index', binding: expectedBinding || null };
      var sdDate = sdRaw.match(DATE_RE);
      return {
        date: (sdDate && sdDate[1]) || (expectedBinding && expectedBinding.date) || '', type: '', raw: sdRaw,
        cpt: codes(sdRaw, CPT_RE), icd10: codes(sdRaw, ICD_RE), len: sdRaw.length,
        observedLen: sdNorm.length, minAcceptedLen: Math.max(60, Number(cfg.minRealLen || 60)),
        fullDetail: true, indexOnly: false, binding: expectedBinding || null,
        frameContract: false, slideoutBody: true, bodyMinimal: false, sectionComplete: true
      };
    }
    if (op === 'slideoutProbe') {
      /* REDACTED forensics for a row whose child frame never refreshed: what
         does the OPEN slideout itself render outside the iframe? Lengths,
         booleans and hash tails only - never patient text. */
      var soOpen = null;
      try { soOpen = document.querySelector('.slideout.chart-component.slideout-open'); } catch (eSoFind) {}
      if (!soOpen) return { present: false };
      var soText = txt(soOpen);
      var soNorm = String(soText || '').toLowerCase().replace(/\s+/g, ' ').trim();
      var soFrames = 0; try { soFrames = soOpen.querySelectorAll('iframe').length; } catch (eSoFr) {}
      return { present: true, textLen: soNorm.length, clinical: clinicalBody(soText), iframes: soFrames, hash8: soNorm ? hashText(soNorm).slice(0, 8) : '' };
    }
    if (op === 'detailFrameProbe') {
      var probeUrl = '';
      try { probeUrl = String(location.href || ''); } catch (eProbeUrl) {}
      var probeContract = /athenahealth/i.test(probeUrl) && /encounter/i.test(probeUrl) && /summary/i.test(probeUrl) && /(?:\?|&)FROMSTREAMLINED=/i.test(probeUrl) && /(?:\?|&)CROSSFRAMEID=/i.test(probeUrl);
      var probeSection = null;
      try { probeSection = document.getElementById('SECTIONCONTAINER'); } catch (eProbeSection) {}
      var probeRaw = probeSection ? txt(probeSection) : '';
      return { frameContract: probeContract, sectionPresent: !!probeSection, contentHash: probeRaw ? hashText(probeRaw) : '', len: probeRaw.length, ready: String(document.readyState || '') };
    }
    if (op === 'detailFrame') {
      /* This operation is executed ONLY in the one newly created child frame
         whose URL and parent frame satisfy the encounter-summary contract. No
         page-wide/largest-block fallback is allowed. */
      var frameUrl = '';
      try { frameUrl = String(location.href || ''); } catch (eFrameUrl) {}
      var frameContract = /athenahealth/i.test(frameUrl) && /encounter/i.test(frameUrl) && /summary/i.test(frameUrl) && /(?:\?|&)FROMSTREAMLINED=/i.test(frameUrl) && /(?:\?|&)CROSSFRAMEID=/i.test(frameUrl);
      if (!frameContract) return { raw: '', len: 0, fullDetail: false, reason: 'encounter-frame-contract-mismatch', binding: expectedBinding || null };
      var sectionContainer = null;
      try { sectionContainer = document.getElementById('SECTIONCONTAINER'); } catch (eSection) {}
      if (!sectionContainer) return { raw: '', len: 0, fullDetail: false, reason: 'encounter-section-missing', binding: expectedBinding || null };
      var frameRaw = txt(sectionContainer);
      var normalizedFrameRaw = String(frameRaw || '').replace(/\s+/g, ' ').trim();
      var observedLen = normalizedFrameRaw.length;
      var minMinimalBodyLen = Math.max(8, Math.min(40, Number(cfg.minMinimalBodyLen || 8)));
      var frameReady = String(document.readyState || '').toLowerCase();
      var sectionBusy = false;
      try { sectionBusy = String(sectionContainer.getAttribute && sectionContainer.getAttribute('aria-busy') || '').toLowerCase() === 'true'; } catch (eBusy) {}
      var loadingOnly = /^(?:loading|please wait|retrieving|fetching|working)(?:\s+(?:the|encounter|visit|clinical|content|summary|data))*[.…!\s-]*$/i.test(normalizedFrameRaw);
      var bodyMinimal = false, minimalComplete = false;
      if (!clinicalBody(frameRaw)) {
        /* Live 2026-07-14 contract: some REAL prior visits carry a genuinely
           brief/non-narrative encounter summary. When the ORCHESTRATOR proved
           this frame is URL-BOUND to the row's frozen data-encounter-id, the
           complete section text — however short — IS this visit's honest full
           detail; capture it flagged bodyMinimal instead of failing the whole
           patient. Rows proven only by the content-delta fallback keep the
           strict clinical floor. Never fabricated, never another row's text. */
        if (cfg.allowMinimalBody === true) {
          minimalComplete = frameReady === 'complete' && !sectionBusy && !loadingOnly && observedLen >= minMinimalBodyLen;
          if (!minimalComplete) return {
            raw: '', len: observedLen, observedLen: observedLen, minAcceptedLen: minMinimalBodyLen,
            fullDetail: false, frameContract: true, bodyMinimal: false, sectionComplete: false,
            reason: loadingOnly || sectionBusy || frameReady !== 'complete' ? 'encounter-section-loading' : 'encounter-section-empty',
            binding: expectedBinding || null
          };
          bodyMinimal = true;
        } else return { raw: '', len: observedLen, observedLen: observedLen, minAcceptedLen: minMinimalBodyLen, fullDetail: false, reason: 'encounter-section-incomplete', binding: expectedBinding || null };
      }
      var frameDate = frameRaw.match(DATE_RE);
      return {
        date: (frameDate && frameDate[1]) || (expectedBinding && expectedBinding.date) || '', type: '', raw: frameRaw,
        cpt: codes(frameRaw, CPT_RE), icd10: codes(frameRaw, ICD_RE), len: frameRaw.length,
        observedLen: observedLen, minAcceptedLen: bodyMinimal ? minMinimalBodyLen : Math.max(60, Number(cfg.minRealLen || 60)),
        fullDetail: true, indexOnly: false, binding: expectedBinding || null,
        frameContract: true, bodyMinimal: bodyMinimal, sectionComplete: bodyMinimal ? minimalComplete : true
      };
    }
    if (op === 'detail') {
      var g4 = bestGroup();
      var exactRow = resolveRow(g4, idx, expectedBinding);
      if (!exactRow) return g4 ? { raw: '', len: 0, fullDetail: false, reason: 'no-row', d2: noRowDiag(expectedBinding) } : { raw: '', len: 0, fullDetail: false, reason: 'no-group', d2: noRowDiag(expectedBinding) };
      var actualBinding = rowBinding(exactRow, idx), marker = null;
      try { marker = window.__mlsVisitReadBinding || null; } catch (e0) {}
      if (!sameBinding(actualBinding, expectedBinding) || !sameBinding(marker, expectedBinding)) {
        return { raw: '', len: 0, fullDetail: false, reason: 'detail-binding-mismatch', binding: actualBinding };
      }

      /* Only inspect detail owned by the exact clicked row (or an element that
         row explicitly controls). Never score page-wide notes: a different open
         encounter elsewhere in the chart would otherwise be rebound to idx. */
      var candidates = [], seen = [];
      function addCandidate(n) { if (!n || n === exactRow || seen.indexOf(n) >= 0 || !visible(n)) return; seen.push(n); candidates.push(n); }
      var localSelectors = cfg.detailSelectors.concat(['.accordion-content', '.accordion-body', '[role="region"]', '[class*="detail" i]', '[class*="note" i]', '[class*="documentation" i]', '[class*="summary" i]', '[data-section]']);
      for (var s2 = 0; s2 < localSelectors.length; s2++) {
        var local = []; try { local = Array.prototype.slice.call(exactRow.querySelectorAll(localSelectors[s2])); } catch (e1) {}
        for (var l2 = 0; l2 < local.length; l2++) addCandidate(local[l2]);
      }
      try {
        var controlIds = [exactRow.getAttribute('aria-controls'), exactRow.getAttribute('data-target')];
        var ctl = exactRow.querySelector('[aria-controls],[data-target],a[href^="#"]');
        if (ctl) controlIds.push(ctl.getAttribute('aria-controls'), ctl.getAttribute('data-target'), ctl.getAttribute('href'));
        for (var ci = 0; ci < controlIds.length; ci++) {
          var id = String(controlIds[ci] || '').replace(/^#/, '').trim();
          if (id) addCandidate(document.getElementById(id));
        }
      } catch (e2) {}

      var best = null, bestRaw = '', bestScore = -1;
      for (var j2 = 0; j2 < candidates.length; j2++) {
        var t2 = txt(candidates[j2]); if (!clinicalBody(t2)) continue;
        /* A copied list summary is not a clinical body even if it is long. The
           owned detail must differ from the frozen index text. */
        var norm2 = t2.toLowerCase().replace(/\s+/g, ' ').trim();
        var candidateHash = hashText(norm2);
        if (candidateHash === expectedBinding.indexTextHash || (marker.preDetailHashes && marker.preDetailHashes[candidateHash])) continue;
        var sc2 = Math.min(t2.length, 8000) / 1000;
        if (hasCpt(t2)) sc2 += 2; if (hasIcd(t2)) sc2 += 2;
        if (/\b(?:assessment|plan|hpi|exam|diagnos|procedure)\b/i.test(t2)) sc2 += 3;
        if (sc2 > bestScore) { bestScore = sc2; best = candidates[j2]; bestRaw = t2; }
      }
      /* v2.9.22 (live Athena v26.3): the clicked li.encounter-list-item expands
         its clinical body INSIDE ITSELF (`accordion-open`) with no dedicated
         detail descendant, so the old descendant-only scan returned 0/15 bodies.
         Accept the exact bound row's own text as the encounter body, but only
         fail-closed: the row must be visibly open, its normalized text must
         differ from the frozen index text and its own pre-click snapshot, it
         must have GROWN past the index header, and it must read as clinical
         content. Never another row, never page-wide text. */
      if (!best && isOpenRow(exactRow)) {
        var rowRaw = txt(exactRow);
        var rowHash = hashText(rowRaw.toLowerCase().replace(/\s+/g, ' ').trim());
        var grewPastIndex = rowRaw.length > (Number(expectedBinding.indexTextLen) || 0) + 40;
        var changedSinceClick = marker.alreadyOpen === true || (rowHash !== marker.preRowHash && rowRaw.length > (Number(marker.preRowLen) || 0));
        if (rowHash !== expectedBinding.indexTextHash && !(marker.preDetailHashes && marker.preDetailHashes[rowHash]) && grewPastIndex && changedSinceClick && clinicalBody(rowRaw)) {
          best = exactRow; bestRaw = rowRaw;
        }
      }
      if (!best || !clinicalBody(bestRaw)) {
        return { date: expectedBinding.date || '', type: '', raw: '', cpt: [], icd10: [], len: 0, fullDetail: false, indexOnly: true, reason: 'no-bound-clinical-detail', binding: actualBinding, d2: rowFailDiag(exactRow, expectedBinding, marker, candidates) };
      }
      var d3 = bestRaw.match(DATE_RE);
      return {
        date: (d3 && d3[1]) || expectedBinding.date || '', type: '', raw: bestRaw,
        cpt: codes(bestRaw, CPT_RE), icd10: codes(bestRaw, ICD_RE), len: bestRaw.length,
        fullDetail: true, indexOnly: false, binding: actualBinding
      };
    }
    return null;
  }

  // ---- orchestrator (background scope; chrome.* + closures OK) ---------------
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  var __visitGuardByHint = new WeakMap();
  var __visitGuardByTab = new Map();
  function touchVisitLease() {
    try { if (self.__mlsQpTouch) self.__mlsQpTouch(); } catch (e) {}
  }
  /* Bound every worker/browser promise by the ONE read deadline. A 30s lease
     heartbeat runs while an op is pending, so the quiet-pull 120s watchdog
     cannot move Athena home in the middle of a valid 165-180s reader. */
  function settleVisitOp(promise, hardDeadline) {
    var deadline = Number(hardDeadline || 0);
    var left = Math.max(0, deadline - Date.now());
    if (!left) return Promise.resolve({ timeout: true });
    touchVisitLease();
    var keep = null;
    try { keep = setInterval(touchVisitLease, Math.min(30000, Math.max(1000, left))); } catch (e) {}
    return Promise.race([
      Promise.resolve(promise).then(function (value) { return { ok: true, value: value }; }, function (error) { return { error: error }; }),
      sleep(left).then(function () { return { timeout: true }; })
    ]).finally(function () { if (keep != null) try { clearInterval(keep); } catch (e) {} });
  }
  function guardCfg(guard) {
    return { __readDeadline: Number(guard && guard.deadline || 0), __requestToken: String(guard && guard.token || '') };
  }
  /* Quiet-work restoration is detached from the response, but it still owns
     Athena's tab position until qpRelease settles. Register each cleanup before
     its deferred timer starts and serialize later cleanups behind it. A
     re-entrant AllVisits request can therefore observe the prior restoration
     even when it is dispatched synchronously from sendResponse. */
  var visitCleanupTail = Promise.resolve();
  var visitCleanupPending = 0;
  var VISIT_CLEANUP_BARRIER_MS = 250;
  function fireVisitCleanup(reason, immediate) {
    /* qpRelease remains fire-and-forget from the caller's perspective: this
       promise is only a coordination barrier for the NEXT read. It is never
       awaited by the response that scheduled it. */
    visitCleanupPending++;
    var prior = visitCleanupTail;
    var task = Promise.resolve(prior).catch(function () {}).then(function () {
      return new Promise(function (resolve) {
        function startCleanup() {
          try {
            if (!self.__mlsQpRelease) { resolve({ ok: true, skipped: true }); return; }
            Promise.resolve(self.__mlsQpRelease(reason)).then(function () {
              resolve({ ok: true });
            }, function () {
              /* qpRelease owns its own best-effort restoration. A rejection is
                 terminal for this queue entry; do not leave the barrier leaked. */
              resolve({ ok: false });
            });
          } catch (e) { resolve({ ok: false }); }
        }
        /* qpEnsure can move a tab synchronously and then never settle. In that
           failure mode start restoration now; ordinary after-response cleanup
           stays deferred so it cannot extend the response path. */
        if (immediate) startCleanup(); else setTimeout(startCleanup, 0);
      });
    });
    visitCleanupTail = task;
    task.then(function () { visitCleanupPending = Math.max(0, visitCleanupPending - 1); }, function () { visitCleanupPending = Math.max(0, visitCleanupPending - 1); });
    return task;
  }
  function waitForVisitCleanup(callerDeadlineAt) {
    if (!visitCleanupPending) return Promise.resolve({ ok: true });
    var callerDeadline = Number(callerDeadlineAt || 0);
    var waitMs = VISIT_CLEANUP_BARRIER_MS;
    if (Number.isFinite(callerDeadline) && callerDeadline > 0) waitMs = Math.min(waitMs, Math.max(0, callerDeadline - Date.now()));
    var stopAt = Date.now() + waitMs;
    function waitCurrentTail() {
      if (!visitCleanupPending) return Promise.resolve({ ok: true });
      var left = Math.max(0, stopAt - Date.now());
      if (!left) return Promise.resolve({ ok: false, reason: 'quiet-cleanup-pending' });
      var snapshot = visitCleanupTail;
      return Promise.race([
        Promise.resolve(snapshot).then(function () { return { settled: true }; }),
        sleep(left).then(function () { return { timeout: true }; })
      ]).then(function (state) {
        if (state && state.timeout) return { ok: false, reason: 'quiet-cleanup-pending' };
        /* A late ensure-timeout backstop may have queued another restoration
           while this snapshot settled. Include it in the same bounded wait. */
        return waitCurrentTail();
      });
    }
    return waitCurrentTail();
  }
  function loadVisitsCfgBound(timeoutMs) {
    return new Promise(function (resolve) {
      var done = false, timer = null;
      function finish(st) {
        if (done) return; done = true;
        if (timer != null) try { clearTimeout(timer); } catch (e) {}
        var cfg = {}, stored = (st && st.mlsAthenaVisitsCfg) || {};
        for (var k in ORCH_DEFAULT) cfg[k] = (stored[k] != null ? stored[k] : ORCH_DEFAULT[k]);
        for (var k2 in stored) if (cfg[k2] == null) cfg[k2] = stored[k2];
        resolve(cfg);
      }
      try { timer = setTimeout(function () { finish({}); }, Math.max(250, Number(timeoutMs || 1500))); } catch (eT) {}
      try { chrome.storage.local.get(['mlsAthenaVisitsCfg'], finish); } catch (e) { finish({}); }
    });
  }
  function emit(tabId, requestId, message, n, total) {
    try {
      if (tabId != null) chrome.tabs.sendMessage(tabId, {
        type: 'mlsAppVisitsProgress', requestId: String(requestId || '').slice(0, 100),
        message: message, n: n, total: total
      });
    } catch (e) {}
  }

  function pickEmrTab(hint) {
    var guard = null;
    try { guard = __visitGuardByHint.get(hint) || null; } catch (eGuard) {}
    var hardDeadline = Number(guard && guard.deadline || 0);
    var pickPromise = new Promise(function (resolve) {
      try {
        chrome.tabs.query({}, function (tabs) {
          if (Date.now() >= hardDeadline) { resolve(null); return; }
          var cand = (tabs || []).filter(function (t) { return t.url && EMR_RE.test(t.url); });
          cand.sort(function (a, b) { return (b.active ? 1 : 0) - (a.active ? 1 : 0) || (b.id - a.id); });
          /* Keep AllVisits in the exact Athena tab proven by the immediately
             preceding chart receipt. The same-frame gate below still rechecks
             name+DOB/MRN before reading any encounter body. */
          try {
            var lease = self.__mlsVerifiedReadTarget || null, h = hint || {};
            var nk = function (s) { return String(s || '').toLowerCase().replace(/[^a-z0-9]/g, ''); };
            var dk = function (s) {
              var m = String(s || '').match(/(\d{1,4})[\/\-.](\d{1,2})[\/\-.](\d{1,4})/); if (!m) return '';
              var y, mo, d; if (m[1].length === 4) { y=m[1]; mo=m[2]; d=m[3]; } else { mo=m[1]; d=m[2]; y=m[3]; }
              if (String(y).length === 2) y=(Number(y)>40?'19':'20')+y;
              return String(y)+('0'+Number(mo)).slice(-2)+('0'+Number(d)).slice(-2);
            };
            var wantName = h.name || h.patient || h.patientName || '', wantDob = h.dob || h.patientDob || '', wantMrn = h.mrn || h.athenaId || '';
            var leaseMatches = lease && (Date.now() - Number(lease.at || 0)) < 180000 && nk(lease.name) === nk(wantName) && (!wantDob || dk(lease.dob) === dk(wantDob)) && (!wantMrn || nk(lease.mrn) === nk(wantMrn));
            if (leaseMatches) {
              var exact = cand.find(function (t) { return Number(t.id) === Number(lease.tabId); });
              resolve(exact || null); return;
            }
          } catch (eLease) {}
          /* No lease (for example a direct Copy every visit click): prove the
             exact patient across every signed-in Athena tab before choosing
             one. This prevents an active/recent but wrong second Athena tab
             from winning. The scan is read-only and still re-verifies identity
             in the exact Visits frame before any encounter click. */
          try {
            var frozenPick = freezeVisitHint(hint || {});
            if (frozenPick.name && (frozenPick.dob || frozenPick.mrn)) {
              (async function () {
                var exactMatches = [];
                for (var ci0 = 0; ci0 < cand.length; ci0++) {
                  if (Date.now() >= hardDeadline) { resolve(null); return; }
                  try {
                    var idResults = await exec(cand[ci0].id, null, ['identity', guardCfg(guard)]);
                    var idBest = bestResult(idResults, function (r) {
                      return (r && r.name ? 20 : 0) + (r && r.dob ? 15 : 0) + (r && r.mrn ? 10 : 0) + ((r && r.score) || 0);
                    }).result || {};
                    if (visitIdentityGate(frozenPick, idBest).ok) exactMatches.push(cand[ci0]);
                  } catch (ePickIdentity) {}
                }
                if (exactMatches.length) { resolve(exactMatches[0]); return; }
                resolve(null);
              })();
              return;
            }
          } catch (eExactPick) {}
          /* v1.90: unified verified picker; the old active-first order stays the fallback */
          try {
            if (Date.now() >= hardDeadline) { resolve(null); return; }
            if (typeof mlsPickAthenaTab === 'function') { Promise.resolve(mlsPickAthenaTab(tabs, { athenaOnly: true })).then(function (t) { resolve(Date.now() < hardDeadline ? (t || cand[0] || null) : null); }, function () { resolve(Date.now() < hardDeadline ? (cand[0] || null) : null); }); return; }
          } catch (e2) {}
          resolve(cand[0] || null);
        });
      } catch (e) { resolve(null); }
    });
    return settleVisitOp(pickPromise, hardDeadline).then(function (out) { return out && out.ok ? out.value : null; });
  }

  function exec(tabId, frameIds, args) {
    var cfg0 = args && args[1] || {};
    var hardDeadline = Number(cfg0.__readDeadline || 0);
    var requestToken = String(cfg0.__requestToken || '');
    if (!hardDeadline || !requestToken || Date.now() >= hardDeadline) return Promise.resolve([]);
    var target = { tabId: tabId }; if (frameIds) target.frameIds = frameIds; else target.allFrames = true;
    var execPromise;
    if (args && args[0] === 'identity') {
      /* Reuse the production chart identity readers instead of the old generic
         body regex in mlsVisitsDriverFn. Run both plain-DOM and open-shadow-root
         variants; frame IDs remain attached so enumeration can bind identity to
         its exact briefing frame. */
      execPromise = Promise.all([
        chrome.scripting.executeScript({ target: target, func: mlsReadChartIdentity }).catch(function () { return []; }),
        chrome.scripting.executeScript({ target: target, func: mlsReadChartIdentityShadow }).catch(function () { return []; })
      ]).then(function (all) { return (all[0] || []).concat(all[1] || []); });
    } else {
      execPromise = chrome.scripting.executeScript({ target: target, func: mlsVisitsDriverFn, args: args }).catch(function () { return []; });
    }
    return settleVisitOp(execPromise, hardDeadline).then(function (out) { return out && out.ok ? (out.value || []) : []; });
  }
  async function encounterDetailFrames(tabId, parentFrameId) {
    try {
      if (!chrome.webNavigation || typeof chrome.webNavigation.getAllFrames !== 'function') return [];
      var guard = __visitGuardByTab.get(Number(tabId)) || null;
      if (!guard || Date.now() >= Number(guard.deadline || 0)) return [];
      var settled = await settleVisitOp(chrome.webNavigation.getAllFrames({ tabId: tabId }), guard.deadline);
      if (!settled || !settled.ok) return [];
      var frames = settled.value;
      return (frames || []).filter(function (frame) {
        var u = String(frame && frame.url || '');
        return Number(frame && frame.parentFrameId) === Number(parentFrameId) &&
          /athenahealth/i.test(u) && /encounter/i.test(u) && /summary/i.test(u) &&
          /(?:\?|&)FROMSTREAMLINED=/i.test(u) && /(?:\?|&)CROSSFRAMEID=/i.test(u);
      }).map(function (frame) { return { frameId: Number(frame.frameId), parentFrameId: Number(frame.parentFrameId), documentId: String(frame.documentId || ''), url: String(frame.url || '') }; });
    } catch (e) { return []; }
  }
  async function waitForEncounterDetailFrames(tabId, parentFrameId, wantCount, timeoutMs, pollMs) {
    var deadline = Date.now() + Math.max(200, Number(timeoutMs || 1800)), frames = [];
    do {
      frames = await encounterDetailFrames(tabId, parentFrameId);
      if (frames.length === wantCount) return frames;
      await sleep(Math.max(60, Math.min(250, Number(pollMs || 120))));
    } while (Date.now() < deadline);
    return frames;
  }
  async function waitForDetailSurface(tabId, parentFrameId, wantOpen, timeoutMs, pollMs, hardDeadline) {
    var deadline = Date.now() + Math.max(200, Number(timeoutMs || 1800)), state = null;
    if (Number.isFinite(Number(hardDeadline))) deadline = Math.min(deadline, Number(hardDeadline));
    do {
      if (Date.now() >= deadline) break;
      var guard = __visitGuardByTab.get(Number(tabId)) || { deadline: hardDeadline, token: '' };
      var states = await exec(tabId, [parentFrameId], ['detailSurfaceState', guardCfg(guard)]);
      state = bestResult(states, function (r) { return r && typeof r.open === 'boolean' ? 1 : 0; }).result || null;
      /* Cold-chart live finding 2026-07-14: the slideout CONTAINER flips open
         ~100-200ms after the trigger click, but its encounter iframe is created
         later (up to several seconds on a first-open chart). Waiting for OPEN
         must therefore also wait for the iframe contract; returning early made
         the caller's one-shot contract check fail every cold row. The close
      wait and the timeout/fail-closed behavior are unchanged. */
      if (state && state.open === wantOpen && (!wantOpen || state.iframeContract === true)) return state;
      var remaining = Math.max(0, deadline - Date.now());
      if (!remaining) break;
      await sleep(Math.min(remaining, Math.max(60, Math.min(250, Number(pollMs || 120)))));
    } while (Date.now() < deadline);
    return state;
  }
  function bestResult(results, scoreFn) {
    var best = null, bestScore = -1, bestFrame = 0;
    (results || []).forEach(function (r) { if (!r || r.result == null) return; var sc = scoreFn(r.result); if (sc > bestScore) { bestScore = sc; best = r.result; bestFrame = r.frameId; } });
    return { result: best, frameId: bestFrame, score: bestScore };
  }
  function freezeVisitHint(hint) {
    hint = hint || {};
    var out = {
      name: String(hint.name || hint.patientName || '').trim(),
      dob: String(hint.dob || hint.patientDob || hint.dateOfBirth || '').trim(),
      mrn: String(hint.mrn || hint.athenaId || '').trim()
    };
    try { return Object.freeze(out); } catch (e) { return out; }
  }
  function visitIdentityGate(frozen, live) {
    frozen = frozen || {}; live = live || {};
    function words(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(function (w) { return w.length > 1; }); }
    function dob(s) {
      s = String(s || ''); var iso = s.match(/(\d{4})-(\d{1,2})-(\d{1,2})/), m;
      if (iso) return iso[1] + ('0' + iso[2]).slice(-2) + ('0' + iso[3]).slice(-2);
      m = s.match(/(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/); if (!m) return '';
      var y = String(m[3]); if (y.length === 2) y = (Number(y) > 40 ? '19' : '20') + y;
      return y + ('0' + m[1]).slice(-2) + ('0' + m[2]).slice(-2);
    }
    function id(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9]/g, ''); }
    var wantName = words(frozen.name), haveName = words(live.name);
    var wantDob = dob(frozen.dob), haveDob = dob(live.dob);
    var wantMrn = id(frozen.mrn), haveMrn = id(live.mrn);
    if (wantName.length < 2 || (!wantDob && !wantMrn)) return { ok: false, reason: 'identity-hint-incomplete' };
    if (haveName.length < 2) return { ok: false, reason: 'same-frame-name-missing' };
    var have = {}; haveName.forEach(function (w) { have[w] = 1; });
    /* Abbreviated-banner names (see strictNameMatch): a want-token may match a
       live token by exact text, >=4-char prefix in either direction, or a
       single-letter live initial (athena shows "Cubbage-Reilly A"). Live
       single-letter tokens are retained for this check only. The DOB/MRN
       equality gates below are unchanged. */
    var haveAllTok = String(live.name || '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(Boolean);
    function wantTokenOk(wantTok) {
      if (have[wantTok]) return true;
      return haveAllTok.some(function (h) {
        if (h === wantTok) return true;
        if (h.length >= 4 && wantTok.length >= 4 && (h.indexOf(wantTok) === 0 || wantTok.indexOf(h) === 0)) return true;
        return h.length === 1 && h === wantTok.charAt(0);
      });
    }
    var hits = 0; wantName.forEach(function (w) { if (wantTokenOk(w)) hits++; });
    var nameOk = hits >= 2 && wantTokenOk(wantName[0]) && wantTokenOk(wantName[wantName.length - 1]);
    if (!nameOk) return { ok: false, reason: 'same-frame-name-mismatch' };
    /* DOB is preferred when frozen. MRN is the exact fallback for records that
       intentionally omit DOB. Never accept a name-only chart. */
    if (wantDob) {
      if (!haveDob) return { ok: false, reason: 'same-frame-dob-missing' };
      if (wantDob !== haveDob) return { ok: false, reason: 'same-frame-dob-mismatch' };
    } else {
      if (!haveMrn) return { ok: false, reason: 'same-frame-mrn-missing' };
      if (wantMrn !== haveMrn) return { ok: false, reason: 'same-frame-mrn-mismatch' };
    }
    if (wantMrn && haveMrn && wantMrn !== haveMrn) return { ok: false, reason: 'same-frame-mrn-mismatch' };
    return { ok: true, reason: 'name+' + (wantDob ? 'dob' : 'mrn') };
  }
  function realVisit(v, minLen) {
    if (!v) return false;
    var raw = String(v.raw || '').trim();
    var hasCode = (Array.isArray(v.cpt) && v.cpt.length) || (Array.isArray(v.icd10) && v.icd10.length);
    return v.fullDetail === true && v.indexOnly !== true && ((raw.length >= Math.max(60, (minLen || 60))) || hasCode);
  }
  function saveDiag(diag) {
    try { chrome.storage.local.set({ mlsAthenaVisitsDiag: { at: Date.now(), diag: diag } }); } catch (e) {}
    // Redacted (no-PHI) structural map — safe to log so it can be copied for selector tuning.
    try { console.log('[MLS Assist v2.9.22 r4 diag — redacted, no PHI]', JSON.stringify(diag)); } catch (e) {}
  }

  /* v2.9.22 r4: exact-patient, exact-encounter, full-body reader. This
     implementation fails closed unless the complete index and all
     encounter-scoped clinical bodies are proven. */
  function runAllVisits(appTabId, hint, cfg, requestId, callerDeadlineAt) {
    var identity = {}, listFrame = 0, enumRes = null, diag = null;
    var qpOwnedByThisRead = false, readTabId = null, frozenHint = freezeVisitHint(hint);
    var frozenRequestId = String(requestId || '').slice(0, 100);
    var minLen = Math.max(60, Number(cfg.minRealLen || 60));
    /* One absolute budget begins before tab selection/navigation. Encounter
       retries, final identity proof, and cleanup therefore cannot silently add
       another full row budget after the advertised maxReadMs window. */
    var readStartedAt = Date.now();
    var readBudgetMs = Math.max(30000, Math.min(180000, Number(cfg.maxReadMs || 165000)));
    var readDeadline = readStartedAt + readBudgetMs;
    var frozenCallerDeadline = Number(callerDeadlineAt || 0);
    /* The app/content bridge may have less time remaining than this reader's
       normal ceiling (for example near the end of the whole-day batch). Never
       allow a late service-worker dispatch to outlive that caller-owned
       deadline and click after the page has already settled the request. */
    if (Number.isFinite(frozenCallerDeadline) && frozenCallerDeadline > 0) {
      readDeadline = Math.min(readDeadline, frozenCallerDeadline);
    }
    var visitRequestToken = frozenRequestId || ('mlsvis-' + readStartedAt.toString(36) + '-' + Math.random().toString(36).slice(2, 9));
    var readGuard = Object.freeze({ deadline: readDeadline, token: visitRequestToken });
    try { __visitGuardByHint.set(frozenHint, readGuard); } catch (eGuardHint) {}
    cfg = Object.assign({}, cfg, guardCfg(readGuard));
    function deadlineResult(stage) {
      return {
        ok: false, reason: 'read-deadline-exceeded', visits: [], identity: identity, diag: diag,
        requestId: frozenRequestId || undefined,
        receipt: { complete: false, indexComplete: !!enumRes, bodyComplete: false, fullDetail: false, expected: (enumRes && enumRes.count) || 0, parsed: 0, attempted: 0, timeBudgetMs: readBudgetMs, elapsedMs: Math.max(0, Date.now() - readStartedAt) },
        error: 'The verified Athena history read reached its absolute deadline during ' + (stage || 'the read') + '. Nothing partial was reported or saved.'
      };
    }
    var readPromise = (async function () {
      var emr = await pickEmrTab(frozenHint);
      /* Live 2026-07-16: a just-finished chart read can leave the exact tab
         momentarily unreadable (no-athena-tab about once per 20-patient batch).
         Two bounded re-picks after a short settle heal it; every identity gate
         still runs unchanged before any body is read. */
      var rePicks = 0;
      while (!emr && rePicks < 2 && Date.now() + 2500 < readDeadline) {
        rePicks++;
        await sleep(2000);
        emr = await pickEmrTab(frozenHint);
      }
      return emr;
    })().then(async function (emr) {
      if (!emr) return Date.now() >= readDeadline ? deadlineResult('exact-tab selection') : { ok: false, reason: 'no-athena-tab', visits: [], error: 'No exact-patient athenaOne chart or fresh verified chart lease was proved. Open and verify that patient\'s chart, then retry.' };
      var emrId = emr.id;
      readTabId = Number(emrId);
      try { __visitGuardByTab.set(Number(emrId), readGuard); } catch (eGuardTab) {}
      /* Quiet-pull visibility lease: make Athena render without focusing it or
         changing the clinician's selected tab. No reload, URL navigation,
         session-screen click, or write action is performed by this reader. */
      try {
        var qpWasActive = !!(self.__mlsQp && self.__mlsQp.active);
        if (self.__mlsQpEnsure) {
          var qpEnsurePromise = Promise.resolve(self.__mlsQpEnsure(emr, appTabId));
          var qpSettled = await settleVisitOp(qpEnsurePromise, readDeadline);
          if (!qpSettled || qpSettled.timeout) {
            /* The ensure call may have moved the tab before stalling. Start a
               detached cleanup immediately, then keep a second late-settlement
               backstop for implementations that finish after our response. */
            fireVisitCleanup('all-visits-ensure-timeout', true);
            qpEnsurePromise.finally(function () { fireVisitCleanup('all-visits-late-ensure', true); }).catch(function () {});
            return deadlineResult('quiet-work setup');
          }
        }
        qpOwnedByThisRead = !qpWasActive && !!(self.__mlsQp && self.__mlsQp.active && self.__mlsQp.athenaTabId === emrId);
      } catch (e) {}

      emit(appTabId, frozenRequestId, 'Reading every encounter from athenaOne… (read-only)');
      await exec(emrId, null, ['openVisits', cfg]);
      if (Date.now() >= readDeadline) return deadlineResult('Visits navigation');
      touchVisitLease();
      await sleep(Math.min(Math.max(0, readDeadline - Date.now()), cfg.visitTabWaitMs || 2200));
      if (Date.now() >= readDeadline) return deadlineResult('Visits hydration');
      touchVisitLease();
      await sleep(Math.min(Math.max(0, readDeadline - Date.now()), cfg.initialWaitMs || 1000));
      if (Date.now() >= readDeadline) return deadlineResult('encounter-index hydration');

      var dgRes = await exec(emrId, null, ['diagnose', cfg]);
      var db = bestResult(dgRes, function (r) { return (r && r.groupCount) || 0; });
      diag = db.result || null; saveDiag(diag);

      var enR = await exec(emrId, null, ['enumerate', cfg]);
      var eb = bestResult(enR, function (r) {
        if (!(r && r.ok)) return 0;
        return (r.selector === 'li.encounter-list-item' ? 100000 : 0) + (r.score || 0);
      });
      enumRes = eb.result; listFrame = eb.frameId;
      var authoritativeEmptyIndex = !!(enumRes && enumRes.ok && enumRes.count === 0 && enumRes.indexComplete === true && enumRes.authoritativeEmpty === true);
      if (!enumRes || !enumRes.ok || (!enumRes.count && !authoritativeEmptyIndex) || !enumRes.indexComplete) {
        return {
          ok: false, reason: 'encounter-index-incomplete', identity: {}, visits: [], diag: diag,
          receipt: { complete: false, indexComplete: false, bodyComplete: false, fullDetail: false, expected: (enumRes && enumRes.count) || 0, parsed: 0, attempted: 0, cap: cfg.maxVisits },
          error: 'No complete patient-scoped encounter index was recognized. Nothing was reported as a full history.'
        };
      }
      var rows = enumRes.rows || [], total = rows.length;
      if (total > cfg.maxVisits) {
        return {
          ok: false, reason: 'visits-cap-exceeded', identity: {}, visits: [], diag: diag,
          receipt: { complete: false, indexComplete: true, bodyComplete: false, fullDetail: false, expected: total, parsed: 0, attempted: 0, cap: cfg.maxVisits },
          error: 'Athena exposed ' + total + ' encounters, above this reader\'s safety cap of ' + cfg.maxVisits + '. Nothing was reported as complete.'
        };
      }

      /* Verify identity LIVE in the exact frame that supplied the encounter
         index. A stale identity from another frame cannot authorize any body. */
      var liveIds = await exec(emrId, [listFrame], ['identity', cfg]);
      identity = bestResult(liveIds, function (r) {
        if (!r) return 0;
        return (r.score || 0) + (r.name ? 20 : 0) + (r.dob ? 15 : 0) + (r.mrn ? 10 : 0) + (r.via === 'banner' ? 20 : 0);
      }).result || {};
      var gate = visitIdentityGate(frozenHint, identity);
      if (!gate.ok) {
        return {
          ok: false, reason: gate.reason, identity: identity, visits: [], diag: diag,
          receipt: { complete: false, indexComplete: true, bodyComplete: false, fullDetail: false, expected: total, parsed: 0, attempted: 0, cap: cfg.maxVisits, identityVerified: false },
          error: 'Safety stop: the live patient identity in the encounter-list frame did not match the frozen MLS patient (name plus DOB/MRN). No encounter body was read.'
        };
      }

      var detailWaitMs = Math.max(300, Math.min(2500, Number(cfg.waitMs || 1400)));
      /* A newly opened Athena briefing surface can spend several seconds
         hydrating its first accordion rows and cached encounter iframe. Keep
         the normal path fast, but allow one same-row, same-binding cold retry
         with a longer bounded wait. No identity, frame, or stable-key gate is
         weakened by this retry. */
      /* Live 2026-07-14 cold evidence (patients with 1/7/11 prior visits): the
         FIRST slideout + iframe hydration on a cold chart takes ~5-8s, so a 4s
         retry ceiling still loses its only row. The retry stays bounded by
         readDeadline; only this ceiling changes. */
      var coldRetryWaitMs = Math.max(detailWaitMs, Math.min(10000, Number(cfg.coldRetryWaitMs || Math.max(8000, detailWaitMs + 6600))));
      var coldRetryPauseMs = Math.max(120, Math.min(500, Number(cfg.coldRetryPauseMs || 300)));
      var remainingReadBudgetMs = Math.max(0, readDeadline - Date.now());
      /* Admission reserves one full cold hydration retry in addition to the
         fixed navigation/final-proof margin. More than one cold miss still
         fails closed at the absolute deadline; it can never overrun it. */
      var coldRetryReserveMs = coldRetryWaitMs + coldRetryPauseMs + 700;
      var normalEncounterBudgetMs = (detailWaitMs * 2) + 700;
      var maxByBudget = Math.max(0, Math.floor((remainingReadBudgetMs - 15000 - coldRetryReserveMs) / normalEncounterBudgetMs));
      if (total > maxByBudget) {
        return {
          ok: false, reason: 'visits-time-budget-exceeded', identity: identity, visits: [], diag: diag,
          receipt: { complete: false, indexComplete: true, bodyComplete: false, fullDetail: false, expected: total, parsed: 0, attempted: 0, cap: cfg.maxVisits, timeBudgetMs: readBudgetMs, remainingBudgetMs: remainingReadBudgetMs, coldRetryReserveMs: coldRetryReserveMs, maxEncountersByBudget: maxByBudget, identityVerified: true },
          error: 'Athena exposed ' + total + ' encounters, which cannot all be verified inside this pull\'s bounded read budget. Nothing was opened or reported as complete.'
        };
      }

      var visits = [], failures = [], retryCount = 0, minimalBodies = 0, attemptedCount = 0, administrativeRows = [];
      async function sleepWithinReadDeadline(ms) {
        var remaining = Math.max(0, readDeadline - Date.now());
        if (!remaining) return false;
        await sleep(Math.min(remaining, Math.max(0, Number(ms || 0))));
        return Date.now() < readDeadline;
      }
      for (var i = 0; i < total; i++) {
        if (Date.now() >= readDeadline) { failures.push({ index: i, reason: 'read-deadline-exceeded' }); break; }
        var snap = rows[i] || {}, expected = snap.binding || null;
        if (!expected || Number(expected.index) !== i || !expected.rowKey) {
          failures.push({ index: i, reason: 'index-binding-missing' });
          continue;
        }
        /* Live 2026-07-16: 'order group' rows are administrative order
           summaries rendered in the cached classic_summary frame - they have
           no clinical note body and can never satisfy the fresh-frame proof
           (encounter-frame-not-refreshed on every chart carrying one). Count
           them honestly on the receipt instead of failing the whole batch. */
        if (/^\s*order\s*group\b/i.test(String(snap.type || ''))) {
          administrativeRows.push({ index: i, type: String(snap.type || '').slice(0, 60) });
          continue;
        }
        attemptedCount++;
        emit(appTabId, frozenRequestId, 'Opening encounter ' + (i + 1) + ' of ' + total + '…', i, total);
        var twoStageAthena = enumRes.selector === 'li.encounter-list-item';
        var runBoundAttempt = async function (rowWaitMs) {
          var preDetailFrames = [], preDetailProbes = {};
          if (Date.now() >= readDeadline) return { failure: { reason: 'read-deadline-exceeded' } };
          try {
            if (twoStageAthena) {
              await exec(emrId, [listFrame], ['closeDetailFrame', cfg]);
              if (Date.now() >= readDeadline) return { failure: { reason: 'read-deadline-exceeded' } };
              var closedSurface = await waitForDetailSurface(emrId, listFrame, false, Math.max(500, rowWaitMs), cfg.detailPollMs, readDeadline);
              if (!closedSurface || closedSurface.open !== false) return { failure: { reason: 'stale-encounter-surface-open' } };
              /* Athena may retain one hidden cached iframe after closing. Freeze
                 its document id and redacted content fingerprint; a reused
                 frame must navigate or change after the exact next-row click. */
              preDetailFrames = await encounterDetailFrames(emrId, listFrame);
              if (preDetailFrames.length > 1) return { failure: { reason: 'ambiguous-cached-encounter-frames' } };
              for (var pf0 = 0; pf0 < preDetailFrames.length; pf0++) {
                if (Date.now() >= readDeadline) return { failure: { reason: 'read-deadline-exceeded' } };
                var preProbeR = await exec(emrId, [preDetailFrames[pf0].frameId], ['detailFrameProbe', cfg]);
                preDetailProbes[String(preDetailFrames[pf0].frameId)] = bestResult(preProbeR, function (r) { return r && r.frameContract ? 1 : 0; }).result || null;
              }
            }

            if (Date.now() >= readDeadline) return { failure: { reason: 'read-deadline-exceeded' } };
            var clickR = await exec(emrId, [listFrame], ['click', cfg, i, expected]);
            var clicked = bestResult(clickR, function (r) { return (r && r.clicked === true) ? 1 : 0; }).result || {};
            if (!clicked.clicked) return { failure: { reason: clicked.reason || 'click-failed', d2: clicked.d2 || null } };

            if (!twoStageAthena) {
              var legacyDeadline = Math.min(readDeadline, Date.now() + rowWaitMs), legacyDetail = {}, legacyR;
              do {
                if (!(await sleepWithinReadDeadline(Math.max(80, Math.min(300, Number(cfg.detailPollMs || 180)))))) break;
                legacyR = await exec(emrId, [listFrame], ['detail', cfg, i, expected]);
                legacyDetail = bestResult(legacyR, function (r) { return (r && r.fullDetail === true && r.raw) ? r.raw.length : 0; }).result || {};
                if (legacyDetail.fullDetail === true && legacyDetail.raw) break;
              } while (Date.now() < legacyDeadline);
              return { detail: legacyDetail };
            }

            /* Stage 2: after the exact row accordion opens, click only that
               row's visible slideout trigger. This creates one new child frame
               under the verified Visits frame. */
            var openDeadline = Math.min(readDeadline, Date.now() + rowWaitMs), opened = {}, openR;
            do {
              if (!(await sleepWithinReadDeadline(Math.max(80, Math.min(250, Number(cfg.detailPollMs || 180)))))) break;
              openR = await exec(emrId, [listFrame], ['openDetailFrame', cfg, i, expected]);
              opened = bestResult(openR, function (r) { return (r && r.clicked === true) ? 1 : 0; }).result || {};
              if (opened.clicked) break;
            } while (Date.now() < openDeadline && (opened.reason === 'accordion-not-open' || opened.reason === 'slideout-trigger-missing' || !opened.reason));
            if (!opened.clicked) return { failure: { reason: opened.reason || 'slideout-open-failed' } };

            var openedSurface = await waitForDetailSurface(emrId, listFrame, true, rowWaitMs, cfg.detailPollMs, readDeadline);
            if (!openedSurface || openedSurface.open !== true || openedSurface.iframeContract !== true) return { failure: { reason: 'encounter-surface-not-open' } };

            var frameProofDeadline = Math.min(readDeadline, Date.now() + rowWaitMs), detailFrames = [], detailFrame = null, frameProven = false, frameUrlBound = false;
            do {
              detailFrames = await encounterDetailFrames(emrId, listFrame);
              if (detailFrames.length === 1 && Number.isFinite(detailFrames[0].frameId)) {
                detailFrame = detailFrames[0];
                var priorFrame = null;
                for (var pfi = 0; pfi < preDetailFrames.length; pfi++) if (preDetailFrames[pfi].frameId === detailFrame.frameId) priorFrame = preDetailFrames[pfi];
                var documentChanged = !priorFrame || (!!priorFrame.documentId && !!detailFrame.documentId && priorFrame.documentId !== detailFrame.documentId);
                var probeR = await exec(emrId, [detailFrame.frameId], ['detailFrameProbe', cfg]);
                var probe = bestResult(probeR, function (r) { return r && r.frameContract && r.sectionPresent && r.contentHash ? r.len || 1 : 0; }).result || null;
                var priorProbe = preDetailProbes[String(detailFrame.frameId)] || null;
                var contentChanged = !!(probe && (!priorProbe || probe.contentHash !== priorProbe.contentHash || Number(probe.len) !== Number(priorProbe.len)));
                /* Live 2026-07-14: the chart-open PRE-CACHES an iframe already
                   showing the MOST RECENT encounter, so clicking that row can
                   never produce a document/content delta. Athena's own URL is
                   the direct binder: when the frame URL carries this row's
                   FROZEN data-encounter-id (non-alphanumeric boundaries), the
                   frame IS this encounter — caching cannot spoof it and a
                   different row's id can never match. Delta proof remains the
                   fallback for id-less rows. */
                var urlBound = false;
                try {
                  var eidRaw = String(expected.encounterId || '');
                  if (eidRaw && /^[A-Za-z0-9_-]{2,}$/.test(eidRaw)) {
                    var eidRe = new RegExp('(?:^|[^0-9A-Za-z])' + eidRaw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?:[^0-9A-Za-z]|$)');
                    urlBound = eidRe.test(String(detailFrame.url || ''));
                  }
                } catch (eUrlBind) {}
                if (probe && (urlBound || documentChanged || contentChanged)) { frameProven = true; frameUrlBound = urlBound; break; }
              }
              if (!(await sleepWithinReadDeadline(Math.max(80, Math.min(250, Number(cfg.detailPollMs || 180)))))) break;
            } while (Date.now() < frameProofDeadline);
            if (!frameProven || !detailFrame) {
              /* Live 2026-07-16 forensics: appointment-type rows (est/post/epnp)
                 fail this proof deterministically on some charts. Capture what
                 the open slideout renders OUTSIDE the child frame (REDACTED:
                 lengths, booleans, hash tails) to distinguish a real in-slideout
                 body from an appointment row with no note document. */
              var soProbe = null;
              try {
                var soR = await exec(emrId, [listFrame], ['slideoutProbe', cfg]);
                soProbe = bestResult(soR, function (r) { return r && r.present ? 1 : 0; }).result || null;
              } catch (eSoProbe) {}
              /* Run-2 forensics confirmed: these rows carry the real clinical
                 body in the slideout DOM (iframe hash frozen pre/post on every
                 failing row). Accept that body under the full existing gate
                 chain: proven-closed-then-opened surface, exact-row binding
                 marker, live patient identity re-proof, clinical floor, and
                 index-text inequality. Anything less still fails closed. */
              if (detailFrames.length <= 1 && soProbe && soProbe.present && soProbe.clinical) {
                if (Date.now() >= readDeadline) return { failure: { reason: 'read-deadline-exceeded' } };
                var soIds = await exec(emrId, [listFrame], ['identity', cfg]);
                var soIdentity = bestResult(soIds, function (r) { return (r && r.name ? 20 : 0) + (r && r.dob ? 15 : 0) + (r && r.mrn ? 10 : 0) + ((r && r.score) || 0); }).result || {};
                if (visitIdentityGate(frozenHint, soIdentity).ok) {
                  var soDetailR = await exec(emrId, [listFrame], ['slideoutDetail', cfg, i, expected]);
                  var soDetail = bestResult(soDetailR, function (r) { return (r && r.fullDetail === true && r.raw) ? String(r.raw).length : 0; }).result || {};
                  if (soDetail.fullDetail === true && soDetail.raw) return { detail: soDetail };
                }
              }
              return { failure: { reason: detailFrames.length > 1 ? 'ambiguous-encounter-frames' : 'encounter-frame-not-refreshed', d2: { hadFrame: detailFrames.length, urlBoundChecked: !!(expected && expected.encounterId), rowType: String((snap && snap.type) || '').slice(0, 60), hadDetailFrame: !!detailFrame, frameUrlTail: detailFrame ? String(detailFrame.url || '').split('/').slice(-1)[0].split('?')[0].slice(0, 40) : '', preHash8: (priorProbe && priorProbe.contentHash) ? String(priorProbe.contentHash).slice(0, 8) : '', postHash8: (probe && probe.contentHash) ? String(probe.contentHash).slice(0, 8) : '', frameLen: (probe && probe.len != null) ? Number(probe.len) : null, slideout: soProbe } } };
            }

            /* Re-prove the parent patient after the child frame opens. A tab or
               chart switch during the two clicks invalidates this encounter. */
            if (Date.now() >= readDeadline) return { failure: { reason: 'read-deadline-exceeded' } };
            var rowIds = await exec(emrId, [listFrame], ['identity', cfg]);
            var rowIdentity = bestResult(rowIds, function (r) { return (r && r.name ? 20 : 0) + (r && r.dob ? 15 : 0) + (r && r.mrn ? 10 : 0) + ((r && r.score) || 0); }).result || {};
            var rowGate = visitIdentityGate(frozenHint, rowIdentity);
            if (!rowGate.ok) return { failure: { reason: 'identity-changed-before-detail' } };

            /* Give the section its normal chance to render a rich clinical body
               first; only near the deadline may the PROVEN frame return its
               complete-but-brief section text flagged bodyMinimal. The frame
               proof above (URL-id binding or document/content delta after our
               bound click) is the same trust anchor rich bodies rely on, so a
               brief body under that proof is no weaker — it is simply a real
               visit with little documentation. Live 2026-07-14: some case-backed
               encounters bind by delta with a different frame-id namespace. */
            var detailDeadline = Math.min(readDeadline, Date.now() + rowWaitMs), frameDetail = {}, detailR;
            var completeFrameDetail = function (r) {
              if (!r || r.fullDetail !== true || r.frameContract !== true) return false;
              if (r.bodyMinimal !== true) return !!r.raw;
              var observed = Number(r.observedLen || String(r.raw || '').replace(/\s+/g, ' ').trim().length);
              var required = Math.max(1, Number(r.minAcceptedLen || 1));
              return r.sectionComplete === true && !!String(r.raw || '').trim() && observed >= required;
            };
            do {
              if (!(await sleepWithinReadDeadline(Math.max(80, Math.min(250, Number(cfg.detailPollMs || 180)))))) break;
              var minimalWindow = (Date.now() + 600) >= detailDeadline;
              var detailCfg = minimalWindow ? Object.assign({}, cfg, { allowMinimalBody: true }) : cfg;
              detailR = await exec(emrId, [detailFrame.frameId], ['detailFrame', detailCfg, i, expected]);
              frameDetail = bestResult(detailR, function (r) { return completeFrameDetail(r) ? String(r.raw || '').length : 0; }).result || {};
              if (completeFrameDetail(frameDetail)) break;
            } while (Date.now() < detailDeadline);
            return { detail: frameDetail };
          } finally {
            if (twoStageAthena && Date.now() < readDeadline) {
              try { await exec(emrId, [listFrame], ['closeDetailFrame', cfg]); } catch (eClose) {}
              try { await waitForDetailSurface(emrId, listFrame, false, Math.max(500, rowWaitMs), cfg.detailPollMs, readDeadline); } catch (eWaitClose) {}
            }
          }
        };
        var attempt = await runBoundAttempt(detailWaitMs);
        var retryReason = attempt && attempt.failure && String(attempt.failure.reason || '');
        var coldRetryable = /^(?:encounter-surface-not-open|encounter-frame-not-refreshed|accordion-not-open|slideout-trigger-missing|slideout-open-failed)$/.test(retryReason);
        /* 2026-07-15 live: one cold reopen was not enough for encounter-frame-not-refreshed on slow charts (one stale body failed the whole day batch). Allow a SECOND bounded reopen for the same retryable reasons while the read deadline permits. */
        var coldTries = 0;
        while (coldRetryable && coldTries < 2 && Date.now() + 1000 < readDeadline) {
          retryCount++; coldTries++;
          emit(appTabId, frozenRequestId, 'Finishing cold encounter ' + (i + 1) + ' of ' + total + '\u2026', i, total);
          await sleepWithinReadDeadline(coldRetryPauseMs);
          attempt = await runBoundAttempt(coldRetryWaitMs);
          retryReason = attempt && attempt.failure && String(attempt.failure.reason || '');
          coldRetryable = /^(?:encounter-surface-not-open|encounter-frame-not-refreshed|accordion-not-open|slideout-trigger-missing|slideout-open-failed)$/.test(retryReason);
        }
        if (attempt.failure) {
          failures.push({ index: i, reason: attempt.failure.reason || 'detail-read-failed', d2: attempt.failure.d2 || null });
          continue;
        }
        var d = attempt.detail || {};
        var bound = d.binding && Number(d.binding.index) === i && d.binding.rowKey === expected.rowKey && (!expected.encounterId || d.binding.encounterId === expected.encounterId);
        var visit = {
          date: snap.date || d.date || '', type: snap.type || d.type || '', raw: d.raw || '',
          cpt: d.cpt || [], icd10: d.icd10 || [], source: 'athena-copy',
          patientName: identity.name || '', patientDob: identity.dob || '', patientMrn: identity.mrn || identity.athenaId || '',
          indexOnly: false, fullDetail: d.fullDetail === true, encounterIndex: i,
          encounterId: expected.encounterId || '', sourceVisitKey: expected.rowKey,
          rowKey: expected.rowKey, bodyMinimal: d.bodyMinimal === true
        };
        /* A URL-bound frame's complete-but-brief section is this visit's honest
           full detail (bodyMinimal). It is counted transparently in the receipt
           and never substitutes for a rich body when one exists. */
        var minimalObservedLen = Number(d.observedLen || String(d.raw || '').replace(/\s+/g, ' ').trim().length);
        var minimalRequiredLen = Math.max(1, Number(d.minAcceptedLen || 1));
        var acceptedMinimal = d.bodyMinimal === true && visit.fullDetail === true && d.sectionComplete === true && !!String(d.raw || '').trim() && minimalObservedLen >= minimalRequiredLen;
        if (!bound || !(realVisit(visit, minLen) || acceptedMinimal)) {
          failures.push({ index: i, reason: d.reason || (!bound ? 'detail-binding-mismatch' : 'clinical-body-incomplete'), d2: d.d2 || null });
          continue;
        }
        if (acceptedMinimal) minimalBodies++;
        visits.push(visit);
        emit(appTabId, frozenRequestId, 'Read full encounter ' + (i + 1) + ' of ' + total + '…', i + 1, total);
      }

      /* Refuse a batch if the chart changed while encounter rows were open. */
      var finalIdentity = {}, finalGate = { ok: false, reason: 'read-deadline-exceeded' };
      if (Date.now() < readDeadline) {
        var finalIds = await exec(emrId, [listFrame], ['identity', cfg]);
        finalIdentity = bestResult(finalIds, function (r) { return (r && r.name ? 20 : 0) + (r && r.dob ? 15 : 0) + (r && r.mrn ? 10 : 0) + ((r && r.score) || 0); }).result || {};
        if (Date.now() >= readDeadline) {
          finalGate = { ok: false, reason: 'read-deadline-exceeded' };
          if (!failures.some(function (failure) { return failure && failure.reason === 'read-deadline-exceeded'; })) failures.push({ index: -1, reason: 'read-deadline-exceeded' });
        } else {
          finalGate = visitIdentityGate(frozenHint, finalIdentity);
          if (!finalGate.ok) failures.push({ index: -1, reason: 'identity-changed-during-read' });
          else identity = finalIdentity;
        }
      } else if (!failures.some(function (failure) { return failure && failure.reason === 'read-deadline-exceeded'; })) {
        failures.push({ index: -1, reason: 'read-deadline-exceeded' });
      }

      var clinicalTotal = Math.max(0, total - administrativeRows.length);
      var sourceKeys = {}, stableKeysComplete = visits.length === clinicalTotal;
      for (var sk = 0; sk < visits.length; sk++) {
        var sourceKey = String(visits[sk] && visits[sk].sourceVisitKey || '');
        if (!sourceKey || sourceKeys[sourceKey]) stableKeysComplete = false;
        sourceKeys[sourceKey] = 1;
      }
      if (!stableKeysComplete) failures.push({ index: -1, reason: 'stable-source-keys-incomplete' });
      var bodyComplete = failures.length === 0 && visits.length === clinicalTotal && stableKeysComplete;
      var receipt = {
        complete: bodyComplete, indexComplete: true, bodyComplete: bodyComplete,
        fullDetail: bodyComplete, expected: clinicalTotal, parsed: visits.length, administrativeRows: administrativeRows.length, indexTotal: total,
        attempted: attemptedCount, failures: failures.length, cap: cfg.maxVisits, retryCount: retryCount,
        timeBudgetMs: readBudgetMs, elapsedMs: Math.max(0, Date.now() - readStartedAt), coldRetryReserveMs: coldRetryReserveMs,
        identityVerified: gate.ok && finalGate.ok, stableKeysComplete: stableKeysComplete, minimalBodies: minimalBodies,
        authoritativeEmpty: total === 0 && authoritativeEmptyIndex
      };
      if (!bodyComplete) {
        return {
          ok: false, reason: 'visit-bodies-incomplete', identity: identity, visits: [], diag: diag,
          strategy: 'bound-click', found: total, receipt: receipt, failedIndexes: failures,
          error: 'Athena exposed ' + total + ' encounters, but only ' + visits.length + ' had full clinical detail bound to the exact encounter row. Nothing was reported as complete or saved.'
        };
      }
      emit(appTabId, frozenRequestId, 'Read all ' + visits.length + ' full encounter(s).', visits.length, total);
      return { ok: true, identity: identity, visits: visits, diag: diag, strategy: 'bound-click', found: total, receipt: receipt };
    }).catch(function (e) {
      return { ok: false, identity: identity, visits: [], diag: diag, receipt: { complete: false, indexComplete: !!enumRes, bodyComplete: false, fullDetail: false }, error: String((e && e.message) || e) };
    }).then(function (res) {
      res = res || {};
      res.readerVersion = '2.9.22-visits-r4-two-stage';
      if (!res.receipt || typeof res.receipt !== 'object') res.receipt = {};
      var proven = res.ok === true && res.receipt.indexComplete === true && res.receipt.bodyComplete === true && Number(res.receipt.parsed) === Number(res.receipt.expected) && (Number(res.receipt.expected) > 0 || res.receipt.authoritativeEmpty === true || Number(res.receipt.administrativeRows || 0) > 0);
      res.receipt.complete = proven;
      res.receipt.fullDetail = proven;
      res.receipt.readerVersion = res.readerVersion;
      if (frozenRequestId) res.requestId = frozenRequestId;
      if (enumRes) {
        res.selected = { selector: enumRes.selector || '', count: enumRes.count || 0,
          uniqueDates: enumRes.uniqueDates || 0, strongRows: enumRes.strongRows || 0 };
      }
      return res;
    });
    readPromise.__mlsAfterResponseCleanup = function () {
      try {
        var lease = self.__mlsVerifiedReadTarget || null;
        var lk = function (s) { return String(s || '').toLowerCase().replace(/[^a-z0-9]/g, ''); };
        if (lease && lk(lease.name) === lk(frozenHint.name)) self.__mlsVerifiedReadTarget = null;
      } catch (eLeaseClear) {}
      try { __visitGuardByHint.delete(frozenHint); } catch (eGuardHintClear) {}
      try { if (__visitGuardByTab.get(readTabId) === readGuard) __visitGuardByTab.delete(readTabId); } catch (eGuardTabClear) {}
      if (qpOwnedByThisRead) fireVisitCleanup('all-visits-after-response');
    };
    return readPromise;
  }

  var activeAllVisitsPromise = null;
  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || msg.type !== 'mlsAppAllVisitsRequest') return; // not ours; let other listeners handle
    var appTabId = sender && sender.tab && sender.tab.id;
    var transportRequestId = String(msg.requestId || '').slice(0, 100);
    if (activeAllVisitsPromise) {
      sendResponse({
        ok: false, reason: 'busy', requestId: transportRequestId, readerVersion: '2.9.22-visits-r4-two-stage', visits: [],
        receipt: { complete: false, indexComplete: false, bodyComplete: false, fullDetail: false },
        error: 'A verified history read is already running. Wait for it to finish, then retry.'
      });
      return true;
    }
    var startup = { pending: true, requestId: transportRequestId };
    activeAllVisitsPromise = startup;
    try {
      loadVisitsCfgBound(1500).then(function (cfg) {
        if (activeAllVisitsPromise !== startup) return;
        /* A prior response is never delayed by quiet-work restoration, but this
           next read must not race that deferred qpRelease. Wait briefly for the
           registered cleanup queue; if it remains pending, fail closed without
           selecting, moving, or reading an Athena tab. */
        waitForVisitCleanup(msg.deadlineAt).then(function (cleanupReady) {
          if (activeAllVisitsPromise !== startup) return;
          if (!cleanupReady || cleanupReady.ok !== true) {
            activeAllVisitsPromise = null;
            sendResponse({
              ok: false, reason: 'read-deadline-exceeded', requestId: transportRequestId,
              readerVersion: '2.9.22-visits-r4-two-stage', visits: [], retryable: true,
              receipt: { complete: false, indexComplete: false, bodyComplete: false, fullDetail: false },
              error: 'The prior read is still restoring the quiet Athena work tab. Retry this history read; no new Athena action was started.'
            });
            return;
          }
          var thisRead = runAllVisits(appTabId, msg.hint || {}, cfg, transportRequestId, msg.deadlineAt);
          activeAllVisitsPromise = thisRead;
          function finish(value) {
            /* Clear single-flight ownership before responding. Cleanup is
               registered immediately after sendResponse returns and is never
               awaited by this completed read. */
            if (activeAllVisitsPromise === thisRead) activeAllVisitsPromise = null;
            sendResponse(value);
            try { if (thisRead.__mlsAfterResponseCleanup) thisRead.__mlsAfterResponseCleanup(); } catch (eCleanup) {}
          }
          thisRead.then(finish, function (e) { finish({ ok: false, requestId: transportRequestId, error: String((e && e.message) || e) }); });
        });
      }, function (eLoad) {
        if (activeAllVisitsPromise === startup) activeAllVisitsPromise = null;
        sendResponse({ ok: false, requestId: transportRequestId, error: String((eLoad && eLoad.message) || eLoad) });
      });
    } catch (e) { activeAllVisitsPromise = null; sendResponse({ ok: false, requestId: transportRequestId, error: String((e && e.message) || e) }); }
    return true; // async response
  });

  // --- v1.40: publish the PROVEN read-all-visits engine so the Seamless overlay
  //     router can reuse it directly (the overlay was previously bound to a
  //     never-implemented name and so could never read the chart). Same cfg load,
  //     same engine, same honest failures - additive, no behavior change here. ---
  try {
    self.__mlsOverlayReadVisits = function (appTabId, hint) {
      return loadVisitsCfgBound(1500).then(function (cfg) {
        var read = runAllVisits(appTabId != null ? appTabId : null, hint || {}, cfg);
        return read.then(function (result) {
          try { if (read.__mlsAfterResponseCleanup) read.__mlsAfterResponseCleanup(); } catch (eCleanup) {}
          return result;
        }, function (e) {
          try { if (read.__mlsAfterResponseCleanup) read.__mlsAfterResponseCleanup(); } catch (eCleanup) {}
          return { ok: false, error: String((e && e.message) || e) };
        });
      });
    };
  } catch (e) {}
})();


/* === MLS Assist v1.36 — panel pull-to-app + read-only search-and-navigate driver (APPEND-ONLY to background.js) ===
 * One additional chrome.runtime.onMessage listener (Chrome supports multiple).
 * It returns true ONLY for its own message types and otherwise returns nothing,
 * so existing listeners are unaffected. NEVER clicks Save/Sign/finalize on a
 * chart (read-only navigation: typing in the search bar + opening a chart only).
 *
 *  - mlsAssistPullToApp: the panel "Pull from chart" button asks us to run the
 *    proven in-app Athena pull. We focus the MLS (mlsscribe.com) tab and trigger
 *    its real "Pull from Athena" flow (frame-aware v1.34 reader) so the open
 *    chart's patient + all visits land in MLS with the app's status/verify.
 *
 *  - mlsAppSearchOpenRequest: drive athenaOne's PATIENT SEARCH bar — type the
 *    "Last, First" name, run the search, find the matching result, open the
 *    chart. Content-scored selectors with fallbacks (robust without a live tune),
 *    plus a PHI-safe redacted structural diag for one-time tuning. */
(function () {
  'use strict';
  try { if (self.__mlsV136Wired) return; self.__mlsV136Wired = 1; } catch (e) {}

  // local EMR-tab picker (does not rely on the existing mlsPickEmrTab being in scope)
  /* v1.65: score athena candidates like the (working) chart-read/go-home pickers.
     The old "active-or-first" pick chose a SECOND athenahealth tab (a www portal/
     login page full of demdex trackers, zero schedule rows) while go-home/read drove
     the real athenanet tab - live-proven cause of the v1.64 'open-failed'. */
  function mlsScoreAthTab(t) {
    var u = (t.url || '').toLowerCase(); var s = 0;
    if (/athenanet\.athenahealth\.com/.test(u)) s += 100;
    if (/globalframeset|\/ax\/|dashboard|schedul|calendar|frontoffice/.test(u)) s += 40;
    if (/aws\.caas|\/login|sign-?in|\/auth|\/oauth|accounts\.|\bwww\.athenahealth\.com\b|landing|portal|marketing/.test(u)) s -= 200;
    if (t.active) s += 5;
    return s;
  }
  function pickEmrTab(all) {
    try {
      var http = all.filter(function (t) { return /^https?:\/\//.test(t.url || ''); });
      var known = http.filter(function (t) { return /athenahealth\.com|athenanet/i.test(t.url || ''); });
      if (known.length) { known.sort(function (a, b) { return (mlsScoreAthTab(b) - mlsScoreAthTab(a)) || ((b.lastAccessed || 0) - (a.lastAccessed || 0)); }); return known[0]; }
      var emrish = http.filter(function (t) { return /emr|ehr|chart|clinical|epic|cerner|practice/i.test((t.url || '') + ' ' + (t.title || '')); });
      if (emrish.length) return emrish[0];
      var nonMls = http.filter(function (t) { return !/mlsscribe\.com|github\.com|google\.com\/search/i.test(t.url || ''); });
      return nonMls.sort(function (a, b) { return (b.lastAccessed || 0) - (a.lastAccessed || 0); })[0] || null;
    } catch (e) { return null; }
  }

  function findAppTab(all) {
    return all.find(function (t) { return /^https?:\/\/(www\.)?mlsscribe\.com\//.test(t.url || ''); }) || null;
  }

  // --- the page-side driver (self-contained; serialized to the tab) ---
  async function mlsSearchOpenDriverFn(name, phase, requestGuard, appointmentId, requireAppointmentId) {
    try {
      var __openGuard = Object.freeze({ deadline: Number(requestGuard && requestGuard.deadline || 0), token: String(requestGuard && requestGuard.token || '') });
      function openAllowed() { return !!__openGuard.token && Number.isFinite(__openGuard.deadline) && Date.now() < __openGuard.deadline; }
      function deadlineOut() { return { phase: phase, opened: false, filled: false, candidates: 0, reason: 'open-deadline-exceeded', requestToken: __openGuard.token || '' }; }
      if (!openAllowed()) return deadlineOut();
      /* v1.84: never scan/type on the findpatient RESULTS page - its rows are
         javascript: links this (isolated) world cannot navigate; clicking them
         reports a phantom "open" while nothing happens. The findpatient route
         owns that page. Other frames of the tab scan normally. */
      try { if (/findpatient\.esp/i.test(String(location.pathname || ''))) return { phase: phase, opened: false, filled: false, candidates: 0, diag: { frame: 'findpatient-excluded', topScore: -1 } }; } catch (e0) {}
      function vis(el) { try { var r = el.getBoundingClientRect(); var s = getComputedStyle(el); return r.width > 1 && r.height > 1 && s.visibility !== 'hidden' && s.display !== 'none'; } catch (e) { return false; } }
      /* v1.90 (same normalization as the findpatient route): strip "(Bob)" nicknames
         for the SEARCH string only; drop generational suffixes after a comma
         (", Jr" is a suffix, not a first name). Apostrophes/hyphens kept. */
      var SUFX = /^(jr|sr|ii|iii|iv|v|esq|junior|senior)\.?$/i;
      var cleanN = String(name || '').replace(/\([^)]*\)/g, ' ').replace(/\s+/g, ' ').trim();
      var parts = cleanN.split(',').map(function (s) { return s.trim(); }).filter(Boolean);
      while (parts.length > 1 && SUFX.test(parts[parts.length - 1])) parts.pop();
      var lname = (parts[0] || '').toLowerCase();
      var fname = parts.slice(1).join(' ').trim().toLowerCase();
      /* v1.62: callers pass either "Last, First" OR "First Last" (the app's day-pull
         passes the display name "Ruth Gehrman"). Normalize BOTH so row-matching uses
         real first/last tokens, and athenaOne's search gets its expected
         "lastname,firstname" (no space) form. */
      if (parts.length < 2) {
        var toks = (parts[0] || '').split(/\s+/).filter(Boolean);
        while (toks.length > 1 && SUFX.test(toks[toks.length - 1])) toks.pop();
        if (toks.length >= 2) { lname = toks[toks.length - 1].toLowerCase(); fname = toks[0].toLowerCase(); }
      }
      var searchStr = (lname && fname) ? (lname + ',' + fname) : String(name || '').trim();
      if (phase === 'fill') {
        var inputs = [].slice.call(document.querySelectorAll('input,textarea')).filter(vis);
        function scoreInput(i) {
          var s = 0;
          var hay = ((i.placeholder || '') + ' ' + (i.name || '') + ' ' + (i.id || '') + ' ' + (i.getAttribute('aria-label') || '') + ' ' + (i.title || '')).toLowerCase();
          if (/search/.test(hay)) s += 3;
          if (/patient|name|find|lookup|client|mrn|chart|quicksearch|global/.test(hay)) s += 3;
          var ty = (i.type || '').toLowerCase();
          if (ty === 'search') s += 3; if (ty === '' || ty === 'text') s += 1;
          if (ty === 'hidden' || ty === 'password' || ty === 'checkbox' || ty === 'radio') s -= 10;
          var r = i.getBoundingClientRect(); if (r.top < 170) s += 1; // global search usually top
          return s;
        }
        inputs.sort(function (a, b) { return scoreInput(b) - scoreInput(a); });
        var best = inputs[0];
        var diag = { frame: location.hostname, inputCount: inputs.length, topScore: best ? scoreInput(best) : -1 };
        if (!best || scoreInput(best) < 3) return { phase: 'fill', filled: false, diag: diag };
        try {
          var proto = window.HTMLInputElement && window.HTMLInputElement.prototype;
          var setter = proto && Object.getOwnPropertyDescriptor(proto, 'value');
          if (!openAllowed()) return deadlineOut();
          best.focus();
          /* v1.62: athenaOne's global search expects "lastname,firstname" (no space). */
          if (!openAllowed()) return deadlineOut();
          if (setter && setter.set) setter.set.call(best, searchStr); else best.value = searchStr;
          if (!openAllowed()) return deadlineOut();
          best.dispatchEvent(new Event('input', { bubbles: true }));
          best.dispatchEvent(new Event('change', { bubbles: true }));
          ['keydown', 'keypress', 'keyup'].forEach(function (t) {
            if (!openAllowed()) return;
            try { best.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true })); } catch (e) {}
          });
          var form = best.closest && best.closest('form');
          if (form) {
            var sb = [].slice.call(form.querySelectorAll('button,[role=button],input[type=submit]')).filter(vis).find(function (b) {
              return /search|find|go|lookup/i.test((b.textContent || '') + ' ' + (b.getAttribute('aria-label') || '') + ' ' + (b.value || ''));
            });
            if (sb && openAllowed()) try { sb.click(); } catch (e) {}
          }
        } catch (e) { return { phase: 'fill', filled: false, diag: diag, error: String((e && e.message) || e) }; }
        diag.inputSig = { tag: best.tagName, type: (best.type || ''), hasPlaceholder: !!best.placeholder };
        return { phase: 'fill', filled: true, diag: diag };
      }
      if (phase === 'open') {
        var BAD = /save|sign|finalize|post|bill|submit|delete|lock|addend|amend|close encounter|check ?out|log ?out|sign ?off|cancel/i;
        function rowText(el) { return (el.textContent || '').replace(/\s+/g, ' ').trim(); }
        function scoreRow(tx, el) {
          if (!tx || tx.length > 220) return -1;
          /* v1.64: BAD-test only a CONTROL's own short label. A schedule ROW's status
             text ("Check-out", "Cancelled") must not disqualify the row - live 2026-07-09:
             42 of 52 afternoon rows carried "Check-out" and the blanket BAD test made
             EVERY open fail (the whole 0-of-N pull). Click-target choice in clickRow is
             BAD-filtered too, so a dangerous control still can't be clicked. */
          var isCtl = false;
          try { var tg0 = (el.tagName || '').toUpperCase(); isCtl = (tg0 === 'A' || tg0 === 'BUTTON' || (el.getAttribute && el.getAttribute('role') === 'button')); } catch (e0) {}
          if (isCtl && tx.length < 34 && BAD.test(tx)) return -1;
          var s = 0;
          if (lname && tx.indexOf(lname) !== -1) s += 4;
          if (fname && tx.indexOf(fname) !== -1) s += 3;
          if (lname && fname) { try { if (new RegExp(lname.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*,\\s*' + fname.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).test(tx)) s += 3; } catch (e) {} }
          if (el.tagName === 'A' || el.getAttribute('role') === 'option' || el.getAttribute('role') === 'link') s += 1;
          return s;
        }
        // v1.61: include athenaOne's appointment-container buttons (the reader's
        // proven schedule-row selector) so we match the real schedule rows.
        // v1.62: + the global-search SUGGESTION dropdown items (live-observed: typing
        // "gehrman,ruth" opens a suggestion list; clicking its item opens the chart).
        var SEL = 'a,[role=option],[role=row],tr,li,[role=link],div[role=button],[class*="PatientAppointment_appointment-container"],[role=listbox] *,[class*="suggest"],[class*="typeahead"],[class*="autocomplete"]';
        function scanOnce() {
          var nodes = [].slice.call(document.querySelectorAll(SEL)).filter(vis);
          /* v1.66: when BOTH names are known, require BOTH to match (score >= 7) - a
             last-name-only hit (+4) could be the PROVIDER's label ("Schaeffer" x17 on
             the live dashboard) and clicking it navigates nowhere useful. */
          var best = null, bestSc = (lname && fname) ? 6 : 3;
          for (var i = 0; i < nodes.length; i++) { var tx = rowText(nodes[i]).toLowerCase(); var sc = scoreRow(tx, nodes[i]); if (sc > bestSc) { bestSc = sc; best = nodes[i]; } }
          return { el: best, sc: bestSc, scanned: nodes.length };
        }
        // v1.62: athenaOne v26.3 renders schedule rows as plain <div>s wired to React
        // synthetic events - a bare el.click() does NOTHING on them (live-proven: the
        // opener "clicked" and athena never navigated). Dispatch the real pointer/mouse
        // sequence, exactly like the verified mlsEnsureClinicalChartFn nav does.
        function realClick(el) {
          if (!openAllowed()) return false;
          try { el.scrollIntoView({ block: 'center' }); } catch (e1) {}
          if (!openAllowed()) return false;
          try {
            var r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
            var o = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y };
            ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach(function (tp) {
              if (!openAllowed()) return;
              try { el.dispatchEvent(new (tp.indexOf('pointer') === 0 ? PointerEvent : MouseEvent)(tp, o)); } catch (e2) {}
            });
          } catch (e3) {}
          if (!openAllowed()) return false;
          try { el.click(); } catch (e4) { return false; }
          return true;
        }
        function clickRow(row) {
          var clickT = null;
          // v1.53: prefer the child link whose text matches the patient NAME (not the
          // row's first <a>, which on a schedule row is often a time/status link).
          try {
            /* v1.64: never pick a click target whose own label is a dangerous control
               ("Check-out" button inside the row). */
            var cand = [].slice.call(row.querySelectorAll('a,[role=link],[role=button],[onclick]')).filter(vis).filter(function (a) { var tb = rowText(a); return !(tb.length < 34 && BAD.test(tb)); });
            clickT = cand.filter(function (a) { var t = rowText(a).toLowerCase(); return (lname && t.indexOf(lname) !== -1) || (fname && t.indexOf(fname) !== -1); })[0] || cand[0];
          } catch (e0) {}
          if (!clickT) {
            /* v1.64: the live dashboard row's name cell is a plain DIV.name (no a/role) -
               pick the SMALLEST visible descendant carrying the patient's name (the
               live-proven click target), BAD-filtered. */
            try {
              var els6 = [].slice.call(row.querySelectorAll('*')).filter(vis);
              var bestN = null, bl6 = 1e9;
              for (var ei6 = 0; ei6 < els6.length; ei6++) {
                var t6 = rowText(els6[ei6]).toLowerCase();
                if (t6 && t6.length < 70 && !BAD.test(t6) && ((lname && t6.indexOf(lname) !== -1) || (fname && t6.indexOf(fname) !== -1)) && t6.length < bl6) { bestN = els6[ei6]; bl6 = t6.length; }
              }
              if (bestN) clickT = bestN;
            } catch (e6) {}
          }
          if (!clickT) clickT = (row.querySelector && row.querySelector('a')) || row;
          if (!realClick(clickT)) return false;
          // v1.62: if the chosen target was a non-navigating wrapper, also drive the row.
          if (clickT !== row && openAllowed()) { try { realClick(row); } catch (e5) {} }
          return true;
        }
        /* v2.9.25: exact appointment-id row binding for day-grid variants that
           render NO demographics (live 2026-07-15: 17/17 rows carried only
           name/time/reason plus a data appointment id). The id selects the ONE
           exact row; the row must still contain the expected LAST NAME, and the
           follow-up chart read's banner identity remains the proof gate. In
           bootstrap mode a missing id row NEVER falls back to a name scan. */
        function apptIdRow() {
          var wantId = String(appointmentId || '').trim();
          if (!wantId || !/^[A-Za-z0-9_-]{2,40}$/.test(wantId)) return null;
          var holders = [];
          try { holders = [].slice.call(document.querySelectorAll('[data-appointment-id="' + wantId + '"],[data-appt-id="' + wantId + '"],[data-appointmentid="' + wantId + '"],[appointmentid="' + wantId + '"]')); } catch (eIdSel) {}
          if (!holders.length) {
            try {
              var escId = wantId.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
              var idRe = new RegExp('[?&#/](?:appointmentid|appointment_id|appointment|apptid)[=/:]' + escId + '(?![A-Za-z0-9])', 'i');
              holders = [].slice.call(document.querySelectorAll('a[href*="appointment"]')).filter(function (a) { return idRe.test(String(a.getAttribute('href') || '')); });
            } catch (eIdHref) {}
          }
          var matchedRows = [];
          for (var hi = 0; hi < holders.length && hi < 24; hi++) {
            var row = holders[hi];
            var matchedRow = null;
            for (var up = 0; up < 5 && row; up++) {
              if (vis(row)) {
                var t = rowText(row).toLowerCase();
                if (t && t.length < 700 && lname && t.indexOf(lname) !== -1 && (!fname || t.indexOf(fname) !== -1)) { matchedRow = row; break; }
              }
              row = row.parentElement;
            }
            if (!matchedRow) continue;
            var sameRow = matchedRows.some(function (existing) {
              try { return existing === matchedRow || existing.contains(matchedRow) || matchedRow.contains(existing); } catch (eSame) { return existing === matchedRow; }
            });
            if (!sameRow) matchedRows.push(matchedRow);
          }
          if (matchedRows.length > 1) return { el: null, sc: 99, scanned: holders.length, viaApptId: true, ambiguous: true, matches: matchedRows.length };
          return matchedRows.length === 1 ? { el: matchedRows[0], sc: 99, scanned: holders.length, viaApptId: true, matches: 1 } : null;
        }
        // fast path: exact id only in bootstrap mode; ordinary opens retain the
        // proven name scan as a compatibility fallback.
        var hit = apptIdRow() || (requireAppointmentId === true ? { el: null, sc: 0, scanned: 0 } : scanOnce());
        if (hit.ambiguous) return { phase: 'open', opened: false, candidates: hit.matches || 2, reason: 'appointment-id-ambiguous', diag: { frame: location.hostname, scanned: hit.scanned, topScore: hit.sc, apptIdBound: false, apptIdMatches: hit.matches || 2 } };
        if (hit.el) { if (!clickRow(hit.el)) return deadlineOut(); return { phase: 'open', opened: true, via: hit.viaApptId ? 'appt-id' : 'quick', candidates: 1, diag: { frame: location.hostname, scanned: hit.scanned, topScore: hit.sc, apptIdBound: hit.viaApptId === true, apptIdMatches: hit.matches || 1 } }; }
        // v1.61: SCROLL the virtualized schedule + re-scan. athenaOne renders only the
        // rows in the viewport, so a below-the-fold patient (e.g. Ruth Gehrman) was never
        // found by the old single-scan opener - "open-failed". The reader already scrolls
        // to capture all 52 appts; the opener now mirrors that. Bounded + scoped selectors
        // (no full-DOM innerText walk), so it does not free-scan / freeze athena.
        // v1.62 perf: the v1.61 version called getComputedStyle on EVERY div (thousands
        // on athenaOne) - slow enough to stall the frame's injection. Pre-filter cheaply
        // on scrollHeight/clientHeight (layout-only) and cap the candidate set.
        function findScrollers() {
          var out = [];
          var cands = [].slice.call(document.querySelectorAll('[class*="ScheduleColumn_schedule-column"],[class*="schedule"],[class*="calendar"],main,section')).slice(0, 400);
          for (var i = 0; i < cands.length && out.length < 3; i++) {
            var el = cands[i];
            try {
              if (!(el.scrollHeight > el.clientHeight + 60 && el.clientHeight > 150)) continue;
              var cs = getComputedStyle(el);
              if (/(auto|scroll)/.test(cs.overflowY)) out.push(el);
            } catch (e) {}
          }
          try { var se = document.scrollingElement; if (se && se.scrollHeight > (window.innerHeight + 60) && out.indexOf(se) < 0) out.push(se); } catch (e) {}
          return out;
        }
        var scrollers = findScrollers();
        var scannedTotal = hit.scanned;
        for (var si = 0; si < scrollers.length; si++) {
          var sc0 = scrollers[si], orig = 0; try { orig = sc0.scrollTop; } catch (e) {}
          var step = Math.max(220, Math.round((sc0.clientHeight || 400) * 0.8));
          var maxH = 0; try { maxH = sc0.scrollHeight; } catch (e) {}
          for (var y = 0; y <= maxH && y < 40000; y += step) {
            if (!openAllowed()) return deadlineOut();
            try { sc0.scrollTop = y; sc0.dispatchEvent(new Event('scroll', { bubbles: true })); } catch (e) {}
            await new Promise(function (r) { setTimeout(r, 320); });
            var h2 = requireAppointmentId === true ? (apptIdRow() || { el: null, sc: 0, scanned: 0 }) : scanOnce(); if (h2.scanned > scannedTotal) scannedTotal = h2.scanned;
            if (h2.ambiguous) return { phase: 'open', opened: false, candidates: h2.matches || 2, reason: 'appointment-id-ambiguous', diag: { frame: location.hostname, scanned: scannedTotal, scrolledTo: y, topScore: h2.sc, apptIdBound: false, apptIdMatches: h2.matches || 2 } };
            if (h2.el) { if (!clickRow(h2.el)) return deadlineOut(); return { phase: 'open', opened: true, via: h2.viaApptId ? 'appt-id-scroll' : 'scroll', candidates: 1, diag: { frame: location.hostname, scanned: scannedTotal, scrolledTo: y, topScore: h2.sc, apptIdBound: h2.viaApptId === true, apptIdMatches: h2.matches || 1 } }; }
          }
          if (openAllowed()) try { sc0.scrollTop = orig; } catch (e) {}
        }
        /* v1.62: report a real topScore so bestFrameResult surfaces the SCHEDULE frame's
           diag instead of the empty top frame's (v1.61 dropped it and masked the truth). */
        return { phase: 'open', opened: false, candidates: 0, reason: requireAppointmentId === true ? 'appointment-id-not-found' : 'name-not-found', diag: { frame: location.hostname, scanned: scannedTotal, scrollers: scrollers.length, topScore: scannedTotal > 0 ? 0 : -1, apptIdBound: false } };
      }
      return { phase: phase, error: 'unknown phase' };
    } catch (e) { return { phase: phase, error: String((e && e.message) || e) }; }
  }

  /* The exact appointment click is only a candidate until Athena proves a
     TRUE before/after navigation delta on the same frozen tab. Comparing one
     clicked frame with every post-click frame let an unchanged cached target
     iframe falsely prove a no-op click; truncating its URL could do the same.
     This worker-side verifier compares complete URLs by frameId and accepts
     only a newly-created or changed frame whose post-click URL carries the
     exact appointment id. */
  function mlsAppointmentNavigationDelta(appointmentId, beforeFrames, afterFrames) {
    try {
      var want = String(appointmentId || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 40);
      if (!want) return { matched: false, changedFrameIds: [] };
      var esc = want.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      var re = new RegExp('(?:appointment|appointmentid|appointment_id|apptid)(?:\\/|=|:)' + esc + '(?![A-Za-z0-9_-])', 'i');
      var beforeById = new Map();
      (beforeFrames || []).forEach(function (frame) { if (frame && typeof frame.frameId === 'number') beforeById.set(frame.frameId, String(frame.url || '')); });
      var changed = [];
      (afterFrames || []).forEach(function (frame) {
        if (!frame || typeof frame.frameId !== 'number') return;
        var url = String(frame.url || ''), existed = beforeById.has(frame.frameId), prior = existed ? beforeById.get(frame.frameId) : '';
        if ((!existed || prior !== url) && re.test(url)) changed.push(frame.frameId);
      });
      changed = Array.from(new Set(changed));
      return { matched: changed.length > 0, changedFrameIds: changed };
    } catch (e) { return { matched: false, changedFrameIds: [] }; }
  }

  function bestFrameResult(results, key) {
    // results: array of {result} from executeScript allFrames. Pick the frame
    // whose driver reports success / highest score.
    var rs = (results || []).map(function (r) {
      var x = r && r.result;
      if (x && typeof r.frameId === 'number') try { x.__frameId = r.frameId; } catch (e) {}
      return x;
    }).filter(Boolean);
    var hit = rs.filter(function (r) { return r && (r.filled || r.opened); });
    if (hit.length) {
      hit.sort(function (a, b) { return ((b.diag && b.diag.topScore) || 0) - ((a.diag && a.diag.topScore) || 0); });
      return hit[0];
    }
    // none succeeded — return the richest diag for tuning
    rs.sort(function (a, b) { return ((b.diag && b.diag.topScore) || -2) - ((a.diag && a.diag.topScore) || -2); });
    return rs[0] || null;
  }

  function progress(tabId, message, requestId) { try { chrome.tabs.sendMessage(tabId, { type: 'mlsAppSearchOpenProgress', message: message, requestId: String(requestId || '').slice(0, 100) }); } catch (e) {} }

  /* --- v1.78: "Find a Patient" opener (injected into the TOP frame; drives the
     content frame). The displayed schedule proved to be an UNRELIABLE open
     surface: it renders one department's rows only (live 07-10: the dashboard
     showed a single FROZEN slot for the selected department while the doctor's
     20 real patients were booked under another one -> 17/17 'open-failed').
     athenaOne's classic client/findpatient.esp page is fully programmatic -
     proven live: set input value + input/change, click Find, click the result
     row's Chart link. Read-only: searches and OPENS a chart; never touches
     Save/Sign/orders. Runs from the TOP frame (which never navigates) so the
     driver survives the content frame's two navigations. The result row shows
     name + DOB, so the match is verified BEFORE the chart is opened. */
  async function mlsFindPatientOpenDriverFn(name, dob, requestGuard, mrn) {
    try {
      /* The action guard and the MRN are deliberately separate arguments.
         SearchOpen must preserve BOTH: the guard prevents a late injection from
         navigating Athena, while the MRN narrows duplicate-name candidates only
         after the existing name tier and DOB veto. Keeping them separate also
         prevents a serialized guard object from silently replacing the MRN. */
      var __guardArg = (requestGuard && typeof requestGuard === 'object') ? requestGuard : {};
      var __openGuard = Object.freeze({ deadline: Number(__guardArg.deadline || 0), token: String(__guardArg.token || '') });
      function openAllowed() { return !!__openGuard.token && Number.isFinite(__openGuard.deadline) && Date.now() < __openGuard.deadline; }
      function deadlineOut() { return { opened: false, reason: 'open-deadline-exceeded', requestToken: __openGuard.token || '' }; }
      function sleep(ms) { var left = Math.max(0, __openGuard.deadline - Date.now()); return new Promise(function (r) { setTimeout(r, Math.min(left, Math.max(0, Number(ms || 0)))); }); }
      if (!openAllowed()) return deadlineOut();
      /* v1.90 name-shape fix: strip "(Bob)" nicknames for the SEARCH string only;
         drop generational suffixes after a comma (", Jr" is a suffix, not a first
         name - live shape "Tom E Hatton, Jr" searched as "Tom E Hatton,Jr" -> 0
         results). Apostrophes/hyphens are athena's own spelling - kept. */
      var SUFX = /^(jr|sr|ii|iii|iv|v|esq|junior|senior)\.?$/i;
      var cleanN = String(name || '').replace(/\([^)]*\)/g, ' ').replace(/\s+/g, ' ').trim();
      var parts = cleanN.split(',').map(function (s) { return s.trim(); }).filter(Boolean);
      while (parts.length > 1 && SUFX.test(parts[parts.length - 1])) parts.pop();
      var lname = parts[0] || '', fname = parts.slice(1).join(' ').trim();
      if (parts.length < 2) {
        var toks = lname.split(/\s+/).filter(Boolean);
        while (toks.length > 1 && SUFX.test(toks[toks.length - 1])) toks.pop();
        if (toks.length >= 2) { lname = toks[toks.length - 1]; fname = toks.slice(0, -1).join(' '); }
      }
      if (!lname) return { opened: false, reason: 'no-name' };
      var fq = (fname.split(/\s+/)[0] || '');
      var searchStr = fq ? (lname + ',' + fq) : lname;
      function nrmDob(s) { var m = /([01]?\d)[\/\-\.]([0-3]?\d)[\/\-\.](\d{2,4})/.exec(String(s || '')); if (!m) return ''; var y = m[3].length === 2 ? ((Number(m[3]) > 26 ? '19' : '20') + m[3]) : m[3]; return Number(m[1]) + '/' + Number(m[2]) + '/' + y; }
      function nrmMrn(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9]/g, ''); }
      function mrnCellMatches(value, wanted) {
        var raw = String(value || ''), labeled = null;
        if (!wanted) return false;
        try { labeled = /(?:\bmrn\b|medical\s+record(?:\s+(?:number|id))?|patient\s+(?:id|number|#))\s*[:#-]?\s*([a-z0-9][a-z0-9._-]*)/i.exec(raw); } catch (e0) {}
        if (labeled && nrmMrn(labeled[1]) === wanted) return true;
        /* An unlabeled Athena result cell commonly contains only the MRN. Match
           the complete token, never a substring; short numbers and date cells
           are excluded so a year/age cannot masquerade as an MRN. */
        if (wanted.length < 5 || /[01]?\d[\/\-.][0-3]?\d[\/\-.]\d{2,4}/.test(raw)) return false;
        var tokens = raw.match(/[a-z0-9][a-z0-9._-]*/ig) || [];
        for (var ti = 0; ti < tokens.length; ti++) if (nrmMrn(tokens[ti]) === wanted) return true;
        return false;
      }
      var wantDob = nrmDob(dob);
      var wantMrn = nrmMrn(mrn);
      /* locate the main content frame: deepest big same-origin frame, skipping
         nav/status/messaging frames (prefers the proven /f1/f2/f2 slot). */
      var SKIP = /globalnav|statusbar|stm\.esp|schedulenavclose|coordinator\/enterprise|blank\.html/i;
      var best = null;
      (function walk(w, depth) {
        if (depth > 6) return;
        for (var i = 0; i < w.frames.length; i++) {
          var f = w.frames[i];
          try {
            void f.document;
            var p = String(f.location.pathname || '');
            var el = f.frameElement; var r = el ? el.getBoundingClientRect() : null;
            var area = r ? (r.width * r.height) : 0;
            if (!SKIP.test(p) && area > 150000) {
              if (!best || depth > best.depth || (depth === best.depth && area > best.area)) best = { w: f, depth: depth, area: area };
            }
            walk(f, depth + 1);
          } catch (e) {}
        }
      })(window, 0);
      if (!best) return { opened: false, reason: 'no-content-frame' };
      /* practice prefix + CSRF token, harvested from live frame URLs */
      var prefix = '';
      var tokOwn = '', tokAny = '';
      (function walkT(w, depth) {
        if (depth > 6) return;
        for (var i = 0; i < w.frames.length; i++) {
          var f = w.frames[i];
          try {
            void f.document;
            if (!prefix) { var pm = /^\/(\d+)\/(\d+)\//.exec(String(f.location.pathname || '')); if (pm) prefix = '/' + pm[1] + '/' + pm[2] + '/'; }
            var t = new URLSearchParams(String(f.location.search || '')).get('CSRFPROTECT') || '';
            if (t) { if (f === best.w) tokOwn = t; if (!tokAny && !/globalnav|statusbar/i.test(String(f.location.pathname || ''))) tokAny = t; }
            walkT(f, depth + 1);
          } catch (e) {}
        }
      })(window, 0);
      if (!prefix) { var pm2 = /^\/(\d+)\/(\d+)\//.exec(String(location.pathname || '')); if (pm2) prefix = '/' + pm2[1] + '/' + pm2[2] + '/'; }
      if (!prefix) return { opened: false, reason: 'no-practice-prefix' };
      var tok = tokOwn || tokAny || '';
      /* v1.80: findpatient.esp WITHOUT a findtext param renders a server-side
         "You cannot leave the find text field blank" ERROR page with NO form at
         all (live root cause of 'findpatient-no-load'). Navigate the way the
         global search does - filtertype/findtext/defaultaction - which renders
         the form WITH the search text pre-filled; then click Find to run the
         real search (the URL-only search itself returns nothing). */
      if (!openAllowed()) return deadlineOut();
      best.w.location.href = prefix + 'client/findpatient.esp?filtertype=NAME&findtext=' + encodeURIComponent(searchStr)
        + '&defaultaction=' + encodeURIComponent(prefix + 'client/clientsummary.esp')
        + (tok ? ('&CSRFPROTECT=' + encodeURIComponent(tok)) : '');
      var deadline = Math.min(__openGuard.deadline, Date.now() + 14000), ready = false;
      while (Date.now() < deadline) {
        await sleep(400);
        try {
          var d2 = best.w.document;
          if (d2 && d2.body && d2.querySelector('input[type=text]')) { ready = true; break; }
        } catch (e) {}
      }
      if (!ready) return { opened: false, reason: 'findpatient-no-load' };
      /* v1.79: the page's own init can re-render/CLEAR the input after we fill it
         (live: Find submitted empty -> "You cannot leave the find text field
         blank"). Settle first; fill the first VISIBLE text input via the native
         value setter; RE-QUERY each try (re-renders replace the node); verify the
         value actually stuck before clicking Find; retry once if athena still
         reports a blank search. */
      await sleep(900);
      function findInput() {
        try {
          var ins = Array.prototype.slice.call(best.w.document.querySelectorAll('input[type=text]'));
          for (var q2 = 0; q2 < ins.length; q2++) { var rc = ins[q2].getBoundingClientRect(); if (rc.width > 50 && rc.height > 10) return ins[q2]; }
          return ins[0] || null;
        } catch (e) { return null; }
      }
      function setVal(el, v) {
        if (!openAllowed()) return false;
        try {
          var proto = best.w.HTMLInputElement && best.w.HTMLInputElement.prototype;
          var desc = proto && Object.getOwnPropertyDescriptor(proto, 'value');
          if (desc && desc.set) desc.set.call(el, v); else el.value = v;
        } catch (e) { try { el.value = v; } catch (e2) {} }
        if (!openAllowed()) return false;
        try { el.dispatchEvent(new best.w.Event('input', { bubbles: true })); el.dispatchEvent(new best.w.Event('change', { bubbles: true })); } catch (e) {}
        return true;
      }
      var filled = false;
      for (var ft = 0; ft < 4 && !filled; ft++) {
        var inp = findInput();
        if (!inp) { await sleep(500); continue; }
        if (!openAllowed()) return deadlineOut();
        try { inp.focus(); } catch (e) {}
        if (!setVal(inp, searchStr)) return deadlineOut();
        await sleep(600);
        var inpChk = findInput();
        if (inpChk && inpChk.value === searchStr) { filled = true; break; }
      }
      if (!filled) return { opened: false, reason: 'fill-not-sticking' };
      var resText = '';
      for (var fa = 0; fa < 2; fa++) {
        var findBtn = Array.prototype.slice.call(best.w.document.querySelectorAll('button,input[type=submit],input[type=button]')).filter(function (b) { return /^find$/i.test((b.innerText || b.value || '').trim()); })[0];
        if (!findBtn) return { opened: false, reason: 'no-find-button' };
        if (!openAllowed()) return deadlineOut();
        findBtn.click();
        var resDeadline = Math.min(__openGuard.deadline, Date.now() + 12000);
        resText = '';
        while (Date.now() < resDeadline) {
          await sleep(450);
          try { resText = (best.w.document.body && best.w.document.body.innerText) || ''; } catch (e) { resText = ''; }
          if (/\d+\s+results?\s+found|no results|cannot leave the find text field blank/i.test(resText)) break;
        }
        if (/cannot leave the find text field blank/i.test(resText)) {
          var inpR = findInput();
          if (inpR) { if (!setVal(inpR, searchStr)) return deadlineOut(); await sleep(500); }
          continue;
        }
        break;
      }
      if (!/\d+\s+results?\s+found/i.test(resText)) return { opened: false, reason: (/cannot leave the find text field blank/i.test(resText) ? 'blank-error' : (/no results/i.test(resText) ? 'no-results' : 'results-timeout')) };
      /* v1.85: the "N results found" TEXT renders BEFORE the rows' action links
         hydrate (live: 2 Marie Dunnes on screen but zero Chart links at scan
         time -> false 'no-name-match'). Poll for the links. */
      var chartAs = [];
      var linkDeadline = Math.min(__openGuard.deadline, Date.now() + 6000);
      while (Date.now() < linkDeadline) {
        var d4 = best.w.document;
        chartAs = Array.prototype.slice.call(d4.querySelectorAll('a')).filter(function (a) { return /^chart$/i.test((a.innerText || '').trim()); });
        if (chartAs.length) break;
        await sleep(400);
      }
      if (!chartAs.length) return { opened: false, reason: 'rows-not-rendered' };
      d4 = best.w.document;
      var lnorm = lname.toLowerCase(), fnorm = fq.toLowerCase();
      /* v1.81: TWO-TIER first-name matching. A prefix like "pat" matches
         Patricia AND Patrick (live: "6 results found" -> every such patient
         failed 'ambiguous'). Tier 1 = the row's first-name cell EQUALS the
         token (or its first word does); tier 2 = prefix. A single tier-1 hit
         wins even when tier 2 is ambiguous. DOB (when the app sent one, or
         shown on the row) still disambiguates first. */
      var exact = [], prefix = [], vetoedExact = [], vetoedAny = 0;
      for (var c = 0; c < chartAs.length; c++) {
        var tr = chartAs[c].closest ? chartAs[c].closest('tr') : null;
        if (!tr) continue;
        var cells = Array.prototype.slice.call(tr.querySelectorAll('td,th')).map(function (x) { return (x.innerText || '').trim(); });
        var rowT = cells.join(' | ').toLowerCase();
        if (rowT.indexOf(lnorm) < 0) continue;
        var rowDob = '';
        for (var cd = 0; cd < cells.length; cd++) { var dm2 = /([01]?\d)\/([0-3]?\d)\/(\d{4})/.exec(cells[cd]); if (dm2) { rowDob = Number(dm2[1]) + '/' + Number(dm2[2]) + '/' + dm2[3]; break; } }
        var rowMrnMatched = false;
        if (wantMrn) {
          for (var cm = 0; cm < cells.length; cm++) {
            if (mrnCellMatches(cells[cm], wantMrn)) { rowMrnMatched = true; break; }
          }
        }
        var m = { a: chartAs[c], dob: rowDob, mrnMatched: rowMrnMatched };
        var isExact = false, isPrefix = false;
        if (!fnorm) { isPrefix = true; }
        else {
          for (var cx = 0; cx < cells.length; cx++) {
            var v = cells[cx].trim().toLowerCase();
            if (!v || v.length > 40) continue;
            var w0 = v.split(/\s+/)[0];
            if (v === fnorm || w0 === fnorm) { isExact = true; break; }
            /* v1.87: registered nicknames - athena renders "Robert (Bob)"; the
               roster says "Bob". A word-boundary hit inside the first-name cell
               counts as exact (the row still had to match the LAST name, and
               DOB / single-candidate gating still applies). */
            try { if (new RegExp('\\b' + fnorm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b').test(v)) { isExact = true; break; } } catch (e7) {}
            if (v.indexOf(fnorm) === 0) isPrefix = true;
          }
        }
        if (wantDob && rowDob && rowDob !== wantDob) {
          /* v1.94: do NOT silently drop DOB-vetoed name matches - report them.
             The store/roster DOB can be junk (live: LAURA ZAKORCHEMNY stored
             12/31/1940 vs athena 05/14/1990 -> every open refused forever). */
          if (isExact) vetoedExact.push(m);
          if (isExact || isPrefix) vetoedAny++;
          continue;
        }
        if (isExact) exact.push(m); else if (isPrefix) prefix.push(m);
      }
      var pool = exact.length ? exact : prefix;
      if (!pool.length) {
        if (vetoedExact.length === 1) return { opened: false, reason: 'dob-mismatch', count: 1, tier: 'exact', rowDob: vetoedExact[0].dob || '' };
        if (vetoedAny) return { opened: false, reason: 'dob-mismatch', count: vetoedAny, tier: vetoedExact.length ? 'exact' : 'prefix', rowDob: '' };
        return { opened: false, reason: 'no-name-match' };
      }
      /* MRN is an additional exact discriminator only after the existing name
         tier and DOB veto have passed. A positive exact-token match narrows an
         ambiguous pool; an Athena layout that does not expose MRN falls back to
         the unchanged name+DOB behavior and the chart reader re-verifies MRN. */
      var mrnNarrowed = false;
      if (wantMrn) {
        var mrnPool = pool.filter(function (candidate) { return candidate.mrnMatched === true; });
        if (mrnPool.length) { mrnNarrowed = mrnPool.length < pool.length; pool = mrnPool; }
      }
      if (pool.length > 1) return { opened: false, reason: 'ambiguous', count: pool.length, tier: exact.length ? 'exact' : 'prefix' };
      if (!openAllowed()) return deadlineOut();
      pool[0].a.click();
      /* v1.82: return IMMEDIATELY after the Chart click - same contract as the
         schedule-click route. The app's open bridge budget is ~18s and the READ
         side's chart-ready gate (52s budget, shadow-aware from round 2) is the
         component designed to wait for the chart to load. The v1.81 settle loop
         here pushed every open past the app's budget -> empty in-place reads. */
      return { opened: true, via: 'findpatient', rowDob: pool[0].dob || '', rowMrnMatched: pool[0].mrnMatched === true, mrnNarrowed: mrnNarrowed };
    } catch (e) { return { opened: false, error: String((e && e.message) || e) }; }
  }

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || !msg.type) return;

    // (A) Panel "Pull from chart" -> trigger the proven in-app pull without changing the user's tab
    if (msg.type === 'mlsAssistPullToApp') {
      (async function () {
        try {
          var all = await chrome.tabs.query({});
          var appTab = findAppTab(all);
          if (!appTab) { sendResponse({ ok: false, error: 'Open MLS (mlsscribe.com) in a tab first, then try again.' }); return; }
          /* v2.9.14 (Codex E3): READ-ONLY PREFLIGHT, retried once on transient
             injection failure — confirms a pull target exists BEFORE the
             click-bearing injection, which then runs EXACTLY once (a lost
             response channel can mean the pull already started; never re-click). */
          var pf = null;
          for (var pfTry = 0; pfTry < 2 && !pf; pfTry++) {
            try {
              var pr = await chrome.scripting.executeScript({ target: { tabId: appTab.id }, func: function () {
                try { return { hasBtn: !!document.getElementById('ptPullAthenaBtn'), hasShared: !!(window.__mlsAthenaActions && window.__mlsAthenaActions.pullOpenChart), hasAuto: !!(window.__mlsAthenaAutoPull && window.__mlsAthenaAutoPull.run) }; } catch (e) { return null; }
              } });
              pf = pr && pr[0] && pr[0].result;
            } catch (ePf) { pf = null; }
            if (!pf && pfTry === 0) { await new Promise(function (r2) { setTimeout(r2, 600); }); }
          }
          if (!pf || (!pf.hasBtn && !pf.hasShared && !pf.hasAuto)) { sendResponse({ ok: false, reason: 'no-target', error: 'Open the MLS Visit or Patients page first, then try again.' }); return; }
          /* This is a read kickoff. Injection works in a background app tab, so
             never activate/focus it over whatever non-Athena tab the user chose. */
          var r = null;
          try {
            r = await chrome.scripting.executeScript({
              target: { tabId: appTab.id },
              func: function () {
                try {
                  var btn = document.getElementById('ptPullAthenaBtn');
                  if (btn) { btn.click(); return 'clicked'; }
                  if (window.__mlsAthenaActions && window.__mlsAthenaActions.pullOpenChart) { window.__mlsAthenaActions.pullOpenChart({ title: 'Pull from chart', patientName: null, intent: { brings: 'Pull from chart → brings in name, DOB and all visits.', mode: 'read' } }); return 'shared'; }
                  if (window.__mlsAthenaAutoPull && window.__mlsAthenaAutoPull.run) { window.__mlsAthenaAutoPull.run(); return 'autopull'; }
                  return 'no-target';
                } catch (e) { return 'err:' + (e && e.message); }
              }
            });
          } catch (eClick) {
            /* channel lost AFTER the click injection was dispatched — the pull may
               have started; report honestly, never re-click. */
            sendResponse({ ok: false, reason: 'pull-outcome-unknown', error: 'The pull request was sent but its result was lost — check the MLS tab: if no pull is running, click Pull again there.' });
            return;
          }
          var v = r && r[0] && r[0].result;
          if (v === 'no-target') { sendResponse({ ok: false, reason: 'no-target', error: 'Open the MLS Visit or Patients page first, then try again.' }); return; }
          if (typeof v === 'string' && v.indexOf('err:') === 0) { sendResponse({ ok: false, error: v.slice(4) }); return; }
          sendResponse({ ok: true, via: v });
        } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
      })();
      return true;
    }

    // (B) Search-and-navigate by name (read-only: type in search bar + open chart)
    if (msg.type === 'mlsAppSearchOpenRequest') {
      var searchOpenRecoverBase = mlsRecoverAthenaTab;
      (async function () {
        var senderTab = sender && sender.tab && sender.tab.id;
        var frozenMrn = String(msg.mrn || msg.patientMrn || msg.athenaId || '').trim().slice(0, 40);
        var frozenApptId = String(msg.appointmentId || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 40);
        var bootstrapIdentity = msg.bootstrapIdentity === true;
        var frozenScheduleDate = /^\d{4}-\d{2}-\d{2}$/.test(String(msg.scheduleDate || '')) ? String(msg.scheduleDate) : '';
        var rawSendResponse = sendResponse, responseSent = false;
        var openStartedAt = Date.now();
        var openBudgetMs = Math.max(15000, Math.min(90000, Number(msg.maxOpenMs || 70000)));
        var openRequestToken = String(msg.requestId || msg.id || ('mlsopen-' + openStartedAt.toString(36) + '-' + Math.random().toString(36).slice(2, 9))).slice(0, 100);
        var callerDeadline = Number(msg.deadlineAt || 0);
        var openDeadline = openStartedAt + openBudgetMs;
        if (Number.isFinite(callerDeadline) && callerDeadline > 0) openDeadline = Math.min(openDeadline, callerDeadline);
        var openGuard = Object.freeze({ deadline: openDeadline, token: openRequestToken });
        sendResponse = function (payload) {
          if (responseSent) return; responseSent = true;
          rawSendResponse(Object.assign({}, payload || {}, { requestId: openGuard.token, deadlineAt: openGuard.deadline }));
        };
        var findGuard = Object.freeze({ value: frozenMrn, deadline: openGuard.deadline, token: openGuard.token });
        function openExpired() { return Date.now() >= openGuard.deadline; }
        function failOpenDeadline(stage) {
          sendResponse({ ok: false, opened: false, reason: 'open-deadline-exceeded', requestToken: openGuard.token, error: 'The Athena patient open reached its one absolute deadline during ' + (stage || 'navigation') + '. No retry or fallback was dispatched after the timeout.' });
        }
        if (bootstrapIdentity && !frozenApptId) {
          sendResponse({ ok: false, opened: false, reason: 'appointment-id-missing', error: 'The exact Athena appointment identity was missing. Nothing was opened.' });
          return;
        }
        async function settleOpen(promise) {
          var left = Math.max(0, openGuard.deadline - Date.now());
          if (!left) return { timeout: true };
          return Promise.race([
            Promise.resolve(promise).then(function (value) { return { ok: true, value: value }; }, function (error) { return { error: error }; }),
            mlsSleepW(left).then(function () { return { timeout: true }; })
          ]);
        }
        async function execOpen(opts, ceilingMs) {
          var left = Math.max(0, openGuard.deadline - Date.now());
          if (!left) return { timeout: true, deadline: true };
          var x = await mlsExecTO(opts, Math.max(1, Math.min(left, Number(ceilingMs || left))));
          if ((x && x.timeout) || openExpired()) return { timeout: true, deadline: true };
          return x || {};
        }
        async function waitOpen(ms) {
          var left = Math.max(0, openGuard.deadline - Date.now());
          if (!left) return false;
          await mlsSleepW(Math.min(left, Math.max(0, Number(ms || 0))));
          return !openExpired();
        }
        /* Preserve legacy freeze-guard call sites, but bind every recovery wait
           to this request's same immutable absolute deadline. */
        var mlsRecoverAthenaTab = async function (tabId) {
          var settledRecovery = await settleOpen(searchOpenRecoverBase(tabId));
          if (!settledRecovery || !settledRecovery.ok) {
            failOpenDeadline('Athena recovery');
            return { ok: false, reason: 'open-deadline-exceeded' };
          }
          return settledRecovery.value;
        };
        try {
          var allSettled = await settleOpen(chrome.tabs.query({}));
          if (!allSettled || !allSettled.ok) { failOpenDeadline('Athena tab selection'); return; }
          var all = allSettled.value || [];
          var picked = await settleOpen(mlsPickAthenaTab(all, { athenaOnly: true }));
          if (!picked || !picked.ok) { failOpenDeadline('Athena tab selection'); return; }
          /* SearchOpen is Athena-specific and identity-sensitive. If the
             athenaOnly picker returns null (or its defensive catch ever hands
             back a generic HTTP tab), fail closed instead of navigating an
             unrelated browser page. */
          var tab = picked.value || null;
          var __searchTabUrl = String(tab && tab.url || '');
          var __searchExactAthena = !!tab
            && /athenahealth|athenanet|athenaone|athena\.io|\.px\.athena/i.test(__searchTabUrl)
            && !/^(?:https?:\/\/)?(?:identity|login|signin|sso|auth|accounts|okta|myapps)\./i.test(__searchTabUrl.replace(/^https?:\/\//i, ''))
            && !/\/login\b|sign-?in|\/auth\b|\/authn\b|\/oauth|\/sso\b|\bwww\.athenahealth\.com\b/i.test(__searchTabUrl);
          if (!__searchExactAthena) { sendResponse({ ok: false, reason: 'no-athena-tab', error: 'Open your signed-in athenaOne in another tab, then try again.' }); return; }
          /* v1.91 (§2.9): athena reliably freezes after ~5-9 rapid chart opens+reads,
             and the findpatient-first flow never goes Home, so the go-home chunker
             (>=6) no longer runs on bulk pulls. Chunk HERE at the same natural
             boundary: reload-recover the tab BEFORE the next open once enough reads
             accumulated. Live 07-10 repro this prevents: alternating open-failures
             (Zakorchemny / Boyle / Pownall) with the tab CDP-frozen afterward. */
          if (__mlsReadsSinceReload >= 5 && !msg.noReload) {
            if (openExpired()) { failOpenDeadline('freeze-guard recovery'); return; }
            if (senderTab) progress(senderTab, 'Giving athenaOne a breather (freeze-guard reload)…', openGuard.token);
            await mlsRecoverAthenaTab(tab.id);
            /* Reload recovery returns Athena to its default/current day. An
               exact appointment-id bootstrap for a non-today or month route
               must re-ground the SAME frozen requested date before scanning;
               otherwise the id is honestly absent and history silently drops.
               Never substitute today. */
            if (bootstrapIdentity) {
              if (!frozenScheduleDate) { sendResponse({ ok: false, opened: false, reason: 'schedule-date-missing-after-recovery', error: 'The requested schedule date was missing after Athena recovery. Nothing was opened.' }); return; }
              var regroundX = await execOpen({ target: { tabId: tab.id, allFrames: true }, args: [frozenScheduleDate, false, openGuard], func: mlsAthenaGotoDate }, 40000);
              if (regroundX.timeout) { failOpenDeadline('post-recovery date restoration'); return; }
              var regroundOk = (regroundX.r || []).map(function (entry) { return entry && entry.result; }).filter(Boolean).some(function (value) { return value.done === true && String(value.schedDate || '') === frozenScheduleDate; });
              if (!regroundOk) { sendResponse({ ok: false, opened: false, reason: 'schedule-date-restore-failed', error: 'Athena recovered, but the exact requested date could not be restored. No appointment was opened.' }); return; }
            }
          }
          // === v1.53 ROUTE 1 — SCHEDULE/CALENDAR CLICK-OPEN (reliable on athenaOne v26.3) ===
          // The synthetic search-box 'fill' path below does NOT register a query on
          // athenaOne v26.3 (verified live: it types but the search never runs), so we
          // FIRST scan the CURRENT athenaOne page (schedule / calendar / dashboard —
          // exactly where the day+month bulk-pull patients already are) for the
          // patient's row and click their name link. Read-only: opens the chart, never
          // Save/Sign. Only if no matching row is on screen do we fall back to the
          // legacy search-box path.
          /* v1.78: TWO real routes, ordered by what last worked (sticky pref).
             Route A = schedule/dashboard row click (proven when the right
             department's schedule is displayed). Route B = findpatient.esp
             (schedule-INDEPENDENT; proven live 07-10 when route A failed
             17/17 on a wrong-department dashboard). After a route succeeds it
             goes first for the rest of the session, so bulk pulls do not burn
             ~20s per patient re-failing the broken route. */
          /* v1.85: findpatient FIRST by default - it is schedule-independent and
             verifies name+DOB on the result row BEFORE opening. The schedule
             scan is the fallback (it depends on the right department's schedule
             being displayed and can phantom-click name-bearing inbox rows). */
          /* A bounded freeze-guard recovery may already have sent the one
             terminal deadline response. Never continue into another injected
             find/schedule action after that response. */
          if (responseSent) return;
          /* v2.9.25: a row-bound appointment id (grids that render no
             demographics) makes the schedule row the STRONGEST opener — the id
             selects the exact clicked row, and the chart banner supplies the
             identity proof afterward. findpatient stays first only when the
             caller proved DOB/MRN. */
          var order = bootstrapIdentity ? ['sched'] : (frozenMrn ? ['find', 'sched'] : (frozenApptId ? ['sched', 'find'] : ((self.__mlsOpenPref === 'schedule') ? ['sched', 'find'] : ['find', 'sched'])));
          var sched = null, findRes = null;
          for (var oi = 0; oi < order.length; oi++) {
            if (order[oi] === 'sched') {
              if (senderTab) progress(senderTab, 'Looking for “' + (msg.name || '') + '” on the athenaOne schedule…', openGuard.token);
              /* v1.89: a stuck-open Calendar nav dropdown can overlay the very
                 schedule rows this scan is about to read/click - close it first
                 (Escape + one gated neutral click; strictly zero-touch when no
                 menu overlay is visible). Sched route ONLY (wf_6): findpatient
                 navigates the content frame anyway. Never blocks the open. */
              try {
                if (typeof mlsDismissNavMenuFn === 'function') {
                  var dismissX = await execOpen({ target: { tabId: tab.id, allFrames: true }, func: mlsDismissNavMenuFn, args: [openGuard] }, 6000);
                  if (dismissX.timeout) { failOpenDeadline('schedule preparation'); return; }
                }
              } catch (eDm) {}
              var beforeAppointmentFrames = [];
              if (bootstrapIdentity) {
                var beforeFramesSettled = await settleOpen(chrome.webNavigation.getAllFrames({ tabId: tab.id }));
                if (!beforeFramesSettled || !beforeFramesSettled.ok) {
                  sendResponse({ ok: false, opened: false, reason: 'appointment-navigation-snapshot-unavailable', error: 'Athena frame state could not be frozen before the exact appointment click. Nothing was opened.' }); return;
                }
                beforeAppointmentFrames = beforeFramesSettled.value || [];
              }
              var schedX = await execOpen({ target: { tabId: tab.id, allFrames: true }, func: mlsSearchOpenDriverFn, args: [msg.name || '', 'open', openGuard, frozenApptId, bootstrapIdentity] }, 42000);
              if (schedX.timeout) { failOpenDeadline('schedule-row open'); return; }
              var schedRes = schedX.r || [];
              if (bootstrapIdentity) {
                var exactOpenResults = schedRes.map(function (entry) {
                  var value = entry && entry.result;
                  if (value && typeof entry.frameId === 'number') try { value.__frameId = entry.frameId; } catch (eFrameTag) {}
                  return value;
                }).filter(Boolean);
                var exactAmbiguous = exactOpenResults.some(function (value) { return value && (value.reason === 'appointment-id-ambiguous' || (value.diag && Number(value.diag.apptIdMatches || 0) > 1)); });
                var exactSuccesses = exactOpenResults.filter(function (value) { return value && value.opened === true && value.diag && value.diag.apptIdBound === true; });
                if (exactAmbiguous || exactSuccesses.length > 1) {
                  sendResponse({ ok: false, opened: false, reason: 'appointment-id-ambiguous', error: 'More than one visible Athena row claimed the exact appointment id. Nothing was opened.' }); return;
                }
                sched = exactSuccesses[0] || bestFrameResult(schedRes, 'open');
              } else sched = bestFrameResult(schedRes, 'open');
              if (sched && sched.opened) {
                var appointmentNavigationProven = !bootstrapIdentity;
                var appointmentNavigationFrameIds = [];
                if (bootstrapIdentity && sched.diag && sched.diag.apptIdBound === true) {
                  var proofUntil = Math.min(openGuard.deadline, Date.now() + 12000);
                  while (!appointmentNavigationProven && Date.now() < proofUntil) {
                    if (!(await waitOpen(500))) break;
                    var afterFramesSettled = await settleOpen(chrome.webNavigation.getAllFrames({ tabId: tab.id }));
                    if (!afterFramesSettled || !afterFramesSettled.ok) { failOpenDeadline('appointment navigation proof'); return; }
                    var navigationDelta = mlsAppointmentNavigationDelta(frozenApptId, beforeAppointmentFrames, afterFramesSettled.value || []);
                    appointmentNavigationProven = navigationDelta.matched === true;
                    appointmentNavigationFrameIds = navigationDelta.changedFrameIds || [];
                  }
                  if (!appointmentNavigationProven) {
                    sendResponse({ ok: false, opened: false, reason: 'appointment-navigation-unverified', error: 'Athena did not prove navigation from the exact appointment row. Nothing was read.' }); return;
                  }
                }
                try { self.__mlsOpenPref = 'schedule'; } catch (e0) {}
                /* v1.60: remember WHO we just opened - the follow-up bare chart read
                   uses this to wait for the RIGHT patient's banner instead of
                   accepting a stale/lurking frame's identity. */
                try { self.__mlsExpectOpen = { name: msg.name || '', dob: msg.dob || '', mrn: frozenMrn, tabId: tab.id, at: Date.now(), requestId: openGuard.token, appointmentId: frozenApptId, appointmentIdBound: bootstrapIdentity && appointmentNavigationProven, appointmentNavigationFrameIds: appointmentNavigationFrameIds.slice(0, 24), scheduleDate: frozenScheduleDate }; self.__mlsWriteTarget = { name: msg.name || '', dob: msg.dob || '', mrn: frozenMrn, tabId: tab.id, appTabId: senderTab || null, at: Date.now() }; } catch (e0) {}
                sendResponse({ ok: true, opened: true, via: bootstrapIdentity ? 'appointment-id' : 'schedule-click', candidates: sched.candidates, appointmentId: bootstrapIdentity ? frozenApptId : '', appointmentIdBound: bootstrapIdentity && appointmentNavigationProven, appointmentNavigationFrameIds: appointmentNavigationFrameIds.slice(0, 24), athenaTabId: tab.id, diag: sched.diag }); return;
              }
            } else {
              if (senderTab) progress(senderTab, 'Searching athenaOne patients for “' + (msg.name || '') + '”…', openGuard.token);
              /* v1.83: MAIN world - the result row's Chart link is a javascript:
                 URL (redirectToAirlock), and Chrome refuses javascript: navigations
                 initiated from an extension's ISOLATED world: the fill and Find
                 worked but every Chart click silently did nothing (live: the frame
                 sat on the results page while reads came back empty). Page-context
                 clicks are proven to navigate (the Adam chart open). */
              /* v1.91 (§2.9): a frozen/hung athena renderer surfaces here as an
                 injection timeout or a load/render failure. Recover the tab
                 (reload + Continue-clear) and retry this SAME patient once, so a
                 freeze costs a pause instead of an open-failure. Honest refusals
                 (ambiguous / no-results / no-name-match) never trigger a retry. */
              var fx = null;
              for (var fpTry = 0; fpTry < 2; fpTry++) {
                fx = await execOpen({ target: { tabId: tab.id }, world: 'MAIN', args: [msg.name || '', msg.dob || '', findGuard, frozenMrn], func: mlsFindPatientOpenDriverFn }, 42000);
                if (fx.timeout) { failOpenDeadline('find-patient open'); return; }
                findRes = (fx && fx.r && fx.r[0] && fx.r[0].result) || null;
                if (findRes && findRes.opened) break;
                var rzn = (findRes && findRes.reason) || '';
                var retryable = !findRes || !!(findRes && findRes.error) || /^(findpatient-no-load|results-timeout|fill-not-sticking|no-content-frame|rows-not-rendered|blank-error|no-find-button)$/.test(rzn); /* v1.98: no-find-button = findpatient rendered inside an odd view layout (live: dept-calendar-parked tab) - a reload recovery restores the normal frameset */
                if (fpTry === 0 && retryable && !msg.noReload) {
                  if (senderTab) progress(senderTab, 'athenaOne stopped responding — reloading it and retrying “' + (msg.name || '') + '”…', openGuard.token);
                  if (openExpired()) { failOpenDeadline('find-patient recovery'); return; }
                  var retryRecovery = await mlsRecoverAthenaTab(tab.id);
                  if (!retryRecovery || retryRecovery.reason === 'open-deadline-exceeded' || responseSent) return;
                  continue;
                }
                break;
              }
              /* v1.94: the store/roster DOB can be junk. When the search found
                 EXACTLY ONE exact-name row and only the DOB veto blocked it,
                 re-run once with no DOB and open that single match. Read-only:
                 the chart read + every save/write gate still verifies the REAL
                 banner name+DOB downstream, so a true different-person row can
                 be opened but never saved against the wrong record. 2+ rows
                 stay refused (ambiguous) exactly as before. */
              if (findRes && findRes.reason === 'dob-mismatch' && findRes.count === 1 && findRes.tier === 'exact') {
                if (senderTab) progress(senderTab, 'DOB on file differs from athena for “' + (msg.name || '') + '” — opening the single exact name match (read-only)…', openGuard.token);
                var fxo = await execOpen({ target: { tabId: tab.id }, world: 'MAIN', args: [msg.name || '', '', findGuard, frozenMrn], func: mlsFindPatientOpenDriverFn }, 42000);
                if (fxo.timeout) { failOpenDeadline('DOB-override open'); return; }
                var fro = (fxo && fxo.r && fxo.r[0] && fxo.r[0].result) || null;
                if (fro && fro.opened) {
                  try { self.__mlsOpenPref = 'findpatient'; } catch (e0) {}
                  try { self.__mlsExpectOpen = { name: msg.name || '', dob: msg.dob || '', mrn: frozenMrn, tabId: tab.id, at: Date.now() }; self.__mlsWriteTarget = { name: msg.name || '', dob: msg.dob || '', mrn: frozenMrn, tabId: tab.id, appTabId: senderTab || null, at: Date.now() }; } catch (e0) {}
                  sendResponse({ ok: true, opened: true, via: 'findpatient', candidates: 1, dobOverride: true, rowDob: fro.rowDob || '', rowMrnMatched: fro.rowMrnMatched === true, diag: { route: 'findpatient-dob-override', rowDobKnown: fro.rowDob ? 1 : 0, rowMrnMatched: fro.rowMrnMatched === true } }); return;
                }
                findRes = fro || findRes;
              }
              /* v2.9.6 COMPOUND-SURNAME RETRY (live case 2026-07-13: "Priscilla
                 Pennington Zytkowicz" -> searched "Zytkowicz,Priscilla" -> no-results,
                 but her athenaOne last name IS "Pennington Zytkowicz"; the reshaped
                 search opened her chart with the DOB row-verified). When the plain
                 first+last search honestly finds nothing and the requested comma-less
                 name has 3+ tokens, retry ONCE treating the LAST TWO tokens as the
                 surname ("Pennington Zytkowicz, Priscilla"). Read-only and
                 gate-neutral: the same DOB veto + ambiguity refusal run inside the
                 driver on the retry, and every downstream chart-read/write identity
                 gate is unchanged. A retry that also finds nothing keeps the original
                 honest refusal. */
              if (findRes && !findRes.opened && /^(no-results|no-name-match)$/.test(findRes.reason || '') && String(msg.name || '').indexOf(',') < 0) {
                var cTok = String(msg.name || '').replace(/\([^)]*\)/g, ' ').replace(/\s+/g, ' ').trim().split(' ').filter(Boolean);
                while (cTok.length > 1 && /^(jr|sr|ii|iii|iv|v|esq|junior|senior)\.?$/i.test(cTok[cTok.length - 1])) cTok.pop();
                if (cTok.length >= 3) {
                  var cName = cTok.slice(-2).join(' ') + ', ' + cTok.slice(0, -2).join(' ');
                  if (senderTab) progress(senderTab, 'No match for “' + (msg.name || '') + '” — retrying with compound last name “' + cName + '”…', openGuard.token);
                  var fxc = await execOpen({ target: { tabId: tab.id }, world: 'MAIN', args: [cName, msg.dob || '', findGuard, frozenMrn], func: mlsFindPatientOpenDriverFn }, 42000);
                  if (fxc.timeout) { failOpenDeadline('compound-name open'); return; }
                  var frc = (fxc && fxc.r && fxc.r[0] && fxc.r[0].result) || null;
                  if (frc && (frc.opened || /^(ambiguous|dob-mismatch)$/.test(frc.reason || ''))) findRes = frc;
                }
              }
              if (findRes && findRes.opened) {
                try { self.__mlsOpenPref = 'findpatient'; } catch (e0) {}
                try { self.__mlsExpectOpen = { name: msg.name || '', dob: msg.dob || '', mrn: frozenMrn, tabId: tab.id, at: Date.now() }; self.__mlsWriteTarget = { name: msg.name || '', dob: msg.dob || '', mrn: frozenMrn, tabId: tab.id, appTabId: senderTab || null, at: Date.now() }; } catch (e0) {}
                sendResponse({ ok: true, opened: true, via: 'findpatient', candidates: 1, rowDob: findRes.rowDob || '', rowMrnMatched: findRes.rowMrnMatched === true, diag: { route: 'findpatient', rowDobKnown: findRes.rowDob ? 1 : 0, rowMrnMatched: findRes.rowMrnMatched === true, mrnNarrowed: findRes.mrnNarrowed === true } }); return;
              }
              /* v1.84: if the search RAN and left its RESULTS page on screen
                 (ambiguous / no match), do NOT fall through to the schedule
                 scanner - it false-positives on the results rows (javascript:
                 links that cannot navigate from the isolated world; live:
                 phantom opens then junk reads "Mainline, Lauren" / "Fail, PTA"
                 that the app gate had to refuse). Fail honestly instead. */
              if (findRes && /^(ambiguous|no-results|no-name-match|blank-error|rows-not-rendered|dob-mismatch)$/.test(findRes.reason || '')) {
                sendResponse({ ok: false, opened: false, candidates: (findRes.count || 0),
                  error: findRes.reason === 'ambiguous' ? ('Found ' + (findRes.count || 'several') + ' possible matches for ' + (msg.name || '') + ' — refusing to open any of them without a matching DOB or MRN to disambiguate.')
                    : findRes.reason === 'dob-mismatch' ? ('athenaOne has ' + (findRes.count || 1) + ' name match(es) for ' + (msg.name || '') + ' but the DOB on file does not match any of them — check the stored DOB.')
                    : 'athenaOne patient search found no matching patient.',
                  findReason: findRes.reason }); return;
              }
            }
          }
          if (bootstrapIdentity) {
            sendResponse({ ok: false, opened: false, reason: (sched && sched.reason) || 'appointment-id-not-found', error: 'The exact Athena appointment row could not be opened. No name fallback was attempted.' });
            return;
          }
          // === legacy fallback: synthetic global-search (kept for off-schedule patients; may fail on v26.3) ===
          if (senderTab) progress(senderTab, 'Not on the current view — trying the Athena patient search…', openGuard.token);
          var fillX = await execOpen({ target: { tabId: tab.id, allFrames: true }, func: mlsSearchOpenDriverFn, args: [msg.name || '', 'fill', openGuard] }, 20000);
          if (fillX.timeout) { failOpenDeadline('legacy search fill'); return; }
          var fillRes = fillX.r || [];
          var fill = bestFrameResult(fillRes, 'fill');
          if (!fill || !fill.filled) {
            sendResponse({ ok: false, opened: false, error: 'Could not find the Athena patient search box on this screen.', diag: fill && fill.diag });
            return;
          }
          if (senderTab) progress(senderTab, 'Searching “' + (msg.name || '') + '”…', openGuard.token);
          if (!(await waitOpen(1900))) { failOpenDeadline('legacy search results'); return; } // let results render
          if (senderTab) progress(senderTab, 'Reading the results…', openGuard.token);
          var openX = await execOpen({ target: { tabId: tab.id, allFrames: true }, func: mlsSearchOpenDriverFn, args: [msg.name || '', 'open', openGuard] }, 30000);
          if (openX.timeout) { failOpenDeadline('legacy search open'); return; }
          var openRes = openX.r || [];
          var opened = bestFrameResult(openRes, 'open');
          if (opened && opened.opened) {
            try { self.__mlsExpectOpen = { name: msg.name || '', dob: msg.dob || '', mrn: frozenMrn, tabId: tab.id, at: Date.now() }; self.__mlsWriteTarget = { name: msg.name || '', dob: msg.dob || '', mrn: frozenMrn, tabId: tab.id, appTabId: senderTab || null, at: Date.now() }; } catch (e0) {}
            sendResponse({ ok: true, opened: true, candidates: opened.candidates, diag: opened.diag });
          } else {
            var cands = (openRes || []).map(function (r) { return r && r.result; }).filter(Boolean).reduce(function (a, r) { return a + ((r && r.candidates) || 0); }, 0);
            sendResponse({ ok: false, opened: false, candidates: cands, error: cands > 1 ? ('Found ' + cands + ' possible matches.') : 'No matching patient was found in the results.', diag: opened && opened.diag, findReason: (findRes && (findRes.reason || findRes.error)) || '' });
          }
        } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
      })();
      return true;
    }
    // not ours — let other listeners handle it
  });
})();


// ---- v1.40: Athena "Sign & Save" driver (injected, runs per frame) ----------
// USER-INITIATED ONLY - fired because the doctor clicked "Sign and Save" in MLS,
// never autonomously. Self-contained for chrome.scripting injection.
//   mode 'probe' = READ-ONLY: locate the Sign/Save control(s); click NOTHING.
//   mode 'sign'  = click Sign & Save, confirm any dialog, then VERIFY the chart
//                  actually signed/saved. Reports signed:true ONLY on positive
//                  confirmation - it NEVER fabricates success.
async function mlsAthenaSignSave(mode) {
  mode = (mode === 'sign') ? 'sign' : 'probe';
  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  function vis(el) { try { var r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; var s = getComputedStyle(el); return s.display !== 'none' && s.visibility !== 'hidden' && parseFloat(s.opacity || '1') > 0.05; } catch (e) { return false; } }
  function txt(el) { try { return ((el && (el.textContent || el.value || (el.getAttribute && el.getAttribute('aria-label')))) || '').replace(/\s+/g, ' ').trim(); } catch (e) { return ''; } }
  // Strict: the control must clearly mean "sign (and save/file)". Never destructive.
  var SIGN_RE = /\bsign\s*(?:&|and)?\s*(?:save|file)\b|\bsave\s*(?:&|and)\s*sign\b/i;
  var SIGN_ONLY_RE = /\bsign\b/i;
  var BAD_RE = /cancel|delete|discard|remove|unsign|void|addend|amend|reopen|log\s*out|sign\s*out|sign\s*off\s*&?\s*next|next\s*patient|close\s*(?:without|encounter)|don'?t\s*save/i;
  function findSignControls() {
    var els = [].slice.call(document.querySelectorAll('button,[role=button],input[type=submit],input[type=button],a[role=button]')).filter(vis);
    var hits = [];
    for (var i = 0; i < els.length; i++) {
      var el = els[i], t = txt(el);
      if (!t || t.length > 40 || BAD_RE.test(t)) continue;
      var s = 0;
      if (SIGN_RE.test(t)) s += 10; else if (SIGN_ONLY_RE.test(t)) s += 4; else continue;
      if (/save|file/i.test(t)) s += 3;
      hits.push({ el: el, t: t, s: s, len: t.length });
    }
    hits.sort(function (a, b) { return (b.s - a.s) || (a.len - b.len); });
    return hits;
  }
  function signedIndicator() {
    var body = (document.body && document.body.innerText || '');
    if (/\bsigned\s*(?:by|on)\b|electronically\s*signed|note\s*signed|encounter\s*(?:signed|closed)|signed\s*(?:and|&)\s*(?:saved|filed)|successfully\s*signed|chart\s*closed/i.test(body)) return true;
    var toast = [].slice.call(document.querySelectorAll('[role=status],[role=alert],.toast,.notification,.success,[class*=success],[class*=signed]')).filter(vis);
    for (var i = 0; i < toast.length; i++) { if (/signed|filed|closed|success/i.test(txt(toast[i]))) return true; }
    return false;
  }
  function clickEl(el) {
    try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
    var r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
    var o = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y };
    ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) {
      try { el.dispatchEvent(new (tp.indexOf('pointer') === 0 ? PointerEvent : MouseEvent)(tp, o)); } catch (e) {}
    });
    try { el.click(); } catch (e) {}
  }

  var controls = findSignControls();
  var alreadySigned = signedIndicator();
  var observed = { url: location.href, top: (function () { try { return window.top === window; } catch (e) { return false; } })(),
    controlFound: !!controls.length, controlText: controls.length ? controls[0].t : '', controlCount: controls.length, alreadySigned: alreadySigned };

  if (mode === 'probe') return { ok: true, mode: 'probe', ready: !!controls.length, observed: observed };

  // ----- SIGN (clicks; user-initiated; never invoked autonomously) -----
  if (alreadySigned) return { ok: true, signed: true, reason: 'already-signed', observed: observed };
  if (!controls.length) return { ok: false, signed: false, reason: 'no-control', msg: 'Could not find a Sign & Save control on this Athena screen.', observed: observed };

  clickEl(controls[0].el);
  await sleep(700);
  // a confirm dialog may appear -> click the AFFIRMATIVE sign/confirm button (not cancel)
  var dlg = [].slice.call(document.querySelectorAll('[role=dialog],[role=alertdialog],.modal,.dialog,[class*=modal],[class*=dialog]')).filter(vis);
  if (dlg.length) {
    var btns = [];
    dlg.forEach(function (d) { [].slice.call(d.querySelectorAll('button,[role=button],input[type=submit]')).filter(vis).forEach(function (b) { btns.push(b); }); });
    var pick = null;
    for (var i = 0; i < btns.length; i++) { var bt = txt(btns[i]); if (!bt || BAD_RE.test(bt)) continue; if (SIGN_RE.test(bt) || /\b(?:confirm|ok|yes|continue|accept)\b/i.test(bt)) { pick = btns[i]; if (SIGN_RE.test(bt)) break; } }
    if (pick) { clickEl(pick); await sleep(800); }
  }
  // verify - REQUIRE a positive signed indicator. Control disappearing alone is NOT proof.
  for (var w = 0; w < 10; w++) {
    if (signedIndicator()) return { ok: true, signed: true, reason: 'confirmed', observed: observed };
    await sleep(500);
  }
  return { ok: true, signed: false, reason: 'unconfirmed', msg: 'Clicked Sign & Save but could not confirm Athena finished signing - check the chart in Athena before relying on it.', observed: observed };
}

/* ===== v1.38: MLS Seamless Pop-up overlay router (appended) ===== */
/* =========================================================================
   MLS Seamless Pop-up  —  background.js ADDITIONS  (v0.2.0)

   APPEND-ONLY block for the MLS Assist service worker. It adds an intent
   router for the overlay and re-uses the EXISTING, in-production handlers —
   it does NOT rewrite them:
       mlsAppReadAllVisits  (read open patient + all visits, identity)   [reuse]
       mlsAppPasteNote      (frame-aware verified paste, never signs)    [reuse]
       (note generation goes through the existing backend call path)     [reuse]
   plus ONE new, FLAG-GATED driver: mlsAppWriteCodes (coding-field driver).

   HARD RAILS: read-only except the two deliberate gated writes; NEVER clicks
   Save/Sign/attest/submit-charges; success only when verified; no fabrication.

   The functions referenced as EXISTING (runReadAllVisits, runPasteNote,
   readChartIdentity, callBackendNote, namesMatch, dobsMatch, normDob,
   findAthenaTab, focusTab, validateCodesViaApp, saveVisitsViaApp) are the
   service worker's already-shipped internals; this block only orchestrates
   them. Names are bound defensively so a missing internal degrades honestly
   rather than throwing.
   ========================================================================= */
(function () {
  'use strict';
  if (typeof chrome === 'undefined' || !chrome.runtime) return;
  if (self.__mlsOverlayRouterInstalled) return;
  self.__mlsOverlayRouterInstalled = true;

  // ---- feature flag: the codes-into-pickers driver stays OFF until it has
  //      had one real athenaOne selector-tuning pass (see 04_codes_writeback).
  /* Legacy codes automation is a permanent kill switch. A storage value must
     never enable this old all-frame driver; v2 actions use a separate contract. */
  var FLAGS = Object.freeze({ codesDriver: false });

  // ---- per-tab session: the identity locked at "Go" -----------------------
  var sessions = {};   // tabId -> { lockedIdentity:{name,dob} }
  function sess(tabId) { return (sessions[tabId] = sessions[tabId] || {}); }

  // ---- recording session: which overlay tab is currently recording --------
  //      (transcript chunks are streamed back to exactly this tab)
  var recordingTabId = null;

  // ---- defensive bind to existing service-worker internals ----------------
  function bind(name) { return (typeof self[name] === 'function') ? self[name] : null; }
  function fn(name) { return (typeof self[name] === 'function') ? self[name] : null; }

  // =====================================================================
  // v1.40 ROOT-CAUSE FIX: the overlay was bound to adapter names that were
  // NEVER implemented (findAthenaTab / readChartIdentity / runReadAllVisits /
  // runPasteNote / callBackendNote). Every binding resolved to null, so STATUS
  // always reported patientOpen:false and GO/GENERATE/WRITEBACK all failed -
  // the overlay was permanently stuck on "Open a patient in Athena". These
  // adapters wire the overlay to the PROVEN, in-production engines instead.
  // All read-only except the existing gated note paste. NEVER Save/Sign here.
  // =====================================================================

  // find the signed-in athenaOne / EMR tab (reuse the proven picker)
  function overlayFindEmrTab() {
    return new Promise(function (resolve) {
      try {
        chrome.tabs.query({}, function (all) {
          var picker = fn('mlsPickEmrTab');
          resolve(picker ? (picker(all || []) || null) : ((all || []).filter(function (t) { return /athenahealth|athenanet|athenaone/i.test(t.url || ''); })[0] || null));
        });
      } catch (e) { resolve(null); }
    });
  }

  // read the OPEN chart's identity (read-only; best-scoring frame)
  function overlayReadIdentity(tabId) {
    var reader = fn('mlsReadChartIdentity');
    if (!reader || typeof chrome.scripting === 'undefined' || tabId == null) return Promise.resolve(null);
    return chrome.scripting.executeScript({ target: { tabId: tabId, allFrames: true }, func: reader })
      .then(function (res) {
        var best = mlsBestIdentityFrom(res); /* v1.59: banner-preferred */
        return best ? { name: best.name, dob: best.dob || '', mrn: best.mrn || '', score: best.score || 0 } : null;
      })
      .catch(function () { return null; });
  }

  function overlayNoteText(noteObj) {
    if (!noteObj) return '';
    if (typeof noteObj === 'string') return noteObj;
    var t = noteObj.soap || noteObj.text || noteObj.note || noteObj.content || '';
    if (!t && noteObj.insurance) t = noteObj.insurance;
    return String(t || '');
  }

  // verified, frame-scored paste of the note (PATIENT GATE already enforced by
  // doWriteBack). Reuses the proven mlsFieldScanner + mlsNotePaster path. Never signs.
  function overlayPasteNote(arg) {
    var noteObj = (arg && arg.note != null) ? arg.note : arg;
    var text = overlayNoteText(noteObj);
    var scanner = fn('mlsFieldScanner'), paster = fn('mlsNotePaster'), segmenter = fn('mlsSegmentNote');
    if (!text.trim()) return Promise.resolve({ error: 'Nothing to write.' });
    if (!scanner || !paster || typeof chrome.scripting === 'undefined') return Promise.resolve({ error: 'Write path unavailable - reload the extension.' });
    return overlayFindEmrTab().then(function (tab) {
      if (!tab) return { error: 'No signed-in athenaOne tab is open.' };
      var segs = segmenter ? segmenter(text) : [{ text: text, section: (noteObj && noteObj.section) || 'progress' }];
      var sections = [];
      var i = 0;
      function step() {
        if (i >= segs.length) return { sections: sections };
        var seg = segs[i];
        var last = { ok: false };
        var attempt = 0;
        function tryOnce() {
          var measureP;
          try { measureP = chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, args: [seg.text, seg.section], func: scanner }); }
          catch (e) { measureP = chrome.scripting.executeScript({ target: { tabId: tab.id }, args: [seg.text, seg.section], func: scanner }); }
          return measureP.then(function (measure) {
            var wf = null, bs = -1e12, wfScan = null;
            (measure || []).forEach(function (m) { if (m && m.result && m.result.has && m.result.score > bs) { bs = m.result.score; wf = (m.frameId != null ? m.frameId : 0); wfScan = m.result; } });
            if (wf === null) { last = { ok: false, notfound: true, targetLabel: seg.section }; return new Promise(function (r) { setTimeout(r, 400); }).then(function () { return null; }); }
            return chrome.scripting.executeScript({ target: { tabId: tab.id, frameIds: [wf] }, args: [seg.text, seg.section, wfScan], func: paster })
              .then(function (r) { last = (r && r[0] && r[0].result) || { ok: false }; return null; });
          });
        }
        function loop() {
          if (attempt >= 2 || (last.ok && last.confirmed)) {
            sections.push({ section: last.chosenSection || last.targetLabel || seg.section, confirmed: !!last.confirmed, written: !!last.ok });
            i++; return step();
          }
          attempt++;
          return tryOnce().then(function () { if (last.ok && last.confirmed) { sections.push({ section: last.chosenSection || last.targetLabel || seg.section, confirmed: true, written: true }); i++; return step(); } return new Promise(function (r) { setTimeout(r, 380); }).then(loop); });
        }
        return loop();
      }
      return Promise.resolve(step());
    });
  }

  // backend note generation (reuse the proven authenticated backend call)
  function overlayBackendNote(req) {
    var cb = fn('callBackend');
    if (!cb) return Promise.reject(new Error('backend-unavailable'));
    req = req || {};
    var transcript = String(req.transcript || '');
    var typed = String(req.typedNotes || '');
    var combined = (transcript + (transcript && typed ? '\n\n' : '') + typed).trim();
    return cb('/api/assist/note', { transcript: combined }).then(function (d) {
      d = d || {};
      if (d.error) throw new Error(d.error);
      var n = d.note || d;
      var text = n.soap || n.text || n.note || n.content || (typeof n === 'string' ? n : '');
      return { soap: text, text: text, insurance: n.insurance || '', em_level: n.em_level || n.em || '', icd10: n.icd10 || n.icd || [], cpt: n.cpt || [] };
    });
  }

  function overlayFocusTab(tabId) {
    try { chrome.tabs.update(tabId, { active: true }, function (t) { try { if (t && t.windowId != null) chrome.windows.update(t.windowId, { focused: true }); } catch (e) {} }); } catch (e) {}
    return Promise.resolve({ ok: true });
  }

  var matcher = fn('mlsMatchPatients');
  var ext = {
    // read open patient + ALL visits - drive the PROVEN v1.34 visits engine
    readAllVisits: (typeof self.__mlsOverlayReadVisits === 'function')
      ? function (opts) { opts = opts || {}; return self.__mlsOverlayReadVisits((opts.appTabId != null ? opts.appTabId : null), {}); }
      : (bind('runReadAllVisits') || bind('mlsRunReadAllVisits')),
    pasteNote:     (fn('mlsNotePaster') ? overlayPasteNote : (bind('runPasteNote') || bind('mlsRunPasteNote'))),
    readIdentity:  (fn('mlsReadChartIdentity') ? overlayReadIdentity : (bind('readChartIdentity'))),
    backendNote:   (fn('callBackend') ? overlayBackendNote : (bind('callBackendNote') || bind('mlsCallBackendNote'))),
    signSave:      (fn('mlsAthenaSignSave') ? overlaySignSave : null),
    validateCodes: bind('validateCodesViaApp'),
    saveVisits:    bind('saveVisitsViaApp'),
    findTab:       (fn('mlsPickEmrTab') ? overlayFindEmrTab : (bind('findAthenaTab') || bind('mlsFindAthenaTab'))),
    focusTab:      overlayFocusTab,
    // robust patient-gate helpers (reuse the conservative mlsMatchPatients logic)
    namesMatch:    matcher ? function (a, b) { try { var m = matcher({ name: a }, { name: b }); return !!(m && m.nameMatch === true); } catch (e) { return false; } } : bind('namesMatch'),
    dobsMatch:     matcher ? function (a, b) { try { var m = matcher({ dob: a }, { dob: b }); return !!(m && m.dobMatch === true); } catch (e) { return false; } } : bind('dobsMatch'),
    normDob:       function (s) { var m = /([01]?\d)[\/\-\.]([0-3]?\d)[\/\-\.](\d{2,4})/.exec(String(s || '')); if (!m) return ''; var y = m[3]; if (y.length === 2) y = (parseInt(y, 10) > 30 ? '19' : '20') + y; return ('0' + m[1]).slice(-2) + '/' + ('0' + m[2]).slice(-2) + '/' + y; },
    // Backend transcription of ONE complete §35 segment, using the doctor's JWT
    // (pulled from the mlsscribe tab, exactly as the rest of the worker does).
    // Contract: (Uint8Array|number[] bytes, mime) -> Promise<{ text }>.
    // The backend transcription endpoint is UNCHANGED - each segment is already
    // a complete, decodable file (the §35 fix). If this internal isn't present,
    // recording degrades HONESTLY to type-only (no fabricated transcript).
    transcribeSegment: bind('transcribeSegmentViaBackend') || bind('uploadAudioSegment') || bind('mlsTranscribeSegment')
  };

  // ---- v1.40 Sign & Save adapter: USER-INITIATED verified signing -----------
  // Re-reads the OPEN chart identity, re-checks it against the identity LOCKED at
  // "Go" (name + DOB), and only then injects the Sign & Save driver. Reports
  // signed:true ONLY when Athena confirmed the save/sign. Never autonomous.
  function overlaySignSave(opts) {
    opts = opts || {};
    var driver = fn('mlsAthenaSignSave');
    if (!driver || typeof chrome.scripting === 'undefined') return Promise.resolve({ error: 'sign-unavailable', message: 'Sign path unavailable - reload the extension.' });
    return overlayFindEmrTab().then(function (tab) {
      if (!tab) return { error: 'no-tab', message: 'No signed-in athenaOne tab is open.' };
      var mode = (opts.probe ? 'probe' : 'sign');
      return chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: driver, args: [mode] })
        .then(function (res) {
          var rs = (res || []).map(function (x) { return x && x.result; }).filter(Boolean);
          if (mode === 'probe') {
            var ready = rs.find(function (r) { return r && r.ready; }) || rs[0] || { ok: false };
            return ready;
          }
          var signed = rs.find(function (r) { return r && r.signed === true; });
          if (signed) return { ok: true, signed: true, observed: signed.observed };
          var clicked = rs.find(function (r) { return r && r.ok && r.reason === 'unconfirmed'; });
          if (clicked) return { ok: true, signed: false, reason: 'unconfirmed', message: clicked.msg };
          var none = rs.find(function (r) { return r && r.reason === 'no-control'; }) || rs[0] || { ok: false };
          return { ok: false, signed: false, reason: (none && none.reason) || 'sign-failed', message: (none && none.msg) || 'Could not complete Sign & Save in Athena.' };
        })
        .catch(function (e) { return { error: 'sign-exec-failed', message: String((e && e.message) || e) }; });
    });
  }

  function progress(tabId, message, kind) {
    try { chrome.tabs.sendMessage(tabId, { type: 'MLS_OVL_PROGRESS', message: message, kind: kind || 'run' }); } catch (e) {}
  }

  // ---- conservative identity match (reuse ext fns; safe fallback) ---------
  function identitiesMatch(a, b) {
    if (!a || !b || !a.name || !b.name) return false;
    var nameOk = ext.namesMatch ? !!ext.namesMatch(a.name, b.name)
      : norm(a.name) === norm(b.name);
    var da = ext.normDob ? ext.normDob(a.dob) : (a.dob || '');
    var db = ext.normDob ? ext.normDob(b.dob) : (b.dob || '');
    var dobOk = ext.dobsMatch ? !!ext.dobsMatch(a.dob, b.dob) : (!!da && da === db);
    return nameOk && dobOk;                 // require BOTH name and DOB
  }
  function norm(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9]/g, ''); }

  // ====================================================================== //
  //  NEW: coding-field driver (flag-gated). Types each code into Athena's   //
  //  Diagnoses/Orders/E-M pickers, selects the EXACT-code row, verifies it  //
  //  in the committed list. NEVER picks a near match. NEVER saves/signs.    //
  //  Returns {ok, added:[], missed:[{code,reason}]}. Real selectors are     //
  //  tuned in the one live athenaOne pass; until then the flag is OFF and   //
  //  callers receive {deferred:true}.                                       //
  // ====================================================================== //
  function writeCodes(tabId, codes) {
    // OFF until one real athenaOne selector-tuning pass (04_codes_writeback.md).
    if (!FLAGS.codesDriver) {
      return Promise.resolve({ deferred: true, added: [], missed: [] });
    }
    var driver = (typeof self !== 'undefined' && self.__mlsCodesDriver) ? self.__mlsCodesDriver : null;
    if (!driver || !ext.findTab || typeof chrome.scripting === 'undefined') {
      return Promise.resolve({ deferred: true, added: [], missed: [] });
    }
    var tab = ext.findTab();
    if (!tab) return Promise.resolve({ deferred: true, added: [], missed: [] });

    // serialize the content-scored page-side driver into the Athena frames,
    // one bounded phase at a time: find -> type -> (wait) -> select -> verify.
    function phase(p, step) {
      return chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        func: driver.codesPickerDriverFn,
        args: [step.kind, step.code, p]
      }).then(function (res) {
        // pick the first frame that returned a definitive result
        var hit = (res || []).map(function (x) { return x && x.result; })
                             .filter(function (r) { return r && (r.ok || r.reason); });
        return hit.find(function (r) { return r.ok; }) || hit[0] || { ok: false, reason: 'no-frame' };
      }).catch(function () { return { ok: false, reason: 'exec-failed' }; });
    }
    function driveOne(step) {
      return phase('type', step).then(function (t) {
        if (!t.ok) return t;
        return new Promise(function (r) { setTimeout(r, 2500); })       // bounded wait for the result list
          .then(function () { return phase('select', step); })
          .then(function (s) { if (!s.ok) return s; return phase('verify', step); });
      });
    }
    return driver.runCodes(codes, driveOne, function (m, k) { progress(tabId, m, k); });
  }

  // ====================================================================== //
  //  Intent router                                                         //
  // ====================================================================== //
  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || typeof msg.type !== 'string' || msg.type.indexOf('MLS_OVL_') !== 0) return;
    var tabId = sender && sender.tab && sender.tab.id;

    // ---------- STATUS (read-only, passive) ----------
    if (msg.type === 'MLS_OVL_STATUS') {
      Promise.resolve()
        .then(function () { return ext.findTab ? ext.findTab() : null; })
        .then(function (tab) {
          // passive: do NOT focus/navigate; just report what we can see
          var athenaOpen = !!tab;
          var patientOpen = false;
          // identity read is read-only; only attempt if a tab exists
          var idP = (athenaOpen && ext.readIdentity) ? ext.readIdentity(tab.id).catch(function () { return null; }) : Promise.resolve(null);
          return idP.then(function (id) {
            patientOpen = !!(id && id.name);
            if (patientOpen || !athenaOpen || typeof chrome.scripting === 'undefined') {
              sendResponse({ athenaOpen: athenaOpen, mlsApp: true, patientOpen: patientOpen, identity: (id && id.name) ? { name: id.name, dob: id.dob || '' } : null });
              return;
            }
            /* v1.50 fallback: identity text can be unreadable in some athena skins, but an
               open encounter/chart URL in ANY frame still proves a patient is open (fixes
               the overlay being stuck on "Open a patient in Athena"). */
            chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: function () { try { return location.href; } catch (e) { return ''; } } })
              .then(function (res) {
                var urls = (res || []).map(function (r) { return (r && r.result) || ''; });
                var open2 = urls.some(function (u) { return /\/encounter\/\d+|\/chart\/|patientid=\d+|\/patient\//i.test(u || ''); });
                sendResponse({ athenaOpen: athenaOpen, mlsApp: true, patientOpen: open2, identity: null });
              })
              .catch(function () { sendResponse({ athenaOpen: athenaOpen, mlsApp: true, patientOpen: false, identity: null }); });
          });
        })
        .catch(function () { sendResponse({ error: 'status-failed' }); });
      return true;
    }

    // ---------- GO: read patient + all visits (READ-ONLY) ----------
    if (msg.type === 'MLS_OVL_GO') {
      if (!ext.readAllVisits) { sendResponse({ ok: false, message: 'Reader unavailable — reload the extension.' }); return true; }
      progress(tabId, 'Reading the open patient…', 'run');
      /* v1.51 STALE-BINDING FIX: verify a patient chart is ACTUALLY open before
         reading/locking — a GO with no chart open used to bind whatever the
         reader last saw (live repro: locked "Corbin M." while Katz was wanted). */
      Promise.resolve()
        .then(function () { return ext.findTab ? ext.findTab() : null; })
        .then(function (tab) {
          if (!tab) return { block: 'No athenaOne tab is open — open athenaOne first.' };
          return (ext.readIdentity ? ext.readIdentity(tab.id).catch(function () { return null; }) : Promise.resolve(null))
            .then(function (id) {
              if (!id || !id.name) return { block: 'No patient chart is open in athenaOne — open the patient, then press Go. Nothing was read.' };
              return { ok: true };
            });
        })
        .then(function (pre) {
          if (pre && pre.block) { sendResponse({ ok: false, message: pre.block }); return; }
          return ext.readAllVisits({ onProgress: function (m) { progress(tabId, m, 'run'); } })
            .then(function (r) {
              r = r || {};
              if (!r.ok) { sendResponse({ ok: false, message: r.message || "Couldn't read this chart's visits — nothing saved." }); return; }
              if (tabId != null && r.identity) sess(tabId).lockedIdentity = r.identity;   // LOCK identity
              if (ext.saveVisits) { try { ext.saveVisits(r.visits, r.identity); } catch (e) {} }   // persist via app brain
              sendResponse({ ok: true, identity: r.identity, visits: r.visits, savedCount: (r.visits || []).length });
            });
        })
        .catch(function () { sendResponse({ ok: false, message: "Couldn't read this chart's visits — nothing saved." }); });
      return true;
    }

    // ---------- RECORD start/stop (reuses §35 recorder via offscreen doc) ----------
    if (msg.type === 'MLS_OVL_RECORD_START') { recordingTabId = tabId; startRecorder(tabId).then(function (r) { sendResponse(r); }); return true; }
    if (msg.type === 'MLS_OVL_RECORD_STOP')  { stopRecorder(tabId).then(function (r) { recordingTabId = null; sendResponse(r); }); return true; }

    // ---------- GENERATE: note + codes (backend, reuse) ----------
    if (msg.type === 'MLS_OVL_GENERATE') {
      if (!ext.backendNote) { sendResponse({ error: 'backend-unavailable', message: 'Note service unavailable.' }); return true; }
      progress(tabId, 'Writing the note…', 'run');
      ext.backendNote({ transcript: msg.transcript, typedNotes: msg.typedNotes })
        .then(function (note) {
          progress(tabId, 'Checking codes against your code sheet…', 'run');
          var vP = ext.validateCodes ? ext.validateCodes(note).catch(function () { return null; }) : Promise.resolve(null);
          return vP.then(function (codes) { sendResponse({ note: note, codes: codes }); });
        })
        .catch(function () { sendResponse({ error: 'generate-failed', message: "Couldn't generate the note." }); });
      return true;
    }

    // ---------- WRITEBACK: gate -> note paste -> codes (NEVER signs) ----------
    if (msg.type === 'MLS_OVL_WRITEBACK') {
      doWriteBack(tabId, msg).then(function (r) { sendResponse(r); })
        .catch(function () { sendResponse({ error: 'write-failed', message: 'Write failed.' }); });
      return true;
    }

    // ---------- FOCUS Athena tab (brings forward, clicks NOTHING) ----------
    if (msg.type === 'MLS_OVL_FOCUS_ATHENA') {
      Promise.resolve(ext.findTab ? ext.findTab() : null).then(function (tab) {
        if (tab && ext.focusTab) ext.focusTab(tab.id);
        sendResponse({ ok: true });
      });
      return true;
    }

    // ---------- SIGN & SAVE (USER-INITIATED ONLY; gated; verified) ----------
    // Fires ONLY because the doctor clicked "Sign and Save" in MLS (the overlay
    // "written" state, or the mlsscribe.com bridge) - never autonomously. Flow:
    // re-confirm the patient gate (name + DOB) against the identity locked at Go
    // OR the MLS active patient; (optionally) write the verified note; then
    // auto-click Athena's Sign & Save and report "signed" ONLY if Athena confirms.
    if (msg.type === 'MLS_OVL_SIGNSAVE') {
      if (msg.userInitiated !== true) { sendResponse({ error: 'not-user-initiated', message: 'Sign & Save must be triggered by your own click.' }); return true; }
      if (!(msg.probe === true && msg.note == null && msg.codes == null)) {
        sendResponse({ error: 'sign-route-disabled', blocked: true, signed: false, message: 'Automatic Save/Sign is disabled until exact encounter, provider and visit-date identity can be locked and verified. Review and sign directly in athenaOne.' });
        return true;
      }
      if (!ext.signSave) { sendResponse({ error: 'sign-unavailable', message: 'Sign path unavailable - reload the extension.' }); return true; }

      // Read the MLS active patient (read-only) as a gate target fallback.
      function readMlsActivePatient() {
        var reader = (typeof self.mlsReadActivePatient === 'function') ? self.mlsReadActivePatient : null;
        if (!reader || typeof chrome.scripting === 'undefined') return Promise.resolve(null);
        return chrome.tabs.query({ url: ['https://mlsscribe.com/*', 'https://*.mlsscribe.com/*'] })
          .then(function (mt) {
            mt = mt || []; mt.sort(function (a, b) { return (b.lastAccessed || 0) - (a.lastAccessed || 0); });
            var i = 0;
            function next() {
              if (i >= mt.length) return null;
              var t = mt[i++];
              return chrome.scripting.executeScript({ target: { tabId: t.id }, func: reader })
                .then(function (r) { var v = r && r[0] && r[0].result; if (v && (v.name || v.dob)) return v; return next(); })
                .catch(function () { return next(); });
            }
            return next();
          }).catch(function () { return null; });
      }

      var locked = (tabId != null && sessions[tabId]) ? sessions[tabId].lockedIdentity : null;
      var targetP = locked ? Promise.resolve(locked)
        : (msg.mlsIdentity && msg.mlsIdentity.name) ? Promise.resolve(msg.mlsIdentity)
        : readMlsActivePatient();

      Promise.all([targetP, Promise.resolve(ext.findTab ? ext.findTab() : null)])
        .then(function (pair) {
          var target = pair[0], tab = pair[1];
          var readP = (tab && ext.readIdentity) ? ext.readIdentity(tab.id) : Promise.resolve(null);
          return readP.then(function (chartId) {
            var confident = target && target.name && chartId && chartId.name && identitiesMatch(target, chartId);
            if (!confident) {
              progress(tabId, '⛔ Could not confirm this is the right patient - did NOT write or sign.', 'fail');
              return { blocked: true, signed: false, mlsIdentity: target || null, chartIdentity: chartId || null,
                       message: 'Patient gate failed (name + DOB) - refusing to sign this chart.' };
            }
            // optional verified note write FIRST (gate already satisfied)
            var writeP = (msg.note != null && ext.pasteNote)
              ? (progress(tabId, '✓ Confirmed - writing the note before signing...', 'ok'), ext.pasteNote({ note: msg.note }))
              : Promise.resolve(null);
            return writeP.then(function (wr) {
              if (wr && wr.error) return { error: wr.error, signed: false, message: wr.error + ' - did NOT sign.' };
              progress(tabId, 'Signing & saving in athenaOne...', 'run');
              return ext.signSave({ probe: !!msg.probe }).then(function (r) {
                r = r || {};
                if (r.signed === true) progress(tabId, '✓ Athena confirmed - signed & saved.', 'ok');
                else progress(tabId, (r.message || 'Could not confirm signing - check Athena before relying on it.'), 'warn');
                if (wr && wr.sections) r.note = { sections: wr.sections };
                return r;
              });
            });
          });
        })
        .then(function (r) { sendResponse(r || { error: 'sign-failed', signed: false }); })
        .catch(function (e) { sendResponse({ error: 'sign-failed', signed: false, message: String((e && e.message) || e) }); });
      return true;
    }
  });

  // ====================================================================== //
  //  Increment 3 — offscreen §35 segmented recorder orchestration.          //
  //  BG owns the offscreen doc lifecycle + the authenticated upload; the    //
  //  offscreen doc owns mic capture + segmentation. Transcript text only    //
  //  ever comes from a REAL backend response (no fabrication).              //
  // ====================================================================== //
  var OFFSCREEN_PATH = 'offscreen.html';

  function hasOffscreenApi() {
    return (typeof chrome !== 'undefined' && chrome.offscreen &&
            typeof chrome.offscreen.createDocument === 'function');
  }

  function ensureOffscreen() {
    if (!hasOffscreenApi()) return Promise.resolve(false);
    // Avoid creating a second offscreen document if one already exists.
    var checkP;
    if (chrome.runtime.getContexts) {
      checkP = chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] })
        .then(function (ctxs) { return ctxs && ctxs.length > 0; })
        .catch(function () { return false; });
    } else if (typeof chrome.offscreen.hasDocument === 'function') {
      checkP = chrome.offscreen.hasDocument().catch(function () { return false; });
    } else {
      checkP = Promise.resolve(false);
    }
    return checkP.then(function (exists) {
      if (exists) return true;
      return chrome.offscreen.createDocument({
        url: OFFSCREEN_PATH,
        reasons: ['USER_MEDIA'],
        justification: 'Record the visit audio in complete §35 segments for backend transcription.'
      }).then(function () { return true; }).catch(function () { return false; });
    });
  }

  function closeOffscreen() {
    if (!hasOffscreenApi() || typeof chrome.offscreen.closeDocument !== 'function') return Promise.resolve();
    return chrome.offscreen.closeDocument().catch(function () {});
  }

  function startRecorder(tabId) {
    if (!hasOffscreenApi()) {
      // Honest degrade: no offscreen support -> type-only. Never fake a transcript.
      progress(tabId, 'Mic capture unavailable here — type your note instead.', 'warn');
      return Promise.resolve({ ok: false, reason: 'no-offscreen', typeOnly: true });
    }
    return ensureOffscreen().then(function (ready) {
      if (!ready) {
        progress(tabId, 'Couldn’t start the recorder — type your note instead.', 'warn');
        return { ok: false, reason: 'offscreen-failed', typeOnly: true };
      }
      progress(tabId, 'Recording… (talk through the visit)', 'run');
      return new Promise(function (resolve) {
        try {
          chrome.runtime.sendMessage({ type: 'MLS_OFFSCREEN_START' }, function (r) {
            if (chrome.runtime.lastError || !r || r.ok === false) {
              var reason = (r && r.reason) || 'recorder-start-failed';
              progress(tabId, reason === 'mic-denied'
                ? 'Microphone blocked — allow mic access or type your note.'
                : 'Couldn’t start the mic — type your note instead.', 'warn');
              resolve({ ok: false, reason: reason, typeOnly: true });
            } else { resolve({ ok: true }); }
          });
        } catch (e) { resolve({ ok: false, reason: 'recorder-start-failed', typeOnly: true }); }
      });
    });
  }

  function stopRecorder(tabId) {
    if (!hasOffscreenApi()) return Promise.resolve({ ok: true });
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage({ type: 'MLS_OFFSCREEN_STOP' }, function (r) {
          // close the doc to release the mic; ignore errors
          closeOffscreen().then(function () { resolve(r || { ok: true }); });
        });
      } catch (e) { closeOffscreen().then(function () { resolve({ ok: true }); }); }
    });
  }

  // ---- segments + errors coming back FROM the offscreen recorder ----------
  //      (a second listener; returns nothing for non-offscreen messages so it
  //       never interferes with the intent router above — the §136 convention)
  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || msg.from !== 'mls-offscreen') return;

    if (msg.type === 'MLS_OFFSCREEN_SEGMENT') {
      var tabId = recordingTabId;
      if (!ext.transcribeSegment) {
        // HONEST: capture works but the backend uploader isn't bound here.
        // Do NOT invent text. Tell the doctor once and let them type.
        if (tabId != null) progress(tabId, 'Captured audio, but transcription isn’t wired in this build — type your note.', 'warn');
        return; // no async response needed
      }
      Promise.resolve(ext.transcribeSegment(msg.bytes, msg.mime))
        .then(function (res) {
          var text = res && (res.text || res.transcript || '');
          if (text && tabId != null) {
            chrome.tabs.sendMessage(tabId, { type: 'MLS_OVL_TRANSCRIPT', text: text, append: true, seq: msg.seq });
          }
        })
        .catch(function () {
          if (tabId != null) progress(tabId, 'A segment didn’t transcribe — kept recording.', 'warn');
        });
      return;
    }

    if (msg.type === 'MLS_OFFSCREEN_ERROR') {
      var tid = recordingTabId;
      if (tid != null) {
        var human = msg.reason === 'mic-denied'
          ? 'Microphone blocked — allow mic access or type your note.'
          : 'Mic problem — type your note instead.';
        progress(tid, human, 'warn');
        try { chrome.tabs.sendMessage(tid, { type: 'MLS_OVL_RECORD_ERROR', reason: msg.reason }); } catch (e) {}
      }
      return;
    }
  });

  function doWriteBack(tabId, msg) {
    if (!ext.pasteNote) return Promise.resolve({ error: 'paste-unavailable', message: 'Write path unavailable — reload the extension.' });
    progress(tabId, 'Confirming this is the right chart…', 'run');

    // ---- HARD patient-match gate (re-read current chart vs lockedIdentity) ----
    var locked = (tabId != null && sessions[tabId]) ? sessions[tabId].lockedIdentity : null;
    // read the CURRENT open chart identity fresh from the Athena tab (read-only)
    return Promise.resolve(ext.findTab ? ext.findTab() : null).then(function (tab) {
      var readP = (tab && ext.readIdentity) ? ext.readIdentity(tab.id) : Promise.resolve(null);
      return readP.then(function (chartId) {
        var matchTarget = locked || null;
        var confident = matchTarget && chartId && identitiesMatch(matchTarget, chartId);
        if (!confident) {
          return { blocked: true, mlsIdentity: matchTarget, chartIdentity: chartId };
        }
        // ---- write the NOTE (segmented router handled inside pasteNote) ----
        progress(tabId, '✓ Confirmed — writing the note…', 'ok');
        return ext.pasteNote({ note: msg.note }).then(function (resp) {
          resp = resp || {};
          var sections = (resp.sections) ? resp.sections : [{
            section: resp.chosenSection || resp.into || 'note field',
            confirmed: !!resp.confirmed
          }];
          if (resp.error) return { error: resp.error, message: resp.error };
          // ---- write CODES (flag-gated) ----
          return writeCodes(tabId, msg.codes || (msg.note && { icd10: msg.note.icd10, cpt: msg.note.cpt, em_level: msg.note.em_level }))
            .then(function (codeRes) {
              return { note: { sections: sections }, codes: codeRes };
            });
        });
      });
    });
  }
})();


/* =========================================================================
 * MLS Assist v1.50 — version reporting + patient picker  (APPEND-ONLY)
 *  A) Version reporting: POSTs {component:'mls-assist', version} to the MLS
 *     backend /api/versions/report on install/startup + every 12h, and the
 *     content bridge announces the version to the MLS app page — powers the
 *     app's update-reminder row in Settings -> MLS Controls. Fire-and-forget;
 *     tolerates the endpoint not existing yet (older backend) silently.
 *  B) Patient picker: MLS_OVL_LIST_PATIENTS reads TODAY'S schedule from the
 *     open mlsscribe.com tab (no PHI leaves the browser); MLS_OVL_OPEN_PATIENT
 *     clicks/searches that patient open in athenaOne (NAVIGATION ONLY — the
 *     open helper only clicks patient-name elements / types into a patient
 *     SEARCH box, never Save/Sign/order controls) and reports the open chart's
 *     identity so the overlay can confirm the right patient is up.
 * ========================================================================= */
(function () {
  'use strict';
  if (typeof chrome === 'undefined' || !chrome.runtime) return;
  if (self.__mlsV150Installed) return; self.__mlsV150Installed = true;
  var VER = ''; try { VER = chrome.runtime.getManifest().version; } catch (e) {}

  function reportVersion() {
    try {
      fetch('https://scrivara-backend.onrender.com/api/versions/report', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ component: 'mls-assist', version: VER })
      }).catch(function () {});
    } catch (e) {}
  }
  try { chrome.runtime.onStartup.addListener(reportVersion); } catch (e) {}
  try { chrome.runtime.onInstalled.addListener(reportVersion); } catch (e) {}
  try {
    if (chrome.alarms) {
      chrome.alarms.create('mlsVersionReport', { periodInMinutes: 720 });
      chrome.alarms.onAlarm.addListener(function (a) { if (a && a.name === 'mlsVersionReport') reportVersion(); });
    }
  } catch (e) {}
  reportVersion();

  /* ---- injected: read TODAY'S patients from the MLS app tab (read-only) ---- */
  function mlsListTodayFn() {
    try {
      var out = [], seen = {};
      var d = new Date(); var td = d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
      var A = window._calAppts || [];
      A.forEach(function (a) {
        if (!a) return;
        var dt = String(a.date || a.appt_date || '');
        if (dt.indexOf(td) < 0) return;
        var nm = String(a.patient || a.name || '').trim();
        if (!nm || seen[nm.toLowerCase()]) return; seen[nm.toLowerCase()] = 1;
        out.push({ name: nm.slice(0, 60), time: String(a.time || '').slice(0, 12), prov: String(a.provider || '').slice(0, 40) });
      });
      return out.slice(0, 120);
    } catch (e) { return []; }
  }

  /* ---- injected: open ONE patient by name (same rules as the chart-request
     opener: click a visible patient-name element, else type into a patient
     SEARCH box — never a numeric/ID field, never action buttons) ---- */
  function mlsV150OpenFn(name) {
    try {
      var parts = name.toLowerCase().replace(/[^a-z\s,]/g, '').split(/[\s,]+/).filter(Boolean);
      if (!parts.length) return 'no';
      var last = parts[parts.length - 1], first = parts[0];
      var els = Array.prototype.slice.call(document.querySelectorAll('a,button,[role="link"],[role="button"],[onclick],td,li,span,div'));
      for (var i = 0; i < els.length; i++) {
        var el = els[i];
        var t = (el.innerText || el.textContent || '').trim().toLowerCase();
        if (t && t.length < 70 && t.indexOf(last) >= 0 && (parts.length < 2 || t.indexOf(first) >= 0)) {
          var r = el.getBoundingClientRect(); if (r.width > 0 && r.height > 0) { el.click(); return 'clicked'; }
        }
      }
      var inputs = Array.prototype.slice.call(document.querySelectorAll('input[type="text"],input[type="search"],input:not([type])'));
      for (var k = 0; k < inputs.length; k++) {
        var inp = inputs[k];
        var h = ((inp.placeholder || '') + ' ' + (inp.name || '') + ' ' + (inp.getAttribute('aria-label') || '') + ' ' + (inp.id || '')).toLowerCase();
        var rr = inp.getBoundingClientRect(); var tp = (inp.type || '').toLowerCase();
        if (rr.width <= 0 || rr.height <= 0) continue;
        if (tp === 'number' || tp === 'tel' || tp === 'date' || tp === 'email' || tp === 'password') continue;
        if ((inp.inputMode || '').toLowerCase() === 'numeric') continue;
        if (/patient\s*id|patientid|\bid\b|\bmrn\b|chart\s*(id|no|num)|\bnpi\b|account|claim|invoice|\bnumber\b|ssn|\bdob\b/.test(h)) continue;
        if (!/search|name|find|look\s*up|lookup|filter|patient/.test(h)) continue;
        inp.focus(); inp.value = name;
        inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true }));
        ['keydown', 'keypress', 'keyup'].forEach(function (tpe) { inp.dispatchEvent(new KeyboardEvent(tpe, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true })); });
        return 'searched';
      }
      return 'no';
    } catch (e) { return 'no'; }
  }

  function readIdent(tabId) {
    if (typeof mlsReadChartIdentity !== 'function' || typeof chrome.scripting === 'undefined') return Promise.resolve(null);
    return chrome.scripting.executeScript({ target: { tabId: tabId, allFrames: true }, func: mlsReadChartIdentity })
      .then(function (res) {
        var best = mlsBestIdentityFrom(res); /* v1.59: banner-preferred */
        return best ? { name: best.name, dob: best.dob || '' } : null;
      }).catch(function () { return null; });
  }

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || typeof msg.type !== 'string') return;

    if (msg.type === 'MLS_OVL_LIST_PATIENTS') {
      (async function () {
        try {
          var all = await chrome.tabs.query({});
          var app = all.find(function (t) { return /mlsscribe\.com/i.test(t.url || ''); });
          if (!app) return sendResponse({ ok: false, error: 'Open mlsscribe.com in another tab first (it holds today\u2019s schedule).' });
          var res = await chrome.scripting.executeScript({ target: { tabId: app.id }, func: mlsListTodayFn });
          var list = (res && res[0] && res[0].result) || [];
          sendResponse({ ok: true, patients: list, version: VER });
        } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
      })();
      return true;
    }

    if (msg.type === 'MLS_OVL_OPEN_PATIENT') {
      (async function () {
        try {
          var all = await chrome.tabs.query({});
          var tab = (typeof mlsPickAthenaTab === 'function') ? (await mlsPickAthenaTab(all, { athenaOnly: true })) : ((typeof mlsPickEmrTab === 'function') ? mlsPickEmrTab(all) : null);
          if (!tab || !/athena/i.test(((tab.url || '') + ' ' + (tab.title || '')))) return sendResponse({ ok: false, error: 'No signed-in athenaOne tab is open.' });
          var want = String(msg.name || '').trim().slice(0, 80);
          if (!want) return sendResponse({ ok: false, error: 'No patient name given.' });
          var opened = false, statuses = [];
          try { var r1 = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: mlsV150OpenFn, args: [want] }); statuses = (r1 || []).map(function (r) { return r && r.result; }); } catch (e) {}
          if (statuses.indexOf('clicked') >= 0) { opened = true; await new Promise(function (r) { setTimeout(r, 1900); }); }
          else if (statuses.indexOf('searched') >= 0) {
            await new Promise(function (r) { setTimeout(r, 2600); });
            try { var r2 = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: mlsV150OpenFn, args: [want] }); if ((r2 || []).map(function (r) { return r && r.result; }).indexOf('clicked') >= 0) { opened = true; await new Promise(function (r) { setTimeout(r, 1900); }); } } catch (e) {}
          }
          var ident = await readIdent(tab.id);
          sendResponse({ ok: true, opened: opened, identity: ident, version: VER });
        } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
      })();
      return true;
    }
  });
})();


/* =========================================================================
 * MLS Assist v1.89 - mlsDismissNavMenuFn (injected; allFrames, ISOLATED world
 * is fine: synthetic Escape/click events cross worlds, and NO link/control is
 * ever clicked). This user's athenaOne can sit with the Calendar top-nav
 * dropdown OPEN, overlaying the surfaces the schedule scan reads (the menu
 * panel renders on demand and does NOT live in the globalnav frame's DOM, so
 * allFrames is required to reach whichever frame hosts it).
 * GATE (wf_6 tightening): acts ONLY when a VISIBLE overlaying element matching
 * [role=menu] / [class*=menu] with computed position fixed/absolute and
 * height > 60 exists in THIS frame - bare [aria-expanded=true] is NOT used
 * (it matches healthy drawers/accordions), so frames without a real menu
 * overlay are strictly zero-touch (no stray Escape into chart-frame modals).
 * ACTION: Escape keydown/keyup on the document, then ONE neutral click at the
 * (1,1) corner ONLY if elementFromPoint(1,1) is document.body/documentElement
 * (wf_6: never click anything that could be a control).
 * FUTURE NOTE (wf_4/wf_6): if this is ever escalated to clicking the Calendar
 * menu TOGGLE itself (a nav control / javascript:-style link), that click
 * MUST move to world:'MAIN' per the documented isolated-world rule - the
 * current isolated-world dispatch is acceptable ONLY because nothing
 * interactive is clicked. */
function mlsDismissNavMenuFn(requestGuard) {
  try {
    var guard = Object.freeze({ deadline: Number(requestGuard && requestGuard.deadline || 0), token: String(requestGuard && requestGuard.token || '') });
    function actionAllowed() { return !!guard.token && Number.isFinite(guard.deadline) && Date.now() < guard.deadline; }
    if (!actionAllowed()) return { dismissed: false, seen: 0, clicked: false, reason: 'open-deadline-exceeded' };
    var out = { dismissed: false, seen: 0, clicked: false, frame: '' };
    try { out.frame = String(location.pathname || '').slice(0, 80); } catch (e0) {}
    function vis(el) { try { var r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; var s = getComputedStyle(el); return s.display !== 'none' && s.visibility !== 'hidden'; } catch (e) { return false; } }
    var cands = [];
    try { cands = [].slice.call(document.querySelectorAll('[role=menu],[class*="menu" i]')); } catch (e1) {}
    var open = [];
    for (var i = 0; i < cands.length; i++) {
      var el = cands[i];
      if (!vis(el)) continue;
      try {
        var s = getComputedStyle(el);
        if (s.position !== 'fixed' && s.position !== 'absolute') continue; /* must OVERLAY content */
        if (el.getBoundingClientRect().height <= 60) continue;             /* real panel, not a chip */
        open.push(el);
      } catch (e2) {}
    }
    out.seen = open.length;
    if (!open.length) return out; /* nothing to do - zero-touch */
    if (!actionAllowed()) return { dismissed: false, seen: open.length, clicked: false, reason: 'open-deadline-exceeded' };
    var ko = { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true, cancelable: true };
    ['keydown', 'keyup'].forEach(function (t) {
      if (!actionAllowed()) return;
      try { (document.activeElement || document.body).dispatchEvent(new KeyboardEvent(t, ko)); } catch (e3) {}
      try { document.dispatchEvent(new KeyboardEvent(t, ko)); } catch (e4) {}
    });
    /* neutral click at the (1,1) corner - ONLY onto bare body/documentElement */
    try {
      var tgt = document.elementFromPoint(1, 1);
      if (actionAllowed() && (tgt === document.body || tgt === document.documentElement)) {
        var o = { bubbles: true, cancelable: true, view: window, clientX: 1, clientY: 1 };
        ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) {
          if (!actionAllowed()) return;
          try { tgt.dispatchEvent(new (tp.indexOf('pointer') === 0 ? PointerEvent : MouseEvent)(tp, o)); } catch (e5) {}
        });
        out.clicked = true;
      }
    } catch (e6) {}
    out.dismissed = true;
    return out;
  } catch (e) { return { dismissed: false, seen: -1, error: String((e && e.message) || e).slice(0, 80) }; }
}


/* =========================================================================
 * MLS Assist v1.89 - mlsReadVisitsPaneDriverFn (injected, world:'MAIN', TOP
 * frame of the athena tab). READ-ONLY reader of the open chart's left-rail
 * "Visits" pane ("Visits and Cases", light DOM - live-verified 07-10).
 * Self-contained: chrome.scripting serializes this function alone, so NO
 * background helper (mlsExecTO / mlsBestIdentityFrom / nmm...) exists in here.
 * CONSTRAINTS (live-verified):
 *  - The caller MUST wrap this injection in an mlsExecTO-style timeout (the
 *    athenaOne renderer can freeze 45+ seconds after heavy interactions) and
 *    must never assume the tab is responsive.
 *  - The athenaOne tab should be VISIBLE/FOREGROUND for the duration of the
 *    read: the sleep() waits below ride the page's setTimeout, and Chrome
 *    clamps hidden-tab timers (>=1s, down to 1/min under intensive
 *    throttling) - a long-hidden tab can eat the whole budget in waits.
 *    All waits are ABSOLUTE Date.now() deadlines, never counted ticks.
 *  - Identity is verified IN HERE, on the live DOM, immediately before the
 *    rail click - refuses honestly on any mismatch; never reads first.
 *  - Clicks ONLY the left-rail item labeled exactly "Visits" (BAD-blocklist
 *    guarded). Never Save/Sign/orders/check-in. The click NAVIGATES the chart
 *    frame to the Visits pane: app-side ordering must be ReadChart FIRST,
 *    ReadVisits second, per patient.
 *  - If the rail item cannot be found: ok:false reason 'no-rail'. There is NO
 *    silent fallback to reading whatever surface is on screen (wf_6). */
async function mlsReadVisitsPaneDriverFn(name, dob, athenaId) {
  try {
    var T0 = Date.now();
    /* Bounded for renderer safety, but high enough that an ordinary long-term
       chart is never silently truncated. Completeness is reconciled against
       Athena's declared All Events count below. */
    var CAP = 500;
    function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
    if (!String(name || '').trim()) return { ok: false, reason: 'no-patient', error: 'mlsReadVisitsPaneDriverFn requires the requested patient name - refusing an un-gated visits read.' };
    /* ---- normalizers (inline; no background helpers exist in an injected fn) */
    function nrmName(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim(); }
    function nameMatch(a, b) {
      var ta = nrmName(a).split(' ').filter(function (x) { return x.length > 1; });
      var tb = nrmName(b).split(' ').filter(function (x) { return x.length > 1; });
      var o = ta.filter(function (x) { return tb.indexOf(x) >= 0; }).length;
      return o >= 2 || (o >= 1 && Math.min(ta.length, tb.length) === 1);
    }
    function nrmDob(s) {
      var m = /([01]?\d)[\/\-\.]([0-3]?\d)[\/\-\.](\d{2,4})/.exec(String(s || ''));
      if (!m) return '';
      /* v1.89 (wf_4): DYNAMIC 2-digit-year pivot - anything "after next year"
         is 19xx. Never ship the hardcoded >26 pivot again. */
      var pivot = (new Date().getFullYear() % 100) + 1;
      var y = m[3].length === 2 ? ((Number(m[3]) > pivot ? '19' : '20') + m[3]) : m[3];
      var mo = Number(m[1]), dy = Number(m[2]);
      if (mo < 1 || mo > 12 || dy < 1 || dy > 31) return '';
      return mo + '/' + dy + '/' + y;
    }
    function nrmText(s) { return String(s || '').replace(/[\u200B-\u200D\u2060\uFEFF]/g, '').replace(/\s+/g, ' ').trim().toLowerCase(); }
    /* ---- 1) locate the chart content frame: deepest big same-origin frame,
       skipping nav/status/results frames (same recursive walk as the proven
       mlsFindPatientOpenDriverFn, + findpatient.esp in SKIP). Also remember
       every accessible frame for the identity scan. */
    var SKIP = /globalnav|statusbar|stm\.esp|schedulenavclose|coordinator\/enterprise|blank\.html|findpatient\.esp/i;
    var JUNK = /letter|athenatext|communicat|\bfax|printer|documentviewer|clinicaldocument|inbox|messag/i;
    var best = null, allFr = [];
    (function walk(w, depth) {
      if (depth > 6) return;
      for (var i = 0; i < w.frames.length; i++) {
        var f = w.frames[i];
        try {
          void f.document;
          allFr.push(f);
          var p = String(f.location.pathname || '');
          var el = f.frameElement; var r = el ? el.getBoundingClientRect() : null;
          var area = r ? (r.width * r.height) : 0;
          if (!SKIP.test(p) && area > 150000) {
            if (!best || depth > best.depth || (depth === best.depth && area > best.area)) best = { w: f, depth: depth, area: area };
          }
          walk(f, depth + 1);
        } catch (e) {}
      }
    })(window, 0);
    var W = (best && best.w) || window;
    /* ---- 2) compact shadow-aware LINE collector (inline; same walker shape
       as the live-proven mlsReadChartIdentityShadow: block tags break lines,
       <slot>s flatten, open shadow roots descend; bounded so a struggling
       renderer is never asked for more than ~8000 text nodes per document). */
    function docLines(doc, cap) {
      var BLOCK = /^(div|p|li|tr|td|th|section|header|footer|h[1-6]|ul|ol|table|article|aside|nav|form|fieldset|dl|dt|dd|pre|address|hr|br)$/;
      var out = { items: [], n: 0 };
      function coll(root, depth) {
        if (depth > 25 || out.n > cap) return;
        var kids = root.childNodes || [];
        for (var k = 0; k < kids.length; k++) {
          if (out.n > cap) return;
          var n = kids[k];
          if (n.nodeType === 3) { var s = String(n.nodeValue || '').replace(/\s+/g, ' ').trim(); if (s) { out.items.push({ t: s }); out.n++; } }
          else if (n.nodeType === 1) {
            var tag = (n.tagName || '').toLowerCase();
            if (tag === 'script' || tag === 'style') continue;
            var isB = BLOCK.test(tag);
            if (isB) { out.items.push({ nl: 1 }); out.n++; }
            try {
              if (tag === 'slot' && n.assignedNodes) {
                var an = n.assignedNodes({ flatten: true });
                for (var a = 0; a < an.length; a++) {
                  if (an[a].nodeType === 3) { var s2 = String(an[a].nodeValue || '').replace(/\s+/g, ' ').trim(); if (s2) { out.items.push({ t: s2 }); out.n++; } }
                  else if (an[a].nodeType === 1) coll(an[a], depth + 1);
                }
              } else if (n.shadowRoot) coll(n.shadowRoot, depth + 1);
              else coll(n, depth + 1);
            } catch (e) {}
            if (isB) { out.items.push({ nl: 1 }); out.n++; }
          }
        }
      }
      try { coll(doc.body || doc, 0); } catch (e) {}
      var lines = [], cur = [];
      for (var x = 0; x < out.items.length; x++) {
        if (out.items[x].nl) { if (cur.length) { lines.push(cur.join(' ')); cur = []; } }
        else cur.push(out.items[x].t);
      }
      if (cur.length) lines.push(cur.join(' '));
      return lines;
    }
    /* ---- 3) inline identity from the banner CHIP line ("20yo M | 03-24-2006
       | #7833832" - live-verified: the #id equals the stable athena patient id,
       NOT an encounter number). Name = SMALLEST join of the 1-3 lines rendered
       directly above the chip (kk=1..3 - never glue a badge line onto the
       name; wf_1 finding 3 fixed here, not replicated). */
    function identFrom(lines) {
      var AGE_CHIP = /\b(\d{1,3})\s*(?:yo|y\/o|yrs?\.?|years?\s*old)\b/i;
      var BARE_DATE = /\b([01]?\d)[\/\-\.]([0-3]?\d)[\/\-\.](\d{4})\b/;
      var MRN_HASH = /#\s?(\d{4,})/;
      var STOP1 = /^(please|the|new|find|create|search|no|today|welcome|inbox|schedule|calendar|department|provider|patient|results|appointment|encounter|billing|orders|messages|close|camera|panel|visits|history)$/i;
      var PROVCRED = /^(MD|DO|PA|PAC|NP|CRNA|APRN|DPM|DDS|DMD|RN|CRNP|FNP|DNP|PHD|MBBS|OD|MSN|LPN|CNM|DC|DPT|DR|PHYS|PT)$/i;
      function okName(cand) {
        if (!cand || cand.length < 4 || cand.length > 60) return '';
        if (!/^([A-Z][A-Za-z'\-\.]*(?:\s+[A-Z][A-Za-z'\-\.]*){1,3})$/.test(cand)) return '';
        var toks = cand.replace(/,/g, ' ').split(/\s+/);
        for (var q = 0; q < toks.length; q++) { if (STOP1.test(toks[q])) return ''; }
        if (PROVCRED.test(toks[toks.length - 1].replace(/[.\-]/g, ''))) return '';
        if (/^DR\.?$/i.test(toks[0])) return '';
        return cand;
      }
      /* v1.89.4/.5 (live, Bob Dunne): the banner can render MULTIPLE chip
         instances with different name shapes above them - the collapsed strip
         gives "DUNNE"/"Legal:"/"Robert DUNNE" while the expanded drawer gives
         "Bob Dunne Legal: Robert Dunne". Returning only the FIRST parse
         ("Robert DUNNE") made the gate refuse the roster name ("Bob Dunne").
         So: collect candidates from EVERY chip instance, split "X Legal: Y"
         combos into BOTH names, strip parens into tokens ("Robert (Bob)"),
         and return them ALL - the caller matches any. */
      var out = [];
      for (var i = 0; i < lines.length && out.length < 8; i++) {
        if (!AGE_CHIP.test(lines[i]) || !BARE_DATE.test(lines[i])) continue;
        var bd = BARE_DATE.exec(lines[i]);
        var mh = MRN_HASH.exec(lines[i]);
        var dobS = ('0' + bd[1]).slice(-2) + '/' + ('0' + bd[2]).slice(-2) + '/' + bd[3];
        var mrnS = (mh && mh[1]) || '';
        for (var kk = 1; kk <= 3; kk++) {
          if (i - kk < 0) break;
          var joined = lines.slice(i - kk, i).join(' ').replace(/[()]/g, ' ').replace(/\s+/g, ' ').trim();
          var parts = joined.split(/legal\s*:/i).map(function (s) { return s.replace(/\s+/g, ' ').trim(); }).filter(Boolean);
          for (var pp = 0; pp < parts.length; pp++) {
            var nm = okName(parts[pp]);
            if (nm && !out.some(function (o) { return o.name === nm; })) out.push({ name: nm, dob: dobS, mrn: mrnS });
          }
        }
      }
      return out;
    }
    /* scan order: chart content frame first, then other non-skip non-junk
       frames (junk letters/messaging frames can carry OTHER patients' names
       and are excluded entirely), then the top document. First hit wins. */
    var scanWs = [];
    if (best && best.w) scanWs.push(best.w);
    for (var fi = 0; fi < allFr.length && scanWs.length < 9; fi++) {
      try {
        var pth = String(allFr[fi].location.pathname || '');
        if (allFr[fi] !== W && !SKIP.test(pth) && !JUNK.test(pth)) scanWs.push(allFr[fi]);
      } catch (eS) {}
    }
    scanWs.push(window);
    /* v1.89.2/.3 (live fixes, same day): the airlock banner renders ASYNC
       after a fresh findpatient open - a single-shot scan raced it and refused
       'unverified' (live: Bob backfill), and a naive retry then locked onto
       the PREVIOUS chart's stale banner and refused 'wrong-chart' while Bob's
       banner was still rendering. So: keep scanning until the identity
       MATCHES the requested patient or the deadline passes; only then refuse
       (wrong-chart if a stable different banner, unverified if none). The
       caller's 90s mlsExecTO still bounds the whole driver. */
    var ident = null, lastSeen = null, nameOnlyHit = null;
    var identDeadline = Date.now() + 15000;
    var wantDobPre = nrmDob(dob);
    while (!ident && Date.now() < identDeadline) {
      for (var si = 0; si < scanWs.length && !ident; si++) {
        var candList = [];
        try { candList = identFrom(docLines(scanWs[si].document, 8000)) || []; } catch (eI) {}
        for (var ci = 0; ci < candList.length; ci++) {
          if (candList[ci] && candList[ci].name) {
            if (!lastSeen) lastSeen = candList[ci];
            if (nameMatch(candList[ci].name, String(name || ''))) {
              /* v2.02 de-race: banner surfaces can expose SEVERAL name-matching
                 chip candidates whose nearby dates differ (appointment dates on
                 the briefing surface vs the real DOB chip - live: two corrected-
                 DOB patients refused wrong-dob on backfill opens then passed on
                 settled reads). When the caller supplied a DOB, keep scanning
                 until a candidate CONFIRMS it; a name-only candidate is kept as
                 the fallback and still refuses honestly at the deadline. Never
                 laxer: the accepted candidate must match name AND requested DOB. */
              if (!wantDobPre) { ident = candList[ci]; break; }
              if (nrmDob(candList[ci].dob) === wantDobPre) { ident = candList[ci]; break; }
              if (!nameOnlyHit) nameOnlyHit = candList[ci];
            }
          }
        }
      }
      if (!ident) await sleep(800);
    }
    if (!ident && nameOnlyHit) ident = nameOnlyHit; /* deadline: fall back to the name-matched candidate -> the DOB gate below refuses honestly */
    /* ---- 4) IDENTITY GATE - refuse honestly BEFORE any click/read ---------- */
    if (!ident || !ident.name) {
      if (lastSeen && lastSeen.name) return { ok: false, reason: 'wrong-chart', chartName: lastSeen.name, chartDob: lastSeen.dob || '', chartMrn: lastSeen.mrn || '', error: 'The open athenaOne chart is ' + lastSeen.name + ', not ' + name + '. No visits were read.' };
      return { ok: false, reason: 'unverified', error: 'No readable patient identity (banner chip) on the open athenaOne chart - refusing to read visits. Nothing was captured.' };
    }
    var wantDob = nrmDob(dob);
    if (wantDob) {
      var haveDob = nrmDob(ident.dob);
      /* wf_6: a requested DOB that the chart cannot confirm is a REFUSAL, not
         a pass-through - reason 'unverified-dob'. */
      if (!haveDob) return { ok: false, reason: 'unverified-dob', chartName: ident.name, chartMrn: ident.mrn || '', error: 'A DOB was requested but the open chart shows no readable DOB - refusing to read visits without full verification.' };
      if (haveDob !== wantDob) return { ok: false, reason: 'wrong-dob', chartName: ident.name, chartDob: ident.dob || '', chartMrn: ident.mrn || '', error: 'The open chart\'s DOB (' + ident.dob + ') does not match the requested DOB (' + dob + '). No visits were read.' };
    }
    var wantId = String(athenaId || '').replace(/\D/g, '');
    if (wantId && ident.mrn && String(ident.mrn).replace(/\D/g, '') !== wantId) return { ok: false, reason: 'wrong-id', chartName: ident.name, chartDob: ident.dob || '', chartMrn: ident.mrn || '', error: 'The open chart\'s patient ID #' + ident.mrn + ' does not match the requested #' + wantId + '. No visits were read.' };
    /* ---- 5) click the left-rail "Visits" item (small text label under the
       icon; live-observed rail: Find, Allergies, Problems, Meds, Vaccines,
       Vitals, Results, Visits, History, Quality, Care). Shadow-aware element
       scan, exact-label match, left-edge constraint, BAD-blocklist guard. */
    function visEl(el) { try { var r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; var win = (el.ownerDocument && el.ownerDocument.defaultView) || W; var s = win.getComputedStyle(el); return s.display !== 'none' && s.visibility !== 'hidden'; } catch (e) { return false; } }
    var BAD = /save|sign|order|delete|discard|remove|void|submit|bill|charge|check\s*-?\s*(in|out)|prescri|refill|dispense|cancel|log\s*out/i;
    function realClick(el) {
      try { el.scrollIntoView({ block: 'center' }); } catch (e1) {}
      try {
        var win = (el.ownerDocument && el.ownerDocument.defaultView) || W;
        var r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
        var o = { bubbles: true, cancelable: true, view: win, clientX: x, clientY: y };
        ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach(function (tp) {
          try { el.dispatchEvent(new win[tp.indexOf('pointer') === 0 ? 'PointerEvent' : 'MouseEvent'](tp, o)); } catch (e2) {}
        });
      } catch (e3) {}
      try { el.click(); } catch (e4) {}
    }
    function allEls(doc, cap) {
      var out = [], stack = [doc];
      while (stack.length && out.length < cap) {
        var root = stack.pop();
        var els; try { els = root.querySelectorAll('*'); } catch (e) { continue; }
        for (var i = 0; i < els.length && out.length < cap; i++) {
          out.push(els[i]);
          try { if (els[i].shadowRoot) stack.push(els[i].shadowRoot); } catch (e2) {}
        }
      }
      return out;
    }
    function clickRailLabel(label) {
      var re = new RegExp('^' + label + '$', 'i');
      var els = allEls(W.document, 14000);
      var cands = [];
      for (var i = 0; i < els.length; i++) {
        var el = els[i];
        var own = String(el.textContent || '').replace(/\s+/g, ' ').trim();
        var aria = String((el.getAttribute && (el.getAttribute('aria-label') || el.getAttribute('title'))) || '').replace(/\s+/g, ' ').trim();
        var hit = (own && own.length <= 12 && re.test(own)) || (aria && aria.length <= 24 && re.test(aria));
        if (!hit) continue;
        if (!visEl(el)) continue;
        var r = el.getBoundingClientRect();
        if (r.left > 260) continue; /* left rail only - never a same-named control elsewhere */
        var tgt = (el.closest && el.closest('a,button,[role=button],[role=tab],[role=link],[role=menuitem],li')) || el.parentElement || el;
        var lbl = String((tgt.getAttribute && (tgt.getAttribute('aria-label') || tgt.getAttribute('title'))) || tgt.textContent || '').replace(/\s+/g, ' ').trim();
        if (BAD.test(lbl)) continue; /* read-only nav guard */
        cands.push({ el: tgt, left: r.left, top: r.top });
      }
      if (!cands.length) return false;
      cands.sort(function (a, b) { return (a.left - b.left) || (a.top - b.top); });
      realClick(cands[0].el);
      return true;
    }
    /* v1.89.1 (live find, same day): the rail labels are CSS ::after content
       (content:"Visits") on li.chart-tabs__list-item - they do NOT exist in
       textContent, so the text scan alone can never match. The DOM-stable
       selector is the data attribute: [data-chart-section-id="visits"]
       (siblings live-enumerated: browse/allergies/problems/medications/
       vaccine/vitals/results/visits/history/p4p/careManagement). Attribute
       selector FIRST; the text scan stays as a fallback for older layouts. */
    function clickRailByAttr(sectionId) {
      try {
        var lis = W.document.querySelectorAll('li.chart-tabs__list-item[data-chart-section-id="' + sectionId + '"],[data-chart-section-id="' + sectionId + '"]');
        for (var qi = 0; qi < lis.length; qi++) {
          var li = lis[qi];
          if (!visEl(li)) continue;
          var lbl = String((li.getAttribute && (li.getAttribute('aria-label') || li.getAttribute('data-icon-caption'))) || li.textContent || '').replace(/\s+/g, ' ').trim();
          if (BAD.test(lbl)) continue;
          realClick(li);
          return true;
        }
      } catch (eA) {}
      return false;
    }
    var clicked = false;
    var railDeadline = Date.now() + 12000; /* absolute deadline, short sleeps */
    while (!clicked && Date.now() < railDeadline) {
      clicked = clickRailByAttr('visits') || clickRailLabel('Visits');
      if (!clicked) await sleep(700);
    }
    if (!clicked) return { ok: false, reason: 'no-rail', chartName: ident.name, chartDob: ident.dob || '', chartMrn: ident.mrn || '', error: 'The left-rail "Visits" item was not found on the open chart. Refusing to read any other surface as if it were the verified Visits pane (wf_6) - nothing was captured.' };
    /* ---- 6) wait for the "Visits and Cases" pane (light DOM, live-verified:
       fully readable via innerText). Absolute deadline + short sleeps. */
    var paneDeadline = Date.now() + 16000, paneSeen = false, paneText = '';
    while (Date.now() < paneDeadline) {
      await sleep(500);
      try { paneText = String((W.document.body && W.document.body.innerText) || ''); } catch (eP) { paneText = ''; }
      if (/visits\s+and\s+cases/i.test(paneText)) { paneSeen = true; break; }
    }
    /* v2.01 (live root-cause, clientsummary layout): the section-id LI click can
       land on athena's top-nav Calendar menu instead of the Visits pane. Recover
       ONCE: Escape closes whatever menu opened, then re-run the click ladder and
       wait again - only then refuse. Never a manual-follow fallback. */
    if (!paneSeen) {
      try { W.document.dispatchEvent(new W.KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true })); } catch (eEsc) {}
      await sleep(600);
      try { clickRailByAttr('visits') || clickRailLabel('Visits'); } catch (eRe) {}
      var paneDeadline2 = Date.now() + 10000;
      while (Date.now() < paneDeadline2) {
        await sleep(500);
        try { paneText = String((W.document.body && W.document.body.innerText) || ''); } catch (eP2) { paneText = ''; }
        if (/visits\s+and\s+cases/i.test(paneText)) { paneSeen = true; break; }
      }
    }
    if (!paneSeen) return { ok: false, reason: 'no-pane', chartName: ident.name, chartDob: ident.dob || '', chartMrn: ident.mrn || '', error: 'Clicked the Visits rail item but the "Visits and Cases" pane did not render (retried once with menu-close recovery). No visits were read.' };
    await sleep(1200); /* let the entry list hydrate */
    /* ---- 7) the SHOW control - ONLY the trivially safe case: a real <select>
       carrying an "All Events" option that is not yet selected (native value
       setter + change event, then settle). Custom dropdowns / button menus are
       SKIPPED - opening those is a click risk for zero gain. */
    try {
      var sels = W.document.querySelectorAll('select');
      for (var sx = 0; sx < sels.length; sx++) {
        var opts = sels[sx].options || [];
        var allIx = -1;
        for (var ox = 0; ox < opts.length; ox++) { if (/all\s*events/i.test(String(opts[ox].text || ''))) { allIx = ox; break; } }
        if (allIx < 0) continue;
        if (sels[sx].selectedIndex === allIx) break; /* already showing everything */
        var proto = W.HTMLSelectElement && W.HTMLSelectElement.prototype;
        var desc = proto && Object.getOwnPropertyDescriptor(proto, 'value');
        if (desc && desc.set) desc.set.call(sels[sx], opts[allIx].value); else sels[sx].selectedIndex = allIx;
        try { sels[sx].dispatchEvent(new W.Event('change', { bubbles: true })); } catch (eC) {}
        await sleep(1500);
        break;
      }
    } catch (eShow) {}
    /* ---- 8) parse entries. Live-verified row shape (two lines):
         "<type>"
         "<MM-DD-YYYY>, <Provider>, <Cred>, <Specialty>"
       e.g. "order group" / "07-03-2026, Matthew Schaeffer, MD, Phys. Med. & Rehab."
       Month/day RANGE-VALIDATED (wf_6). Output date is YYYY-MM-DD. */
    /* v2.02: PT/booking rows render the date with a TIME before the comma
       ("08-31-2026 4:00 PM, Michael A Wilson, DPT" - live: Scott Lake's pane is
       25 such rows and the old date-comma regex parsed ZERO of them, so the
       honesty invariant refused the whole chart). Optional time is allowed. */
    var ROW = /^([01]?\d)-([0-3]?\d)-(\d{4})(?:\s+\d{1,2}:\d{2}\s*(?:[AP]\.?M\.?)?)?\s*,\s*(.+)$/i;
    var ROW2 = /^([01]?\d)[\/\.]([0-3]?\d)[\/\.](\d{4})(?:\s+\d{1,2}:\d{2}\s*(?:[AP]\.?M\.?)?)?\s*,\s*(.+)$/i; /* slash/dot tolerance */
    var CRED = /^(MD|DO|PA-?C?|NP|CRNA|APRN|DPM|DDS|DMD|RN|CRNP|FNP|DNP|OD|CNM|DC|DPT)\.?$/i;
    var HDR = /visits\s+and\s+cases|arrange\s+by|^show\s*:|all\s*events/i;
    var _td = new Date();
    var TODAY_ISO = _td.getFullYear() + '-' + ('0' + (_td.getMonth() + 1)).slice(-2) + '-' + ('0' + _td.getDate()).slice(-2); /* v2.04: rows dated after today are bookings, not history */
    function parseEntries() {
      var lines2 = [];
      try { lines2 = String((W.document.body && W.document.body.innerText) || '').split(/\n+/).map(function (s) { return s.replace(/\s+/g, ' ').trim(); }).filter(Boolean); } catch (eL) {}
      var visits = [], seen = {}, upcomingSkipped = 0;
      for (var li = 0; li < lines2.length && visits.length < CAP; li++) {
        var m2 = ROW.exec(lines2[li]) || ROW2.exec(lines2[li]);
        if (!m2) continue;
        var mo2 = Number(m2[1]), dy2 = Number(m2[2]), yr2 = Number(m2[3]);
        if (mo2 < 1 || mo2 > 12 || dy2 < 1 || dy2 > 31 || yr2 < 1900 || yr2 > 2100) continue; /* wf_6 range validation */
        var dateIso = m2[3] + '-' + ('0' + mo2).slice(-2) + '-' + ('0' + dy2).slice(-2);
        var rest = m2[4].split(',').map(function (s) { return s.trim(); }).filter(Boolean);
        var provider = rest[0] || '';
        if (rest[1] && CRED.test(rest[1])) provider += ', ' + rest[1];
        var type = '';
        if (li > 0) {
          var above = lines2[li - 1];
          if (above && above.length <= 60 && !ROW.test(above) && !ROW2.test(above) && !HDR.test(above)) type = above;
        }
        /* v2.02: "(upcoming)" rows are FUTURE bookings, not visit history - never
           file them (the old regex excluded them by accident; the time-tolerant
           one would let them through). They still count as PARSED rows so a pane
           of only-upcoming events is an honest empty, not a parser failure.
           v2.04: not every future booking carries the literal "(upcoming)"
           marker (live: 22 marker-less future rows filed across 7 patients -
           16 of them Scott Lake's scheduled PT sessions, plus "f/u ..."
           follow-ups). A future DATE is the authoritative signal: any row dated
           after today is a booking, not history - skip it and count it. Same-
           day rows are kept (today's completed visit is history). */
        if (/\(upcoming\)/i.test(type) || /\(upcoming\)/i.test(lines2[li]) || dateIso > TODAY_ISO) { upcomingSkipped++; continue; }
        var textHead = ((type ? type + ' | ' : '') + lines2[li]).slice(0, 220);
        /* Track repeated shapes for diagnostics, but retain every Athena row:
           byte-identical same-day encounters are still distinct events. */
        var key = dateIso + '::' + textHead.toLowerCase();
        seen[key] = (seen[key] || 0) + 1;
        visits.push({ date: dateIso, type: type, provider: provider, textHead: textHead });
      }
      var ptext = '';
      try { ptext = String((W.document.body && W.document.body.innerText) || ''); } catch (eT) {}
      var declN = null;
      var mAll = /all\s*events\s*\(\s*(\d+)\s*\)/i.exec(ptext) || /\(\s*(\d+)\s*\)\s*events?\b/i.exec(ptext) || /\b(\d+)\s+events?\b/i.exec(ptext);
      if (mAll) declN = Number(mAll[1]);
      /* v2.02: a pane of ONLY "(upcoming)" bookings is an honest empty HISTORY
         (we parsed the rows, they're all future) - not a parser failure. */
      var explicitEmpty = declN === 0 || upcomingSkipped > 0 || /no\s+(visits|events|cases)\s*(recorded|found|yet|\.|$)/i.test(ptext) || /there\s+are\s+no\s+/i.test(ptext);
      return { visits: visits, upcomingSkipped: upcomingSkipped, declN: declN, explicitEmpty: explicitEmpty };
    }
    /* v2.03 SETTLE-POLL (live root-cause of the FIRST-TRY 'rows-not-parsed'
       refusals that surfaced as the app's "That Athena pull didn't work"
       banner): the "Visits and Cases" heading renders BEFORE the row list
       hydrates, and the old fixed 1200ms sleep + single-shot parse raced it
       (live: Patricia Dorak refused 1-2 tries, then parsed 29 rows on a later
       attempt). Poll the parse until rows appear OR an explicit zero/upcoming-
       only signal does; once something parses, require TWO consecutive equal
       row counts (a partially-hydrated list must never be filed as complete).
       Only after the row list genuinely never appears within the deadline does
       the retryable refusal fire. */
    var parsed = parseEntries();
    var parseDeadline = Date.now() + 14000;
    while (Date.now() < parseDeadline) {
      if (parsed.visits.length || parsed.explicitEmpty) {
        await sleep(800);
        var again = parseEntries();
        if (again.visits.length === parsed.visits.length) { parsed = again; break; }
        parsed = again;
        continue;
      }
      await sleep(700);
      parsed = parseEntries();
    }
    /* v2.01 HONESTY INVARIANT (live root-cause of 'no-visits-on-chart' on charts
       that visibly HAD visits): the clientsummary layout carries a "Visits and
       Cases" summary CARD whose heading satisfies paneSeen with zero readable
       rows - returning ok-empty there silently loses the patient's history.
       The REAL pane declares its count ("All Events (N)" / "N Events"). ok-empty
       is allowed ONLY with an explicit zero signal; a declared N>0 with zero
       parsed rows - or no count signal at all - is a retryable refusal. */
    if (!parsed.visits.length && !parsed.explicitEmpty) {
      return { ok: false, reason: 'rows-not-parsed', chartName: ident.name, chartDob: ident.dob || '', chartMrn: ident.mrn || '', declaredEvents: (parsed.declN == null ? -1 : parsed.declN), error: 'The Visits and Cases heading rendered but no visit rows could be read within the settle deadline' + (parsed.declN != null ? ' (the pane declares ' + parsed.declN + ' events)' : ' (no event count found - probably the summary card, not the real pane)') + '. Refusing to report an empty history that may not be empty - retry will re-open the pane.' };
    }
    var accountedEvents = parsed.visits.length + Number(parsed.upcomingSkipped || 0);
    if (parsed.declN != null && accountedEvents < parsed.declN) {
      return { ok: false, reason: 'visits-incomplete', chartName: ident.name, chartDob: ident.dob || '', chartMrn: ident.mrn || '', declaredEvents: parsed.declN, parsedVisits: parsed.visits.length, upcomingSkipped: parsed.upcomingSkipped || 0, error: 'Athena declares ' + parsed.declN + ' events, but MLS could account for only ' + accountedEvents + '. Nothing was reported as complete; retry after the Visits list finishes loading.' };
    }
    var visits = parsed.visits;
    return {
      ok: true, visits: visits, via: 'visits-pane',
      receipt: { complete: true, declaredEvents: parsed.declN, parsedVisits: visits.length, upcomingSkipped: parsed.upcomingSkipped || 0, accountedEvents: accountedEvents },
      chartName: ident.name, chartDob: ident.dob || '', chartMrn: ident.mrn || '',
      frame: (function () { try { return String(W.location.pathname || '').slice(0, 120); } catch (e) { return ''; } })(),
      ms: Date.now() - T0
    };
  } catch (e) { return { ok: false, reason: 'driver-error', error: String((e && e.message) || e).slice(0, 200) }; }
}


/* =========================================================================
 * MLS Assist v1.89 - mlsAppReadVisits handler. Registered in the same IIFE +
 * onMessage style as the existing v1.36 search-open block. Read-only.
 * Flow: single-flight gate -> athena-tab pick (mlsAssistChartIdentity's
 * scoring) -> ONE MAIN-world top-frame injection of mlsReadVisitsPaneDriverFn
 * (which does its own identity gate on the live DOM) under a 90s mlsExecTO
 * budget. Responds {ok, visits, reason, ...}. Never reloads the tab itself -
 * a timeout is an honest fail (the app's existing pull loop owns recovery). */
(function () {
  'use strict';
  try { if (self.__mlsV189VisitsWired) return; self.__mlsV189VisitsWired = 1; } catch (e) {}

  /* wf_9 single-flight: ONE visits read at a time, extension-wide. An
     overlapping app call (e.g. a retry firing while the first injection is
     still running) is rejected honestly with reason 'busy' - parallel
     MAIN-world drivers on the same athena tab are a proven freeze-maker.
     Module scope: resets only when the MV3 service worker restarts, which
     also kills the in-flight injection, so the flag can never wedge. */
  var __mlsVisitsBusy = 0;

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || msg.type !== 'mlsAppReadVisitsRequest') return; /* not ours - other listeners handle it */
    (async function () {
      var V = '';
      try { V = chrome.runtime.getManifest().version; } catch (eV) {}
      if (__mlsVisitsBusy) {
        sendResponse({ ok: false, reason: 'busy', version: V, error: 'A visits read is already running - one at a time. Retry after the current read finishes.' });
        return;
      }
      __mlsVisitsBusy = 1;
      try {
        var want = String(msg.patient || '').trim();
        if (!want) {
          sendResponse({ ok: false, reason: 'no-patient', version: V, error: 'mlsAppReadVisits requires the requested patient (name, ideally + DOB and athenaId) - refusing an un-gated visits read.' });
          return;
        }
        /* v1.90: unified verified athena-tab pick (heartbeat + reachability ping;
           identity/login hosts excluded — raw athenanet.athenahealth.com only). */
        var all = await chrome.tabs.query({});
        /* Stay on the exact Athena tab that the verified patient search just
           opened. With two signed-in Athena tabs, re-running the generic picker
           here could select a different patient's chart between search and
           verify/write. Identity gates still remain mandatory downstream. */
        var tab = null, expected = null;
        try { expected = self.__mlsExpectOpen; } catch (eEx) {}
        try {
          var nn = function (s) { return String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').replace(/\s+/g, ' ').trim(); };
          if (expected && expected.tabId != null && (Date.now() - Number(expected.at || 0)) < 10 * 60 * 1000 && nn(expected.name) === nn(msg.patient)) {
            var exactTab = await chrome.tabs.get(expected.tabId);
            if (exactTab && mlsAthTabHost(exactTab) === 'athenanet.athenahealth.com' && !mlsAthIsLoginish(exactTab)) tab = exactTab;
          }
        } catch (eExact) { tab = null; }
        if (!tab) tab = await mlsPickAthenaTab(all, { athenaOnly: true });
        if (!tab) {
          sendResponse({ ok: false, reason: 'no-athena-tab', version: V, error: 'Open your signed-in athenaOne in another tab, then try again.' });
          return;
        }
        /* v2.03 (live root-cause of the first-try 'rows-not-parsed' refusals
           behind the "That Athena pull didn't work" banner): the Visits pane's
           ROW LIST hydrates on the page's own rendering loop, which Chrome
           deprioritizes in a HIDDEN tab - the heading renders but the rows
           appear late or never (live: Dorak's pane declared "All Events (31)"
           with zero rows for minutes while hidden, then read fine once
           visible). The driver's contract has always required the athena tab
           VISIBLE for the read - enforce it HERE the way every pull engine
           does: foreground athena for the read; note focus debt ONLY when we
           took focus ourselves, so the guardian returns the doctor to MLS
           afterwards and a user already parked on athena is never yanked. */
        /* v2.9.5 quiet pull: the visible-for-read contract is now met by the
           work strip (visible, never focused) instead of stealing focus. */
        try { await (self.__mlsQpEnsure ? self.__mlsQpEnsure(tab, sender && sender.tab && sender.tab.id) : null); } catch (eF) {}
        /* 90s TOTAL budget (live: the athenaOne renderer can freeze 45+s after
           heavy interactions - every new injected driver must be mlsExecTO-
           wrapped and must not assume the tab is responsive). Identity gating
           happens INSIDE the driver, on the live DOM, so a mid-read chart swap
           cannot slip past a stale background-side check - and this handler
           adds NO extra mlsReadChartIdentity/mlsShadowIdentityTry passes on
           top (no finding-8 scan pile-up from this caller). */
        var fx = await mlsExecTO({ target: { tabId: tab.id }, world: 'MAIN', args: [want, String(msg.dob || ''), String(msg.athenaId || '')], func: mlsReadVisitsPaneDriverFn }, 90000);
        if (fx.timeout) {
          /* v1.91 (§2.9): a 90s hang means the renderer is frozen — recover it NOW
             (reload + Continue-clear) so the caller's retry finds a live tab,
             instead of leaving every subsequent open/read to fail on the frozen one. */
          try { await mlsRecoverAthenaTab(tab.id); } catch (eRc) {}
          sendResponse({ ok: false, reason: 'visits-timeout', version: V, error: 'athenaOne did not finish the visits read within 90s. MLS Assist left the Athena tab untouched; check it, then retry.' });
          return;
        }
        if (fx.err) {
          sendResponse({ ok: false, reason: 'inject-failed', version: V, error: 'Could not inject the visits reader: ' + fx.err });
          return;
        }
        var r = fx && fx.r && fx.r[0] && fx.r[0].result;
        if (!r) {
          sendResponse({ ok: false, reason: 'no-result', version: V, error: 'The visits reader returned nothing (frame navigated mid-read?). Nothing was captured.' });
          return;
        }
        if (!r.ok) {
          sendResponse({ ok: false, reason: r.reason || 'visits-unreadable', version: V, error: r.error || 'The Visits and Cases pane could not be read.', chartName: r.chartName || '', chartDob: r.chartDob || '', chartMrn: r.chartMrn || '' });
          return;
        }
        try { __mlsReadsSinceReload++; } catch (eC) {} /* v1.91 (§2.9): visits reads are heavy too — count them toward the freeze-guard boundary */
        /* The injected reader already enforces its renderer-safety cap and proves
           declared-vs-accounted completeness. Do not silently truncate the
           verified batch here (the former slice(0, 40) lost older visits after
           the driver had successfully read them). Carry its receipt end to end. */
        sendResponse({ ok: true, visits: (r.visits || []).slice(0, 500), receipt: r.receipt || { complete: true, declaredEvents: null, parsedVisits: (r.visits || []).length, upcomingSkipped: 0, accountedEvents: (r.visits || []).length }, via: r.via || 'visits-pane', frame: r.frame || '', chartName: r.chartName || '', chartDob: r.chartDob || '', chartMrn: r.chartMrn || '', ms: r.ms || 0, version: V });
      } catch (e) {
        sendResponse({ ok: false, reason: 'error', version: V, error: String((e && e.message) || e) });
      } finally {
        __mlsVisitsBusy = 0;
      }
    })();
    return true;
  });
})();



/* =========================================================================
 * MLS Assist v2.05 - UNIFIED WRITE DRIVER (mlsUnifiedWriteDriverFn) +
 * mlsAppWriteV2Request handler.
 *
 * WHY: the legacy write path (mlsFieldScanner/mlsNotePaster) runs as PER-FRAME
 * injections with light-DOM attribute selectors - on the current chart History
 * layout the visible note editor is a shadow-DOM contenteditable (and
 * [contenteditable=""]/["true"] also misses "plaintext-only"), so the scan
 * honestly found nothing and nothing was ever written. This driver uses the
 * visits reader's proven architecture instead: ONE top-frame world:'MAIN'
 * injection that walks frames AND shadow roots itself. It is fully generic -
 * no patient, provider, practice or department is hardcoded anywhere; the
 * identity gate reads the live banner, the section map is regex-by-meaning.
 *
 * HARD SAFETY (enforced at the LOWEST level, not just the caller):
 *  - Section keys orders/rx/prescriptions/billing/charges/referrals/pt/imaging
 *    are FORCED to target-only inside the driver: the best matching field is
 *    located and REPORTED (label/heading/frame) but never focused, never
 *    written, never submitted - regardless of what any caller passes.
 *  - The driver never dispatches events on anything but the chosen note field
 *    itself. No button is ever clicked except the read-only left-rail History
 *    nav item and a section's NOTE toggle (both navigation affordances,
 *    guarded by the same BAD-blocklist as the visits reader).
 *  - Identity gate runs IN here on the live DOM before any interaction:
 *    requested name (+DOB +athenaId when given) must match the banner chip or
 *    the driver refuses with the exact reason. Unsigned content only - the
 *    clinician reviews and signs in athenaOne.
 * ========================================================================= */
async function mlsUnifiedWriteDriverFn(name, dob, athenaId, sections) {
  try {
    var T0 = Date.now();
    function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
    if (!String(name || '').trim()) return { ok: false, reason: 'no-patient', error: 'mlsUnifiedWriteDriverFn requires the patient name - refusing an un-gated write.' };
    if (!sections || !sections.length) return { ok: false, reason: 'no-sections', error: 'No sections supplied.' };
    /* Versioned destination contract. Aliases are explicit; an unknown or
       ambiguous key NEVER falls back to a generic note field. Structured and
       order-chain destinations are target/preview-only until dedicated exact
       adapters are independently proven. */
    var ROUTE_CONTRACT_VERSION = 'athena-routes-1';
    var ROUTE_ALIASES = {
      note: 'encounter_note', encounter_note: 'encounter_note',
      hpi: 'hpi', ros: 'ros',
      exam: 'physical_exam', physical_exam: 'physical_exam',
      assessment: 'assessment_narrative', assessment_narrative: 'assessment_narrative',
      plan: 'plan', followup: 'follow_up', follow_up: 'follow_up',
      procedure: 'procedure_note', procedure_note: 'procedure_note',
      past_surgical_history: 'past_surgical_history',
      diagnoses: 'diagnoses_icd10', diagnosis: 'diagnoses_icd10', dx: 'diagnoses_icd10', icd: 'diagnoses_icd10', diagnoses_icd10: 'diagnoses_icd10',
      rx: 'medications_rx', prescriptions: 'medications_rx', medications_rx: 'medications_rx',
      orders: 'orders_preview', order: 'orders_preview', orders_preview: 'orders_preview',
      lab_order: 'lab_order', imaging: 'imaging_order', imaging_order: 'imaging_order',
      referrals: 'referral_order', referral: 'referral_order', referral_order: 'referral_order',
      pt: 'pt_order', pt_order: 'pt_order',
      billing: 'billing_preview', charges: 'billing_preview', billing_preview: 'billing_preview',
      billing_em: 'billing_em', billing_cpt: 'billing_cpt'
    };
    var ROUTE_POLICY = {
      encounter_note: { kind: 'narrative', draft: true },
      hpi: { kind: 'narrative', draft: true },
      ros: { kind: 'narrative', draft: true },
      physical_exam: { kind: 'narrative', draft: true },
      assessment_narrative: { kind: 'narrative', draft: true },
      plan: { kind: 'narrative', draft: true },
      follow_up: { kind: 'narrative', draft: true },
      procedure_note: { kind: 'template-narrative', draft: false },
      past_surgical_history: { kind: 'history-narrative', draft: false },
      diagnoses_icd10: { kind: 'structured-code', draft: false },
      medications_rx: { kind: 'order-chain', draft: false },
      orders_preview: { kind: 'order-chain', draft: false },
      lab_order: { kind: 'order-chain', draft: false },
      imaging_order: { kind: 'order-chain', draft: false },
      referral_order: { kind: 'order-chain', draft: false },
      pt_order: { kind: 'order-chain', draft: false },
      billing_preview: { kind: 'structured-billing', draft: false },
      billing_em: { kind: 'structured-billing', draft: false },
      billing_cpt: { kind: 'structured-billing', draft: false }
    };
    function canonicalRouteKey(k) {
      k = String(k || '').toLowerCase().replace(/[\s-]+/g, '_').trim();
      return ROUTE_ALIASES[k] || '';
    }
    /* ---- normalizers (identical to the proven visits driver) -------------- */
    function nrmName(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim(); }
    function nameMatch(a, b) {
      var ta = nrmName(a).split(' ').filter(function (x) { return x.length > 1; });
      var tb = nrmName(b).split(' ').filter(function (x) { return x.length > 1; });
      var o = ta.filter(function (x) { return tb.indexOf(x) >= 0; }).length;
      return o >= 2 || (o >= 1 && Math.min(ta.length, tb.length) === 1);
    }
    function nrmDob(s) {
      var m = /([01]?\d)[\/\-\.]([0-3]?\d)[\/\-\.](\d{2,4})/.exec(String(s || ''));
      if (!m) return '';
      var pivot = (new Date().getFullYear() % 100) + 1;
      var y = m[3].length === 2 ? ((Number(m[3]) > pivot ? '19' : '20') + m[3]) : m[3];
      var mo = Number(m[1]), dy = Number(m[2]);
      if (mo < 1 || mo > 12 || dy < 1 || dy > 31) return '';
      return mo + '/' + dy + '/' + y;
    }
    function nrmText(s) { return String(s || '').replace(/[\u200B-\u200D\u2060\uFEFF]/g, '').replace(/\s+/g, ' ').trim().toLowerCase(); }
    /* ---- frame walk (same SKIP/JUNK as the visits driver) ------------------ */
    var SKIP = /globalnav|statusbar|stm\.esp|schedulenavclose|coordinator\/enterprise|blank\.html|findpatient\.esp/i;
    var JUNK = /letter|athenatext|communicat|\bfax|printer|documentviewer|clinicaldocument|inbox|messag/i;
    var best = null, allFr = [];
    (function walk(w, depth) {
      if (depth > 6) return;
      for (var i = 0; i < w.frames.length; i++) {
        var f = w.frames[i];
        try {
          void f.document;
          allFr.push(f);
          var p = String(f.location.pathname || '');
          var el = f.frameElement; var r = el ? el.getBoundingClientRect() : null;
          var area = r ? (r.width * r.height) : 0;
          if (!SKIP.test(p) && area > 150000) {
            if (!best || depth > best.depth || (depth === best.depth && area > best.area)) best = { w: f, depth: depth, area: area };
          }
          walk(f, depth + 1);
        } catch (e) {}
      }
    })(window, 0);
    var W = (best && best.w) || window;
    /* ---- shadow-aware line collector + chip identity (proven verbatim) ---- */
    function docLines(doc, cap) {
      var BLOCK = /^(div|p|li|tr|td|th|section|header|footer|h[1-6]|ul|ol|table|article|aside|nav|form|fieldset|dl|dt|dd|pre|address|hr|br)$/;
      var out = { items: [], n: 0 };
      function coll(root, depth) {
        if (depth > 25 || out.n > cap) return;
        var kids = root.childNodes || [];
        for (var k = 0; k < kids.length; k++) {
          if (out.n > cap) return;
          var n = kids[k];
          if (n.nodeType === 3) { var s = String(n.nodeValue || '').replace(/\s+/g, ' ').trim(); if (s) { out.items.push({ t: s }); out.n++; } }
          else if (n.nodeType === 1) {
            var tag = (n.tagName || '').toLowerCase();
            if (tag === 'script' || tag === 'style') continue;
            var isB = BLOCK.test(tag);
            if (isB) { out.items.push({ nl: 1 }); out.n++; }
            try {
              if (tag === 'slot' && n.assignedNodes) {
                var an = n.assignedNodes({ flatten: true });
                for (var a = 0; a < an.length; a++) {
                  if (an[a].nodeType === 3) { var s2 = String(an[a].nodeValue || '').replace(/\s+/g, ' ').trim(); if (s2) { out.items.push({ t: s2 }); out.n++; } }
                  else if (an[a].nodeType === 1) coll(an[a], depth + 1);
                }
              } else if (n.shadowRoot) coll(n.shadowRoot, depth + 1);
              else coll(n, depth + 1);
            } catch (e) {}
            if (isB) { out.items.push({ nl: 1 }); out.n++; }
          }
        }
      }
      try { coll(doc.body || doc, 0); } catch (e) {}
      var lines = [], cur = [];
      for (var x = 0; x < out.items.length; x++) {
        if (out.items[x].nl) { if (cur.length) { lines.push(cur.join(' ')); cur = []; } }
        else cur.push(out.items[x].t);
      }
      if (cur.length) lines.push(cur.join(' '));
      return lines;
    }
    function identFrom(lines) {
      var AGE_CHIP = /\b(\d{1,3})\s*(?:yo|y\/o|yrs?\.?|years?\s*old)\b/i;
      var BARE_DATE = /\b([01]?\d)[\/\-\.]([0-3]?\d)[\/\-\.](\d{4})\b/;
      var MRN_HASH = /#\s?(\d{4,})/;
      var STOP1 = /^(please|the|new|find|create|search|no|today|welcome|inbox|schedule|calendar|department|provider|patient|results|appointment|encounter|billing|orders|messages|close|camera|panel|visits|history)$/i;
      var PROVCRED = /^(MD|DO|PA|PAC|NP|CRNA|APRN|DPM|DDS|DMD|RN|CRNP|FNP|DNP|PHD|MBBS|OD|MSN|LPN|CNM|DC|DPT|DR|PHYS|PT)$/i;
      function okName(cand) {
        if (!cand || cand.length < 4 || cand.length > 60) return '';
        if (!/^([A-Z][A-Za-z'\-\.]*(?:\s+[A-Z][A-Za-z'\-\.]*){1,3})$/.test(cand)) return '';
        var toks = cand.replace(/,/g, ' ').split(/\s+/);
        for (var q = 0; q < toks.length; q++) { if (STOP1.test(toks[q])) return ''; }
        if (PROVCRED.test(toks[toks.length - 1].replace(/[.\-]/g, ''))) return '';
        if (/^DR\.?$/i.test(toks[0])) return '';
        return cand;
      }
      var out = [];
      for (var i = 0; i < lines.length && out.length < 8; i++) {
        if (!AGE_CHIP.test(lines[i]) || !BARE_DATE.test(lines[i])) continue;
        var bd = BARE_DATE.exec(lines[i]);
        var mh = MRN_HASH.exec(lines[i]);
        var dobS = ('0' + bd[1]).slice(-2) + '/' + ('0' + bd[2]).slice(-2) + '/' + bd[3];
        var mrnS = (mh && mh[1]) || '';
        for (var kk = 1; kk <= 3; kk++) {
          if (i - kk < 0) break;
          var joined = lines.slice(i - kk, i).join(' ').replace(/[()]/g, ' ').replace(/\s+/g, ' ').trim();
          var parts = joined.split(/legal\s*:/i).map(function (s) { return s.replace(/\s+/g, ' ').trim(); }).filter(Boolean);
          for (var pp = 0; pp < parts.length; pp++) {
            var nm = okName(parts[pp]);
            if (nm && !out.some(function (o) { return o.name === nm; })) out.push({ name: nm, dob: dobS, mrn: mrnS });
          }
        }
      }
      return out;
    }
    var scanWs = [];
    if (best && best.w) scanWs.push(best.w);
    for (var fi = 0; fi < allFr.length && scanWs.length < 9; fi++) {
      try {
        var pth = String(allFr[fi].location.pathname || '');
        if (allFr[fi] !== W && !SKIP.test(pth) && !JUNK.test(pth)) scanWs.push(allFr[fi]);
      } catch (eS) {}
    }
    scanWs.push(window);
    var ident = null, identWin = null, lastSeen = null, nameOnlyHit = null, nameOnlyWin = null;
    var identDeadline = Date.now() + 15000;
    var wantDobPre = nrmDob(dob);
    while (!ident && Date.now() < identDeadline) {
      for (var si = 0; si < scanWs.length && !ident; si++) {
        var candList = [];
        try { candList = identFrom(docLines(scanWs[si].document, 8000)) || []; } catch (eI) {}
        for (var ci = 0; ci < candList.length; ci++) {
          if (candList[ci] && candList[ci].name) {
            if (!lastSeen) lastSeen = candList[ci];
            if (nameMatch(candList[ci].name, String(name || ''))) {
              if (!wantDobPre) { ident = candList[ci]; identWin = scanWs[si]; break; }
              if (nrmDob(candList[ci].dob) === wantDobPre) { ident = candList[ci]; identWin = scanWs[si]; break; }
              if (!nameOnlyHit) { nameOnlyHit = candList[ci]; nameOnlyWin = scanWs[si]; }
            }
          }
        }
      }
      if (!ident) await sleep(800);
    }
    if (!ident && nameOnlyHit) { ident = nameOnlyHit; identWin = nameOnlyWin; }
    if (!ident || !ident.name) {
      if (lastSeen && lastSeen.name) return { ok: false, reason: 'wrong-chart', chartName: lastSeen.name, chartDob: lastSeen.dob || '', chartMrn: lastSeen.mrn || '', error: 'The open athenaOne chart is ' + lastSeen.name + ', not ' + name + '. Nothing was written.' };
      return { ok: false, reason: 'unverified', error: 'No readable patient identity on the open athenaOne chart - refusing to write. Nothing was touched.' };
    }
    var wantDob = nrmDob(dob);
    if (wantDob) {
      var haveDob = nrmDob(ident.dob);
      if (!haveDob) return { ok: false, reason: 'unverified-dob', chartName: ident.name, chartMrn: ident.mrn || '', error: 'A DOB was requested but the open chart shows no readable DOB - refusing to write.' };
      if (haveDob !== wantDob) return { ok: false, reason: 'wrong-dob', chartName: ident.name, chartDob: ident.dob || '', chartMrn: ident.mrn || '', error: 'The open chart DOB (' + ident.dob + ') does not match the requested DOB (' + dob + '). Nothing was written.' };
    }
    var wantId = String(athenaId || '').replace(/\D/g, '');
    if (wantId && !String(ident.mrn || '').replace(/\D/g, '')) return { ok: false, reason: 'unverified-id', chartName: ident.name, chartDob: ident.dob || '', error: 'A patient ID was requested but no readable patient ID is shown on the open chart - refusing to write.' };
    if (wantId && String(ident.mrn).replace(/\D/g, '') !== wantId) return { ok: false, reason: 'wrong-id', chartName: ident.name, chartDob: ident.dob || '', chartMrn: ident.mrn || '', error: 'The open chart patient ID #' + ident.mrn + ' does not match the requested #' + wantId + '. Nothing was written.' };
    /* ---- v2.9.2 WRITE-TARGET SAFETY (owner: never write to the wrong place) -
       The identity gate above can legitimately match a patient whose chart is
       loaded in a BACKGROUND frame (e.g. the app opener pre-loaded it) while a
       generic field picker would choose a VISIBLE editable that sits in a
       DIFFERENT frame (a dashboard note box). That is "right patient verified,
       WRONG place." So before ANY write we require the chosen field to be
       either (a) inside the exact frame where we confirmed this patient, or
       (b) inside a frame chain that independently shows this same patient. If
       neither holds we REFUSE that field instead of writing to it. Read-only. */
    function frameChainOf(el) {
      var wins = [], w = null;
      try { w = (el.ownerDocument && el.ownerDocument.defaultView) || W; } catch (e) { w = W; }
      var g = 0;
      while (w && g++ < 6) {
        wins.push(w);
        var pw = null; try { pw = (w.parent && w.parent !== w) ? w.parent : null; } catch (e2) { pw = null; }
        w = pw;
      }
      return wins;
    }
    function targetChartMatches(el) {
      try {
        var wins = frameChainOf(el);
        if (identWin) { for (var q = 0; q < wins.length; q++) { if (wins[q] === identWin) return true; } }
        for (var i = 0; i < wins.length; i++) {
          var doc; try { doc = wins[i].document; } catch (e) { continue; }
          var cands = []; try { cands = identFrom(docLines(doc, 8000)) || []; } catch (e2) { cands = []; }
          for (var j = 0; j < cands.length; j++) {
            var c = cands[j];
            if (!c || !c.name) continue;
            if (!nameMatch(c.name, String(name || ''))) continue;
            if (wantDob && nrmDob(c.dob) !== wantDob) continue;
            if (wantId && String(c.mrn || '').replace(/\D/g, '') !== wantId) continue;
            return true;
          }
        }
      } catch (e) {}
      return false;
    }
    /* ---- deep editable collector: frames + shadow roots ------------------- */
    var BADF = /search|find|lookup|filter|chat|messag|comment|reason for|\baddress\b|e-?mail|phone|\bnpi\b|\bmrn\b|patient.?id|claim|login|password|user.?name|\bzip\b|\bcity\b|\bstate\b/i;
    function deepActive(doc) { var a = null; try { a = doc.activeElement; while (a && a.shadowRoot && a.shadowRoot.activeElement) a = a.shadowRoot.activeElement; } catch (e) {} return a; }
    function hostChainText(el, hops) {
      var out = [], n = el, h = 0;
      while (n && h < (hops || 7)) {
        try {
          var al = n.getAttribute && (n.getAttribute('aria-label') || n.getAttribute('title') || n.getAttribute('data-section') || n.getAttribute('data-sectionname'));
          if (al && al.length <= 80) out.push(al);
          if (n.querySelector) {
            var hd = n.querySelector('h1,h2,h3,h4,h5,h6,legend,[role="heading"]');
            if (hd) { var ht = String(hd.textContent || '').replace(/\s+/g, ' ').trim(); if (ht && ht.length <= 80) out.push(ht); }
          }
        } catch (e) {}
        var up = null;
        try { up = n.parentElement || (n.getRootNode && n.getRootNode().host) || null; } catch (e2) { up = null; }
        n = up; h++;
      }
      return out.join(' ');
    }
    function labelOf(el) {
      try {
        var l = (el.getAttribute && (el.getAttribute('aria-label') || el.getAttribute('placeholder') || el.getAttribute('title') || el.getAttribute('name'))) || '';
        return String(l).replace(/\s+/g, ' ').trim().slice(0, 60);
      } catch (e) { return ''; }
    }
    function visEl(el, win) {
      try {
        if (el.disabled || el.readOnly) return false;
        var s = (win || window).getComputedStyle(el);
        if (s.display === 'none' || s.visibility === 'hidden' || parseFloat(s.opacity || '1') < 0.05) return false;
        var r = el.getBoundingClientRect();
        return r.width > 90 && r.height > 14;
      } catch (e) { return false; }
    }
    function collectEditables() {
      var cands = [];
      function walkRoot(root, win, act, budget) {
        var els; try { els = root.querySelectorAll('*'); } catch (e) { return budget; }
        for (var i = 0; i < els.length; i++) {
          if (--budget < 0) return budget;
          var el = els[i];
          try { if (el.shadowRoot) budget = walkRoot(el.shadowRoot, win, act, budget); } catch (eS) {}
          var tag = (el.tagName || '').toUpperCase();
          var isTA = tag === 'TEXTAREA';
          var isIN = tag === 'INPUT' && /^(text|search|)$/.test(String(el.getAttribute('type') || '').toLowerCase());
          var isCE = el.isContentEditable === true && el.getAttribute && el.getAttribute('contenteditable') != null;
          if (!isTA && !isIN && !isCE) continue;
          if (!visEl(el, win)) continue;
          var r = el.getBoundingClientRect();
          var hay = (labelOf(el) + ' ' + hostChainText(el)).toLowerCase();
          cands.push({ el: el, win: win, tag: tag, ce: isCE, area: Math.min(r.width * r.height, 400000), hay: hay, label: labelOf(el) || '', focused: el === act });
        }
        return budget;
      }
      var wins = [window];
      for (var fi2 = 0; fi2 < allFr.length; fi2++) {
        try { var p2 = String(allFr[fi2].location.pathname || ''); if (!SKIP.test(p2) && !JUNK.test(p2)) wins.push(allFr[fi2]); } catch (e) {}
      }
      for (var wi = 0; wi < wins.length && wi < 10; wi++) {
        try { walkRoot(wins[wi].document, wins[wi], deepActive(wins[wi].document), 14000); } catch (e) {}
      }
      return cands;
    }
    /* ---- section map (generic, by meaning - nothing account-specific) ----- */
    var DEFS = {
      encounter_note: /encounter\s+note|progress\s+note|clinical\s+note|narrative|free.?text|documentation/i,
      hpi: /\bhpi\b|history of present|present illness|subjective|chief complaint|interval history/i,
      ros: /review of systems|\bros\b/i,
      physical_exam: /physical exam|\bexam\b|objective|findings/i,
      assessment_narrative: /assessment\s*(?:narrative|note|text)?|impression|a&p|a\/p/i,
      plan: /\bplan\b|recommendation|decision\s*making/i,
      follow_up: /follow.?up|return to clinic|\brtc\b|next visit/i,
      procedure_note: /procedure\s*(?:documentation|note)|operative\s+note/i,
      past_surgical_history: /surgical\s*(?:&|and)?\s*procedure\s*history|past\s+surgical\s+history/i,
      diagnoses_icd10: /add assessment|diagnos(?:is|es)|\bicd(?:-?10)?\b|problem\s+list/i,
      medications_rx: /prescri|\brx\b|\bsig\b|pharmacy|dispense|refill|medication order/i,
      orders_preview: /\borders?\b|add\s+order/i,
      lab_order: /lab(?:oratory)?\s+order|order\s+lab/i,
      imaging_order: /imaging\s+order|radiology\s+order|order\s+imaging/i,
      referral_order: /referral\s+order|order\s+referral/i,
      pt_order: /physical\s+therapy\s+order|\bpt\s+order/i,
      billing_preview: /billing|charge|superbill|e&m|e\/m|claim|\bcpt\b/i,
      billing_em: /e&m|e\/m|evaluation\s+and\s+management/i,
      billing_cpt: /add\s+charge|\bcpt\b|procedure\s+code|hcpcs/i
    };
    function bestFieldFor(key) {
      var re = DEFS[key];
      if (!re) return null;
      var cands = collectEditables();
      var top = null, topScore = -1e12;
      for (var i = 0; i < cands.length; i++) {
        var c = cands[i];
        if (!re.test(c.hay)) continue;
        var sc = c.area / 1000;
        sc += 2000;
        if (BADF.test(c.hay)) sc -= 1800;
        if (c.tag === 'TEXTAREA') sc += 120;
        if (c.ce) sc += 100;
        if (c.focused) sc += 40;
        c.score = sc;
        if (sc > topScore) { topScore = sc; top = c; }
      }
      if (!top) return null;
      return top;
    }
    /* ---- History-pane navigation + NOTE-editor opener (read-only nav) ----- */
    var BADNAV = /save|sign|order|delete|discard|remove|void|submit|bill|charge|check\s*-?\s*(in|out)|prescri|refill|dispense|cancel|log\s*out/i;
    function realClick(el, win) {
      try { el.scrollIntoView({ block: 'center' }); } catch (e1) {}
      try {
        var w2 = win || (el.ownerDocument && el.ownerDocument.defaultView) || W;
        var r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
        var o = { bubbles: true, cancelable: true, view: w2, clientX: x, clientY: y };
        ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach(function (tp) {
          try { el.dispatchEvent(new w2[tp.indexOf('pointer') === 0 ? 'PointerEvent' : 'MouseEvent'](tp, o)); } catch (e2) {}
        });
      } catch (e3) {}
      try { el.click(); } catch (e4) {}
    }
    function frameText() { var t = ''; try { t = String((W.document.body && W.document.body.innerText) || ''); } catch (e) {} return t; }
    var HIST_HEAD = /surgical\s*&?\s*procedure\s*history/i;
    /* v2.07: the clientsummary CARD carries the same heading TEXT as the real
       History drawer, so innerText alone is a lie (the v2.05/06 runs "saw" the
       pane without ever opening it). The real signal is an ON-SCREEN heading
       ELEMENT (x > -50; the collapsed drawer's copies measure x ~ -420). Also:
       the rail click can open athena's top-nav Calendar menu instead (proven
       collision) - detect + Escape it before every step. */
    async function dismissNavMenu() {
      try {
        var els = W.document.querySelectorAll('a,li,span,div');
        for (var i = 0; i < els.length; i++) {
          var own = String(els[i].textContent || '').replace(/\s+/g, ' ').trim();
          if (own === 'View Calendar' || own === 'Staff Directory') {
            var r = els[i].getBoundingClientRect();
            if (r.width > 2 && r.x >= 0) {
              try { W.document.dispatchEvent(new W.KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true })); } catch (e1) {}
              try { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true })); } catch (e2) {}
              await sleep(350);
              return true;
            }
          }
        }
      } catch (e) {}
      return false;
    }
    function onScreenHeading(headingRe) {
      var els; try { els = W.document.querySelectorAll('div,section,li,h1,h2,h3,h4,span'); } catch (e) { return null; }
      for (var i = 0; i < els.length; i++) {
        var own = String(els[i].textContent || '').replace(/\s+/g, ' ').trim();
        if (own && own.length < 60 && headingRe.test(own)) {
          try { var r = els[i].getBoundingClientRect(); if (r.width > 10 && r.x > -50) return els[i]; } catch (e2) {}
        }
      }
      return null;
    }
    var histDiag = { clicks: 0, frames: [] };
    function drawerEl() {
      /* v2.09 STRUCTURAL drawer detection (live-proven on the real chart): the
         History drawer is div[data-chart-section-id="history"], and its
         x-position IS the toggle state - x ~ 54 open, x ~ -420 collapsed.
         Heading-TEXT checks lie twice over (the read-only briefing card and the
         clientsummary card both render the heading + saved note text), and the
         rail LI is a TOGGLE, so a text-based "is it open" check made earlier
         builds flap the drawer open/closed. */
      var dv; try { dv = W.document.querySelectorAll('div[data-chart-section-id="history"]'); } catch (e) { dv = []; }
      for (var i = 0; i < dv.length; i++) {
        try { var r = dv[i].getBoundingClientRect(); if (r.width > 200 && r.x > -50) return dv[i]; } catch (e2) {}
      }
      return null;
    }
    function paneLive() { return !!drawerEl(); }
    async function openHistoryPane() {
      await dismissNavMenu();
      if (paneLive()) return true;
      var deadline = Date.now() + 16000;
      while (Date.now() < deadline) {
        var clicked = false;
        /* v2.09: the chart rail may live in a DIFFERENT frame than the one the
           size heuristic picked (live: a briefing frame won the pick while the
           chart frame owned the rail). Search every candidate frame and ADOPT
           the frame that has the clickable rail item. */
        for (var wi2 = 0; wi2 < scanWs.length && !clicked; wi2++) {
          try {
            var lis = scanWs[wi2].document.querySelectorAll('li.chart-tabs__list-item[data-chart-section-id="history"],[data-chart-section-id="history"]');
            for (var qi = 0; qi < lis.length; qi++) {
              var li = lis[qi];
              try { var rr = li.getBoundingClientRect(); if (rr.width < 2) continue; } catch (eR) { continue; }
              var lbl = String((li.getAttribute && (li.getAttribute('aria-label') || li.getAttribute('data-icon-caption'))) || li.textContent || '').replace(/\s+/g, ' ').trim();
              if (BADNAV.test(lbl)) continue;
              W = scanWs[wi2];
              histDiag.clicks++;
              try { histDiag.frames.push(String(W.location.pathname || '').slice(-18)); } catch (eHd) {}
              realClick(li, W); clicked = true; break;
            }
          } catch (eA) {}
        }
        if (clicked) {
          var pd = Date.now() + 6000;
          while (Date.now() < pd) {
            await sleep(500);
            await dismissNavMenu(); /* the click may have opened the Calendar menu instead */
            if (paneLive()) { await sleep(900); return true; } /* v2.09: let the slide-in settle + handlers attach */
          }
        }
        await sleep(700);
      }
      return paneLive();
    }
    async function openNoteEditor(headingRe) {
      /* v2.09: everything is SCOPED TO THE OPEN DRAWER CONTAINER (live-proven
         layout): the drawer stacks sections (Family / Social / Surgical &
         Procedure / Implant / Past Medical), each with its own heading. When a
         section is EMPTY its affordance is a small NOTE chip (~37px SPAN);
         when a note EXISTS the chip is replaced by the saved-note ROW - the
         clinician edits by clicking the note text itself. The "Add procedure"
         search box lives OUTSIDE the drawer and must never be picked. */
      await dismissNavMenu();
      var dr = drawerEl();
      if (!dr) return { ok: false, error: 'history-drawer-not-open' };
      function headingEl() {
        var els; try { els = dr.querySelectorAll('div,section,li,h1,h2,h3,h4,span'); } catch (e) { return null; }
        for (var i = 0; i < els.length; i++) {
          var own = String(els[i].textContent || '').replace(/\s+/g, ' ').trim();
          if (own && own.length < 60 && headingRe.test(own)) {
            try { var r = els[i].getBoundingClientRect(); if (r.width > 10) return els[i]; } catch (e2) {}
          }
        }
        return null;
      }
      function inDrawer(el) {
        /* shadow-aware containment: contains() is false across shadow
           boundaries, so climb parentElement -> shadow host instead */
        var n = el, h = 0;
        while (n && h < 40) { if (n === dr) return true; n = n.parentElement || (n.getRootNode && n.getRootNode().host) || null; h++; }
        return false;
      }
      function drawerEditors() {
        /* SHADOW-PIERCING collector scoped to the drawer - the note editor is
           a shadow-DOM contenteditable (live-proven: the successful write's
           method was ce-insert), invisible to plain querySelectorAll. */
        var out = [];
        function walkR(root, budget) {
          var els; try { els = root.querySelectorAll('*'); } catch (e) { return budget; }
          for (var i = 0; i < els.length; i++) {
            if (--budget < 0) return budget;
            var el2 = els[i];
            try { if (el2.shadowRoot) budget = walkR(el2.shadowRoot, budget); } catch (eS) {}
            var tag = (el2.tagName || '').toUpperCase();
            var okKind = tag === 'TEXTAREA' ||
              (tag === 'INPUT' && /^(text|search|)$/.test(String(el2.getAttribute('type') || '').toLowerCase())) ||
              (el2.isContentEditable === true);
            if (okKind && visEl(el2, W)) out.push(el2);
          }
          return budget;
        }
        walkR(dr, 12000);
        return out;
      }
      function nearestBelow(list, refY) {
        /* a section's editor sits BELOW its heading; anything above belongs to
           the previous section. 0..420px window inside the drawer. */
        var top = null, d0 = 1e9;
        for (var i = 0; i < list.length; i++) {
          try { var y = list[i].getBoundingClientRect().y; var d = y - refY; if (d >= -10 && d < d0) { d0 = d; top = list[i]; } } catch (e) {}
        }
        return (d0 <= 420) ? top : null;
      }
      var head = headingEl();
      if (!head) return { ok: false, error: 'section-heading-not-in-drawer' };
      try { head.scrollIntoView({ block: 'center' }); } catch (eSc) {}
      await sleep(250);
      var headY = 0; try { headY = head.getBoundingClientRect().y; } catch (e) {}
      var preAll = drawerEditors();
      var near0 = nearestBelow(preAll, headY);
      if (near0) return { ok: true, el: near0, head: head }; /* this section's editor already open */
      /* affordance ladder, all inside the drawer and below THIS heading:
         (1) the small NOTE chip (empty section);
         (2) the saved-note row (filled section) - a modest text block that is
             not chrome ("None recorded" / "Add ..." / "Last modified ...").
         BADNAV filters both; nothing here can be a Save/Sign/order control. */
      function findAffordance() {
        /* STRUCTURAL FIRST (live-inspected): athena's note UI is the
           "universal-text-area" (UTA) component - the note affordance is
           .uta-note-label-add-note.clickable (empty section) and the saved
           note's span.uta-note-label-note-text (filled section; clicking it
           bubbles to the clickable label and opens the editor - manually
           proven). Class names are the component's own stable API; the text
           heuristics below stay as a generic-EMR fallback. */
        try {
          var uta = dr.querySelectorAll('span.uta-note-label-note-text, .uta-note-label-add-note.clickable, .uta-note-label .clickable');
          var bestU = null, bDU = 1e9;
          for (var ui = 0; ui < uta.length; ui++) {
            var ru; try { ru = uta[ui].getBoundingClientRect(); } catch (eU) { continue; }
            if (ru.width < 2) continue;
            var ddu = ru.y - headY;
            if (ddu < 4 || ddu > 420) continue;
            if (ddu < bDU) { bDU = ddu; bestU = uta[ui]; }
          }
          if (bestU) return bestU;
        } catch (eUta) {}
        var toggles; try { toggles = dr.querySelectorAll('a,button,span,div,label'); } catch (e) { toggles = []; }
        var tg = null, tgD = 1e9, tgA = 1e12, kind = '';
        for (var ti = 0; ti < toggles.length; ti++) {
          var tt = String(toggles[ti].textContent || '').replace(/\s+/g, ' ').trim();
          if (!tt || BADNAV.test(tt)) continue;
          var ty; try { ty = toggles[ti].getBoundingClientRect(); } catch (e) { continue; }
          if (ty.width < 2) continue;
          var dd = ty.y - headY;
          if (dd < 4 || dd > 420) continue;
          if (/^NOTE$/i.test(tt) && ty.width <= 120) {
            if (kind !== 'chip' || dd < tgD) { tg = toggles[ti]; tgD = dd; kind = 'chip'; }
            continue;
          }
          if (kind === 'chip') continue; /* the chip always wins when present */
          if (tt.length >= 12 && ty.width >= 120 && ty.width <= 460 && ty.height <= 130 &&
              !/^(none recorded|add\b|show|hide|last modified|first-degree|patient does not)/i.test(tt)) {
            /* overlapping row candidates: the OUTER wrapper DIVs have no click
               handler (live-proven: clicking a 385px wrapper did nothing, the
               inner 350px SPAN opened the editor). Prefer the SMALLEST-AREA
               match; <= keeps the deepest on ties (document order = outer first). */
            var aa = ty.width * ty.height;
            if (kind !== 'row' || aa <= tgA) { tg = toggles[ti]; tgD = dd; tgA = aa; kind = 'row'; }
          }
        }
        return tg;
      }
      /* v2.09: up to 3 click attempts - a click during the drawer's slide-in /
         before handlers attach is silently ignored (live: same click worked on
         a settled drawer and did nothing right after opening). */
      var sawAffordance = false;
      for (var att = 0; att < 3; att++) {
        var tg2 = findAffordance();
        if (!tg2) { if (att === 0) break; await sleep(900); continue; }
        sawAffordance = true;
        var pre = drawerEditors();
        realClick(tg2, W);
        var dl = Date.now() + 4200;
        while (Date.now() < dl) {
          await sleep(400);
          var post = drawerEditors();
          var fresh = [];
          for (var pi = 0; pi < post.length; pi++) { if (pre.indexOf(post[pi]) < 0) fresh.push(post[pi]); }
          var pick = nearestBelow(fresh.length ? fresh : post, headY);
          if (pick) return { ok: true, el: pick, head: head };
          var da = deepActive(W.document);
          if (da && (da.tagName === 'TEXTAREA' || da.isContentEditable) && visEl(da, W) && inDrawer(da)) return { ok: true, el: da, head: head };
        }
        try { headY = head.getBoundingClientRect().y; } catch (eH2) {}
      }
      return { ok: false, error: sawAffordance ? 'editor-did-not-appear' : 'note-affordance-not-found' };
    }
    /* ---- field writer (notes only; never invoked for order-class) --------- */
    async function writeField(el, txt, head, mergePolicy, replaceConfirmed) {
      var CE = !!el.isContentEditable;
      function rd() { return CE ? String(el.innerText || el.textContent || '') : String(el.value || ''); }
      function norm(s) { return nrmText(s); }
      function setNative(v) {
        if (CE) { try { el.textContent = v; } catch (e) {} return; }
        var pr = (el.tagName === 'TEXTAREA') ? W.HTMLTextAreaElement.prototype : W.HTMLInputElement.prototype;
        var d = null; try { d = Object.getOwnPropertyDescriptor(pr, 'value'); } catch (e) {}
        if (d && d.set) d.set.call(el, v); else el.value = v;
      }
      function fire(type, data) { try { el.dispatchEvent(new W.InputEvent('input', { bubbles: true, inputType: type || 'insertText', data: data })); } catch (e) { try { el.dispatchEvent(new W.Event('input', { bubbles: true })); } catch (e2) {} } }
      txt = String(txt == null ? '' : txt);
      if (!norm(txt)) return { written: false, verified: false, draftEntered: false, draftVerified: false, persisted: false, serverVerified: false, error: 'empty-write-disabled', method: 'none', into: rd().length };
      var before = rd();
      mergePolicy = String(mergePolicy || 'append').toLowerCase();
      if (mergePolicy !== 'append' && mergePolicy !== 'replace') mergePolicy = 'append';
      if (mergePolicy === 'replace' && norm(before) && replaceConfirmed !== true) return { written: false, verified: false, draftEntered: false, draftVerified: false, persisted: false, serverVerified: false, error: 'replace-needs-explicit-confirmation', method: 'none', into: before.length };
      if (norm(before).indexOf(norm(txt)) >= 0) return { written: false, verified: true, draftEntered: false, draftVerified: true, alreadyPresent: true, persisted: false, serverVerified: false, method: 'already-present', into: before.length };
      var next = (mergePolicy === 'replace' || !norm(before)) ? txt : (before.replace(/\s+$/, '') + '\n\n' + txt);
      try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
      realClick(el, W);
      try { el.focus(); } catch (e) {}
      await sleep(50);
      if (CE) {
        try { var rg = W.document.createRange(); rg.selectNodeContents(el); var se = W.getSelection(); se.removeAllRanges(); se.addRange(rg); } catch (e) {}
        var okc = false;
        try { okc = W.document.execCommand('insertText', false, next); } catch (e) { okc = false; }
        if (!okc) setNative(next);
      } else {
        try { if (el.setSelectionRange) el.setSelectionRange(0, (el.value || '').length); } catch (e) {}
        setNative(next);
      }
      fire('insertText', next);
      try { el.dispatchEvent(new W.Event('change', { bubbles: true })); } catch (e) {}
      await sleep(120);
      var cur = rd();
      var probe = norm(txt).slice(0, Math.min(norm(txt).length, 40));
      var landed = !!probe && norm(cur).indexOf(probe) >= 0;
      /* A same-editor readback proves only that the draft entered the client
         DOM. It is NOT evidence of an Athena server save. The field stays open
         for clinician review; only a future independent commit + cold readback
         may set serverVerified/persisted. */
      return { written: landed, verified: landed, draftEntered: landed, draftVerified: landed, commitObserved: false, persisted: false, serverVerified: false, into: cur.length, method: CE ? 'ce-insert' : 'native', mergePolicy: mergePolicy };
    }
    /* ---- run the sections -------------------------------------------------- */
    var results = [], forcedHeld = [];
    for (var s = 0; s < sections.length; s++) {
      var sec = sections[s] || {};
      var requestedKey = String(sec.key || '');
      var key = canonicalRouteKey(requestedKey);
      var policy = key && ROUTE_POLICY[key];
      var requestedExecute = !!sec.execute;
      var wantExecute = !!(requestedExecute && policy && policy.draft === true);
      if (requestedExecute && (!policy || policy.draft !== true)) forcedHeld.push(requestedKey || '(missing)');
      var entry = { key: key || requestedKey || '(missing)', requestedKey: requestedKey, routeKind: (policy && policy.kind) || '', execute: wantExecute, found: false, written: false, verified: false, draftEntered: false, draftVerified: false, persisted: false, serverVerified: false, fieldLabel: '', fieldHeading: '', fieldTag: '', method: '', error: '' };
      if (!key || !policy || !DEFS[key]) {
        entry.error = 'unknown-section-key';
        entry.blocked = true;
        results.push(entry);
        continue;
      }
      try {
        if (sec.verify) {
          /* v2.09 READ-ONLY VERIFY: open the section's note editor and report
             its CURRENT text without writing anything - the honest "verify it
             landed" leg of write->verify->delete. Never modifies content. */
          entry.execute = false; entry.verifyRead = true;
          var elv = null, hVer = null;
          if (key === 'past_surgical_history') {
            var okPv = await openHistoryPane();
            if (okPv) {
              hVer = onScreenHeading(HIST_HEAD);
              var opv = await openNoteEditor(HIST_HEAD);
              if (opv.ok) { elv = opv.el; hVer = opv.head || hVer; } else entry.error = opv.error;
            } else entry.error = 'history-pane-not-reachable';
          } else entry.error = 'verify-supported-for-past-surgical-history-only';
          /* read-only diagnostics: what the driver actually sees around the
             heading (frame tail, rendered section text, chip/editor census) -
             lets a caller distinguish "summary card" from the real drawer. */
          try {
            entry.histDiag = histDiag;
            entry.paneTail = String(W.location.pathname || '').slice(-30);
            /* per-frame rail census: which frames exist and which own the rail */
            entry.railScan = [];
            for (var rf = 0; rf < allFr.length && entry.railScan.length < 14; rf++) {
              try {
                var rTail = String(allFr[rf].location.pathname || '').slice(-24);
                var rl = allFr[rf].document.querySelectorAll('[data-chart-section-id="history"]');
                var vis = 0;
                for (var rv2 = 0; rv2 < rl.length; rv2++) { try { if (rl[rv2].getBoundingClientRect().width >= 2) vis++; } catch (eV2) {} }
                entry.railScan.push(rTail + ':' + rl.length + '/' + vis);
              } catch (eRf) { entry.railScan.push('x'); }
            }
            try {
              var rl0 = window.document.querySelectorAll('[data-chart-section-id="history"]');
              entry.railTop = rl0.length;
            } catch (eT) {}
            if (hVer) {
              var hpv = hVer.parentElement || hVer;
              entry.sectionText = String(hpv.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 260);
              var hy = 0; try { hy = hVer.getBoundingClientRect().y; } catch (eY) {}
              var cens = { chips: 0, chipW: [], editors: 0 };
              var tgv; try { tgv = W.document.querySelectorAll('a,button,span,div,label'); } catch (eQ) { tgv = []; }
              for (var tv = 0; tv < tgv.length; tv++) {
                var ttv = String(tgv[tv].textContent || '').replace(/\s+/g, ' ').trim();
                if (!/^NOTE$/i.test(ttv)) continue;
                try { var rv = tgv[tv].getBoundingClientRect(); if (rv.width >= 2) { var dv = rv.y - hy; if (dv >= -10 && dv <= 320) { cens.chips++; if (cens.chipW.length < 6) cens.chipW.push(Math.round(rv.width)); } } } catch (eB) {}
              }
              var edv; try { edv = W.document.querySelectorAll('textarea,[contenteditable],input[type="text"],input:not([type])'); } catch (eE) { edv = []; }
              for (var ev2 = 0; ev2 < edv.length; ev2++) {
                if (!visEl(edv[ev2], W)) continue;
                try { var ry2 = edv[ev2].getBoundingClientRect().y - hy; if (ry2 >= -10 && ry2 <= 320) cens.editors++; } catch (eC2) {}
              }
              entry.census = cens;
              /* Read-only, bounded control census near Surgical & Procedure
                 History. Used to distinguish the note editor from Athena's
                 saved-note controls without clicking anything. */
              try {
                entry.controlScan = [];
                var cv = W.document.querySelectorAll('button,a,[role="button"],input[type="button"],input[type="submit"]');
                for (var ci = 0; ci < cv.length && entry.controlScan.length < 24; ci++) {
                  if (!visEl(cv[ci], W)) continue;
                  var cr = cv[ci].getBoundingClientRect(), dy = cr.y - hy;
                  if (dy < -30 || dy > 520) continue;
                  entry.controlScan.push({
                    tag: String(cv[ci].tagName || '').toLowerCase(),
                    text: String(cv[ci].textContent || '').replace(/\s+/g, ' ').trim().slice(0, 90),
                    aria: String(cv[ci].getAttribute && cv[ci].getAttribute('aria-label') || '').slice(0, 90),
                    title: String(cv[ci].getAttribute && cv[ci].getAttribute('title') || '').slice(0, 90),
                    cls: String(cv[ci].className || '').replace(/\s+/g, ' ').trim().slice(0, 120),
                    dy: Math.round(dy)
                  });
                }
              } catch (eCtl) {}
              try {
                entry.sectionControlScan = [];
                var sv = hpv.querySelectorAll('button,a,[role="button"],[onclick],[aria-label],[title],[data-testid]');
                for (var si2 = 0; si2 < sv.length && entry.sectionControlScan.length < 32; si2++) {
                  entry.sectionControlScan.push({
                    tag: String(sv[si2].tagName || '').toLowerCase(),
                    text: String(sv[si2].textContent || '').replace(/\s+/g, ' ').trim().slice(0, 90),
                    aria: String(sv[si2].getAttribute && sv[si2].getAttribute('aria-label') || '').slice(0, 90),
                    title: String(sv[si2].getAttribute && sv[si2].getAttribute('title') || '').slice(0, 90),
                    testid: String(sv[si2].getAttribute && sv[si2].getAttribute('data-testid') || '').slice(0, 90),
                    cls: String(sv[si2].className || '').replace(/\s+/g, ' ').trim().slice(0, 120),
                    visible: !!visEl(sv[si2], W)
                  });
                }
              } catch (eSectCtl) {}
            }
          } catch (eDg) {}
          if (elv) {
            entry.found = true;
            var txtv = elv.isContentEditable ? String(elv.innerText || elv.textContent || '') : String(elv.value || '');
            entry.textCodes = txtv.slice(0, 8).split('').map(function (ch) { return ch.charCodeAt(0); });
            var semv = txtv.replace(/[\u200B-\u200D\u2060\uFEFF]/g, '');
            entry.textHead = semv.replace(/\s+/g, ' ').trim().slice(0, 220);
            entry.textLen = semv.replace(/\s+/g, ' ').trim().length;
            /* leave the untouched editor the way a human closes it: blur only */
            try { elv.blur(); } catch (eBv) {}
            if (hVer) { try { realClick(hVer, W); } catch (eCv) {} }
          }
          results.push(entry);
          continue;
        }
        if (!wantExecute) {
          var t = bestFieldFor(key);
          if (t) { entry.found = true; entry.fieldTag = t.tag + (t.ce ? '/contenteditable' : ''); entry.fieldLabel = t.label; entry.fieldHeading = t.hay.slice(0, 90); }
          else entry.error = 'no-matching-field-on-screen';
        } else {
          var el = null, opHead = null;
          if (key === 'past_surgical_history') {
            var okPane = await openHistoryPane();
            if (okPane) {
              var op = await openNoteEditor(HIST_HEAD);
              if (op.ok) { el = op.el; opHead = op.head || null; } else entry.error = op.error;
            } else entry.error = 'history-pane-not-reachable';
          }
          if (!el) {
            var b2 = bestFieldFor(key);
            if (b2 && DEFS[key].test(b2.hay)) el = b2.el;
          }
          if (!el) { if (!entry.error) entry.error = 'no-matching-field-on-screen'; }
          else if (!targetChartMatches(el)) {
            /* the field we located is NOT on this patient's open chart - refuse
               rather than write to the wrong place (e.g. a dashboard note box). */
            entry.found = true; entry.written = false; entry.verified = false;
            entry.error = 'target-not-on-open-chart';
          }
          else {
            entry.found = true;
            var wr = await writeField(el, String(sec.text == null ? '' : sec.text), opHead, sec.mergePolicy, sec.replaceConfirmed === true);
            entry.written = wr.written; entry.verified = wr.verified; entry.method = wr.method;
            entry.draftEntered = !!wr.draftEntered;
            entry.draftVerified = !!wr.draftVerified;
            entry.commitObserved = !!wr.commitObserved;
            entry.serverVerified = !!wr.serverVerified;
            entry.persisted = !!wr.persisted;
            entry.into = wr.into;
            if (wr.alreadyPresent) entry.alreadyPresent = true;
            if (wr.mergePolicy) entry.mergePolicy = wr.mergePolicy;
            if (wr.error) entry.error = wr.error;
            if (wr.afterCodes) entry.afterCodes = wr.afterCodes;
          }
        }
      } catch (eSec) { entry.error = String((eSec && eSec.message) || eSec).slice(0, 140); }
      results.push(entry);
    }
    return { ok: true, routeContractVersion: ROUTE_CONTRACT_VERSION, chartName: ident.name, chartDob: ident.dob || '', chartMrn: ident.mrn || '', forcedHeld: forcedHeld, results: results, ms: Date.now() - T0 };
  } catch (e) { return { ok: false, reason: 'driver-error', error: String((e && e.message) || e).slice(0, 200) }; }
}

/* v2.05 handler: single-flight, verified tab pick, freeze-guard, foreground-
 * for-write (hidden tabs neither hydrate nor commit edits reliably), 90s cap. */
(function () {
  'use strict';
  try { if (self.__mlsV205WriteWired) return; self.__mlsV205WriteWired = 1; } catch (e) {}
  var busy = 0;
  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || msg.type !== 'mlsAppWriteV2Request') return;
    (async function () {
      var V = '';
      try { V = chrome.runtime.getManifest().version; } catch (eV) {}
      /* The section-by-section writer predates the immutable manifest review.
         Keep this message name only so stale cached pages receive an explicit
         fail-closed result; never enter its legacy tab-pick or mutation code. */
      sendResponse({ ok: false, blocked: true, reason: 'unified-confirmation-required', version: V, error: 'The legacy direct writer is disabled. Refresh MLS and use the unified Athena review.' });
      return;
      var trustedSender = false;
      try { var senderUrl = new URL(sender && sender.tab && sender.tab.url || ''); trustedSender = senderUrl.protocol === 'https:' && /(^|\.)mlsscribe\.com$/i.test(senderUrl.hostname); } catch (eSender) {}
      if (!trustedSender || msg.userGesture !== true || !String(msg.gestureProof || '').trim()) { sendResponse({ ok: false, blocked: true, reason: 'fresh-trusted-click-required', version: V, error: 'Click Write selected drafts yourself, then try again.' }); return; }
      if (busy) { sendResponse({ ok: false, reason: 'busy', version: V, error: 'A write is already running - one at a time.' }); return; }
      busy = 1;
      var usedWriteTarget = false;
      try {
        var secs = Array.isArray(msg.sections) ? msg.sections : [];
        if (!String(msg.patient || '').trim() || !secs.length) { sendResponse({ ok: false, reason: 'bad-args', version: V, error: 'patient and sections are required.' }); return; }
        var KNOWN_WRITE_KEYS = { note:1, encounter_note:1, hpi:1, ros:1, exam:1, physical_exam:1, assessment:1, assessment_narrative:1, plan:1, followup:1, follow_up:1, procedure:1, procedure_note:1, past_surgical_history:1, diagnoses:1, diagnosis:1, dx:1, icd:1, diagnoses_icd10:1, rx:1, prescriptions:1, medications_rx:1, orders:1, order:1, orders_preview:1, lab_order:1, imaging:1, imaging_order:1, referrals:1, referral:1, referral_order:1, pt:1, pt_order:1, billing:1, charges:1, billing_preview:1, billing_em:1, billing_cpt:1 };
        var EXECUTABLE_NARRATIVE = { note:1, encounter_note:1, hpi:1, ros:1, exam:1, physical_exam:1, assessment:1, assessment_narrative:1, plan:1, followup:1, follow_up:1 };
        var unknown = [];
        var hasNarrativeExecute = false;
        for (var vsi = 0; vsi < secs.length; vsi++) {
          var vk = String((secs[vsi] && secs[vsi].key) || '').toLowerCase().replace(/[\s-]+/g, '_').trim();
          if (!KNOWN_WRITE_KEYS[vk]) unknown.push(vk || '(missing)');
          if (secs[vsi] && secs[vsi].execute === true && EXECUTABLE_NARRATIVE[vk]) hasNarrativeExecute = true;
        }
        if (unknown.length) { sendResponse({ ok: false, reason: 'unknown-section-key', version: V, unknownKeys: unknown, error: 'Unknown Athena destination key(s): ' + unknown.join(', ') + '. Nothing was touched.' }); return; }
        var all = await chrome.tabs.query({});
        var candidates = all.filter(function (t) { try { return mlsAthTabHost(t) === 'athenanet.athenahealth.com' && !mlsAthIsLoginish(t); } catch (e) { return false; } });
        if (candidates.length > 1) { sendResponse({ ok: false, reason: 'ambiguous-athena-tabs', version: V, error: 'More than one signed-in Athena tab is open. Leave exactly one Athena tab open, then retry. Nothing was touched.' }); return; }
        var tab = null, wt = null;
        var senderTabId = sender && sender.tab && sender.tab.id;
        function nKey(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').replace(/\s+/g, ' ').trim(); }
        function dKey(s) { var m = /([01]?\d)[\/\-.]([0-3]?\d)[\/\-.](\d{2,4})/.exec(String(s || '')); if (!m) return ''; var y = m[3]; if (y.length === 2) y = (Number(y) > ((new Date().getFullYear() % 100) + 1) ? '19' : '20') + y; return Number(m[1]) + '/' + Number(m[2]) + '/' + y; }
        try { wt = self.__mlsWriteTarget || null; } catch (eWt) {}
        try {
          var wtFresh = wt && wt.tabId != null && (Date.now() - Number(wt.at || 0)) < 10 * 60 * 1000;
          var wtApp = wtFresh && (wt.appTabId == null || senderTabId == null || Number(wt.appTabId) === Number(senderTabId));
          var wtName = wtFresh && nKey(wt.name) === nKey(msg.patient);
          var wtDob = wtFresh && (!dKey(wt.dob) || !dKey(msg.dob) || dKey(wt.dob) === dKey(msg.dob));
          if (wtFresh && wtApp && wtName && wtDob) {
            var exact = await chrome.tabs.get(wt.tabId);
            if (exact && candidates.length === 1 && Number(candidates[0].id) === Number(exact.id) && mlsAthTabHost(exact) === 'athenanet.athenahealth.com' && !mlsAthIsLoginish(exact)) { tab = exact; usedWriteTarget = true; }
          }
        } catch (eExactWrite) { tab = null; }
        if (!tab) {
          tab = candidates.length === 1 ? candidates[0] : null;
        }
        if (!tab) { sendResponse({ ok: false, reason: 'no-athena-tab', version: V, error: 'Open your signed-in athenaOne in another tab, then try again.' }); return; }
        /* v2.9.5: writes keep the proven foreground-for-write path — leave quiet-pull
           mode first so the tab.active check below sees the restored layout. */
        if (hasNarrativeExecute) try { if (self.__mlsQp && self.__mlsQp.active) { await self.__mlsQpRelease('write'); tab = await chrome.tabs.get(tab.id); } } catch (eQ) {}
        if (hasNarrativeExecute) try {
          if (!tab.active) {
            await chrome.tabs.update(tab.id, { active: true });
            if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true });
            try { self.__mlsFgNote && self.__mlsFgNote(sender && sender.tab && sender.tab.id, tab.id, tab.windowId); } catch (eN) {}
          }
        } catch (eF) {}
        var fx = await mlsExecTO({ target: { tabId: tab.id }, world: 'MAIN', args: [String(msg.patient || ''), String(msg.dob || ''), String(msg.athenaId || ''), secs], func: mlsUnifiedWriteDriverFn }, 90000);
        if (fx.timeout) {
          sendResponse({ ok: false, reason: 'write-timeout', version: V, error: 'athenaOne did not finish within 90s. The tab was not reloaded or retried because the outcome may be uncertain; inspect it manually before trying again.' });
          return;
        }
        if (fx.err) { sendResponse({ ok: false, reason: 'inject-failed', version: V, error: 'Could not inject the write driver: ' + fx.err }); return; }
        var r = fx && fx.r && fx.r[0] && fx.r[0].result;
        if (!r) { sendResponse({ ok: false, reason: 'no-result', version: V, error: 'The write driver returned nothing (frame navigated mid-write?).' }); return; }
        try { __mlsReadsSinceReload++; } catch (eC) {}
        r.version = V;
        sendResponse(r);
      } catch (e) {
        sendResponse({ ok: false, reason: 'error', version: V, error: String((e && e.message) || e) });
      } finally { if (usedWriteTarget) { try { self.__mlsWriteTarget = null; } catch (eClear) {} } busy = 0; }
    })();
    return true;
  });
})();
/* ATHENA_ACTION_V2_HANDLER_START */ /* contract boundary: generic v2 writer ends above; supervised handler is isolated earlier in this file */

/* ===== MLS EXT HEALTH (device-role lane, 2026-07-16). Read-only snapshot
 * for the MLS Extension Health screen: version, granted permissions, armed
 * alarms (the service-worker suspension backstops), athenaOne tab presence
 * incl. DISCARDED tabs (Mac Memory-Saver silently unloads background tabs -
 * a discarded Athena tab cannot answer reads until reawakened), platform,
 * and worker boot time. Separate listener, own verb - touches no existing
 * router. Never reads chart content; operational metadata only. */
try { if (typeof self !== 'undefined' && !self.__mlsWorkerBootAt) self.__mlsWorkerBootAt = Date.now(); } catch (e) {}
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || msg.type !== 'mlsExtHealthRequest') return;
  (async function () {
    var out = { ok: true, at: Date.now() };
    try { var m = chrome.runtime.getManifest(); out.version = m.version; out.versionName = m.version_name || m.version; } catch (e) {}
    try { out.permissions = await chrome.permissions.getAll(); } catch (e) { out.permissions = null; }
    try {
      var alarms = await chrome.alarms.getAll();
      out.alarms = alarms.map(function (a) { return { name: a.name, periodInMinutes: a.periodInMinutes || null }; });
    } catch (e) { out.alarms = null; }
    try {
      var tabs = await chrome.tabs.query({ url: '*://*.athenahealth.com/*' });
      var discarded = 0;
      for (var i = 0; i < tabs.length; i++) { if (tabs[i].discarded || tabs[i].status === 'unloaded') discarded++; }
      out.athena = { tabs: tabs.length, discarded: discarded };
    } catch (e) { out.athena = null; }
    try { out.platform = await chrome.runtime.getPlatformInfo(); } catch (e) { out.platform = null; }
    try { out.workerBootAt = self.__mlsWorkerBootAt || null; } catch (e) { out.workerBootAt = null; }
    try { var errBag = await chrome.storage.local.get('mlsWorkerErrorLogV1'); out.workerErrors = (errBag && errBag.mlsWorkerErrorLogV1) || []; } catch (e) { out.workerErrors = null; } /* wet-1.1.0: crash log rides the health verb */
    try { sendResponse(out); } catch (e) {}
  })();
  return true;
});

/* ===== MLS ATHENA WINDOW/TAB GUARD (device-role lane; awg-2.0.0 2026-07-17).
 * Owner-confirmed: the quiet-pull machinery keeps Athena in a PRESET-size
 * strip window (hard 520-780px floor/cap computed from the host window, with
 * persisted bounds re-applied verbatim) - that fixed-size dependency is what
 * breaks on Macs and smaller/narrower screens. awg-2.0.0 removes the harm at
 * the API boundary: every window placement is ADAPTED to the display that is
 * actually there, instead of trusting preset geometry (or, as in awg-1.0.0,
 * merely dropping it when fully off-screen). All windows.update/windows.create
 * callers go through property lookup, so this late wrapper covers the QP
 * module without touching it.
 *   1. macOS FULLSCREEN (unchanged from awg-1.0.0): unfocused maintenance
 *      bounds/state changes aimed at a fullscreen window are dropped on mac
 *      only (focused:true passes - write-path foregrounding unchanged).
 *   2. ADAPTIVE BOUNDS (new): any bounds-bearing update/create is clamped to
 *      the best current display's work area - width/height capped at the work
 *      area, position clamped so the window is FULLY on that display. The
 *      target display is the one with the largest overlap with the requested
 *      rect; a fully off-screen rect (stale persisted strip after an undock /
 *      display change) is relocated to the window's current display, else the
 *      primary. No display info -> fail-open, bounds pass unchanged.
 *   3. DISCARD GUARD (unchanged): autoDiscardable=false asserted on athenanet
 *      tabs every 5 minutes (alarm) - Chrome Memory-Saver cannot silently
 *      unload the signed-in Athena tab (the browser-side forced-relogin path).
 *      Policy-compliant: never synthesizes activity; Athena's own idle
 *      timeout is untouched.
 * Read-only otherwise; reversible by removing this block. */
(function () {
  'use strict';
  if (self.__mlsAthWinGuard) return;
  var G = { version: 'awg-2.0.0', platform: '', dropsFullscreen: 0, adapts: 0, discardGuards: 0 };
  self.__mlsAthWinGuard = G;
  try { chrome.runtime.getPlatformInfo(function (pi) { try { G.platform = (pi && pi.os) || ''; } catch (e) {} }); } catch (e) {}

  function workAreaOf(d) { return d && (d.workArea || d.bounds) || null; }
  function overlapArea(L, T, W, H, wa) {
    var ix = Math.min(L + W, wa.left + wa.width) - Math.max(L, wa.left);
    var iy = Math.min(T + H, wa.top + wa.height) - Math.max(T, wa.top);
    return (ix > 0 && iy > 0) ? ix * iy : 0;
  }
  /* pick the display the requested rect mostly lives on; fall back to the
     window's current display, then the primary, then the first. */
  function pickDisplay(displays, L, T, W, H, win) {
    var best = null, bestA = 0, i, wa;
    for (i = 0; i < displays.length; i++) {
      wa = workAreaOf(displays[i]); if (!wa) continue;
      var a = overlapArea(L, T, W, H, wa);
      if (a > bestA) { bestA = a; best = displays[i]; }
    }
    if (!best && win) {
      var cx = (win.left | 0) + ((win.width | 0) / 2), cy = (win.top | 0) + ((win.height | 0) / 2);
      for (i = 0; i < displays.length; i++) {
        wa = workAreaOf(displays[i]); if (!wa) continue;
        if (cx >= wa.left && cx < wa.left + wa.width && cy >= wa.top && cy < wa.top + wa.height) { best = displays[i]; break; }
      }
    }
    if (!best) { for (i = 0; i < displays.length; i++) { if (displays[i] && displays[i].isPrimary) { best = displays[i]; break; } } }
    return best || displays[0] || null;
  }

  /* pure decision helper (unit-testable): returns the SAFE update object,
     null if the update should be skipped entirely. */
  G.decide = function (win, updates, displays, platform) {
    var u = updates || {};
    var hasBounds = ('left' in u) || ('top' in u) || ('width' in u) || ('height' in u);
    var forcesState = ('state' in u) && win && u.state !== win.state;
    /* rule 1: mac fullscreen - never move/resize/de-fullscreen for unfocused
       maintenance; an explicit focused:true (user-facing action) passes. */
    if (platform === 'mac' && win && win.state === 'fullscreen' && u.focused !== true && (hasBounds || forcesState)) {
      var rest = {};
      for (var k in u) { if (k !== 'left' && k !== 'top' && k !== 'width' && k !== 'height' && k !== 'state') rest[k] = u[k]; }
      return Object.keys(rest).length ? { updates: rest, reason: 'mac-fullscreen-bounds-dropped' } : { updates: null, reason: 'mac-fullscreen-skip' };
    }
    /* rule 2 (awg-2.0.0): adapt bounds to the display that is actually there. */
    if (hasBounds && displays && displays.length) {
      var L = ('left' in u) ? u.left : (win ? win.left : 0);
      var T = ('top' in u) ? u.top : (win ? win.top : 0);
      var W = ('width' in u) ? u.width : (win ? win.width : 800);
      var Hh = ('height' in u) ? u.height : (win ? win.height : 600);
      var disp = pickDisplay(displays, L, T, W, Hh, win);
      var wa = workAreaOf(disp);
      if (wa) {
        var W2 = Math.max(1, Math.min(W | 0, wa.width));
        var H2 = Math.max(1, Math.min(Hh | 0, wa.height));
        var L2 = Math.min(Math.max(L | 0, wa.left), wa.left + wa.width - W2);
        var T2 = Math.min(Math.max(T | 0, wa.top), wa.top + wa.height - H2);
        if (L2 !== L || T2 !== T || W2 !== W || H2 !== Hh) {
          var adapted = {};
          for (var k2 in u) adapted[k2] = u[k2];
          /* pin every bound that moved so the final rect is the adapted one */
          if (('left' in u) || L2 !== L) adapted.left = L2;
          if (('top' in u) || T2 !== T) adapted.top = T2;
          if (('width' in u) || W2 !== W) adapted.width = W2;
          if (('height' in u) || H2 !== Hh) adapted.height = H2;
          return { updates: adapted, reason: 'bounds-adapted' };
        }
      }
    }
    return { updates: u, reason: 'pass' };
  };

  var realUpdate = chrome.windows.update.bind(chrome.windows);
  chrome.windows.update = function (windowId, updates, cb) {
    var needCheck = updates && (('left' in updates) || ('top' in updates) || ('width' in updates) || ('height' in updates) || ('state' in updates));
    if (!needCheck) return cb ? realUpdate(windowId, updates, cb) : realUpdate(windowId, updates);
    var finish = function (result) { /* promise-or-callback, matching the real API */
      if (cb) { result.then(function (w) { cb(w); }, function () { cb(undefined); }); return undefined; }
      return result;
    };
    return finish((async function () {
      var win = null, displays = null;
      try { win = await chrome.windows.get(windowId); } catch (e) {}
      try { if (chrome.system && chrome.system.display && chrome.system.display.getInfo) displays = await chrome.system.display.getInfo(); } catch (e) {}
      var d = G.decide(win, updates, displays, G.platform);
      if (d.reason === 'mac-fullscreen-skip' || d.reason === 'mac-fullscreen-bounds-dropped') G.dropsFullscreen++;
      if (d.reason === 'bounds-adapted') G.adapts++;
      if (!d.updates) return win || undefined; /* skipped entirely: report current state */
      return realUpdate(windowId, d.updates);
    })());
  };

  /* awg-2.0.0: the strip's INITIAL window is born preset-sized through
     windows.create - clamp it the same way (url/tabId/focused/type keys are
     preserved untouched; only geometry adapts). */
  var realCreate = chrome.windows.create.bind(chrome.windows);
  chrome.windows.create = function (createData, cb) {
    var cd = createData || {};
    var hasBounds = ('left' in cd) || ('top' in cd) || ('width' in cd) || ('height' in cd);
    if (!hasBounds) return cb ? realCreate(createData, cb) : realCreate(createData);
    var finish = function (result) {
      if (cb) { result.then(function (w) { cb(w); }, function () { cb(undefined); }); return undefined; }
      return result;
    };
    return finish((async function () {
      var displays = null;
      try { if (chrome.system && chrome.system.display && chrome.system.display.getInfo) displays = await chrome.system.display.getInfo(); } catch (e) {}
      var d = G.decide(null, cd, displays, G.platform);
      if (d.reason === 'bounds-adapted') G.adapts++;
      return realCreate(d.updates || cd);
    })());
  };

  /* rule 3: keep Chrome from discarding signed-in athenanet tabs. */
  async function guardAthenaTabs() {
    try {
      var tabs = await chrome.tabs.query({ url: '*://*.athenahealth.com/*' });
      for (var i = 0; i < tabs.length; i++) {
        var t = tabs[i];
        if (t.autoDiscardable !== false) {
          try { await chrome.tabs.update(t.id, { autoDiscardable: false }); G.discardGuards++; } catch (e) {}
        }
      }
    } catch (e) {}
  }
  G.guardAthenaTabs = guardAthenaTabs;
  try { chrome.alarms.create('mlsAthGuard', { periodInMinutes: 5 }); } catch (e) {}
  try {
    chrome.alarms.onAlarm.addListener(function (a) { if (a && a.name === 'mlsAthGuard') guardAthenaTabs(); });
  } catch (e) {}
  try { setTimeout(guardAthenaTabs, 3000); } catch (e) {}
})();
